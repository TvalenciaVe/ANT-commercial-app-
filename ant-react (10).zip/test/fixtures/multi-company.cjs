/* =========================================================================
   TEST-ONLY multi-company fixture. Never part of the visible demo.

   addCompanyB(payload)      adds "Test Mechanical" (company2): its own
                             warehouse, zone and bin, a Foreman, a Journeyman
                             and a Warehouse Manager, one project with a
                             jobsite, one request, and its own stock.
   addRoleTestUsers(payload) adds company1 people for creator and role
                             tests: a Project Manager, a Superintendent, an
                             Owner who is also Company Admin and Purchasing
                             Manager ("Tom"), and a Company Admin.
   Both take and return a saved schema v4 payload (JSON object).
   ========================================================================= */
const T = 1790214000000;
const user = (id, companyId, first, last, role, workerType, extra) => Object.assign({
  id, companyId, firstName: first, lastName: last, fullName: first + ' ' + last,
  email: id + '@test.example', phone: '(555) 700-' + String(1000 + id.length * 37).slice(-4), pin: '1111',
  primaryRole: role, companyRoles: [role], workerType, status: 'ACTIVE', avatarUrl: null, createdAt: T, updatedAt: T,
}, workerType === 'FIELD' ? { lastProjectId: null, mostUsed: [], recentlyUsed: [], brandPrefs: {} } : {}, extra || {});

function addCompanyB(p) {
  const base = p.companies[0];
  p.companies.push({
    id: 'company2', name: 'Test Mechanical', legalName: 'Test Mechanical LLC', companyType: 'MECHANICAL_CONTRACTOR',
    phone: '', email: '', address: '', logoUrl: null, timezone: 'America/New_York', status: 'ACTIVE',
    settings: Object.assign({}, base.settings, { defaultWarehouseId: 'loc-wh-company2-main' }),
    features: Object.assign({}, base.features), createdAt: T, updatedAt: T,
  });
  const loc = (id, name, type, parent, extra) => Object.assign({ id, companyId: 'company2', name, type, parentLocationId: parent,
    projectId: null, address: '', status: 'ACTIVE', metadata: {}, createdAt: T, updatedAt: T }, extra || {});
  p.locations.push(
    loc('loc-wh-company2-main', 'Main Warehouse', 'WAREHOUSE', null),
    loc('loc-wh-company2-main-zone-shelving', 'Shelving', 'WAREHOUSE_ZONE', 'loc-wh-company2-main', { metadata: { zoneKey: 'shelving' } }),
    loc('loc-wh-company2-main-bin-shelf-m-9', 'Shelf M-9', 'WAREHOUSE_BIN', 'loc-wh-company2-main-zone-shelving'),
    loc('loc-site-projB1', 'Harbor Plant Jobsite', 'JOBSITE', null, { projectId: 'projB1', address: '1 Harbor Way, Bayonne, NJ 07002' }),
  );
  p.users.push(
    user('fb1', 'company2', 'Nora', 'Quinn', 'FOREMAN', 'FIELD', { lastProjectId: 'projB1' }),
    user('jb1', 'company2', 'Omar', 'Reyes', 'JOURNEYMAN', 'FIELD', { lastProjectId: 'projB1' }),
    user('mb1', 'company2', 'Pia', 'Stone', 'WAREHOUSE_MANAGER', 'WAREHOUSE'),
  );
  p.projects.push({ id: 'projB1', companyId: 'company2', name: 'Harbor Plant', projectNumber: 'TM-1', address: '1 Harbor Way', city: 'Bayonne',
    state: 'NJ', zipCode: '07002', description: '', status: 'ACTIVE', startDate: null, expectedCompletionDate: null,
    assignedWarehouseId: 'loc-wh-company2-main', materialBudget: null, createdAt: T, createdBy: 'fb1', updatedAt: T });
  p.memberships.push(
    { id: 'mem-b1', companyId: 'company2', projectId: 'projB1', userId: 'fb1', projectRole: 'FOREMAN', permissionLevel: 'FULL_CONTROL', status: 'ACTIVE', assignedAt: T, assignedBy: 'fb1' },
    { id: 'mem-b2', companyId: 'company2', projectId: 'projB1', userId: 'jb1', projectRole: 'JOURNEYMAN', permissionLevel: 'CAN_EDIT', status: 'ACTIVE', assignedAt: T, assignedBy: 'fb1' },
  );
  const v = 'pf-thhn::#12|Black|Stranded';
  p.materialRequests.push({
    id: 'ORD-9001', companyId: 'company2', projectId: 'projB1', requestedByUserId: 'fb1', priority: 'HIGH', neededBy: T + 86400000, notes: 'Company B only',
    workflowStatus: 'PENDING', createdAt: T, submittedAt: T, updatedAt: T, packedAt: null, shippedAt: null, completedAt: null,
    fieldConfirmed: false, fieldConfirmedByUserId: null, fieldConfirmedByNameSnapshot: null, fieldConfirmedAt: null, deliveryIssues: null,
    items: [{ id: 'ORD-9001-L1', requestId: 'ORD-9001', productVariantId: v, quantity: 40, unit: 'FT',
      productNameSnapshot: '#12 Black Stranded THHN / THWN-2 Copper',
      variantSnapshot: { familyId: 'pf-thhn', familyName: 'THHN / THWN-2 Copper', attributes: { gauge: '#12', color: 'Black', conductor: 'Stranded' }, unit: 'FT', displayName: '#12 Black Stranded THHN / THWN-2 Copper' },
      brandSnapshot: { selection: 'ANY', manufacturerId: null, manufacturerName: 'Any Brand', manufacturerPartNumber: null },
      legacyProductId: null, collected: false, pickedQuantity: 0, packedQuantity: 0, shortQuantity: 0, shortage: null, legacyProgress: null }],
  });
  // v4 stock: an inventory item, one opening balance in the ledger, and its balance
  const seq = (p.sequences.movement || 0) + 1; p.sequences.movement = seq;
  const bin = 'loc-wh-company2-main-bin-shelf-m-9';
  p.companies[p.companies.length - 1].inventoryLedgerStartedAt = T;
  p.inventoryItems.push({ id: 'inv:company2:' + v, companyId: 'company2', productVariantId: v, primaryLocationId: bin, minimumStock: null, reorderPoint: 150, targetStock: null, active: true, createdAt: T, updatedAt: T });
  p.materialMovements.push({ id: 'mov_' + String(seq).padStart(6, '0'), companyId: 'company2', productVariantId: v, movementType: 'OPENING_BALANCE', quantity: 500, unit: 'FT',
    fromLocationId: null, toLocationId: bin, fromInventoryState: null, toInventoryState: 'AVAILABLE', projectId: null, requestId: null, requestItemId: null,
    fulfillmentId: null, shipmentId: null, returnId: null, purchaseOrderId: null, reasonCode: 'LEDGER_OPENING_BALANCE', notes: '', performedByUserId: null, actorType: 'SYSTEM',
    timestamp: T, reversalOfMovementId: null, operationKey: null, metadata: { source: 'test fixture' } });
  p.inventoryBalances.push({ id: 'bal:company2:' + bin + ':AVAILABLE:' + v, companyId: 'company2', productVariantId: v, locationId: bin, inventoryState: 'AVAILABLE', quantity: 500, unit: 'FT', updatedAt: T });
  return p;
}

function addRoleTestUsers(p) {
  p.users.push(
    user('pm1', 'company1', 'Priya', 'Manning', 'PROJECT_MANAGER', 'MANAGEMENT'),
    user('su1', 'company1', 'Sam', 'Ulrich', 'SUPERINTENDENT', 'MANAGEMENT'),
    user('ow1', 'company1', 'Tom', 'Owens', 'OWNER', 'MANAGEMENT', { companyRoles: ['OWNER', 'COMPANY_ADMIN', 'PURCHASING_MANAGER'] }),
    user('ad1', 'company1', 'Ada', 'Mins', 'COMPANY_ADMIN', 'ADMIN'),
  );
  return p;
}

// Test-only approvers for the Phase 3 correction pass: a Purchasing Manager in
// each company. Company role only: no project membership (it is not a project role).
function addApproverTestUsers(p) {
  p.users.push(
    user('pu1', 'company1', 'Paula', 'Ueda', 'PURCHASING_MANAGER', 'PURCHASING'),
    user('pb1', 'company2', 'Pete', 'Brandt', 'PURCHASING_MANAGER', 'PURCHASING'),
  );
  return p;
}

module.exports = { addCompanyB, addRoleTestUsers, addApproverTestUsers };
