/* =========================================================================
   TEST N — responsive layout in a REAL browser (Chromium via Playwright).

   Drives the key field and warehouse screens at 375 / 390 / 430 (phones),
   768 (tablet) and 1280 (desktop), plus a stress pass in Spanish with Large
   Text at 375. For every screen it checks that nothing makes the page scroll
   sideways (horizontal rails are allowed: they are their own scrollers) and
   saves a screenshot for review.

   Run:   npm run test:visual
   First time on a machine:  npx playwright-core install chromium
   Options (env): ANT_ROOT=<project dir>  ANT_VISUAL_OUT=<screenshot dir>
   Time is frozen so "3 hours ago", greetings and dates are repeatable.
   ========================================================================= */
const path = require('path');
const fs = require('fs');
const http = require('http');
const { buildSync } = require('esbuild');

const ROOT = process.env.ANT_ROOT || path.join(__dirname, '..');
const OUT = process.env.ANT_VISUAL_OUT || path.join(__dirname, '.visual');
const WIDTHS = [375, 390, 430, 768, 1280];
const FROZEN = 1790214454697;   // the moment the demo seed data was written

function buildPage() {
  const dir = path.join(OUT, '_site');
  fs.rmSync(dir, { recursive: true, force: true });
  fs.mkdirSync(dir, { recursive: true });
  buildSync({ entryPoints: [path.join(ROOT, 'test', 'entry.jsx')], bundle: true, format: 'iife', outdir: dir, entryNames: 'app',
    jsx: 'automatic', define: { 'process.env.NODE_ENV': '"production"' }, logLevel: 'error' });
  fs.writeFileSync(path.join(dir, 'index.html'), '<!doctype html><html lang="en"><head><meta charset="UTF-8">' +
    '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">' +
    '<link rel="stylesheet" href="app.css"></head><body><div id="root"></div><script src="app.js"></script></body></html>');
  return dir;
}
function serve(dir) {
  const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
  const server = http.createServer((req, res) => {
    const f = path.join(dir, req.url === '/' ? 'index.html' : req.url.split('?')[0]);
    if (!f.startsWith(dir) || !fs.existsSync(f)) { res.writeHead(404); return res.end(); }
    res.writeHead(200, { 'Content-Type': types[path.extname(f)] || 'application/octet-stream' });
    fs.createReadStream(f).pipe(res);
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server)));
}

// Each step only uses actions that exist in every ANT version, so the same
// script can also drive an older build for before/after comparison.
// Steps run inside the page, so values are written into the function text.
const signIn = (role, id, pin) => new Function('{ A, ui }',
  'if (ui.currentUser) A.logout(); A.chooseRole(' + JSON.stringify(role) + '); A.pickProfile(' + JSON.stringify(role) + ', ' + JSON.stringify(id) + '); ' +
  JSON.stringify(pin) + ".split('').forEach((d) => A.pinDigit(d));");
const STEPS = [
  ['01-role-select', () => {}],
  ['02-field-home', signIn('foreman', 'f1', '4827')],
  ['03-search-results', ({ A }) => A.search('3/4 emt')],
  ['04-configure-sheet', ({ A }) => A.openFamily('cn-family-emt')],
  ['05-cart', ({ A, ui, C }) => {
    const fam = C.familyById('cn-family-emt');
    for (let g = 0; g < 6 && !C.familySelectionComplete(fam, ui.modalFamilySelection); g++) {
      const v = fam.variants.find((x) => !ui.modalFamilySelection[x.key]);
      A.selectFamilyVariant(v.key, v.key === 'size' ? '3/4"' : 0);
    }
    A.addFamilyToCart(); A.clearSearch(); A.quickAddToCart(ui.currentUser.recentlyUsed[0]); A.goto('fCart');
  }],
  ['06-request-details', ({ A }) => A.goto('fOrderForm')],
  ['07-my-orders', ({ A }) => A.fNavTo('orders', 'fMyOrders')],
  ['08-projects', ({ A }) => A.fNavTo('projects', 'fProjects')],
  ['09-workspace-team', ({ A }) => { A.openProjectWorkspace('proj1'); A.setWorkspaceTab('team'); }],
  ['10-workspace-materials', ({ A }) => A.setWorkspaceTab('materials')],
  ['11-field-profile', ({ A }) => A.fNavTo('profile', 'fProfile')],
  ['12-manager-home', signIn('manager', 'm1', '0000')],
  ['13-manager-orders', ({ A }) => A.mNavTo('orders', 'mOrders')],
  ['14-order-sheet', ({ A }) => A.openOrder('ORD-1001')],
  ['15-inventory', ({ A }) => { A.closeOrder(); A.mNavTo('inventory', 'mInventory'); }],
  ['15b-inventory-detail', ({ A }) => A.openInventoryDetail('pf-thhn::#12|Black|Stranded')],
  ['15c-inventory-adjust', ({ A }) => { A.openAdjust('pf-thhn::#12|Black|Stranded'); A.setAdjustField('quantity', '5'); }],
  ['16-worker-home', signIn('manager', 'm3', '8899')],
  ['17-packing-mode', ({ A }) => A.startPackingMode('ORD-1001')],
  ['18-warehouse-profile', ({ A }) => { A.exitPackingMode(); A.mNavTo('profile', 'mProfile'); }],
];
// Phase 3 screens (appended so older builds stay comparable up to step 18).
// Data is created through the real services: a request partly available from
// the warehouse, an Emergency request waiting for the demo Project Manager.
const P3_SETUP = ({ S, db }) => {
  const U = (id) => db.USERS.find((u) => u.id === id);
  const mk = (qty, priority, key) => S.Wf.submitRequest(U('f1'), { projectId: 'proj1', priority, neededBy: Date.now() + 864e5,
    lines: [{ productId: 'pf-thhn::#12|Black|Stranded', qty }, { productId: 'pf-emt-connector::3/4"|Standard|Steel', qty: 20 }] }, { submissionKey: key, duplicateOverride: [] }).request;
  window.__p3 = { partial: mk(2500, 'NORMAL', 'vis-partial').id, emergency: mk(10, 'EMERGENCY', 'vis-emergency').id };
};
const P3_STEPS = [
  ['22-duplicate-warning', ({ A, ui, S, db }) => {
    if (ui.currentUser) A.logout(); A.chooseRole('foreman'); A.pickProfile('foreman', 'f1'); '4827'.split('').forEach((d) => A.pinDigit(d));
    const o = db.REQUESTS.find((r) => r.id === 'ORD-1001');
    ui.cart = [{ productId: o.items[0].productVariantId, qty: 50, brandIdx: 0 }];
    A.goto('fOrderForm'); A.reviewOrder(); A.sendOrder();
    return new Promise((r) => setTimeout(r, 600));
  }],
  ['23-request-detail', (ctx) => { ctx.A.closeDuplicateWarning(); ctx.ui.cart = []; __SETUP__(ctx); ctx.A.fNavTo('orders', 'fMyOrders'); ctx.A.openRequestDetail(window.__p3.partial); }],
  ['24-pm-home-approvals', ({ A, ui }) => { A.closeRequestDetail(); if (ui.currentUser) A.logout(); A.chooseRole('foreman'); A.pickProfile('foreman', 'demo-pm1'); '7272'.split('').forEach((d) => A.pinDigit(d)); }],
  ['25-approval-decision', ({ A, db }) => { A.openApprovals(); A.openApproval(db.APPROVAL_REQUESTS.find((x) => x.requestId === window.__p3.emergency).id); }],
  ['26-manager-order-v5', ({ A, ui }) => { A.closeApprovals(); if (ui.currentUser) A.logout(); A.chooseRole('manager'); A.pickProfile('manager', 'm1'); '0000'.split('').forEach((d) => A.pinDigit(d)); A.openOrder(window.__p3.partial); }],
  ['27-allocation-sheet', ({ A }) => A.openAllocation(window.__p3.partial)],
  ['28-packing-mode-v5', ({ A, ui }) => { A.closeAllocation(); A.closeOrder(); if (ui.currentUser) A.logout(); A.chooseRole('manager'); A.pickProfile('manager', 'm3'); '8899'.split('').forEach((d) => A.pinDigit(d)); A.startPackingMode(window.__p3.partial); }],
].map(([n, f]) => [n, new Function('ctx', 'return (' + f.toString().replace('__SETUP__', '(' + P3_SETUP.toString() + ')') + ')(ctx);')]);
const P3_STRESS = [
  ['29-es-large-request-detail', (ctx) => { ctx.A.setLanguage('es'); ctx.A.setTextSize('large'); __SETUP__(ctx);
    if (ctx.ui.currentUser) ctx.A.logout(); ctx.A.chooseRole('foreman'); ctx.A.pickProfile('foreman', 'f1'); '4827'.split('').forEach((d) => ctx.A.pinDigit(d)); ctx.A.openRequestDetail(window.__p3.partial); }],
  ['30-es-large-approval', ({ A, ui, db }) => { A.closeRequestDetail(); if (ui.currentUser) A.logout(); A.chooseRole('foreman'); A.pickProfile('foreman', 'demo-pm1'); '7272'.split('').forEach((d) => A.pinDigit(d));
    A.openApprovals(); A.openApproval(db.APPROVAL_REQUESTS.find((x) => x.requestId === window.__p3.emergency).id); }],
  ['31-es-large-packing-v5', ({ A, ui }) => { A.closeApprovals(); if (ui.currentUser) A.logout(); A.chooseRole('manager'); A.pickProfile('manager', 'm3'); '8899'.split('').forEach((d) => A.pinDigit(d)); A.startPackingMode(window.__p3.partial); }],
].map(([n, f]) => [n, new Function('ctx', 'return (' + f.toString().replace('__SETUP__', '(' + P3_SETUP.toString() + ')') + ')(ctx);')]);
// Phase 3 correction pass: outstanding demand path + several warehouse batches.
const P3C_SETUP = ({ S, db }) => {
  const U = (id) => db.USERS.find((u) => u.id === id);
  const q = (v) => S.Inv.getQuantityByState('company1', v).AVAILABLE || 0;
  const vs = S.Inv.stockedVariantIds('company1').filter((k) => k.includes('::') && !k.includes('Any') && S.Cat.getProductVariant(k).unit === 'EA' && S.Inv.adjustmentCandidates('company1', k).length === 1 && q(k) > 0);
  const set = (v, n) => { const c = q(v); if (c !== n) S.Inv.adjustInventory(U('m1'), { productVariantId: v, direction: n > c ? 'IN' : 'OUT', quantity: Math.abs(n - c), reasonCode: 'PHYSICAL_COUNT_CORRECTION' }); };
  const mk = (v, qty, key) => S.Wf.submitRequest(U('f1'), { projectId: 'proj1', priority: 'HIGH', neededBy: Date.now() + 864e5, lines: [{ productId: v, qty }] }, { submissionKey: key, duplicateOverride: [] }).request;
  set(vs[0], 0); const zero = mk(vs[0], 100, 'vis-zero');
  set(vs[1], 60); const two = mk(vs[1], 100, 'vis-two');
  S.Wsv.collectRequestItem(U('m3'), two.id, two.items[0].id);
  set(vs[1], 40); S.Wf.managerAllocateAvailable(U('m1'), two.id);
  window.__p3c = { zero: zero.id, two: two.id };
};
const P3C_STEPS = [
  ['32-manager-home-outstanding', (ctx) => { const { A, ui } = ctx; A.closeAllocation && A.closeAllocation(); A.exitPackingMode && A.exitPackingMode(); __SETUP__(ctx);
    if (ui.currentUser) A.logout(); A.chooseRole('manager'); A.pickProfile('manager', 'm1'); '0000'.split('').forEach((d) => A.pinDigit(d)); }],
  ['33-allocation-zero-stock', ({ A }) => A.openAllocation(window.__p3c.zero)],
  ['34-worker-two-batches', ({ A, ui }) => { A.closeAllocation(); if (ui.currentUser) A.logout(); A.chooseRole('manager'); A.pickProfile('manager', 'm3'); '8899'.split('').forEach((d) => A.pinDigit(d)); A.mNavTo('packing', 'whPacking'); }],
  ['35-field-detail-batches', ({ A, ui }) => { if (ui.currentUser) A.logout(); A.chooseRole('foreman'); A.pickProfile('foreman', 'f1'); '4827'.split('').forEach((d) => A.pinDigit(d)); A.openRequestDetail(window.__p3c.two); }],
].map(([n, f]) => [n, new Function('ctx', 'return (' + f.toString().replace('__SETUP__', '(' + P3C_SETUP.toString() + ')') + ')(ctx);')]);
const P3C_STRESS = [
  ['36-es-large-manager-outstanding', (ctx) => { ctx.A.setLanguage('es'); ctx.A.setTextSize('large'); __SETUP__(ctx);
    if (ctx.ui.currentUser) ctx.A.logout(); ctx.A.chooseRole('manager'); ctx.A.pickProfile('manager', 'm1'); '0000'.split('').forEach((d) => ctx.A.pinDigit(d)); }],
  ['37-es-large-allocation-detail', ({ A }) => A.openAllocation(window.__p3c.two)],
].map(([n, f]) => [n, new Function('ctx', 'return (' + f.toString().replace('__SETUP__', '(' + P3C_SETUP.toString() + ')') + ')(ctx);')]);
// Phase 3 micro correction: more than 5 outstanding requests + the full list.
const P3M_SETUP = ({ S, db }) => {
  const U = (id) => db.USERS.find((u) => u.id === id);
  const q = (v) => S.Inv.getQuantityByState('company1', v).AVAILABLE || 0;
  const vs = S.Inv.stockedVariantIds('company1').filter((k) => k.includes('::') && !k.includes('Any') && S.Cat.getProductVariant(k).unit === 'EA' && S.Inv.adjustmentCandidates('company1', k).length === 1 && q(k) > 0).slice(2, 9);
  const pri = ['EMERGENCY', 'HIGH', 'NORMAL', 'LOW', 'HIGH', 'NORMAL', 'LOW'];
  vs.forEach((v, i) => { const c = q(v); if (c) S.Inv.adjustInventory(U('m1'), { productVariantId: v, direction: 'OUT', quantity: c, reasonCode: 'PHYSICAL_COUNT_CORRECTION' });
    const r = S.Wf.submitRequest(U('f1'), { projectId: i % 2 ? 'proj2' : 'proj1', priority: pri[i], neededBy: Date.now() + (i + 1) * 864e5, lines: [{ productId: v, qty: 10 * (i + 1) }] },
      { submissionKey: 'vis-m-' + i, duplicateOverride: [] });
    if (r.approval) S.Wf.approveRequest(U('demo-pm1'), r.approval.id); });
};
const P3M_STEPS = [
  ['38-manager-home-many-outstanding', (ctx) => { const { A, ui } = ctx; __SETUP__(ctx);
    if (ui.currentUser) A.logout(); A.chooseRole('manager'); A.pickProfile('manager', 'm1'); '0000'.split('').forEach((d) => A.pinDigit(d)); }],
  // the "View all" button sits below the preview: scroll Home's content to it
  ['38b-manager-home-view-all', () => { const b = [...document.querySelectorAll('button')].find((x) => /View all|Ver las/.test(x.textContent)); if (b) b.scrollIntoView({ block: 'center' }); }],
  ['39-outstanding-full-list', ({ A }) => A.openOutstandingRequests()],
].map(([n, f]) => [n, new Function('ctx', 'return (' + f.toString().replace('__SETUP__', '(' + P3M_SETUP.toString() + ')') + ')(ctx);')]);
const P3M_STRESS = [
  ['40-es-large-manager-home-many', (ctx) => { ctx.A.setLanguage('es'); ctx.A.setTextSize('large'); __SETUP__(ctx);
    if (ctx.ui.currentUser) ctx.A.logout(); ctx.A.chooseRole('manager'); ctx.A.pickProfile('manager', 'm1'); '0000'.split('').forEach((d) => ctx.A.pinDigit(d)); }],
  ['40b-es-large-home-view-all', () => { const b = [...document.querySelectorAll('button')].find((x) => /View all|Ver las/.test(x.textContent)); if (b) b.scrollIntoView({ block: 'center' }); }],
  ['41-es-large-outstanding-full-list', ({ A }) => A.openOutstandingRequests()],
].map(([n, f]) => [n, new Function('ctx', 'return (' + f.toString().replace('__SETUP__', '(' + P3M_SETUP.toString() + ')') + ')(ctx);')]);
// Phase 4: purchasing (requirements, POs, suppliers, incoming + receiving, field "on order").
const P4_SETUP = ({ S, db }) => {
  const U = (id) => db.USERS.find((u) => u.id === id), PUR = U('demo-pur1'), WM = U('m1');
  const q = (v) => S.Inv.getQuantityByState('company1', v).AVAILABLE || 0;
  const vs = S.Inv.stockedVariantIds('company1').filter((k) => k.includes('::') && !k.includes('Any') && S.Cat.getProductVariant(k).unit === 'EA' && S.Inv.adjustmentCandidates('company1', k).length === 1 && q(k) > 0).slice(10, 14);
  const set = (v, n) => { const c = q(v); if (c !== n) S.Inv.adjustInventory(WM, { productVariantId: v, direction: n > c ? 'IN' : 'OUT', quantity: Math.abs(n - c), reasonCode: 'PHYSICAL_COUNT_CORRECTION' }); };
  set(vs[0], 60); set(vs[1], 0); set(vs[2], 0); set(vs[3], 0);
  const sub = (v, qty, pri, days, key) => S.Wf.submitRequest(U('f1'), { projectId: 'proj1', priority: pri, neededBy: Date.now() + days * 864e5, lines: [{ productId: v, qty }] }, { submissionKey: key, duplicateOverride: [] });
  const r1 = sub(vs[0], 100, 'HIGH', 2, 'vis4-1').request, r2 = sub(vs[1], 40, 'NORMAL', 4, 'vis4-2').request;
  const r3 = sub(vs[2], 25, 'NORMAL', 6, 'vis4-3').request;
  const r4 = sub(vs[3], 12, 'EMERGENCY', 1, 'vis4-4'); if (r4.approval) S.Wf.approveRequest(U('demo-pm1'), r4.approval.id);
  const pr = (r) => S.PRS.getRequirementsForRequest(r.id)[0];
  const sups = S.Sup.getSuppliers(PUR);
  S.Sup.addSupplierQuote(PUR, { supplierId: sups[0].id, purchaseRequirementId: pr(r1).id, unitPrice: 1.35, leadTimeDays: 2, quoteNumber: 'Q-1042' });
  S.Sup.addSupplierQuote(PUR, { supplierId: sups[1].id, purchaseRequirementId: pr(r1).id, unitPrice: 1.28, leadTimeDays: 5 });
  // a sent PO, partly received, the rest backordered
  const d2 = S.POS.createDraft(PUR, { supplierId: sups[0].id, expectedDeliveryDate: '2026-10-02', shipping: 12, tax: 3.5,
    lines: [{ productVariantId: pr(r2).productVariantId, unit: 'EA', unitPrice: 2.4, stockOverageQuantity: 10, demand: [{ purchaseRequirementId: pr(r2).id, quantity: 40 }] }] }).purchaseOrder;
  S.POS.sendPurchaseOrder(PUR, d2.id); S.POS.confirmPurchaseOrder(PUR, d2.id, { supplierConfirmationNumber: 'MES-5521' });
  S.Rcv.receivePurchaseOrder(WM, d2.id, { lines: [{ purchaseOrderItemId: d2.items[0].id, quantityGood: 25, locationId: S.Rcv.defaultReceivingLocation(d2, d2.items[0]) }] }, { operationKey: 'vis4-rc' });
  S.POS.markBackordered(PUR, d2.id, d2.items[0].id, 25, '2026-10-09');
  // a draft, and a sent PO expected today (for the warehouse)
  S.POS.createDraft(PUR, { supplierId: sups[1].id, lines: [{ productVariantId: pr(r3).productVariantId, unit: 'EA', unitPrice: 3.1, demand: [{ purchaseRequirementId: pr(r3).id, quantity: 25 }] }] });
  const d4 = S.POS.createDraft(PUR, { supplierId: sups[2].id, expectedDeliveryDate: new Date().toISOString().slice(0, 10),
    lines: [{ productVariantId: pr(r4.request).productVariantId, unit: 'EA', unitPrice: 4.75, demand: [{ purchaseRequirementId: pr(r4.request).id, quantity: pr(r4.request).quantityRequired }] }] }).purchaseOrder;
  S.POS.sendPurchaseOrder(PUR, d4.id);
  window.__P4 = { r1: r1.id, r2: r2.id, pr1: pr(r1).id, po2: d2.id, po4: d4.id, draftPo: db.PURCHASE_ORDERS.find((p) => p.status === 'DRAFT').id, sup: sups[0].id };
};
const asUser = (ctx, role, id, pin) => { const { A, ui } = ctx; if (ui.currentUser) A.logout(); A.chooseRole(role); A.pickProfile(role, id); pin.split('').forEach((d) => A.pinDigit(d)); };
const wrap4 = (steps) => steps.map(([n, f]) => [n, new Function('ctx', 'const asUser = ' + asUser.toString() + ';\nreturn (' + f.toString().replace('__SETUP__', '(' + P4_SETUP.toString() + ')') + ')(ctx);')]);
const P4_STEPS = wrap4([
  ['42-purchasing-home', (ctx) => { __SETUP__(ctx); asUser(ctx, 'purchasing', 'demo-pur1', '5151'); }],
  ['43-requirement-detail', ({ PU }) => PU.openRequirement(window.__P4.pr1)],
  ['44-create-po', ({ PU }) => PU.startPo(window.__P4.pr1)],
  ['45-po-list', ({ PU }) => { PU.closePoDraft(); PU.closeRequirement(); PU.pNavTo('pos', 'pOrders'); }],
  ['46-po-detail-partial-backorder', ({ PU }) => PU.openPo(window.__P4.po2)],
  ['47-po-detail-draft', ({ PU }) => { PU.closePo(); PU.openPo(window.__P4.draftPo); }],
  ['48-suppliers', ({ PU }) => { PU.closePo(); PU.pNavTo('suppliers', 'pSuppliers'); }],
  ['49-supplier-edit', ({ PU }) => PU.openSupplier(window.__P4.sup)],
  ['50-warehouse-home', (ctx) => { ctx.PU.closeSupplier(); asUser(ctx, 'manager', 'm1', '0000'); }],
  ['50b-warehouse-incoming', () => { const el = document.querySelector('[data-incoming]'); if (el) el.scrollIntoView({ block: 'center' }); }],
  ['51-receive-po', ({ PU }) => PU.openReceive(window.__P4.po4)],
  ['52-field-on-order', (ctx) => { ctx.PU.closeReceive(); asUser(ctx, 'foreman', 'f1', '4827'); ctx.A.openRequestDetail(window.__P4.r2); }],
]);
const P4_STRESS = wrap4([
  ['53-es-large-purchasing-home', (ctx) => { ctx.A.setLanguage('es'); ctx.A.setTextSize('large'); __SETUP__(ctx); asUser(ctx, 'purchasing', 'demo-pur1', '5151'); }],
  ['54-es-large-requirement-detail', ({ PU }) => PU.openRequirement(window.__P4.pr1)],
  ['55-es-large-po-detail', ({ PU }) => { PU.closeRequirement(); PU.pNavTo('pos', 'pOrders'); PU.openPo(window.__P4.po2); }],
  ['56-es-large-receive-po', (ctx) => { ctx.PU.closePo(); asUser(ctx, 'manager', 'm1', '0000'); ctx.PU.openReceive(window.__P4.po4); }],
  ['57-es-large-field-on-order', (ctx) => { ctx.PU.closeReceive(); asUser(ctx, 'foreman', 'f1', '4827'); ctx.A.openRequestDetail(window.__P4.r2); }],
]);
// Longer Spanish text + Large Text is where layouts usually break.
const STRESS = [
  ['19-es-large-warehouse-profile', ({ A }) => { A.setLanguage('es'); A.setTextSize('large'); }],
  ['20-es-large-field-home', signIn('foreman', 'f1', '4827')],
  ['21-es-large-request-details', ({ A, ui }) => { A.quickAddToCart(ui.currentUser.recentlyUsed[0]); A.goto('fOrderForm'); }],
];

async function runWidth(browser, url, width, steps, dir) {
  // Reduced motion + frozen animations: sheets are captured fully open, never mid-slide.
  const context = await browser.newContext({ viewport: { width, height: width >= 768 ? 1000 : 844 }, deviceScaleFactor: 1, reducedMotion: 'reduce' });
  await context.addInitScript((t) => {
    const Real = Date;
    class Frozen extends Real { constructor(...a) { super(...(a.length ? a : [t])); } static now() { return t; } }
    window.Date = Frozen;
  }, FROZEN);
  await context.route(/^https?:\/\/(?!127\.0\.0\.1)/, (r) => r.abort());   // no network fonts: identical fallback everywhere
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  // Console errors count too: broken references, missing modules, React errors.
  // The one exception: this run blocks all outside network on purpose (see
  // context.route below), so the product-photo requests it aborts log
  // "Failed to load resource". Those are the test's own doing, not app errors.
  page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push('console: ' + m.text()); });
  await page.goto(url); await page.waitForTimeout(150);
  const results = [];
  fs.mkdirSync(dir, { recursive: true });
  for (const [name, fn] of steps) {
    await page.evaluate('(' + fn.toString() + ')(window.__ANT)');
    await page.waitForTimeout(80);
    // Settle any confirmation toast so screenshots are repeatable.
    await page.evaluate(() => { const { A, ui } = window.__ANT; if (ui.toast) { ui.toast = null; A.goto(ui.screen); } });
    await page.waitForTimeout(40);
    const o = await page.evaluate(() => {
      const iw = window.innerWidth;
      const scrollsX = (el) => { for (let p = el.parentElement; p; p = p.parentElement) { const s = getComputedStyle(p).overflowX; if (s !== 'visible') return true; } return false; };
      const offenders = [...document.querySelectorAll('#root *')].filter((el) => {
        const r = el.getBoundingClientRect();
        return r.width > 0 && (r.right > iw + 1 || r.left < -1) && !scrollsX(el);
      }).slice(0, 3).map((el) => (el.className && typeof el.className === 'string' ? '.' + el.className.split(' ')[0] : el.tagName) + ' ' + Math.round(el.getBoundingClientRect().right) + 'px');
      return { pageOverflow: document.documentElement.scrollWidth > iw + 1, scrollWidth: document.documentElement.scrollWidth, offenders };
    });
    await page.screenshot({ path: path.join(dir, name + '.png'), fullPage: true, animations: 'disabled', caret: 'hide' });
    results.push({ name, ok: !o.pageOverflow && o.offenders.length === 0, ...o });
  }
  await context.close();
  return { results, errors };
}

(async () => {
  let chromium;
  try { ({ chromium } = require('playwright-core')); } catch (e) { console.log('playwright-core is not installed (npm install).'); process.exit(1); }
  const site = buildPage();
  const server = await serve(site);
  const url = 'http://127.0.0.1:' + server.address().port + '/';
  let browser;
  try { browser = await chromium.launch(); } catch (e) { console.log('Chromium is not installed. Run: npx playwright-core install chromium'); server.close(); process.exit(1); }
  let fails = 0, total = 0;
  // Stress pass: sign in as the worker, switch to Spanish + Large Text, then walk field screens.
  const stressSteps = STEPS.filter((s) => /^1[678]-/.test(s[0])).concat(STRESS);
  const runs = WIDTHS.map((w) => [w, STEPS.concat(P3_STEPS, P3C_STEPS, P3M_STEPS, P4_STEPS), String(w), w + 'px']).concat([[375, stressSteps, '375-stress', '375px Spanish + Large Text'],
    [375, P3_STRESS, '375-stress-p3', '375px Spanish + Large Text (Phase 3)'], [375, P3C_STRESS, '375-stress-p3c', '375px Spanish + Large Text (correction pass)'],
    [375, P3M_STRESS, '375-stress-p3m', '375px Spanish + Large Text (outstanding list)'], [375, P4_STRESS, '375-stress-p4', '375px Spanish + Large Text (purchasing)']]);
  for (const [w, steps, folder, label] of runs) {
    const { results, errors } = await runWidth(browser, url, w, steps, path.join(OUT, folder));
    const bad = results.filter((r) => !r.ok);
    total += results.length; fails += bad.length + errors.length;
    console.log((bad.length || errors.length ? 'FAIL ' : 'ok   ') + label.padEnd(30) + results.length + ' screens, ' + bad.length + ' with horizontal overflow' + (errors.length ? ', ' + errors.length + ' runtime/console errors' : ''));
    bad.forEach((r) => console.log('       ' + r.name + ': page width ' + r.scrollWidth + 'px ' + r.offenders.join(', ')));
    errors.slice(0, 3).forEach((e) => console.log('       error: ' + e));
  }
  await browser.close(); server.close();
  console.log('\n' + (total - fails) + ' of ' + total + ' screen checks passed. Screenshots: ' + path.relative(process.cwd(), OUT));
  process.exit(fails ? 1 : 0);
})();
