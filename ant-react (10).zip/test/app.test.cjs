/* ANT end-to-end tests: bundles the real app, loads it in a simulated
   browser (jsdom), and drives it by tapping the same buttons a user would.
   Run with:  npm test  */
const path = require('path');
const fs = require('fs');
const { buildSync } = require('esbuild');
const { JSDOM } = require('jsdom');

const bundle = buildSync({
  entryPoints: [path.join(__dirname, 'entry.jsx')], bundle: true, format: 'iife', write: false,
  loader: { '.css': 'empty' }, jsx: 'automatic', define: { 'process.env.NODE_ENV': '"production"' }, logLevel: 'error',
}).outputFiles[0].text;

let pass = 0, fail = 0; const errors = [], consoleErrors = [];
const check = (label, cond) => { if (cond) pass++; else { fail++; console.log('  FAIL -', label); } };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));


function boot(saved) {
  const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>',
    { runScripts: 'outside-only', pretendToBeVisual: true, url: 'http://localhost/' });
  const W = dom.window;
  W.confirm = () => true;
  W.addEventListener('error', (e) => errors.push(e.message));
  W.console.error = (...args) => consoleErrors.push(args.map(String).join(' '));
  if (saved) W.localStorage.setItem('ant_prototype_data_v1', saved);
  W.eval(bundle);
  return W;
}

(async () => {
  let W = boot(); await wait(80);
  let { A, ui, db, C } = W.__ANT;
  const html = () => W.document.getElementById('root').innerHTML;
  const byId = (id) => W.document.getElementById(id);
  async function click(text, index = 0) {
    const matches = [...W.document.querySelectorAll('button')].filter((b) => b.textContent.trim().includes(text));
    if (!matches[index]) throw new Error('No button containing: ' + text);
    matches[index].dispatchEvent(new W.MouseEvent('click', { bubbles: true }));
    await wait(15);
  }
  async function type(el, value) {
    const proto = el.tagName === 'TEXTAREA' ? W.HTMLTextAreaElement.prototype : W.HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
    el.dispatchEvent(new W.Event('input', { bubbles: true }));
    await wait(5);
  }
  // Stock as the old tests saw it, now read from v4 ledger balances: AVAILABLE
  // quantity and the item's bin (null when it has no bin yet). undefined = not stocked.
  const STK = (vid, co, dbx) => {
    const d = dbx || W.__ANT.db; co = co || 'company1';
    const it = d.INVENTORY_ITEMS.find((x) => x.companyId === co && x.productVariantId === vid);
    if (!it) return undefined;
    const qty = d.INVENTORY_BALANCES.filter((b) => b.companyId === co && b.productVariantId === vid && b.inventoryState === 'AVAILABLE').reduce((a, b) => a + b.quantity, 0);
    const l = d.LOCATIONS.find((x) => x.id === it.primaryLocationId);
    return { qty, locationId: l && l.type !== 'WAREHOUSE' ? l.id : null };
  };
  // Empty a variant's AVAILABLE stock the honest way: a manager adjustment per bin.
  function zeroStock(vid) {
    const S_ = W.__ANT.S, m1 = W.__ANT.db.USERS.find((u) => u.id === 'm1'), k = W.__ANT.I.stockKey(vid, 'company1');
    S_.Inv.locationsHolding('company1', k, 'AVAILABLE').forEach((b) => S_.Inv.adjustInventory(m1, { productVariantId: k, locationId: b.locationId, direction: 'OUT', quantity: b.quantity, reasonCode: 'DATA_CORRECTION' }));
  }
  const TAP = () => wait(W.__ANT.A.TAP_GUARD_MS + 30);
  // Phase 3: a request's warehouse stage and the warehouse's view of it (fulfillment)
  const STAGE = (r) => W.__ANT.S.Ful.stageOf(r);
  const WV = (r) => W.__ANT.S.Ful.warehouseOrderView(r);   // real taps are further apart than the double-tap guard
  async function login(team, name, pin) {
    if (ui.currentUser) { A.logout(); await wait(15); }
    await click(team === 'field' ? "I'm on the Field Team" : team === 'purchasing' ? "I'm on the Purchasing Team" : "I'm on the Warehouse Team");
    await click(name);
    for (const d of pin) await click(d);
    await wait(15);
  }
  const newest = () => db.REQUESTS.slice().sort((a, b) => parseInt(b.id.slice(4), 10) - parseInt(a.id.slice(4), 10))[0];
  async function sendCurrentCart(priority) {
    A.goto('fOrderForm'); await wait(10);
    if (priority) await click(priority);
    await click('Review request'); await click('Send request'); await wait(550);
    return newest();
  }


  console.log('Catalog migration (69 legacy products -> exact variants)');
  const M = W.__ANT.M;
  const legacyIds = C.PRODUCTS.map((p) => p.id);
  check('All 69 legacy products are mapped to a variant', legacyIds.length === 69 && legacyIds.every((id) => M.LEGACY_TO_VARIANT[id]));
  check('Every legacy id still resolves (history stays readable)', legacyIds.every((id) => !!C.getProduct(id)));
  check('Every mapped variant resolves as a configured product', legacyIds.every((id) => { const v = C.getProduct(M.LEGACY_TO_VARIANT[id]); return v && v.isFamilyVariant; }));
  check('Legacy stock moved to its variant with quantity and location', (() => { const r = STK('pf-thhn::#12|Black|Stranded', 'company1'); return r && r.qty === 1988 && W.__ANT.I.inventoryLocation('pf-thhn::#12|Black|Stranded', 'company1') === 'Shelf A-1'; })());
  check('No stock record is still keyed by a legacy id', legacyIds.every((id) => !STK(id, 'company1')));
  check('Old id and new id read the same stock record', M.availableQty('wc1', 'company1') === M.availableQty('pf-thhn::#12|Black|Stranded', 'company1') && M.availableQty('wc1', 'company1') > 0);
  check('#12 Black and #12 White THHN have independent stock and locations',
    STK('pf-thhn::#12|Black|Stranded', 'company1').qty !== STK('pf-thhn::#12|White|Stranded', 'company1').qty && W.__ANT.I.inventoryLocation('pf-thhn::#12|White|Stranded', 'company1') === 'Shelf A-2');
  check('3/4" and 1" EMT connectors have independent stock',
    STK('pf-emt-connector::3/4"|Standard|Steel', 'company1').qty === 131 && STK('pf-emt-connector::1"|Standard|Any', 'company1').qty === 150);
  check('Seeded variants have their own stock and location', M.SEEDED_STOCK.every((s) => STK(s.id, 'company1') && W.__ANT.I.inventoryLocation(s.id, 'company1') === s.location));
  check('Corrected mapping: CAT6 keystone jack -> Data Jack family', M.LEGACY_TO_VARIANT.lv5.indexOf('pf-data-jack::') === 0);
  check('Corrected mapping: two-hole cable clamp -> Cable Clamp family', M.LEGACY_TO_VARIANT.fa5.indexOf('pf-cable-clamp::') === 0);
  check('No Job Kit became empty; every kit line is a resolvable variant',
    db.JOB_KITS.every((k) => k.materials.length > 0 && k.materials.every((m) => m.productId.includes('::') && !!C.getProduct(m.productId))));
  check('Open orders now carry exact variants and keep their legacy id',
    db.REQUESTS.every((o) => o.items.every((i) => i.productVariantId.includes('::') && i.legacyProductId && i.variantSnapshot && C.getProduct(i.productVariantId))));
  check('Recently / Most Used now hold variants', db.USERS.filter((u) => u.workerType === 'FIELD').every((u) => (u.recentlyUsed || []).concat(u.mostUsed || []).every((id) => id.includes('::'))));
  const before = JSON.stringify([db.INVENTORY_ITEMS, db.INVENTORY_BALANCES, db.MATERIAL_MOVEMENTS, db.JOB_KITS, db.REQUESTS, db.USERS]);
  M.migrateCatalogData(db);
  check('Migration is idempotent (running it again changes nothing)', JSON.stringify([db.INVENTORY_ITEMS, db.INVENTORY_BALANCES, db.MATERIAL_MOVEMENTS, db.JOB_KITS, db.REQUESTS, db.USERS]) === before);
  const oldFormat = JSON.stringify({ version: 1, inventory: { wc2: { qty: 999, location: 'Old Bin 7' } },
    jobKits: [{ id: 'k-old', name: 'Old Kit', type: 'Company', createdBy: 'company', materials: [{ productId: 'wc2', qty: 5, unit: 'FT' }] }], orders: [] });
  const Wold = boot(oldFormat); await wait(80);
  const dbo = Wold.__ANT.db;
  check('Older saved data (legacy ids) migrates on load: stock', STK('pf-thhn::#12|White|Stranded', 'company1', dbo) && STK('pf-thhn::#12|White|Stranded', 'company1', dbo).qty === 999 && !STK('wc2', 'company1', dbo));
  check('Older saved data (legacy ids) migrates on load: Job Kit', dbo.JOB_KITS[0].materials[0].productId === 'pf-thhn::#12|White|Stranded');
  const terms = ['THHN', '12 black', '12 awg black', '500 kcmil', 'MC', '12/3 MC', 'Romex', '12/2 Romex', 'EMT', '3/4 EMT', '3/4 connector',
    'compression coupling', 'LB', '4 square', 'mud ring', '3/8 rod', '10-32 screw', 'wire lube', 'ground rod', '20A GFCI', '200A disconnect',
    'CAT6 plenum', 'fire alarm cable', 'strut', 'Polaris', '3/4 compression connector', 'emt comp', '12 black thhn', '500 copper', '4 square deep',
    '4 11 box', '20 amp gfci white', '200 amp disconnect', '3 phase disconnect', '1/2 liquid tight', 'red wire', 'pulling soap', 'split bolt', '2 gang ring', 'cat6 plenum'];
  check('Every search term from the migration spec returns results', terms.every((q) => C.searchProducts(q).length > 0));
  const top = { '3/4 connector': 'pf-emt-connector', '12 awg black': 'pf-thhn', '4 11 box': 'pf-box-411', '3 phase disconnect': 'pf-safety-switch',
    '1/2 liquid tight': 'pf-lfmc', 'pulling soap': 'pf-pulling-lube', '10-32 screw': 'pf-machine-screw', '2 gang ring': 'pf-mudring', 'emt comp': 'pf-emt-comp-connector' };
  Object.keys(top).forEach((q) => check('Search "' + q + '" ranks ' + top[q] + ' first', C.searchProducts(q)[0].id === top[q]));

  console.log('Variant-level inventory (no invented stock, "Any" matching)');
  const I = W.__ANT.I;
  const unstocked = 'pf-thhn::#8|Orange|Stranded';
  check('An unstocked variant has 0 available (no invented quantity)', I.availableQty(unstocked, 'company1') === 0);
  check('An unstocked variant shows "Not stocked" as its location', I.inventoryLocation(unstocked, 'company1') === 'Not stocked');
  check('#12 Black and #12 White THHN have independent quantities and locations',
    I.availableQty('pf-thhn::#12|Black|Stranded', 'company1') !== I.availableQty('pf-thhn::#12|White|Stranded', 'company1') &&
    I.inventoryLocation('pf-thhn::#12|Black|Stranded', 'company1') !== I.inventoryLocation('pf-thhn::#12|White|Stranded', 'company1'));
  check('3/4" and 1" EMT connectors are independent stock records',
    I.stockKey('pf-emt-connector::3/4"|Standard|Any', 'company1') !== I.stockKey('pf-emt-connector::1"|Standard|Any', 'company1'));
  const anyId = 'pf-emt-connector::3/4"|Standard|Any', steelId = 'pf-emt-connector::3/4"|Standard|Steel';
  check('A "Material: Any" request draws from the matching stocked variant (the migrated Steel connectors)',
    I.stockKey(anyId, 'company1') === steelId && I.availableQty(anyId, 'company1') === STK(steelId, 'company1').qty && I.availableQty(anyId, 'company1') > 0);
  check('FT and ROLL of the same THHN are separate stock records', I.stockKey('pf-thhn::#12|Black|Stranded', 'company1') !== I.stockKey('pf-thhn::#12|Black|Stranded~ROLL', 'company1'));
  const fuse = C.familyById('pf-fuse'); const volt = fuse.variants.find((v) => v.key === 'voltage');
  check('Class G fuses: 20A is 600V only, 60A is 480V only (no invalid combination)',
    C.variantOptions(fuse, volt, { class: 'Class G', amperage: '20A' }).join() === '600V' &&
    C.variantOptions(fuse, volt, { class: 'Class G', amperage: '60A' }).join() === '480V');
  const SEARCH_SPEC = { '3/4 compression connector': 'pf-emt-comp-connector', 'emt comp': 'pf-emt-comp-connector', '12/3 mc': 'pf-mc',
    '500 kcmil': 'pf-thhn', '4 square deep': 'pf-box-4sq', '4 11 box': 'pf-box-411', '11b': 'pf-box-411', '20 amp gfci white': 'pf-rcpt-gfci',
    '200 amp disconnect': 'pf-safety-switch', '3 phase disconnect': 'pf-safety-switch', '1/2 liquid tight': 'pf-lfmc', '10-32 screw': 'pf-machine-screw',
    'ground rod': 'pf-groundrod', 'wire lube': 'pf-pulling-lube', 'pulling soap': 'pf-pulling-lube', 'split bolt': 'pf-split-bolt',
    '2 gang ring': 'pf-mudring', 'cat6 plenum': 'pf-cat', '12 awg black': 'pf-thhn', 'compression coupling': 'pf-emt-comp-coupling',
    'fire alarm cable': 'pf-fa-cable', strut: 'pf-strut', sealtite: 'pf-lfmc', kindorf: 'pf-strut', allthread: 'pf-rod', EMT: 'cn-family-emt' };
  Object.keys(SEARCH_SPEC).forEach((q) => check('Spec search "' + q + '" ranks ' + SEARCH_SPEC[q] + ' first', C.searchProducts(q)[0].id === SEARCH_SPEC[q]));

  console.log('Login');
  await click("I'm on the Field Team"); await click('Carlos');
  for (const d of '4829') await click(d);
  check('Wrong PIN is rejected', html().includes('Incorrect PIN'));
  await wait(700);
  for (const d of '4827') await click(d);
  await wait(15);
  check('Correct PIN opens Field Home', ui.screen === 'fHome');
  check('Current project shows role', html().includes('7 Fairfield Rd') && html().includes('cpr-label">Foreman<'));
  check('Home shows 12 category groups', (html().match(/cat-row-label/g) || []).length === 12);

  console.log('Search and catalog');
  const search = byId('home-search-input'); search.setAttribute('data-mark', 'same');
  for (const v of ['1', '19', '190', '1900']) await type(byId('home-search-input'), v);
  check('Typing keeps the same search input (keyboard stays open)', byId('home-search-input').getAttribute('data-mark') === 'same');
  const expect = { '1900': 'pf-box-4sq', redhead: 'pf-antishort', smurf: 'cn-family-ent', romex: 'pf-nmb', greenfield: 'pf-fmc',
    Polaris: 'pf-polaris', LB: 'pf-cb-lb', '3/4 EMT connector': 'pf-emt-connector', '1 inch EMT coupling': 'pf-emt-coupling',
    '12 black THHN': 'pf-thhn', '12/2 MC': 'pf-mc', '20 amp GFCI': 'pf-rcpt-gfci', '2 pole 30 amp breaker': 'pf-breaker',
    '3/4 ground bushing': 'pf-groundbushing', '3/8 threaded rod': 'pf-rod', '4 square mud ring': 'pf-mudring' };
  Object.keys(expect).forEach((q) => check('Search "' + q + '" ranks the right family first', C.searchProducts(q)[0].id === expect[q]));
  await click('1900 Box');
  check('1900 box suggests Mud Ring and Ground Screw', html().includes('Frequently used with') && html().includes('Mud Ring') && html().includes('Ground Screw'));
  A.closeFamily(); A.openFamily('pf-breaker'); await wait(10);
  check('Breaker series stays hidden until a manufacturer is chosen', !html().includes('QO (Plug-On)') && html().includes('Next: choose Manufacturer'));
  await click('Square D');
  check('Square D offers only Square D series', html().includes('QO (Plug-On)') && !html().includes('BR (Plug-On)'));
  A.closeFamily(); A.clearSearch(); await wait(10);

  console.log('Foreman: full material request');
  await type(byId('home-search-input'), '12 black thhn');
  await click('THHN / THWN-2 Copper');
  check('Search pre-selected #12 and Black', ui.modalFamilySelection.gauge === '#12' && ui.modalFamilySelection.color === 'Black');
  await click('Stranded'); await click('ROLL');
  check('"You are requesting" summary is shown', html().includes('#12 Black Stranded THHN'));
  await click('Add to material request');
  check('Confirmation includes the configuration (no empty "()")', ui.toast.includes('ROLL') && !ui.toast.includes('()'));
  await type(byId('home-search-input'), '3/4 emt connector');
  await click('EMT Set-Screw Connector');
  check('Add stays disabled until every required option is chosen', W.document.querySelector('.sheet .btn-primary').disabled === true);
  await click('Standard');
  await type(byId('family-qty'), '25');
  await click('Add to material request');
  A.clearSearch(); await wait(10);
  await click('Add'); // quick add from Recently Used
  check('Cart has 3 distinct lines', ui.cart.length === 3);
  await click('View material request');
  const qty = W.document.querySelector('.qty-stepper-sm input'); qty.setAttribute('data-mark', 'q');
  await type(qty, '2');
  check('Cart quantity edits keep the same input', W.document.querySelector('.qty-stepper-sm input').getAttribute('data-mark') === 'q');
  await click('Continue');
  check('Needed By defaults to today', byId('needed-date').value.length === 10);
  await type(byId('order-notes'), 'Deliver to gate 3');
  await click('High');
  await click('Review request');
  check('Review sheet opens', html().includes('Send material request?'));
  const count = db.REQUESTS.length;
  await click('Send request'); await wait(550);
  const ord = newest();
  check('Order submitted, cart cleared, back on Home', db.REQUESTS.length === count + 1 && ui.cart.length === 0 && ui.screen === 'fHome');
  check('Order keeps priority, notes and configured snapshots', ord.priority === 'HIGH' && ord.notes === 'Deliver to gate 3' && ord.items.every((i) => !!i.variantSnapshot && !!i.brandSnapshot && !!i.productNameSnapshot));
  check('Order keeps the ROLL unit', ord.items.some((i) => i.productVariantId.endsWith('~ROLL') && i.unit === 'ROLL' && i.variantSnapshot.unit === 'ROLL'));


  console.log('Progressive disclosure, last quantity, material history');
  A.clearSearch(); A.openFamily('pf-thhn'); await wait(10);
  check('Configure shows one option at a time (Gauge first)', html().includes('Next: choose Gauge') && !html().includes('>Purple<') && !byId('family-qty'));
  A.selectFamilyVariant('gauge', '#10'); await wait(10);
  check('Choosing Gauge reveals Color next', html().includes('Next: choose Color') && html().includes('>Purple<'));
  A.closeFamily(); A.goto('fHome'); await wait(10);
  const rollId = ord.items.find((i) => i.productVariantId.endsWith('~ROLL')).productVariantId;
  check('Recently Used shows the last quantity ("Last: ... ROLL")', html().includes('Last: ' + ord.items.find((i) => i.productVariantId === rollId).quantity + ' ROLL'));
  ui.cart = []; A.quickAddToCart(rollId); await wait(10);
  check('Quick add re-adds the last quantity, not 1', ui.cart[0].qty === ord.items.find((i) => i.productVariantId === rollId).quantity);
  ui.cart = [];
  A.openProjectWorkspace('proj1'); A.setWorkspaceTab('materials'); await wait(10);
  check('Project Materials tab shows material history by exact variant', html().includes('Material history') && html().includes('#12 · Black · Stranded'));
  A.goto('fHome'); await wait(10);   // back to Home so the next block uses the bottom navigation

  console.log('My Orders, Reorder, Job Kits');
  await click('Orders');
  check('My Orders lists the order', html().includes(ord.id));
  await click('Reorder');
  check('Reorder restores identical lines', ui.screen === 'fCart' && ui.cart.length === ord.items.length &&
    ui.cart.every((c, i) => c.productId === ord.items[i].productVariantId && c.qty === ord.items[i].quantity));
  ui.cart = []; A.fNavTo('orders', 'fMyOrders'); await wait(10);
  await click('Save as Job Kit');
  await type(byId('savekit-name'), 'Gate 3 Kit');
  await click('Save kit');
  check('Order saved as a personal Job Kit', db.JOB_KITS.some((k) => k.name === 'Gate 3 Kit' && k.type === 'Personal'));
  A.goto('fJobKits'); await wait(10);
  check('Suggested materials are labeled as not AI', html().includes('a simple history rule, not AI'));
  await click('Panel Installation');
  await click('Add kit to material request');
  check('Company kit added to the request', ui.screen === 'fCart' && ui.cart.length > 0);
  ui.cart = []; A.goto('fCreateKit'); await wait(10);
  await type(byId('nk-name'), 'Rough-In Test');
  await type(byId('nk-search-input'), 'mud ring');
  await click('Choose');
  check('Configure sheet opens in kit mode', html().includes('Add to kit'));
  await click('1-Gang'); await click('1/2"'); await click('4" Square');
  await click('Add to kit'); await click('Save kit');
  check('Create Job Kit saves a configured item', db.JOB_KITS.some((k) => k.name === 'Rough-In Test' && k.materials[0].productId.startsWith('pf-mudring::')));

  console.log('Projects and team');
  A.fNavTo('projects', 'fProjects'); await wait(10);
  await click('Open project');
  for (const tab of ['Materials', 'Orders', 'Deliveries', 'Team', 'Overview']) await click(tab);
  check('Workspace renders every tab', ui.screen === 'fProjectWorkspace' && html().includes('Recent activity'));
  A.goto('fAddProject'); await wait(10);
  await type(byId('ap-name'), '7 Fairfield Rd'); await type(byId('ap-address'), '1 Test St');
  await click('Create project');
  check('Duplicate project warning appears', !!ui.duplicateWarning);
  await click('Create anyway');
  const proj = db.PROJECTS[db.PROJECTS.length - 1];
  check('Project created with the Foreman membership', db.MEMBERSHIPS.some((m) => m.projectId === proj.id && m.userId === ui.currentUser.id && m.projectRole === 'FOREMAN'));
  await click('Team'); await click('Add team member');
  const line = [...W.document.querySelectorAll('.sheet .checkline')].find((l) => /Journeyman|Apprentice/.test(l.textContent));
  line.querySelector('input').dispatchEvent(new W.MouseEvent('click', { bubbles: true })); await wait(10);
  await click('Add to project');
  const member = db.MEMBERSHIPS.find((m) => m.projectId === proj.id && m.userId !== ui.currentUser.id);
  check('Member added as View Only', member && member.permissionLevel === 'VIEWER');
  await click('Can Request Materials');
  check('Permission change asks for confirmation', !!ui.permissionChangeConfirm);
  await click('Give access');
  check('Permission changed without duplicating the membership', member.permissionLevel === 'CAN_EDIT' &&
    db.MEMBERSHIPS.filter((m) => m.projectId === proj.id && m.userId === member.userId && m.status === 'ACTIVE').length === 1);

  console.log('Journeyman and Apprentice permissions');
  await login('field', 'John Martinez', '2211');
  A.selectProject('proj1'); await wait(10);
  check('Journeyman can request on 7 Fairfield Rd', html().includes('Journeyman · Can Request Materials'));
  A.selectProject('proj2'); await wait(10);
  check('Journeyman is View Only on 12 Lincoln Ave', html().includes('Journeyman · View Only'));
  A.openFamily('pf-thhn'); A.selectFamilyVariant('gauge', '#12'); A.selectFamilyVariant('color', 'Black'); A.selectFamilyVariant('conductor', 'Stranded'); await wait(10);
  check('View Only: Add button is disabled', W.document.querySelector('.sheet .btn-primary').disabled === true);
  A.addFamilyToCart(); await wait(10);
  check('View Only: adding is refused even when called directly', ui.cart.length === 0);
  A.closeFamily();
  ui.cart = [{ productId: 'wc1', qty: 5, brandIdx: 0 }];
  const n0 = db.REQUESTS.length; A.goto('fOrderForm'); A.sendOrder(); await wait(550);
  check('View Only: submitting is refused even with a forced cart', db.REQUESTS.length === n0);
  ui.cart = [];

  console.log('Warehouse Manager: pack, shortage, dispatch');
  await login('warehouse', 'Ana', '0000');
  check('Manager home shows incoming requests', ui.screen === 'mHome' && html().includes('Incoming requests'));

  const seedOrder = db.REQUESTS.find((o) => o.id === 'ORD-1001');
  const emtLine = seedOrder.items.find((i) => i.legacyProductId === 'cn1');
  const emtBefore = M.availableQty(emtLine.productVariantId);
  A.openOrder('ORD-1001'); await wait(10);
  A.toggleItemCollected('ORD-1001', emtLine.id); await wait(10);
  check('Packing a migrated seed-order line draws from the variant stock', M.availableQty(emtLine.productVariantId) === emtBefore - emtLine.quantity && M.availableQty('cn1') === M.availableQty(emtLine.productVariantId));
  check('Warehouse sees the exact variant on a migrated seed order', html().includes('EMT Conduit') && (html().includes('3/4&quot;') || html().includes('3/4"')));
  await TAP(); A.toggleItemCollected('ORD-1001', emtLine.id); await wait(10);
  // Legacy (pre-v5) orders keep the Phase 2 shortage flow on the checklist.
  const lsLine = seedOrder.items[8]; zeroStock(lsLine.productVariantId);
  A.closeOrder(); A.openOrder('ORD-1001'); await wait(10);
  await click('Mark short');
  check('Legacy order: shortage recorded; progress shows the warning, not a clean pack',
    lsLine.shortQuantity > 0 && html().includes('short — not a complete pack') && html().includes('progress-fill warning'));
  A.closeOrder(); await wait(10);
  // The quick-added Recently Used line is now a migrated variant, not a legacy id.
  const legacy = ord.items[ord.items.length - 1];
  check('Quick add from Recently Used added a configured variant', legacy.productVariantId.includes('::'));
  A.openOrder(ord.id); await wait(10);
  check('v5 order: every line is picked from its own reservation, so there is nothing to mark short',
    WV(ord).items.every((i) => i.reservedQuantity >= i.quantity) && !html().includes('Mark short') && html().includes(' reserved'));
  let guard = 0;
  while (WV(ord).items.some((i) => !i.collected) && guard++ < 8) {
    const open = [...W.document.querySelectorAll('.sheet button.check-item')].find((b) => b.querySelector('.checkbox:not(.on)'));
    open.dispatchEvent(new W.MouseEvent('click', { bubbles: true })); await wait(10);
  }
  check('All lines picked: order is Packed', STAGE(ord) === 'PACKED');
  const rollLine = ord.items.find((i) => i.productVariantId.endsWith('~ROLL'));
  check('Warehouse sees the exact configuration and unit (' + rollLine.quantity + ' ROLL)',
    html().includes('<b>' + rollLine.quantity + ' ROLL</b>') && html().includes('#12 · Black · Stranded'));
  A.markShipped(ord.id); await wait(10);
  check('Skipping a step (Packed -> Shipped) is refused', STAGE(ord) === 'PACKED');
  await click('Mark as ready to ship');
  await click('Mark as shipped');
  check('Packed -> Ready to Ship -> Shipped', STAGE(ord) === 'SHIPPED' && !!WV(ord).shippedAt);
  await click('Find suppliers');
  check('Supplier estimates open, clearly labeled illustrative (not supplier records)', html().includes('Illustrative estimates only') && html().includes('not your company'));
  A.closeSuppliers();
  A.goto('mInventory'); await wait(10);
  check('Restock shows the shortage', html().includes('Restock') && html().includes('Short '));
  await type(byId('inv-search-input'), 'thhn');
  check('Inventory search finds the configured THHN stock', html().includes('#12 · Black · Stranded'));
  // a THHN variant that still has plenty of stock at this point of the flow
  const thhn = W.__ANT.I.stockedProductIds().find((id) => id.startsWith('pf-thhn::') && !id.endsWith('~ROLL') && M.availableQty(id) >= 100), invBefore = M.availableQty(thhn), movBefore = db.MATERIAL_MOVEMENTS.length;
  A.openInventoryDetail(thhn); await wait(10);
  check('Manager opens the inventory detail (available / picking / packed / physical)', html().includes('Physical in warehouse') && html().includes('Adjust inventory'));
  await click('Adjust inventory'); await click('Remove');
  const aq = byId('adj-qty'); aq.setAttribute('data-mark', 'a'); await type(aq, '4'); await type(byId('adj-qty'), '42');
  check('Adjustment quantity keeps the same input while typing', byId('adj-qty').getAttribute('data-mark') === 'a' && html().includes((invBefore - 42).toLocaleString()));
  await click('Save adjustment');
  check('An adjustment without a reason is refused', html().includes('Choose a reason for this adjustment.') && M.availableQty(thhn) === invBefore && db.MATERIAL_MOVEMENTS.length === movBefore);
  const sel = byId('adj-reason'); sel.value = 'PHYSICAL_COUNT_CORRECTION'; sel.dispatchEvent(new W.Event('change', { bubbles: true })); await wait(10);
  await TAP(); await click('Save adjustment');
  check('Manager adjusts stock through the ledger (-42, one movement, reason kept)', M.availableQty(thhn) === invBefore - 42 && db.MATERIAL_MOVEMENTS.length === movBefore + 1 &&
    db.MATERIAL_MOVEMENTS[db.MATERIAL_MOVEMENTS.length - 1].movementType === 'INVENTORY_ADJUSTMENT_OUT' && db.MATERIAL_MOVEMENTS[db.MATERIAL_MOVEMENTS.length - 1].reasonCode === 'PHYSICAL_COUNT_CORRECTION');
  check('The detail shows the adjustment in Recent Activity', html().includes('Inventory adjusted -42 FT'));
  A.closeInventoryDetail(); await wait(10);
  A.openOrder(ord.id); await wait(10); await click('Mark as completed');
  check('Shipped -> Completed', STAGE(ord) === 'COMPLETED');

  console.log('Warehouse Worker: Packing Mode');
  await login('field', 'Carlos', '4827');
  // Ground screws are stocked by the BOX and lever connectors by the PACK (see seeded stock).
  A.openFamily('pf-ground-screw'); A.selectFamilyVariant('size', '10-32 x 3/8"'); A.selectFamilyUnit('BOX'); await wait(5); A.addFamilyToCart();
  A.openFamily('pf-lever'); A.selectFamilyVariant('ports', '3-Port'); A.selectFamilyUnit('PACK'); await wait(5); A.addFamilyToCart();
  const ord2 = await sendCurrentCart();
  await login('warehouse', 'Michael Torres', '8899');
  check('Worker home lists orders to pack', ui.screen === 'whHome' && html().includes('Start packing'));
  check('Worker cannot edit stock', (() => { const before = JSON.stringify([db.INVENTORY_BALANCES, db.MATERIAL_MOVEMENTS]); const r = W.__ANT.S.Inv.adjustInventory(ui.currentUser, { productVariantId: 'pf-thhn::#12|Black|Stranded', direction: 'IN', quantity: 1, reasonCode: 'FOUND_STOCK' }); return r.error === 'forbidden' && JSON.stringify([db.INVENTORY_BALANCES, db.MATERIAL_MOVEMENTS]) === before; })());
  A.startPackingMode(ord2.id); await wait(10);
  check('Packing Mode shows Allocated, Location and Reserved (v5)', html().includes('pm-stats') && html().includes('Allocated') && html().includes('Reserved'));
  const first = ui.packingIndex;
  await click('Skip for now');
  check('Skip moves to the next material', ui.packingIndex !== first);
  await click('Pick ');
  check('Pick collects the current material from its reservation', WV(ord2).items.some((i) => i.collected));
  await TAP();
  await click('Pick ');
  check('Packing complete screen appears', html().includes('Packing complete'));
  A.exitPackingMode(); A.openOrder(ord2.id); await wait(10);
  check('Worker has no dispatch or sourcing buttons', !html().includes('Mark as ready to ship') && !html().includes('Find suppliers'));
  A.closeOrder();

  console.log('Delivery confirmation');
  await login('warehouse', 'Ana', '0000');
  A.openOrder(ord2.id); await wait(10);
  await click('Mark as ready to ship'); await click('Mark as shipped'); await click('Mark as completed');
  await login('field', 'Carlos', '4827');
  A.openProjectWorkspace('proj1'); A.setWorkspaceTab('deliveries'); await wait(10);
  check('Deliveries tab asks for confirmation', html().includes('Needs confirmation'));
  await click('Did everything arrive?');
  await click('Something is missing');
  await type(W.document.querySelector('#delivery-report-rows input'), '0');
  check('Missing quantity updates live', html().includes('Missing:'));
  await click('Submit');
  check('Missing items recorded as a delivery issue', db.REQUESTS.some((o) => o.fieldConfirmed && o.deliveryIssues && o.deliveryIssues.length));
  // Regression: two projects share the name "7 Fairfield Rd". Requests are keyed by
  // project id, so the second one belongs to the project Carlos created and switched to,
  // not to whichever project happens to have the same name.
  check('Duplicate-named projects keep separate requests (project id, not name)',
    ord2.projectId === proj.id && ord.projectId === 'proj1' && proj.name === '7 Fairfield Rd');
  A.openProjectWorkspace(ord2.projectId); A.setWorkspaceTab('deliveries'); await wait(10);
  await click('Did everything arrive?');
  await click('Yes, everything arrived');
  check('"Everything arrived" confirmation recorded', db.REQUESTS.filter((o) => o.fieldConfirmed && !o.deliveryIssues).length >= 1);

  console.log('Phase 1: audit trail, notifications, derived statuses, session');
  {
    const S = W.__ANT.S;
    const actions = new Set(db.AUDIT_EVENTS.map((e) => e.action));
    ['LOGIN', 'LOGOUT', 'PROJECT_SWITCHED', 'PROJECT_CREATED', 'MATERIAL_REQUEST_SUBMITTED', 'REQUEST_STATUS_CHANGED',
      'TEAM_MEMBER_ADDED', 'PERMISSION_CHANGED', 'DELIVERY_CONFIRMED', 'DELIVERY_ISSUE_REPORTED']
      .forEach((a) => check('Audit event recorded: ' + a, actions.has(a)));
    const SYSTEM_ACTIONS = ['INVENTORY_LEDGER_STARTED', 'REQUEST_ALLOCATION_STARTED', 'ALLOCATION_CREATED', 'MATERIAL_RESERVED', 'FULFILLMENT_CREATED', 'ALLOCATION_RELEASED', 'MATERIAL_UNRESERVED',
      'PURCHASING_STARTED', 'PURCHASE_REQUIREMENT_CREATED', 'PURCHASE_REQUIREMENT_RELEASED', 'FULFILLMENT_CREATED_FOR_OUTSTANDING_DEMAND', 'PURCHASED_MATERIAL_CONVERTED_TO_WAREHOUSE_ALLOCATION'];
    check('Every audit event has company, user, role and time (system events only for ledger start and automatic allocation)', db.AUDIT_EVENTS.every((e) => e.companyId && e.timestamp > 0 &&
      (e.userId ? !!e.userRole : SYSTEM_ACTIONS.indexOf(e.action) !== -1 && e.actorType === 'SYSTEM')));
    const perm = db.AUDIT_EVENTS.find((e) => e.action === 'PERMISSION_CHANGED');
    check('Permission change audit keeps before, after and project', perm.before.permissionLevel === 'VIEWER' && perm.after.permissionLevel === 'CAN_EDIT' && perm.projectId === proj.id);
    const sub = db.AUDIT_EVENTS.find((e) => e.action === 'MATERIAL_REQUEST_SUBMITTED' && e.entityId === ord.id);
    check('Request submission is audited against the request and its project', !!sub && sub.projectId === ord.projectId && sub.after.status === 'SUBMITTED');
    check('Fulfillment status changes are audited with before and after', db.AUDIT_EVENTS.some((e) => e.action === 'FULFILLMENT_STATUS_CHANGED' && e.entityType === 'Fulfillment' &&
      e.after.requestId === ord.id && e.before.status === 'READY' && !e.before.dispatchStatus && e.after.dispatchStatus === 'SHIPPED'));
    check('Taps and keystrokes are not audited (' + db.AUDIT_EVENTS.length + ' events for the whole session)', db.AUDIT_EVENTS.length < 100);

    const mgrIds = db.USERS.filter((u) => u.primaryRole === 'WAREHOUSE_MANAGER').map((u) => u.id);
    check('Warehouse managers are notified of a new request', mgrIds.length === 2 && mgrIds.every((id) => S.Ntf.notificationsForUser(id).some((n) => n.type === 'FULFILLMENT_CREATED' && n.entityId === ord.id)));
    check('The requester is notified when materials ship', S.Ntf.notificationsForUser('f1').some((n) => n.type === 'REQUEST_SHIPPED' && n.entityId === ord.id));
    check('A delivery issue notifies the warehouse', db.NOTIFICATIONS.some((n) => n.type === 'DELIVERY_ISSUE' && mgrIds.indexOf(n.userId) !== -1));
    check('A notification stays unread until marked read', (() => { const n = S.Ntf.notificationsForUser('f1')[0]; const b = S.Ntf.unreadCount('f1'); S.Ntf.markRead(n.id, 'f1'); return S.Ntf.unreadCount('f1') === b - 1; })());
    check('The notification center is not shown yet (module not built)', !S.Co.isFeatureEnabled('company1', 'notificationsCenter'));

    check('Delivered request with a shortage is PARTIALLY_FULFILLED, not FULFILLED', S.Req.requestStatusOf(ord) === 'PARTIALLY_FULFILLED');
    check('Delivered request: fulfillment READY; shipment ISSUE (short on arrival) vs RECEIVED (complete)', S.Req.fulfillmentStatusOf(ord) === 'READY' && S.Req.shipmentStatusOf(ord) === 'ISSUE' && S.Req.shipmentStatusOf(ord2) === 'RECEIVED');
    check('Receipt status follows what the jobsite reported', S.Req.receiptStatusOf(ord) === 'RECEIVED_WITH_ISSUES' && S.Req.receiptStatusOf(ord2) === 'RECEIVED_COMPLETE');
    check('A new request is allocated and PROCESSING, its fulfillment not started, with no shipment or receipt yet', (() => {
      const r = S.Wf.submitRequest(db.USERS.find((x) => x.id === 'f1'), { projectId: 'proj1', priority: 'NORMAL', neededBy: Date.now() + 86400000, lines: [{ productId: 'pf-thhn::#12|Red|Stranded', qty: 5 }] }, { submissionKey: 'sub-fresh' }).request;
      return S.Req.requestStatusOf(r) === 'PROCESSING' && S.Req.fulfillmentStatusOf(r) === 'ALLOCATED' && S.Req.shipmentStatusOf(r) === null && S.Req.receiptStatusOf(r) === null; })());
    check('Request lines carry a stable id and a unit', ord.items.every((i, k) => i.id === ord.id + '-L' + (k + 1) && !!i.unit));
    check('Nested lines expose their requestId through the service', S.Req.requestItems(ord).every((i) => i.requestId === ord.id));

    check('Session holds ids only', JSON.stringify(Object.keys(ui.session).sort()) === JSON.stringify(['currentCompanyId', 'currentProjectId', 'currentUserId']) &&
      Object.values(ui.session).every((v) => v === null || typeof v === 'string'));
    check('The current user is the user record itself, not a copy', ui.currentUser === db.USERS.find((u) => u.id === ui.session.currentUserId));
    check('The session is never written into saved data', !('session' in JSON.parse(W.localStorage.getItem('ant_prototype_data_v1'))));
    const snap = JSON.stringify([db.PROJECTS, db.REQUESTS, db.MEMBERSHIPS, db.JOB_KITS, db.INVENTORY_BALANCES, db.MATERIAL_MOVEMENTS]);
    A.logout(); await wait(10);
    check('Logout clears the session', ui.session.currentUserId === null && ui.session.currentProjectId === null && ui.currentUser === null);
    check('Logout leaves company, project, request and stock data untouched', JSON.stringify([db.PROJECTS, db.REQUESTS, db.MEMBERSHIPS, db.JOB_KITS, db.INVENTORY_BALANCES, db.MATERIAL_MOVEMENTS]) === snap);
    check('Every movement is explained: ANT posts opening balances and automatic reservations (with their source), everything else by a person', db.MATERIAL_MOVEMENTS.length > 0 &&
      db.MATERIAL_MOVEMENTS.every((m) => (m.actorType === 'SYSTEM' ? (m.movementType === 'OPENING_BALANCE' || (['RESERVE', 'UNRESERVE'].indexOf(m.movementType) !== -1 && m.metadata && m.metadata.source)) && !m.performedByUserId : !!db.USERS.find((u) => u.id === m.performedByUserId))));
    await login('field', 'Carlos', '4827');
  }

  console.log('Preferences and reload');
  A.fNavTo('profile', 'fProfile'); await wait(10);
  await click('Español');
  check('Spanish interface (nav shows "Inicio")', html().includes('Inicio'));
  await click('Grande');
  check('Large text applied', byId('root').classList.contains('text-large'));
  const saved = W.localStorage.getItem('ant_prototype_data_v1');
  W = boot(saved); await wait(80);
  ({ A, ui, db, C } = W.__ANT);
  const again = db.REQUESTS.find((o) => o.id === ord.id);
  check('After reload: order is still there', !!again);
  check('After reload: ROLL line still resolves as ROLL', C.getProduct(again.items.find((i) => i.productVariantId.endsWith('~ROLL')).productVariantId).unit === 'ROLL');
  check('After reload: new project persisted', db.PROJECTS.some((p) => p.address === '1 Test St'));
  for (let i = 0; i < 20 && !W.document.getElementById('root').classList.contains('text-large'); i++) await wait(25);   // let the first render finish
  check('After reload: language and text size persisted', JSON.parse(saved).prefs.language === 'es' && W.document.getElementById('root').classList.contains('text-large'));

  console.log('One-time cleanup of invented stock from older saved data');
  // Starts from REAL v1 data captured from the previous version of the app.
  const old = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', 'v1-react-saved.json'), 'utf8'));
  old.catalogVersion = undefined;
  old.inventory['pf-thhn::#6|Brown|Stranded'] = { qty: 2500, location: 'Main Warehouse' };
  old.inventory['pf-winenut::Small (2-3 #18-#12)|Orange|Standard'] = { qty: 2480, location: 'Unassigned' };
  W = boot(JSON.stringify(old)); await wait(80);
  ({ A, ui, db, C } = W.__ANT);
  check('Invented placeholder records from older versions are removed', !STK('pf-thhn::#6|Brown|Stranded', 'company1') && !STK('pf-winenut::Small (2-3 #18-#12)|Orange|Standard', 'company1'));
  check('Real migrated stock is kept', STK('pf-emt-connector::3/4"|Standard|Steel', 'company1') && STK('pf-emt-connector::3/4"|Standard|Steel', 'company1').qty > 0);
  await login('warehouse', 'Ana', '0000');
  A.openAdjust('pf-thhn::#6|Brown|Stranded'); A.setAdjustField('direction', 'IN'); A.setAdjustField('quantity', '300'); A.setAdjustField('reasonCode', 'FOUND_STOCK'); A.saveAdjustment(); await wait(10);
  check('Manager can start stocking a new variant (real record, starts from 0, no bin yet)', W.__ANT.I.availableQty('pf-thhn::#6|Brown|Stranded') === 300 &&
    STK('pf-thhn::#6|Brown|Stranded', 'company1').locationId === null && W.__ANT.I.inventoryLocation('pf-thhn::#6|Brown|Stranded') === 'Unassigned');
  const saved2 = W.localStorage.getItem('ant_prototype_data_v1');
  W = boot(saved2); await wait(80);
  check('A manager-created record survives later reloads (cleanup runs only once)', STK('pf-thhn::#6|Brown|Stranded', 'company1') && STK('pf-thhn::#6|Brown|Stranded', 'company1').qty === 300);

  /* ======================= Phase 1 architecture (fresh demo data) ======================= */
  console.log('Phase 1: architecture validation (every question answerable)');
  W = boot(); await wait(80);
  ({ A, ui, db, C } = W.__ANT);
  let S = W.__ANT.S, CFG = W.__ANT.CFG;
  const U = (id) => db.USERS.find((x) => x.id === id);
  {
    const j1 = U('j1');
    check('Q1 Which company a user belongs to', S.Co.getCompany(j1.companyId).name === 'Ali Electric');
    check('Q2 Which projects a user belongs to (from memberships)', S.Sel.getProjectsForUser('j1').map((p) => p.id).sort().join() === 'proj1,proj2');
    check('Q3 Their role on each project', ['proj1', 'proj2'].every((pid) => S.Sel.getProjectMembership('j1', pid).projectRole === 'JOURNEYMAN'));
    check('Q4 Their permission on each project', S.Sel.getProjectPermission('j1', 'proj1') === 'CAN_EDIT' && S.Sel.getProjectPermission('j1', 'proj2') === 'VIEWER');
    check('Q5 What they can do on each project', S.Perm.canUser(j1, 'REQUEST_MATERIALS', { projectId: 'proj1' }) &&
      !S.Perm.canUser(j1, 'REQUEST_MATERIALS', { projectId: 'proj2' }) && !S.Perm.canUser(j1, 'MANAGE_PROJECT_TEAM', { projectId: 'proj1' }));
    check('Q6 Which warehouse is assigned to a project', S.Sel.getAssignedWarehouse('proj1').id === 'loc-wh-main' && S.Sel.getAssignedWarehouse('proj1').type === 'WAREHOUSE');
    check('Q7 Which jobsite location belongs to a project', S.Sel.getJobsiteLocation('proj1').type === 'JOBSITE' && S.Sel.getJobsiteLocation('proj1').projectId === 'proj1');
    const r = db.REQUESTS.find((x) => x.id === 'ORD-1001');
    check('Q8 Which company owns a request', r.companyId === 'company1');
    check('Q9 Which project owns a request', r.projectId === 'proj1' && S.Req.requestProjectName(r) === '7 Fairfield Rd');
    check('Q10 Which user created a request', r.requestedByUserId === 'f1' && S.Req.requesterName(r) === 'Carlos Rodriguez' && S.Req.requesterPhone(r) === '(555) 555-0123');
    check('Q11 Which catalog variant each request line is', db.REQUESTS.every((x) => x.items.every((it) => it.productVariantId.includes('::') && S.Cat.variantExists(it.productVariantId))));
    const path12 = S.Loc.locationPath(W.__ANT.I.inventoryLocationId('pf-thhn::#12|Black|Stranded', 'company1'));
    check('Q12 Where a material physically is (' + path12 + ')', path12 === 'Main Warehouse > Shelving > Shelf A-1');

    const co = db.COMPANIES[0];
    check('One demo company with type, settings and feature flags', db.COMPANIES.length === 1 && co.companyType === 'ELECTRICAL_CONTRACTOR' &&
      co.status === 'ACTIVE' && co.settings.defaultWarehouseId === 'loc-wh-main' && typeof co.features === 'object' && !('features' in co.settings));
    check('Every record carries its companyId', [db.USERS, db.PROJECTS, db.MEMBERSHIPS, db.LOCATIONS, db.REQUESTS, db.JOB_KITS].every((l) => l.every((x) => x.companyId === 'company1')));
    check('One users table: names split, canonical role, status (11 + the demo Project Manager + the demo Purchasing Manager)', db.USERS.length === 13 && db.USERS.every((x) => x.firstName && x.lastName &&
      x.name === x.firstName + ' ' + x.lastName && CFG.Roles.ROLES[x.primaryRole] && CFG.Roles.ROLES[x.primaryRole].workerType === x.workerType && x.status === 'ACTIVE'));
    check('No duplicate role fields left on users', db.USERS.every((x) => !('companyRole' in x) && !('baseRole' in x) && !('title' in x) && !('currentProject' in x)));
    check('Requests reference ids, never names', db.REQUESTS.every((x) => !('project' in x) && !('foremanId' in x) && !('foremanName' in x) && !('phone' in x) && (!('status' in x) || W.__ANT.CFG.Req.REQUEST_STATUSES.indexOf(x.status) !== -1)));
    const p1 = db.PROJECTS.find((x) => x.id === 'proj1');
    check('Projects: address split into street/city/state/ZIP, shown exactly as before', p1.address === '7 Fairfield Rd' && p1.city === 'Fairfield' &&
      p1.state === 'NJ' && p1.zipCode === '07004' && p1.status === 'ACTIVE' && 'projectNumber' in p1 && S.Proj.projectAddress(p1) === '7 Fairfield Rd, Fairfield, NJ 07004');
    const byType = (t) => db.LOCATIONS.filter((l) => l.type === t);
    check('Locations: 1 warehouse > zones > bins, and one jobsite per project', byType('WAREHOUSE').length === 1 && byType('JOBSITE').length === db.PROJECTS.length &&
      byType('WAREHOUSE_BIN').every((b) => S.Loc.getLocation(b.parentLocationId).type === 'WAREHOUSE_ZONE' && S.Loc.warehouseOf(b.id).id === 'loc-wh-main'));
    check('Stock points to real locations by id (no text labels)', db.INVENTORY_BALANCES.every((x) => !('location' in x) && !!S.Loc.getLocation(x.locationId)) && db.INVENTORY_ITEMS.every((x) => !!S.Loc.getLocation(x.primaryLocationId)));
    check('Memberships: canonical role, level and status', db.MEMBERSHIPS.every((m) => CFG.Roles.PROJECT_ROLES.includes(m.projectRole) && CFG.Roles.PERMISSION_LEVELS[m.permissionLevel] && m.status === 'ACTIVE' && !('active' in m)));
    check('Zero integrity problems on fresh demo data', S.Integrity.checkIntegrity(db).length === 0);
  }

  console.log('Phase 1: centralized capabilities (canUser)');
  {
    const can = (id, cap, projectId) => S.Perm.canUser(U(id), cap, projectId ? { projectId } : undefined);
    check('Foreman: request and manage the team on his projects', can('f1', 'REQUEST_MATERIALS', 'proj1') && can('f1', 'MANAGE_PROJECT_TEAM', 'proj1') && can('f1', 'MANAGE_PROJECT_TEAM', 'proj2'));
    check('Foreman: nothing on a project he is not on', !can('f1', 'VIEW_PROJECT', 'proj3') && !can('f1', 'REQUEST_MATERIALS', 'proj3'));
    check('Journeyman (Can Request): request and receive, not manage the team', can('j1', 'REQUEST_MATERIALS', 'proj1') && can('j1', 'CONFIRM_PROJECT_RECEIPT', 'proj1') && !can('j1', 'MANAGE_PROJECT_TEAM', 'proj1'));
    check('Apprentice (View Only): view, not request or receive', can('a1', 'VIEW_PROJECT', 'proj1') && can('a1', 'VIEW_MATERIALS', 'proj1') && !can('a1', 'REQUEST_MATERIALS', 'proj1') && !can('a1', 'CONFIRM_PROJECT_RECEIPT', 'proj1'));
    check('Warehouse Manager: orders, picking, stock, dispatch, sourcing', ['VIEW_WAREHOUSE_ORDERS', 'PICK_MATERIALS', 'MANAGE_INVENTORY', 'MANAGE_SHIPMENTS', 'SOURCE_MATERIALS'].every((c) => can('m1', c)));
    check('Warehouse Worker: pick and view only', can('m3', 'PICK_MATERIALS') && can('m3', 'VIEW_INVENTORY') && !can('m3', 'MANAGE_INVENTORY') && !can('m3', 'MANAGE_SHIPMENTS') && !can('m3', 'SOURCE_MATERIALS'));
    check('Warehouse roles have no field project access', !can('m1', 'REQUEST_MATERIALS', 'proj1') && !can('m1', 'VIEW_PROJECT', 'proj1'));
    check('Field roles have no warehouse capabilities', !can('f1', 'PICK_MATERIALS') && !can('f1', 'MANAGE_INVENTORY') && !can('j1', 'MANAGE_SHIPMENTS'));
    check('A project capability without a project is refused', !can('f1', 'REQUEST_MATERIALS'));
    check('Creating projects is a company-role capability', can('f1', 'CREATE_PROJECT') && !can('j1', 'CREATE_PROJECT') && !can('m1', 'CREATE_PROJECT'));
    check('Config: field roles carry no project capability company-wide', ['FOREMAN', 'JOURNEYMAN', 'APPRENTICE'].every((r) => [...CFG.Caps.ROLE_GRANTS[r]].every((c) => !CFG.Caps.PROJECT_SCOPED.has(c))));
    check('Config: every granted capability is defined', Object.values(CFG.Caps.ROLE_GRANTS).concat(Object.values(CFG.Caps.PERMISSION_GRANTS)).every((set) => [...set].every((c) => CFG.Caps.CAP[c] === c)));
    check('Config: permission levels only ever add rights', [...CFG.Caps.PERMISSION_GRANTS.VIEWER].every((c) => CFG.Caps.PERMISSION_GRANTS.CAN_EDIT.has(c)) &&
      [...CFG.Caps.PERMISSION_GRANTS.CAN_EDIT].every((c) => CFG.Caps.PERMISSION_GRANTS.FULL_CONTROL.has(c)));
    U('j1').status = 'INACTIVE';
    check('An inactive user can do nothing', !can('j1', 'VIEW_PROJECT', 'proj1'));
    U('j1').status = 'ACTIVE';
    db.COMPANIES.push(Object.assign(JSON.parse(JSON.stringify(db.COMPANIES[0])), { id: 'company-x', name: 'Other Electric' }));
    db.PROJECTS.push(Object.assign(JSON.parse(JSON.stringify(db.PROJECTS[0])), { id: 'proj-x', companyId: 'company-x', name: 'Foreign Job' }));
    db.MEMBERSHIPS.push({ id: 'mem-x', companyId: 'company-x', projectId: 'proj-x', userId: 'f1', projectRole: 'FOREMAN', permissionLevel: 'FULL_CONTROL', status: 'ACTIVE', assignedAt: 1, assignedBy: 'f1' });
    check('Company isolation: another company\'s project stays closed, even with a forged membership', !can('f1', 'VIEW_PROJECT', 'proj-x') && !can('f1', 'REQUEST_MATERIALS', 'proj-x'));
    check('The integrity check flags the cross-company membership', S.Integrity.checkIntegrity(db).some((p) => p.code === 'MEMBERSHIP_COMPANY' && p.entityId === 'mem-x'));
    db.MEMBERSHIPS.pop(); db.PROJECTS.pop(); db.COMPANIES.pop();
    const settings = db.COMPANIES[0].settings;
    settings.allowJourneymanRequests = false;
    check('Setting allowJourneymanRequests=false stops Journeyman requests only', !can('j1', 'REQUEST_MATERIALS', 'proj1') && can('j2', 'VIEW_PROJECT', 'proj1') && can('f1', 'REQUEST_MATERIALS', 'proj1'));
    settings.allowJourneymanRequests = true;
    settings.projectPermissionsEnabled = false;
    check('Setting projectPermissionsEnabled=false applies role defaults', S.Sel.getProjectPermission('j1', 'proj1') === 'VIEWER' && !can('j1', 'REQUEST_MATERIALS', 'proj1') && can('f1', 'MANAGE_PROJECT_TEAM', 'proj1'));
    settings.projectPermissionsEnabled = true;
    check('Settings restored: Journeyman can request again', can('j1', 'REQUEST_MATERIALS', 'proj1'));

    console.log('Phase 1: feature flags');
    check('Existing modules are on', ['materialRequests', 'jobKits', 'projectWorkspace', 'warehouseFulfillment', 'packingMode', 'deliveryConfirmation', 'supplierLookup'].every((k) => S.Co.isFeatureEnabled('company1', k)));
    check('Phase 3: approvals and allocation are implemented and on', S.Co.isFeatureEnabled('company1', 'approvals') && S.Co.isFeatureEnabled('company1', 'allocation'));
    check('Phase 4: purchasing is implemented and on', S.Co.isFeatureEnabled('company1', 'purchasing'));
    check('Future modules are off', [ 'advancedLogistics', 'returns', 'costTracking', 'analytics'].every((k) => !S.Co.isFeatureEnabled('company1', k)));
    check('Phase 2: inventory and the Material Ledger are on (the ledger cannot be switched off)', S.Co.isFeatureEnabled('company1', 'inventory') && S.Co.isFeatureEnabled('company1', 'materialLedger') &&
      (() => { const f = db.COMPANIES[0].features; f.materialLedger = false; const on = S.Co.isFeatureEnabled('company1', 'materialLedger'); f.materialLedger = true; return on; })());
    const features = db.COMPANIES[0].features;
    features.returns = true;
    check('Switching on a module that isn\'t built still shows nothing', !S.Co.isFeatureEnabled('company1', 'returns'));
    features.returns = false;
    await login('field', 'Carlos', '4827');
    check('Job Kits rail shows while the module is on', html().includes('Job Kits'));
    features.jobKits = false; A.goto('fHome'); await wait(10);
    check('Turning a module off hides it', !html().includes('Job Kits'));
    features.jobKits = true; A.goto('fHome'); await wait(10);
    check('Turning it back on restores it', html().includes('Job Kits'));
  }

  console.log('TEST C: a permission change on Project A never affects Project B');
  {
    // Carlos leads both 7 Fairfield Rd (proj1) and 12 Lincoln Ave (proj2); John is on both.
    A.openProjectWorkspace('proj2'); A.setWorkspaceTab('team'); await wait(10);
    A.requestPermissionChange('proj2', 'j1', 'CAN_EDIT'); await wait(5); await click('Give access');
    check('TEST C: Project B (12 Lincoln Ave) John now Can Request Materials', S.Sel.getProjectPermission('j1', 'proj2') === 'CAN_EDIT');
    check('TEST C: Project A (7 Fairfield Rd) unchanged', S.Sel.getProjectPermission('j1', 'proj1') === 'CAN_EDIT');
    A.openProjectWorkspace('proj1'); A.setWorkspaceTab('team'); await wait(10);
    A.requestPermissionChange('proj1', 'j1', 'VIEWER'); await wait(5); await click('Change to view only');
    check('TEST C: Project A John now View Only', S.Sel.getProjectPermission('j1', 'proj1') === 'VIEWER');
    check('TEST C: Project B still Can Request Materials', S.Sel.getProjectPermission('j1', 'proj2') === 'CAN_EDIT');
    check('TEST C: still exactly one active membership per project', ['proj1', 'proj2'].every((pid) => db.MEMBERSHIPS.filter((m) => m.userId === 'j1' && m.projectId === pid && m.status === 'ACTIVE').length === 1));
    check('TEST C: each change is audited against its own project', db.AUDIT_EVENTS.filter((e) => e.action === 'PERMISSION_CHANGED').map((e) => e.projectId).sort().join() === 'proj1,proj2');
    await login('field', 'John Martinez', '2211');
    A.selectProject('proj1'); await wait(10);
    check('TEST C: John sees View Only on Project A', html().includes('Journeyman · View Only'));
    A.selectProject('proj2'); await wait(10);
    check('TEST C: John sees Can Request Materials on Project B', html().includes('Journeyman · Can Request Materials'));
    check('Guard: a Journeyman cannot change anyone\'s permission', S.Proj.setProjectPermission(U('j1'), 'proj1', 'a1', 'CAN_EDIT') === null);
    check('Guard: a Journeyman can never be given Full Control', S.Proj.setProjectPermission(U('f1'), 'proj1', 'j1', 'FULL_CONTROL') === null);
    check('Guard: a Foreman cannot change his own permission', S.Proj.setProjectPermission(U('f1'), 'proj1', 'f1', 'VIEWER') === null);
    check('Guard: a Foreman cannot change another project lead', S.Proj.setProjectPermission(U('f1'), 'proj2', 'f2', 'VIEWER') === null);
    check('Guard: only a lead can add team members', S.Proj.addTeamMembers(U('j1'), 'proj2', { a2: 'VIEWER' }).length === 0);
  }

  console.log('Acceptance tests A to L (fresh demo data)');
  W = boot(); await wait(80);
  ({ A, ui, db, C } = W.__ANT); S = W.__ANT.S; CFG = W.__ANT.CFG;
  {
    await click("I'm on the Field Team"); await click('Carlos'); for (const d of '4827') await click(d); await wait(15);
    check('TEST A: Foreman login lands on Field Home with user, company and project in session', ui.screen === 'fHome' &&
      ui.session.currentUserId === 'f1' && ui.session.currentCompanyId === 'company1' && ui.session.currentProjectId === 'proj1' && html().includes('7 Fairfield Rd'));
    check('TEST A: dev whoami reports user, company, project, role, permission, schema', (() => { const w = S.Dev.whoami();
      return w.user.id === 'f1' && w.company.name === 'Ali Electric' && w.project.id === 'proj1' && w.projectRole === 'FOREMAN' && w.projectPermission === 'FULL_CONTROL' && w.schemaVersion === 6 && w.user.companyRoles.join() === 'FOREMAN'; })());

    const fromMemberships = db.MEMBERSHIPS.filter((m) => m.userId === 'f1' && m.status === 'ACTIVE').map((m) => m.projectId).sort().join();
    check('TEST B: a user\'s projects come from memberships only', S.Sel.getProjectsForUser('f1').map((p) => p.id).sort().join() === fromMemberships);
    const mem2 = db.MEMBERSHIPS.find((m) => m.userId === 'f1' && m.projectId === 'proj2');
    mem2.status = 'REMOVED';
    check('TEST B: removing a membership removes the project and its access', !S.Sel.getProjectsForUser('f1').some((p) => p.id === 'proj2') && !S.Perm.canViewProject(ui.currentUser, 'proj2'));
    mem2.status = 'ACTIVE';
    A.openSwitcher(); await wait(10);
    check('TEST B: the project switcher lists exactly those projects', html().includes('12 Lincoln Ave') && !html().includes('84 Oak Lane') && !html().includes('25 Main St'));
    A.closeSwitcher(); await wait(5);

    byId('home-search-input').setAttribute('data-mark', 'keep');
    for (const v of ['E', 'EM', 'EMT']) await type(byId('home-search-input'), v);
    check('TEST D: search "EMT" shows results and keeps the same input (keyboard stays open)', byId('home-search-input').getAttribute('data-mark') === 'keep' &&
      html().includes('for "EMT"') && html().includes('EMT Conduit') && C.searchProducts('EMT')[0].id === 'cn-family-emt');
    for (const v of ['3', '3/', '3/4']) await type(byId('home-search-input'), v);
    check('TEST D: search "3/4" shows results and keeps the same input', byId('home-search-input').getAttribute('data-mark') === 'keep' && html().includes('for "3/4"') && C.searchProducts('3/4').length > 0);

    A.clearSearch(); A.openFamily('cn-family-emt'); await wait(10);
    const fam = C.familyById('cn-family-emt');
    let guardE = 0;
    while (!C.familySelectionComplete(fam, ui.modalFamilySelection) && guardE++ < 6) {
      const v = fam.variants.find((x) => !ui.modalFamilySelection[x.key]);
      A.selectFamilyVariant(v.key, v.key === 'size' ? '3/4"' : 0); await wait(5);
    }
    check('TEST E: product detail configures an exact variant and enables Add', ui.modalFamilySelection.size === '3/4"' &&
      W.document.querySelector('.sheet .btn-primary').disabled === false && html().includes('EMT Conduit'));
    await click('Add to material request');
    A.quickAddToCart(ui.currentUser.recentlyUsed[0]); await wait(5);
    const before = db.REQUESTS.length;
    const newReq = await sendCurrentCart('High');
    check('TEST F: request created with company, project, requester, priority, lines and units', db.REQUESTS.length === before + 1 &&
      newReq.companyId === 'company1' && newReq.projectId === 'proj1' && newReq.requestedByUserId === 'f1' && newReq.priority === 'HIGH' &&
      newReq.items.length === 2 && newReq.items.every((i) => i.id && i.requestId === newReq.id && i.unit && S.Cat.variantExists(i.productVariantId)));
    check('TEST F: submission audited and warehouse notified', db.AUDIT_EVENTS.some((e) => e.action === 'MATERIAL_REQUEST_SUBMITTED' && e.entityId === newReq.id) &&
      S.Ntf.notificationsForUser('m1').some((n) => n.entityId === newReq.id));

    await login('warehouse', 'Ana', '0000');
    check('TEST G: the warehouse sees the new request', S.Req.requestsForCompany('company1').includes(newReq) && ui.screen === 'mHome' && html().includes('Incoming requests'));
    A.openOrder(newReq.id); await wait(10);
    check('TEST G: the order shows requester and project read from their own records', html().includes('Carlos Rodriguez') && html().includes('7 Fairfield Rd') && html().includes('(555) 555-0123'));
    const [lineA, lineB] = newReq.items;
    A.toggleItemCollected(newReq.id, lineA.id); await wait(10);
    check('TEST H: checklist progress and status update (1 of 2, Partially Packed)', STAGE(newReq) === 'PARTIALLY_PACKED' && html().includes('1 of 2'));
    A.toggleItemCollected(newReq.id, lineB.id); await wait(10);
    check('TEST H: every line collected: Packed and the bar completes', STAGE(newReq) === 'PACKED' && html().includes('2 of 2') && html().includes('progress-fill complete'));
    await click('Mark as ready to ship'); await click('Mark as shipped'); await click('Mark as completed');
    A.goto('mHistory'); await wait(10);
    check('TEST I: order history lists the completed request', STAGE(newReq) === 'COMPLETED' && html().includes('1 completed order') && html().includes('7 Fairfield Rd'));

    await login('field', 'Carlos', '4827');
    A.fNavTo('orders', 'fMyOrders'); await wait(10);
    check('TEST J: the completed request appears under previous orders', html().includes(newReq.id));
    A.reorder(newReq.id); await wait(10);
    check('TEST J: quick reorder restores the same lines and quantities', ui.screen === 'fCart' && ui.cart.length === newReq.items.length &&
      ui.cart.every((c, k) => c.productId === newReq.items[k].productVariantId && c.qty === newReq.items[k].quantity));
    ui.cart = [];

    A.logout(); await wait(10);
    check('TEST K: logout returns to the start screen and clears the session', ui.screen === 'roleSelect' && ui.session.currentUserId === null);
    A.chooseRole('foreman'); await wait(5); A.pickProfile('foreman', 'm1'); await wait(5);
    check('TEST K: a warehouse profile cannot be opened from the Field entry', ui.screen === 'foremanPicker' && !ui.pendingProfile);
    A.back(); await wait(5);
    await login('field', 'Carlos', '4827');
    const stock = JSON.stringify([db.INVENTORY_BALANCES, db.MATERIAL_MOVEMENTS]);
    S.Inv.adjustInventory(ui.currentUser, { productVariantId: 'pf-thhn::#12|Black|Stranded', direction: 'IN', quantity: 1, reasonCode: 'FOUND_STOCK' }); A.markReadyToShip('ORD-1002'); await wait(5);
    check('TEST K: a field user cannot change stock or dispatch', JSON.stringify([db.INVENTORY_BALANCES, db.MATERIAL_MOVEMENTS]) === stock && db.REQUESTS.find((o) => o.id === 'ORD-1002').workflowStatus === 'PACKED');
    await login('warehouse', 'Ana', '0000');
    ui.cart = [{ productId: 'pf-thhn::#12|Black|Stranded', qty: 5, brandIdx: 0 }];
    const n1 = db.REQUESTS.length; A.goto('fOrderForm'); A.sendOrder(); await wait(550);
    check('TEST K: a warehouse user cannot submit field requests', db.REQUESTS.length === n1);
    check('TEST K: the service refuses it too, even when called directly', !!S.Req.createRequest(U('m1'), { projectId: 'proj1', neededBy: Date.now(), lines: [{ productId: 'pf-thhn::#12|Black|Stranded', qty: 1 }] }).error);
    ui.cart = [];

    await login('field', 'Carlos', '4827');
    const savedL = W.localStorage.getItem('ant_prototype_data_v1');
    W = boot(savedL); await wait(80);
    ({ A, ui, db, C } = W.__ANT); S = W.__ANT.S;
    check('TEST L: after refresh the request, memberships and schema version persist', !!db.REQUESTS.find((o) => o.id === newReq.id) &&
      S.Sel.getProjectPermission('j1', 'proj1') === 'CAN_EDIT' && JSON.parse(savedL).schemaVersion === 6);
    check('TEST L: after refresh the app asks for a PIN again, with zero integrity problems', ui.screen === 'roleSelect' && S.Integrity.checkIntegrity(db).length === 0);
    if (S.Integrity.checkIntegrity(db).length) console.log('   integrity:', JSON.stringify(S.Integrity.checkIntegrity(db).slice(0, 4)));
  }

  console.log('TEST M: older saved data (schema v1) migrates without loss');
  const FIXTURES = [
    ['React v1', 'v1-react-saved.json', { users: 11, projects: 5, memberships: 12, requests: 4, kits: 7 }],
    ['HTML #2', 'v1-html-saved.json', { users: 11, projects: 5, memberships: 11, requests: 4, kits: 6 }],
  ];
  for (const [tag, file, n] of FIXTURES) {
    const raw = fs.readFileSync(path.join(__dirname, 'fixtures', file), 'utf8');
    const v1 = JSON.parse(raw);
    W = boot(raw); await wait(80);
    ({ A, ui, db, C } = W.__ANT); S = W.__ANT.S;
    const req = (id) => db.REQUESTS.find((x) => x.id === id);
    check('TEST M ' + tag + ': schema v1 detected and upgraded v1 -> v2 -> v3 -> v4 -> v5 -> v6', S.loadReport.migratedFrom === 1 && JSON.parse(W.localStorage.getItem(S.STORAGE_KEY)).schemaVersion === 6 &&
      db.MIGRATIONS.map((m) => m.from + '>' + m.to).join() === '1>2,2>3,3>4,4>5,5>6');
    check('TEST M ' + tag + ': the untouched original is kept as a backup', W.localStorage.getItem(S.backupKeyFor(1)) === raw);
    check('TEST M ' + tag + ': nothing lost (' + n.users + ' users, ' + n.projects + ' projects, ' + n.memberships + ' memberships, ' + n.requests + ' requests, ' + n.kits + ' kits)',
      // + the one fictional demo Project Manager v5 adds to the demo company (and their project memberships)
      db.USERS.filter((u) => u.id !== 'demo-pm1' && u.id !== 'demo-pur1').length === n.users && U('demo-pm1') && U('demo-pur1') && db.PROJECTS.length === n.projects && db.MEMBERSHIPS.filter((m) => m.userId !== 'demo-pm1').length === n.memberships && db.REQUESTS.length === n.requests && db.JOB_KITS.length === n.kits &&
      v1.foremen.concat(v1.managers).every((u) => !!U(u.id)) && v1.projects.every((p) => db.PROJECTS.some((x) => x.id === p.id && x.name === p.name)) &&
      v1.jobKits.every((k) => db.JOB_KITS.some((x) => x.id === k.id && x.materials.length === k.materials.length)));
    check('TEST M ' + tag + ': every request keeps its lines, quantities and notes', v1.orders.every((o) => { const r = req(o.id);
      return r && r.notes === o.notes && r.items.length === o.items.length && r.items.every((it, k) => it.quantity === o.items[k].qty && !!it.id && !!it.unit); }));
    check('TEST M ' + tag + ': request ownership resolved from names to ids', v1.orders.every((o) => { const r = req(o.id); const p = db.PROJECTS.find((x) => x.id === r.projectId);
      return p && p.name === o.project && r.requestedByUserId === o.foremanId && r.companyId === 'company1'; }));
    check('TEST M ' + tag + ': priorities and statuses normalized', v1.orders.every((o) => { const r = req(o.id);
      return r.priority === o.priority.toUpperCase() && r.workflowStatus === o.status.toUpperCase().replace(/ /g, '_'); }));
    check('TEST M ' + tag + ': per-project permissions preserved (Foremen keep full team control)', v1.memberships.every((m) => { const x = db.MEMBERSHIPS.find((y) => y.id === m.id);
      return x && x.status === 'ACTIVE' && x.permissionLevel === (m.projectRole === 'Foreman' ? 'FULL_CONTROL' : m.permissionLevel.toUpperCase()); }));
    check('TEST M ' + tag + ': roles mapped for every user', v1.foremen.every((u) => U(u.id).primaryRole === u.companyRole.toUpperCase()) &&
      v1.managers.every((u) => U(u.id).primaryRole === u.baseRole.toUpperCase()));
    check('TEST M ' + tag + ': remembered projects kept as ids', v1.foremen.every((u) => { const p = db.PROJECTS.find((x) => x.id === U(u.id).lastProjectId); return p && p.name === u.currentProject; }));
    check('TEST M ' + tag + ': every project got a jobsite and the main warehouse', db.PROJECTS.every((p) => !!S.Loc.jobsiteForProject(p.id) && p.assignedWarehouseId === 'loc-wh-main'));
    check('TEST M ' + tag + ': stock locations keep their names as bin locations', Object.keys(v1.inventory).every((k) => {
      const label = v1.inventory[k].location; const shown = W.__ANT.I.inventoryLocation(M.LEGACY_TO_VARIANT[k] || k, 'company1');
      return label === 'Unassigned' ? shown === 'Unassigned' : shown === label; }));
    check('TEST M ' + tag + ': zero integrity problems after migration', S.Integrity.checkIntegrity(db).length === 0);
    await login('field', 'John Martinez', '2211');
    check('TEST M ' + tag + ': sign-in works and reopens the remembered project', ui.screen === 'fHome' && ui.session.currentProjectId === 'proj1');
    await login('field', 'Carlos', '4827');
    A.goto('fAddProject'); await wait(5);
    A.setProjectField('name', 'Collision Check'); A.setProjectField('address', '1 New St'); A.reviewCreateProject(); await wait(10);
    const np = db.PROJECTS[db.PROJECTS.length - 1];
    check('TEST M ' + tag + ': a new project gets a fresh id (' + np.id + '), never an old one', np.name === 'Collision Check' && !v1.projects.some((p) => p.id === np.id));
    check('TEST M ' + tag + ': every id stays unique after new writes', ['USERS', 'PROJECTS', 'MEMBERSHIPS', 'REQUESTS', 'JOB_KITS', 'LOCATIONS', 'AUDIT_EVENTS', 'ACTIVITY']
      .every((col) => new Set(db[col].map((x) => x.id)).size === db[col].length));
    const once = W.localStorage.getItem(S.STORAGE_KEY);
    W = boot(once); await wait(80);
    ({ A, ui, db, C } = W.__ANT); S = W.__ANT.S;
    const saved = JSON.parse(once);
    check('TEST M ' + tag + ': loading the upgraded data again changes nothing (idempotent)', S.loadReport.migratedFrom === null &&
      [['users', 'USERS'], ['projects', 'PROJECTS'], ['memberships', 'MEMBERSHIPS'], ['materialRequests', 'REQUESTS'], ['locations', 'LOCATIONS'], ['jobKits', 'JOB_KITS']]
        .every(([k, col]) => JSON.stringify(saved[k]) === JSON.stringify(db[col])) && JSON.stringify(saved.inventoryBalances) === JSON.stringify(db.INVENTORY_BALANCES) && saved.materialMovements.length === db.MATERIAL_MOVEMENTS.length);
  }
  {
    const raw = fs.readFileSync(path.join(__dirname, 'fixtures', 'v1-html-saved.json'), 'utf8');
    W = boot(raw); await wait(80);
    ({ A, ui, db, C } = W.__ANT); S = W.__ANT.S;
    const r = db.REQUESTS.find((x) => x.id === 'ORD-1004');
    check('TEST M HTML #2: an old flat product id becomes its exact variant, keeping the old id', r.items.some((i) => i.legacyProductId === 'wd1' && i.productVariantId.includes('::') && S.Cat.variantExists(i.productVariantId)));
    check('TEST M HTML #2: the Apprentice upgraded in that session keeps Can Request Materials', S.Sel.getProjectPermission('a1', 'proj1') === 'CAN_EDIT');
    check('TEST M HTML #2: counters rebuilt from the data (project and id counters were never saved)', db.PROJECT_SEQ >= 101 && db.ID_SEQ >= 1011);
  }

  {
    // v1 matched names to the FIRST project with that name; the upgrade must do the same.
    const v1 = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', 'v1-react-saved.json'), 'utf8'));
    v1.projects.push(Object.assign({}, v1.projects[0], { id: 'proj-dup', createdAt: v1.projects[0].createdAt + 1 }));
    W = boot(JSON.stringify(v1)); await wait(80);
    ({ A, ui, db, C } = W.__ANT); S = W.__ANT.S;
    check('TEST M: with two same-named projects, old requests stay with the first one, exactly as in v1',
      db.REQUESTS.filter((r) => v1.orders.find((o) => o.id === r.id && o.project === '7 Fairfield Rd')).every((r) => r.projectId === 'proj1') &&
      U('f1').lastProjectId !== 'proj-dup');
    check('TEST M: the ambiguous name is recorded in the migration log', S.loadReport.migrationLog.some((m) => m.includes('Two projects are named "7 Fairfield Rd"')));
  }

  console.log('Phase 1: data integrity detection and safe repair');
  W = boot(); await wait(80);
  ({ A, ui, db, C } = W.__ANT); S = W.__ANT.S; CFG = W.__ANT.CFG;
  {
    db.MEMBERSHIPS.push({ id: 'mem-bad', companyId: 'company1', projectId: 'proj1', userId: 'ghost', projectRole: 'JOURNEYMAN', permissionLevel: 'VIEWER', status: 'ACTIVE', assignedAt: 1, assignedBy: null });
    db.REQUESTS.push(Object.assign(JSON.parse(JSON.stringify(db.REQUESTS[0])), { id: 'ORD-BAD', projectId: 'proj-missing' }));
    db.MEMBERSHIPS.push({ id: 'mem-dup', companyId: 'company1', projectId: 'proj1', userId: 'a1', projectRole: 'APPRENTICE', permissionLevel: 'FULL_CONTROL', status: 'ACTIVE', assignedAt: 2, assignedBy: 'f1' });
    const codes = S.Integrity.checkIntegrity(db).map((p) => p.code);
    check('Integrity detects a membership for an unknown user', codes.includes('MEMBERSHIP_USER'));
    check('Integrity detects a request for an unknown project', codes.includes('REQUEST_PROJECT'));
    check('Integrity detects a duplicate active membership', codes.includes('MEMBERSHIP_DUPLICATE'));
    check('Integrity detects a level too high for the role', codes.includes('MEMBERSHIP_LEVEL_TOO_HIGH'));
    db.MEMBERSHIPS.splice(-1, 1); db.REQUESTS.pop(); db.MEMBERSHIPS.splice(db.MEMBERSHIPS.findIndex((m) => m.id === 'mem-bad'), 1);
    db.LOCATIONS.splice(db.LOCATIONS.findIndex((l) => l.id === 'loc-site-proj1'), 1);
    db.MEMBERSHIPS.find((m) => m.userId === 'f1' && m.projectId === 'proj1').status = 'REMOVED';
    const beforeOthers = db.MEMBERSHIPS.filter((m) => m.userId !== 'f1').map((m) => m.permissionLevel).join();
    const fixes = S.Integrity.repairIntegrity(db);
    check('Repair recreates a missing jobsite', !!S.Loc.jobsiteForProject('proj1') && fixes.some((f) => f.includes('jobsite')));
    check('Repair restores the project creator\'s lead membership only', S.Sel.getProjectPermission('f1', 'proj1') === 'FULL_CONTROL' &&
      fixes.filter((f) => f.includes('membership')).length === 1 && db.MEMBERSHIPS.filter((m) => m.userId !== 'f1').map((m) => m.permissionLevel).join() === beforeOthers);
    check('After repair: zero problems', S.Integrity.checkIntegrity(db).length === 0);
  }

  console.log('Material Ledger movement builder (shape rules)');
  {
    const deps = { variantExists: S.Cat.variantExists };
    const valid = { companyId: 'company1', productVariantId: 'pf-thhn::#12|Black|Stranded', movementType: 'PICK', quantity: 10, unit: 'FT',
      fromLocationId: 'loc-wh-main-bin-shelf-a-1', toLocationId: 'loc-wh-main-bin-shelf-a-1', fromInventoryState: 'AVAILABLE', toInventoryState: 'PICKING', performedByUserId: 'm1' };
    const n0 = db.MATERIAL_MOVEMENTS.length;
    const ok = S.Ledger.createMaterialMovement(valid, deps);
    check('A valid movement is built with every ledger field', !!ok.movement && ['fulfillmentId', 'shipmentId', 'purchaseOrderId', 'returnId', 'reasonCode', 'requestItemId',
      'fromInventoryState', 'toInventoryState', 'reversalOfMovementId', 'metadata', 'timestamp'].every((k) => k in ok.movement));
    check('Invalid movements are refused (type, variant, quantity, locations, user)', [
      Object.assign({}, valid, { movementType: 'TELEPORT' }), Object.assign({}, valid, { productVariantId: 'not-a-variant' }), Object.assign({}, valid, { quantity: 0 }),
      Object.assign({}, valid, { fromLocationId: null }), Object.assign({}, valid, { performedByUserId: null }),
      Object.assign({}, valid, { toLocationId: 'loc-wh-main' }),                                  // a PICK never changes location
      Object.assign({}, valid, { fromInventoryState: 'SCRAP' }),                                  // PICK from SCRAP
      Object.assign({}, valid, { movementType: 'PACK' }),                                         // PACK must start from PICKING
      Object.assign({}, valid, { movementType: 'OPENING_BALANCE' }),                              // entries have no from location
    ].every((x) => !!S.Ledger.createMaterialMovement(x, deps).error));
    check('Building a movement saves nothing (only the ledger service posts)', db.MATERIAL_MOVEMENTS.length === n0);
  }

  console.log('Phase 1: central statuses and priorities');
  {
    check('Every workflow status has a label and a timeline stage', Object.keys(CFG.Stat.WORKFLOW).every((k) => CFG.Stat.WORKFLOW_STATUS[k] && CFG.Stat.WORKFLOW_STATUS[k].label && CFG.Stat.WORKFLOW_STATUS[k].stage >= 0));
    check('Legacy spellings normalize (status, priority, role, permission)', CFG.Stat.normalizeWorkflowStatus('Ready to Ship') === 'READY_TO_SHIP' &&
      CFG.Prio.normalizePriority('High') === 'HIGH' && CFG.Roles.normalizeRole('warehouse_manager') === 'WAREHOUSE_MANAGER' && CFG.Roles.normalizePermissionLevel('can_edit') === 'CAN_EDIT');
    check('Priority sort: Emergency, High, Normal, Low', ['LOW', 'EMERGENCY', 'NORMAL', 'HIGH'].map((p, i) => ({ priority: p, createdAt: i }))
      .sort(CFG.Prio.byPriorityThenNewest).map((x) => x.priority).join() === 'EMERGENCY,HIGH,NORMAL,LOW');
    check('Priority look unchanged (same CSS keys and labels)', CFG.Prio.priorityCss('HIGH') === 'High' && CFG.Prio.priorityLabel('EMERGENCY') === 'Emergency');
    check('Only implemented request statuses can reach the UI', Object.keys(CFG.Stat.REQUEST_STATUS).filter((k) => CFG.Stat.REQUEST_STATUS[k].implemented).join() === 'DRAFT,SUBMITTED,PENDING_APPROVAL,APPROVED,PROCESSING,PARTIALLY_FULFILLED,FULFILLED,CANCELLED');
    check('Dispatch transitions allow only the next step', CFG.Stat.WORKFLOW_TRANSITIONS.PACKED === 'READY_TO_SHIP' && !CFG.Stat.WORKFLOW_TRANSITIONS.PENDING);
  }


  /* ===================== HARDENING PASS: schema v3 ===================== */
  const MC = require('./fixtures/multi-company.cjs');
  const reboot = async (saved) => { W = boot(saved); await wait(80); ({ A, ui, db, C } = W.__ANT); S = W.__ANT.S; CFG = W.__ANT.CFG; };
  const persistNow = async () => { A.setLanguage(ui.language || 'en'); await wait(10); };   // any normal action saves
  const U2 = (id) => db.USERS.find((x) => x.id === id);
  const can2 = (u, cap, projectId) => S.Perm.canUser(U2(u), cap, projectId ? { projectId } : undefined);
  const problems = () => S.Integrity.checkIntegrity(db);
  const LEGACY_LINE_KEYS = ['productId', 'qty', 'brandIdx', 'configured', 'packedQty', 'shortQty'];
  const CANONICAL_LINE_KEYS = ['id', 'requestId', 'productVariantId', 'quantity', 'unit', 'productNameSnapshot', 'variantSnapshot', 'brandSnapshot', 'legacyProductId', 'collected', 'packedQuantity', 'shortQuantity'];
  const I2 = () => W.__ANT.I;
  const V12 = 'pf-thhn::#12|Black|Stranded';

  console.log('Hardening: fresh seed ends at schema v3');
  {
    await reboot(); await persistNow();
    const saved = JSON.parse(W.localStorage.getItem(S.STORAGE_KEY));
    check('Fresh demo data travels v1 -> v2 -> v3 -> v4 -> v5 -> v6', saved.schemaVersion === 6 && db.MIGRATIONS.map((m) => m.from + '>' + m.to).join() === '1>2,2>3,3>4,4>5,5>6');
    check('Fresh seed: 0 integrity problems', problems().length === 0);
    check('Every user has companyRoles containing primaryRole', db.USERS.every((u) => Array.isArray(u.companyRoles) && u.companyRoles.indexOf(u.primaryRole) !== -1));
    check('Every request line is canonical (all v3 fields, no legacy aliases stored)', db.REQUESTS.every((r) => r.items.every((i) => CANONICAL_LINE_KEYS.every((k) => k in i) && !LEGACY_LINE_KEYS.some((k) => k in i) && i.requestId === r.id)));
    check('Saved users store fullName once (no second editable name string)', saved.users.every((u) => u.fullName && !('name' in u)));
    check('Company 1 keeps its warehouse id (loc-wh-main), owned by it', db.COMPANIES[0].settings.defaultWarehouseId === 'loc-wh-main' && S.Loc.getLocation('loc-wh-main').companyId === db.COMPANIES[0].id);
    check('Stock is saved per company (ledger balances)', saved.inventoryBalances.length > 0 && saved.inventoryBalances.every((b) => db.COMPANIES.some((c) => c.id === b.companyId)) && !('inventory' in saved));
  }

  console.log('TEST v2 -> v3: a real saved Phase 1 (schema v2) payload');
  {
    const raw2 = fs.readFileSync(path.join(__dirname, 'fixtures', 'v2-react-saved.json'), 'utf8');
    const v2 = JSON.parse(raw2);
    await reboot(raw2);
    const saved3 = W.localStorage.getItem(S.STORAGE_KEY); const p3 = JSON.parse(saved3);
    const co = db.COMPANIES[0];
    check('v2: detected and upgraded v2 -> v3 -> v4 -> v5 -> v6', v2.schemaVersion === 2 && S.loadReport.migratedFrom === 2 && p3.schemaVersion === 6 &&
      db.MIGRATIONS.map((m) => m.from + '>' + m.to).join() === '1>2,2>3,3>4,4>5,5>6');
    check('v2: the untouched original is kept as a backup', W.localStorage.getItem(S.backupKeyFor(2)) === raw2);
    check('v2: users, projects, memberships, requests, kits, locations all preserved', ['users', 'projects', 'memberships', 'materialRequests', 'jobKits', 'locations']
      .every((k) => p3[k].filter((y) => ['demo-pm1', 'demo-pur1'].indexOf(y.id) === -1 && y.userId !== 'demo-pm1').length === v2[k].length && v2[k].every((x) => p3[k].some((y) => y.id === x.id))));
    check('v2: audit events and notifications preserved (+ ledger start, allocation start and purchasing start per company)', p3.auditEvents.length === v2.auditEvents.length + 3 * p3.companies.length &&
      p3.auditEvents.filter((e) => e.action === 'INVENTORY_LEDGER_STARTED').length === p3.companies.length && p3.auditEvents.filter((e) => e.action === 'REQUEST_ALLOCATION_STARTED').length === p3.companies.length && p3.notifications.length === v2.notifications.length &&
      v2.auditEvents.every((e) => p3.auditEvents.some((x) => x.id === e.id && x.action === e.action)) && v2.notifications.every((n) => p3.notifications.some((x) => x.id === n.id && x.userId === n.userId)));
    check('v2: every stock record kept as an AVAILABLE opening balance at its bin', Object.keys(v2.inventory).every((k) => STK(k, 'company1') && STK(k, 'company1').qty === v2.inventory[k].qty && STK(k, 'company1').locationId === v2.inventory[k].locationId));
    check('v2: the manager-stocked variant kept its 40 units', STK('pf-thhn::#6|Brown|Stranded', 'company1').qty === 40);
    check('v2: every line keeps its id, exact variant and quantity', v2.materialRequests.every((o) => { const r = db.REQUESTS.find((x) => x.id === o.id);
      return r && r.items.length === o.items.length && r.items.every((it, k) => it.id === o.items[k].id && it.productVariantId === o.items[k].productId && it.quantity === o.items[k].qty && it.unit === o.items[k].unit); }));
    check('v2: every line is canonical (legacy aliases gone)', db.REQUESTS.every((r) => r.items.every((i) => CANONICAL_LINE_KEYS.every((k) => k in i) && !LEGACY_LINE_KEYS.some((k) => k in i))));
    const o1 = db.REQUESTS.find((x) => x.id === 'ORD-1001'), o4 = db.REQUESTS.find((x) => x.id === 'ORD-1004'), o2 = db.REQUESTS.find((x) => x.id === 'ORD-1002');
    check('v2: fulfillment progress kept (collected line picked in full, short line 3 picked / 47 short)', o1.items[0].collected && o1.items[0].pickedQuantity === o1.items[0].quantity &&
      o1.items[1].pickedQuantity === 3 && o1.items[1].shortQuantity === 47 && o1.items[1].legacyProductId === 'cf1');
    check('v2: brand index 1 on THHN became the brand itself (Southwire)', o4.items[0].brandSnapshot.manufacturerName === 'Southwire' && o4.items[0].brandSnapshot.selection === 'SPECIFIC');
    check('v2: brand index 0 became an explicit "Any Brand" choice', o4.items[1].brandSnapshot.selection === 'ANY' && o4.items[1].brandSnapshot.manufacturerName === 'Any Brand');
    check('v2: variant snapshot and readable name kept from the old configured snapshot', o4.items[0].variantSnapshot.attributes.gauge === '#10' && o4.items[0].variantSnapshot.attributes.color === 'Red' &&
      o4.items[0].productNameSnapshot.includes('#10 Red'));
    check('v2: receipt actor "Carlos Rodriguez" became user id f1 (name kept only as a snapshot)', o2.fieldConfirmedByUserId === 'f1' && o2.fieldConfirmedByNameSnapshot === 'Carlos Rodriguez' && !('fieldConfirmedBy' in o2));
    check('v2: the delivery issue now points at its exact line', o2.deliveryIssues.length === 1 && o2.deliveryIssues[0].requestItemId === o2.items[0].id &&
      o2.deliveryIssues[0].expectedQuantity === 20 && o2.deliveryIssues[0].receivedQuantity === 16 && o2.deliveryIssues[0].missingQuantity === 4);
    check('v2: workflow states preserved', v2.materialRequests.every((o) => db.REQUESTS.find((x) => x.id === o.id).workflowStatus === o.workflowStatus));
    check('v2: permissions preserved exactly', v2.memberships.every((m) => { const x = db.MEMBERSHIPS.find((y) => y.id === m.id);
      return x && x.permissionLevel === m.permissionLevel && x.projectRole === m.projectRole && x.status === m.status && x.userId === m.userId; }) && S.Sel.getProjectPermission('a1', 'proj1') === 'CAN_EDIT');
    check('v2: companyRoles added as [primaryRole]', db.USERS.every((u) => u.companyRoles.join() === u.primaryRole));
    check('v2: names kept (fullName), the alias still reads them', v2.users.every((o) => { const u = U2(o.id); return u.fullName === o.name && u.name === o.name; }) &&
      db.USERS.filter((u) => !v2.users.some((o) => o.id === u.id)).map((u) => u.id).sort().join() === 'demo-pm1,demo-pur1');
    check('v2: Recently Used, Most Used and last quantities preserved', v2.users.filter((u) => u.workerType === 'FIELD').every((o) => { const u = U2(o.id);
      return JSON.stringify(u.recentlyUsed) === JSON.stringify(o.recentlyUsed) && JSON.stringify(u.mostUsed) === JSON.stringify(o.mostUsed) && JSON.stringify(u.lastQty || {}) === JSON.stringify(o.lastQty || {}); }));
    check('v2: Job Kits preserved with their exact variants', v2.jobKits.every((k) => { const x = db.JOB_KITS.find((y) => y.id === k.id); return x && JSON.stringify(x.materials) === JSON.stringify(k.materials); }));
    check('v2: feature flags moved to company.features; duplicate settings removed', !!co.features && !('features' in co.settings) &&
      !['inventoryTrackingEnabled', 'purchasingEnabled', 'returnsEnabled', 'costTrackingEnabled', 'warehouseLocationsEnabled', 'requestApprovalRequired'].some((k) => k in co.settings) &&
      // v5 renamed the dormant requestApprovalRequired to approvalsEnabled (the company's choice; the flag is features.approvals)
      co.features.jobKits === true && typeof co.settings.approvalsEnabled === 'boolean' && co.features.approvals === true);
    check('v2: default warehouse and every project warehouse belong to the same company', S.Loc.getLocation(co.settings.defaultWarehouseId).companyId === co.id &&
      db.PROJECTS.every((p) => { const w = S.Loc.getLocation(p.assignedWarehouseId); return w && w.type === 'WAREHOUSE' && w.companyId === p.companyId; }));
    check('v2 -> v3: 0 integrity problems (no cross-company references)', problems().length === 0 && S.loadReport.problems.length === 0);
    const vol = (raw) => { const x = JSON.parse(raw); delete x.savedAt; return JSON.stringify(x); };
    await reboot(saved3);
    check('v2 -> v3 is idempotent: a second load migrates nothing and changes nothing', !S.loadReport.migratedFrom && vol(W.localStorage.getItem(S.STORAGE_KEY)) === vol(saved3));
    await login('warehouse', 'Ana Martinez', '0000'); A.openOrder('ORD-1001'); await wait(10);
    const whHtml = html();
    A.closeOrder(); await login('field', 'Carlos', '4827'); A.openProjectWorkspace('proj2'); A.setWorkspaceTab('deliveries'); await wait(10);
    check('Migrated v2 order renders for the warehouse (short 47) and the field (issue reported)', whHtml.includes('Short 47') && html().includes('Delivery issue reported'));
    A.logout(); await wait(10);

    // v2 edge cases: an unknown company role, a duplicated module switch, and a
    // second company that SHARED the demo warehouse (as v2 allowed).
    const edge = JSON.parse(raw2);
    edge.users[0].companyRoles = ['FOREMAN', 'GOD_MODE'];
    edge.companies[0].settings.purchasingEnabled = true;
    edge.companies.push(Object.assign(JSON.parse(JSON.stringify(edge.companies[0])), { id: 'company2', name: 'Test Mechanical' }));
    edge.companies[1].settings.purchasingEnabled = false;
    edge.users.push({ id: 'fx1', companyId: 'company2', firstName: 'Nora', lastName: 'Quinn', name: 'Nora Quinn', email: 'nora@test.example', phone: '(555) 700-9001', pin: '1111',
      primaryRole: 'FOREMAN', workerType: 'FIELD', status: 'ACTIVE', createdAt: 1, updatedAt: 1, lastProjectId: 'projX', mostUsed: [], recentlyUsed: [], brandPrefs: {} });
    edge.projects.push(Object.assign(JSON.parse(JSON.stringify(edge.projects[0])), { id: 'projX', companyId: 'company2', name: 'Shared Warehouse Job', createdBy: 'fx1', assignedWarehouseId: 'loc-wh-main' }));
    edge.memberships.push({ id: 'mem-x1', companyId: 'company2', projectId: 'projX', userId: 'fx1', projectRole: 'FOREMAN', permissionLevel: 'FULL_CONTROL', status: 'ACTIVE', assignedAt: 1, assignedBy: 'fx1' });
    await reboot(JSON.stringify(edge));
    const c2 = db.COMPANIES.find((c) => c.id === 'company2'), pX = db.PROJECTS.find((p) => p.id === 'projX');
    check('v2 edge: an unknown company role string is dropped, never promoted, and the drop is logged', U2('f1').companyRoles.join() === 'FOREMAN' &&
      S.loadReport.migrationLog.some((l) => l.includes('unrecognized company roles')));
    check('v2 edge: a duplicated module switch folds into the feature flag', db.COMPANIES[0].features.purchasing === true && !('purchasingEnabled' in db.COMPANIES[0].settings));
    check('v2 edge: the second company gets its OWN warehouse (loc-wh-company2-main)', c2.settings.defaultWarehouseId === 'loc-wh-company2-main' &&
      S.Loc.getLocation('loc-wh-company2-main').companyId === 'company2' && S.Loc.getLocation('loc-wh-main').companyId === 'company1');
    check('v2 edge: its project no longer uses the other company\'s warehouse', pX.assignedWarehouseId === 'loc-wh-company2-main');
    check('v2 edge: its jobsite is created under its own company', S.Loc.getLocation('loc-site-projX') ? S.Loc.getLocation('loc-site-projX').companyId === 'company2' : true);
    check('v2 edge: two companies never share a location record', db.LOCATIONS.every((l) => db.PROJECTS.filter((p) => p.assignedWarehouseId === l.id).every((p) => p.companyId === l.companyId)) &&
      db.COMPANIES.every((c) => S.Loc.getLocation(c.settings.defaultWarehouseId).companyId === c.id));
    check('v2 edge: 0 integrity problems after migration', problems().length === 0);
  }

  console.log('TEST multi-company isolation (A = Ali Electric, B = Test Mechanical)');
  {
    await reboot(); await persistNow();
    const mcRaw = JSON.stringify(MC.addRoleTestUsers(MC.addCompanyB(JSON.parse(W.localStorage.getItem(S.STORAGE_KEY)))));
    await reboot(mcRaw);
    if (problems().length) console.log('   integrity:', JSON.stringify(problems().slice(0, 5)));
    check('Two-company data loads with 0 integrity problems', db.COMPANIES.length === 2 && problems().length === 0);
    check('Each company owns a different warehouse record', db.COMPANIES.every((c) => S.Loc.getLocation(c.settings.defaultWarehouseId).companyId === c.id) &&
      db.COMPANIES[0].settings.defaultWarehouseId !== db.COMPANIES[1].settings.defaultWarehouseId && S.Loc.mainWarehouseFor('company2').id === 'loc-wh-company2-main');
    check('A cannot view B project', !can2('f1', 'VIEW_PROJECT', 'projB1') && !S.Sel.getProjectFor(U2('f1'), 'projB1') && !!S.Sel.getProjectFor(U2('fb1'), 'projB1'));
    check('A cannot manage B project or its team', !can2('f1', 'MANAGE_PROJECT', 'projB1') && !can2('f1', 'MANAGE_PROJECT_TEAM', 'projB1'));
    check('A Owner and Admin authority stops at their own company', can2('ow1', 'MANAGE_PROJECT', 'proj1') && !can2('ow1', 'VIEW_PROJECT', 'projB1') && !can2('ad1', 'MANAGE_PROJECT_TEAM', 'projB1'));
    check('A company context of another company is refused', !S.Perm.canUser(U2('m1'), 'MANAGE_INVENTORY', { companyId: 'company2' }) && S.Perm.canUser(U2('m1'), 'MANAGE_INVENTORY', { companyId: 'company1' }));
    const reqB = S.Req.createRequest(U2('f1'), { projectId: 'projB1', priority: 'NORMAL', neededBy: Date.now() + 86400000, lines: [{ productId: V12, qty: 1 }] });
    check('A cannot request against B project', !can2('f1', 'REQUEST_MATERIALS', 'projB1') && !!reqB.error && !db.REQUESTS.some((r) => r.projectId === 'projB1' && r.requestedByUserId === 'f1'));
    check('A cannot edit B membership', !S.Proj.setProjectPermission(U2('f1'), 'projB1', 'jb1', 'VIEWER') && S.Sel.getProjectPermission('jb1', 'projB1') === 'CAN_EDIT');
    check('A cannot add a B user to an A project (either path)', S.Proj.addTeamMembers(U2('f1'), 'proj1', { jb1: 'CAN_EDIT' }).length === 0 &&
      !S.Proj.addOrUpdateMembership('proj1', 'jb1', 'JOURNEYMAN', 'CAN_EDIT', 'f1') && !S.Sel.getProjectPermission('jb1', 'proj1'));
    const ordB = () => db.REQUESTS.find((r) => r.id === 'ORD-9001');
    check('A warehouse cannot see, pick, short or dispatch a B request', !S.Sel.getRequestFor(U2('m1'), 'ORD-9001') &&
      S.Wsv.collectRequestItem(U2('m1'), 'ORD-9001', 'ORD-9001-L1').error === 'forbidden' && S.Wsv.markRequestItemShort(U2('m1'), 'ORD-9001', 'ORD-9001-L1').error === 'forbidden' &&
      S.Req.advanceWorkflow(U2('m1'), 'ORD-9001', 'READY_TO_SHIP') === 'forbidden' && ordB().workflowStatus === 'PENDING' && !ordB().items[0].collected);
    A.selectLoginCompany('company1'); await wait(15); await login('warehouse', 'Ana Martinez', '0000');
    A.openOrder('ORD-9001'); A.startPackingMode('ORD-9001'); A.findSuppliers('ORD-9001'); await wait(10);
    check('A signed-in A manager cannot open a B order, packing screen or supplier sheet', ui.currentUser.id === 'm1' && ui.openOrderId !== 'ORD-9001' &&
      ui.packingOrderId !== 'ORD-9001' && ui.supplierOrderId !== 'ORD-9001' && !html().includes('Company B only'));
    A.logout(); A.changeLoginCompany(); await wait(10);
    check('B warehouse manager cannot pick an A request', S.Wsv.collectRequestItem(U2('mb1'), 'ORD-1003', db.REQUESTS.find((r) => r.id === 'ORD-1003').items[1].id).error === 'forbidden');
    const aBefore = STK(V12, 'company1').qty;
    S.Inv.adjustInventory(U2('m1'), { productVariantId: V12, direction: 'OUT', quantity: 7, reasonCode: 'PHYSICAL_COUNT_CORRECTION' });
    check('A stock adjustment changes only A stock', STK(V12, 'company1').qty === aBefore - 7 && STK(V12, 'company2').qty === 500);
    S.Inv.adjustInventory(U2('mb1'), { productVariantId: V12, direction: 'OUT', quantity: 1, reasonCode: 'MISSING' });
    check('B stock adjustment changes only B stock', STK(V12, 'company2').qty === 499 && STK(V12, 'company1').qty === aBefore - 7);
    S.Inv.adjustInventory(U2('m1'), { productVariantId: V12, direction: 'IN', quantity: 7, reasonCode: 'DATA_CORRECTION' }); S.Inv.adjustInventory(U2('mb1'), { productVariantId: V12, direction: 'IN', quantity: 1, reasonCode: 'DATA_CORRECTION' });
    check('Same variant, separate stock and bins per company', I2().availableQty(V12, 'company1') === aBefore && I2().availableQty(V12, 'company2') === 500 &&
      I2().inventoryLocation(V12, 'company2') === 'Shelf M-9' && I2().inventoryLocation(V12, 'company1') === 'Shelf A-1');
    check('An A manager cannot adjust B stock by naming a B bin', S.Inv.adjustInventory(U2('m1'), { productVariantId: V12, locationId: 'loc-wh-company2-main-bin-shelf-m-9', direction: 'OUT', quantity: 1, reasonCode: 'MISSING' }).error === 'location_company' && STK(V12, 'company2').qty === 500);
    check('An A event cannot notify B users (or unknown ones)', S.Ntf.notify(['fb1', 'mb1', 'nobody'], { companyId: 'company1', type: 'REQUEST_SUBMITTED', title: 't', message: 'm' }).length === 0);
    const before = new Set(db.NOTIFICATIONS.map((n) => n.id));
    const reqA = S.Wf.submitRequest(U2('f1'), { projectId: 'proj1', priority: 'NORMAL', neededBy: Date.now() + 86400000, lines: [{ productId: V12, qty: 5 }] }, { duplicateOverride: [] });
    const fresh = db.NOTIFICATIONS.filter((n) => !before.has(n.id));
    check('An A request notifies only A warehouse people', !!reqA.request && fresh.length > 0 && fresh.every((n) => U2(n.userId).companyId === 'company1'));
    check('A never reads B notifications', S.Sel.getNotificationsFor(U2('m1')).every((n) => n.companyId === 'company1') && S.Sel.getNotificationsFor(U2('mb1')).length === 0);
    check('A cannot view B users', !S.Sel.getUsersFor(U2('f1')).some((u) => u.companyId === 'company2') && !S.Sel.getUserFor(U2('f1'), 'fb1') && !!S.Sel.getUserFor(U2('fb1'), 'jb1'));
    check('A cannot view B locations', !S.Sel.getLocationsFor(U2('m1')).some((l) => l.companyId === 'company2') && !S.Sel.getLocationFor(U2('m1'), 'loc-wh-company2-main'));
    check('A cannot view B requests', !S.Sel.getRequestFor(U2('f1'), 'ORD-9001') && !S.Req.requestsForCompany('company1').some((r) => r.id === 'ORD-9001'));
    check('Company kits never leak across companies', S.Kit.companyKits('company2').length === 0 && S.Kit.companyKits().length === 0 && S.Kit.companyKits('company1').length > 0);
    check('B shortages never appear in the A restock list', I2().shortageLines('company1').every((s) => s.order.companyId === 'company1'));

    // integrity detection with ids from the other company
    const bin = db.LOCATIONS.find((l) => l.id === 'loc-wh-company2-main-bin-shelf-m-9');
    const keepParent = bin.parentLocationId; bin.parentLocationId = 'loc-wh-main';
    check('Integrity flags a location under another company\'s location', problems().some((x) => x.entityId === bin.id));
    bin.parentLocationId = keepParent;
    const pB = db.PROJECTS.find((p) => p.id === 'projB1'); pB.assignedWarehouseId = 'loc-wh-main';
    check('Integrity flags a project using another company\'s warehouse', problems().some((x) => x.code === 'PROJECT_WAREHOUSE' && x.entityId === 'projB1'));
    S.Integrity.repairIntegrity(db);
    check('Repair puts it back on its own company\'s warehouse', pB.assignedWarehouseId === 'loc-wh-company2-main');
    db.COMPANIES[1].settings.defaultWarehouseId = 'loc-wh-main';
    check('Integrity flags a default warehouse owned by another company', problems().some((x) => x.code === 'COMPANY_DEFAULT_WAREHOUSE' && x.entityId === 'company2'));
    S.Integrity.repairIntegrity(db);
    check('Repair restores the company\'s own default warehouse', db.COMPANIES[1].settings.defaultWarehouseId === 'loc-wh-company2-main');
    const itB = db.INVENTORY_ITEMS.find((x) => x.companyId === 'company2'); itB.primaryLocationId = 'loc-wh-main-bin-shelf-a-1';
    check('Integrity flags stock pointing at another company\'s bin', problems().some((x) => x.code === 'INVENTORY_ITEM_LOCATION'));
    itB.primaryLocationId = 'loc-wh-company2-main-bin-shelf-m-9';
    const n = db.NOTIFICATIONS[0]; const keepUser = n.userId; n.userId = 'fb1';
    check('Integrity flags a notification delivered across companies', problems().some((x) => x.code === 'NOTIFICATION_COMPANY'));
    n.userId = keepUser;
    const zone = db.LOCATIONS.find((l) => l.id === 'loc-wh-company2-main-zone-shelving');
    zone.parentLocationId = bin.id;
    check('Integrity flags a circular location hierarchy', problems().some((x) => x.code === 'LOCATION_CYCLE'));
    zone.parentLocationId = 'loc-wh-company2-main';
    check('After the detection tests: 0 problems again', problems().length === 0);

    // sign-in with two companies
    A.logout(); A.changeLoginCompany(); await wait(15);
    check('Two companies: sign-in asks for the company first', html().includes('Select your company') && html().includes('Ali Electric') && html().includes('Test Mechanical') &&
      !html().includes("I'm on the Field Team"));
    await click('Ali Electric');
    check('After choosing a company: Field / Warehouse, with a Change company option', html().includes("I'm on the Field Team") && html().includes('Change company'));
    await click("I'm on the Field Team");
    check('The profile list shows only the chosen company\'s people', html().includes('Carlos Rodriguez') && !html().includes('Nora Quinn') && !html().includes('Omar Reyes'));
    A.pickProfile('foreman', 'fb1'); await wait(10);
    check('A profile from another company cannot be picked under this company', !(ui.pendingProfile && ui.pendingProfile.id === 'fb1') && ui.screen !== 'pin');
    A.back(); await wait(10); await click('Change company'); await click('Test Mechanical'); await click("I'm on the Field Team");
    check('Test Mechanical lists only its own people', html().includes('Nora Quinn') && !html().includes('Carlos Rodriguez'));
    await click('Nora Quinn'); for (const d of '1111') await click(d); await wait(15);
    check('A Company B foreman signs in and lands on her own project', ui.currentUser && ui.currentUser.id === 'fb1' && ui.screen === 'fHome' && html().includes('Harbor Plant') &&
      ui.session.currentCompanyId === 'company2' && ui.session.currentProjectId === 'projB1');
    A.openProjectWorkspace('proj1'); await wait(10);
    check('Company B foreman cannot open a Company A project', ui.projectWorkspaceId !== 'proj1' || !html().includes('7 Fairfield Rd'));
    A.logout(); await wait(10);
    A.changeLoginCompany(); await wait(10);
    await click('Ali Electric'); await click("I'm on the Field Team"); await click('Create new profile'); await click('Foreman');
    for (const [k, v] of [['name', 'Ivy Cross'], ['email', 'ivy.cross@example.com'], ['phone', '(555) 610-7777'], ['pin', '2468'], ['company', 'Test Mechanical']]) await type(byId('np-' + k), v);
    const usersBefore = db.USERS.length;
    await click('Create profile');
    check('Onboarding under one company cannot join another company', db.USERS.length === usersBefore && html().includes("That company doesn't match the one you selected."));
  }

  console.log('TEST project creator roles (no invented Foreman)');
  {
    const addr = '10 Test St, Newark, NJ 07102';
    const lead = (p, uid) => db.MEMBERSHIPS.find((m) => m.projectId === p.id && m.userId === uid && m.status === 'ACTIVE');
    const pF = S.Proj.createProject(U2('f1'), { name: 'Creator Foreman Job', address: addr });
    check('FOREMAN creates a project -> Foreman membership, Full Control', !!pF && lead(pF, 'f1').projectRole === 'FOREMAN' && lead(pF, 'f1').permissionLevel === 'FULL_CONTROL');
    const pPM = S.Proj.createProject(U2('pm1'), { name: 'Creator PM Job', address: addr });
    check('PROJECT_MANAGER creates -> Project Manager membership, Full Control', !!pPM && lead(pPM, 'pm1').projectRole === 'PROJECT_MANAGER' && lead(pPM, 'pm1').permissionLevel === 'FULL_CONTROL');
    const pSU = S.Proj.createProject(U2('su1'), { name: 'Creator Super Job', address: addr });
    check('SUPERINTENDENT creates -> Superintendent membership, Full Control', !!pSU && lead(pSU, 'su1').projectRole === 'SUPERINTENDENT' && lead(pSU, 'su1').permissionLevel === 'FULL_CONTROL');
    const pOW = S.Proj.createProject(U2('ow1'), { name: 'Creator Owner Job', address: addr });
    check('OWNER creates -> project created, Owner does NOT become a fake Foreman', !!pOW && db.MEMBERSHIPS.filter((m) => m.projectId === pOW.id).length === 0);
    const pAD = S.Proj.createProject(U2('ad1'), { name: 'Creator Admin Job', address: addr });
    check('COMPANY_ADMIN creates -> project created, Admin does NOT become a fake Foreman', !!pAD && db.MEMBERSHIPS.filter((m) => m.projectId === pAD.id).length === 0);
    check('Owner and Admin still oversee the projects they created (company authority)', can2('ow1', 'MANAGE_PROJECT', pOW.id) && can2('ad1', 'MANAGE_PROJECT_TEAM', pAD.id));
    const pOW2 = S.Proj.createProject(U2('ow1'), { name: 'Creator Owner Job 2', address: addr, creatorProjectRole: 'FOREMAN' });
    check('A creator can only take a lead role they really hold', !!pOW2 && db.MEMBERSHIPS.filter((m) => m.projectId === pOW2.id).length === 0);
    check('Every new project uses its own company\'s warehouse', [pF, pPM, pSU, pOW, pAD].every((p) => p.assignedWarehouseId === 'loc-wh-main'));
    check('A Journeyman cannot create a project', S.Proj.createProject(U2('j1'), { name: 'Nope', address: addr }) === null);
    S.Integrity.repairIntegrity(db);
    check('Integrity repair never invents a lead membership for an Owner or Admin', db.MEMBERSHIPS.filter((m) => m.projectId === pOW.id || m.projectId === pAD.id).length === 0 && problems().length === 0);
    A.selectLoginCompany('company1'); await wait(15); await login('field', 'John Martinez', '2211');
    A.fNavTo('projects', 'fProjects'); A.setProjectField('name', 'Should Fail'); A.setProjectField('address', addr); A.reviewCreateProject(); await wait(10);
    check('The refusal message is permission-based', ui.errorBanner === "You don't have permission to create a project.");
    A.goto('fHome'); A.logout(); await wait(10);
  }

  console.log('TEST project role independence (primaryRole != projectRole)');
  {
    const role = (u, p) => { const m = db.MEMBERSHIPS.find((x) => x.userId === u && x.projectId === p && x.status === 'ACTIVE'); return m ? m.projectRole + '/' + m.permissionLevel : null; };
    check('Start: j1 is a Journeyman (primary) and Journeyman / Can Edit on Project A', U2('j1').primaryRole === 'JOURNEYMAN' && role('j1', 'proj1') === 'JOURNEYMAN/CAN_EDIT' && !role('j1', 'proj4'));
    check('A Foreman cannot appoint a lead on their project (needs lead-assignment rights)', S.Proj.addTeamMembers(U2('f4'), 'proj4', { j1: { projectRole: 'FOREMAN', permissionLevel: 'FULL_CONTROL' } }).length === 0 && !role('j1', 'proj4'));
    const added = S.Proj.addTeamMembers(U2('ow1'), 'proj4', { j1: { projectRole: 'FOREMAN', permissionLevel: 'FULL_CONTROL' } });
    check('An Owner makes the Journeyman the Foreman of Project B', added.length === 1 && role('j1', 'proj4') === 'FOREMAN/FULL_CONTROL');
    check('primaryRole and each projectRole stay independent', U2('j1').primaryRole === 'JOURNEYMAN' && role('j1', 'proj1') === 'JOURNEYMAN/CAN_EDIT' && role('j1', 'proj4') === 'FOREMAN/FULL_CONTROL');
    check('He leads Project B but not Project A', can2('j1', 'MANAGE_PROJECT_TEAM', 'proj4') && !can2('j1', 'MANAGE_PROJECT_TEAM', 'proj1'));
    S.Proj.setProjectPermission(U2('f1'), 'proj1', 'j1', 'VIEWER');
    check('Changing Project A does not touch Project B', role('j1', 'proj1') === 'JOURNEYMAN/VIEWER' && role('j1', 'proj4') === 'FOREMAN/FULL_CONTROL');
    check('A Foreman cannot modify another lead\'s membership', !S.Proj.setProjectPermission(U2('f4'), 'proj4', 'j1', 'VIEWER') && role('j1', 'proj4') === 'FOREMAN/FULL_CONTROL');
    check('Journeymen and Apprentices can never get Full Control', S.Proj.addTeamMembers(U2('ow1'), 'proj4', { a1: { projectRole: 'APPRENTICE', permissionLevel: 'FULL_CONTROL' } }).length === 0 &&
      !S.Proj.addOrUpdateMembership('proj3', 'j2', 'JOURNEYMAN', 'FULL_CONTROL', 'f3') && !role('a1', 'proj4') && !role('j2', 'proj3'));
    check('Only real project roles are accepted (not Owner, not Warehouse)', !S.Proj.addOrUpdateMembership('proj3', 'j2', 'OWNER', 'VIEWER', 'f3') &&
      !S.Proj.addOrUpdateMembership('proj3', 'j2', 'WAREHOUSE_MANAGER', 'VIEWER', 'f3') && !S.Proj.addOrUpdateMembership('proj3', 'm1', 'JOURNEYMAN', 'VIEWER', 'f3'));
    S.Proj.addTeamMembers(U2('f3'), 'proj3', { a2: 'VIEWER' });
    check('The existing screen\'s input still works ({ userId: level }, role defaults to primary)', role('a2', 'proj3') === 'APPRENTICE/VIEWER');
    S.Proj.setProjectPermission(U2('f1'), 'proj1', 'j1', 'CAN_EDIT');
    check('No user.projects[] / project.users[] arrays exist (memberships are the only source)', db.USERS.every((u) => !('projects' in u)) && db.PROJECTS.every((p) => !('users' in p)));
    check('Role changes leave 0 integrity problems', problems().length === 0);
  }

  console.log('TEST company roles (one person, several responsibilities)');
  {
    check('Tom is ONE user holding Owner, Company Admin and Purchasing Manager', db.USERS.filter((u) => u.fullName === 'Tom Owens').length === 1 && U2('ow1').companyRoles.join() === 'OWNER,COMPANY_ADMIN,PURCHASING_MANAGER');
    const m2 = U2('m2'); m2.companyRoles = ['WAREHOUSE_MANAGER', 'PURCHASING_MANAGER'];
    check('Company capabilities are the union of all company roles', can2('m2', 'MANAGE_PURCHASING') && can2('m2', 'MANAGE_SHIPMENTS') && !can2('m1', 'MANAGE_PURCHASING'));
    check('...and company roles grant no project rights', !can2('m2', 'VIEW_PROJECT', 'proj1'));
    const j2 = U2('j2'); j2.companyRoles = ['JOURNEYMAN', 'PURCHASING_MANAGER'];
    check('A company role never opens other projects to a field worker', can2('j2', 'MANAGE_PURCHASING') && can2('j2', 'VIEW_PROJECT', 'proj1') && !can2('j2', 'VIEW_PROJECT', 'proj3'));
    j2.companyRoles = ['JOURNEYMAN', 'SUPER_ADMIN'];
    check('An unknown role string grants nothing and is flagged', !can2('j2', 'MANAGE_COMPANY') && problems().some((x) => x.code === 'USER_COMPANY_ROLE'));
    j2.companyRoles = ['PURCHASING_MANAGER'];
    check('primaryRole missing from companyRoles is flagged', problems().some((x) => x.code === 'USER_PRIMARY_NOT_IN_ROLES'));
    j2.companyRoles = ['JOURNEYMAN']; m2.companyRoles = ['WAREHOUSE_MANAGER'];
    check('Company roles restored: 0 problems', problems().length === 0);
  }

  console.log('TEST capability separation (project vs company)');
  {
    const PS = CFG.Caps.PROJECT_SCOPED;
    check('Project capabilities have their own names', ['VIEW_PROJECT', 'MANAGE_PROJECT', 'VIEW_PROJECT_TEAM', 'MANAGE_PROJECT_TEAM', 'VIEW_MATERIALS', 'REQUEST_MATERIALS',
      'VIEW_PROJECT_DELIVERIES', 'CONFIRM_PROJECT_RECEIPT', 'VIEW_PROJECT_INVENTORY', 'VIEW_PROJECT_RETURNS',
      'VIEW_PROJECT_APPROVALS', 'RESOLVE_PROJECT_APPROVAL'].every((c) => PS.has(c)) && PS.size === 12 &&
      !PS.has('VIEW_COMPANY_APPROVALS') && !PS.has('RESOLVE_COMPANY_APPROVAL'));
    check('Company modules are never project-scoped', ['VIEW_WAREHOUSE_ORDERS', 'PICK_MATERIALS', 'VERIFY_MATERIALS', 'PACK_MATERIALS', 'VIEW_INVENTORY', 'MANAGE_INVENTORY', 'VIEW_PURCHASING',
      'MANAGE_PURCHASING', 'VIEW_SHIPMENTS', 'MANAGE_SHIPMENTS', 'VIEW_RETURNS', 'MANAGE_RETURNS', 'VIEW_COSTS', 'VIEW_BUDGETS', 'VIEW_ANALYTICS'].every((c) => CFG.Caps.CAP[c] && !PS.has(c)));
    check('No project permission level grants a company module', Object.values(CFG.Caps.PERMISSION_GRANTS).every((set) => [...set].every((c) => PS.has(c))));
    check('A Foreman sees Project A deliveries, not the company logistics module', can2('f1', 'VIEW_PROJECT_DELIVERIES', 'proj1') && !can2('f1', 'VIEW_SHIPMENTS') && !can2('f1', 'VIEW_SHIPMENTS', 'proj1') && can2('m1', 'VIEW_SHIPMENTS'));
    check('Delivery confirmation is CONFIRM_PROJECT_RECEIPT on that project', can2('f1', 'CONFIRM_PROJECT_RECEIPT', 'proj1') && !can2('a1', 'CONFIRM_PROJECT_RECEIPT', 'proj1') && !can2('m1', 'CONFIRM_PROJECT_RECEIPT', 'proj1'));
  }

  console.log('TEST warehouse and inventory services (ledger write path, audited)');
  {
    const o3 = db.REQUESTS.find((r) => r.id === 'ORD-1003');
    const line = o3.items.find((i) => !i.collected && !(i.shortQuantity > 0));
    const stock0 = I2().availableQty(line.productVariantId, 'company1');
    const phys0 = I2().physicalOnHand(line.productVariantId, 'company1');
    const r1 = S.Wsv.collectRequestItem(U2('m3'), 'ORD-1003', line.id);
    check('A worker picks through the service: AVAILABLE drops by exactly the line quantity, physical stays', r1.ok && line.collected && line.pickedQuantity === line.quantity &&
      I2().availableQty(line.productVariantId, 'company1') === stock0 - line.quantity && I2().physicalOnHand(line.productVariantId, 'company1') === phys0 && r1.movements.every((m) => m.movementType === 'PICK'));
    const ev = db.AUDIT_EVENTS.find((e) => e.action === 'MATERIAL_PICKED');
    check('MATERIAL_PICKED is audited with movement ids and the request line', ev.action === 'MATERIAL_PICKED' && ev.userId === 'm3' && ev.companyId === 'company1' && ev.projectId === o3.projectId &&
      ev.after.requestId === 'ORD-1003' && ev.after.requestItemId === line.id && ev.after.movementIds.join() === r1.movements.map((m) => m.id).join() && ev.after.quantity === line.quantity);
    const r2 = S.Wsv.uncollectRequestItem(U2('m3'), 'ORD-1003', line.id);
    check('Un-pick returns the stock with UNPICK linked to the PICK, and is audited', r2.ok && !line.collected && line.pickedQuantity === 0 && I2().availableQty(line.productVariantId, 'company1') === stock0 &&
      r2.movements.every((m) => m.movementType === 'UNPICK' && m.reversalOfMovementId === r1.movements[0].id) && db.AUDIT_EVENTS[0].action === 'MATERIAL_UNPICKED' && S.Ledger && !!S.Ledger);
    check('Mark short is refused while there is enough stock (pick it instead)', S.Wsv.markRequestItemShort(U2('m3'), 'ORD-1003', line.id).error === 'enough_stock' && I2().availableQty(line.productVariantId, 'company1') === stock0);
    check('A field user cannot pick through the service', S.Wsv.collectRequestItem(U2('f1'), 'ORD-1003', line.id).error === 'forbidden' && !line.collected);
    check('A worker cannot adjust stock through the service', S.Inv.adjustInventory(U2('m3'), { productVariantId: line.productVariantId, direction: 'IN', quantity: 1, reasonCode: 'FOUND_STOCK' }).error === 'forbidden' && I2().availableQty(line.productVariantId, 'company1') === stock0);
    const o1 = db.REQUESTS.find((r) => r.id === 'ORD-1001');
    const sl = o1.items[2]; const key = I2().stockKey(sl.productVariantId, 'company1');
    const have = I2().availableQty(key, 'company1');
    S.Inv.adjustInventory(U2('m1'), { productVariantId: key, direction: 'OUT', quantity: have - 3, reasonCode: 'PHYSICAL_COUNT_CORRECTION' });
    const r3 = S.Wsv.markRequestItemShort(U2('m3'), 'ORD-1001', sl.id);
    check('Mark short picks what is on hand and records the rest short (shortage record)', r3.ok && sl.pickedQuantity === 3 && sl.shortQuantity === sl.quantity - 3 && I2().availableQty(sl.productVariantId, 'company1') === 0 &&
      sl.shortage && sl.shortage.requestedQuantity === sl.quantity && sl.shortage.pickedQuantity === 3 && sl.shortage.reportedByUserId === 'm3' && sl.shortage.requestItemId === sl.id);
    const se = db.AUDIT_EVENTS.find((e) => e.action === 'REQUEST_ITEM_MARKED_SHORT');
    check('REQUEST_ITEM_MARKED_SHORT is audited with the pick movement', se.after.shortQuantity === sl.shortQuantity && se.entityId === sl.id && se.after.movementIds.length === 1 && se.userId === 'm3');
    const adj = () => db.AUDIT_EVENTS.filter((e) => e.action === 'INVENTORY_ADJUSTED').length;
    const n0 = adj(), q0 = STK(V12, 'company1').qty;
    const ra = S.Inv.adjustInventory(U2('m1'), { productVariantId: V12, direction: 'OUT', quantity: 5, reasonCode: 'MISSING', notes: 'count' });
    const e = db.AUDIT_EVENTS[0];
    check('One saved adjustment = ONE INVENTORY_ADJUSTED event with before, after, reason and movement', adj() === n0 + 1 && e.after.movementIds[0] === ra.movements[0].id &&
      e.before.available === q0 && e.after.available === q0 - 5 && e.after.quantity === -5 && e.after.reasonCode === 'MISSING' && e.companyId === 'company1');
    S.Inv.adjustInventory(U2('m1'), { productVariantId: V12, direction: 'IN', quantity: 5, reasonCode: 'DATA_CORRECTION' });
    // source-level guarantees
    const srcRoot = path.join(__dirname, '..', 'src');
    const walk = (d) => fs.readdirSync(d).flatMap((f) => { const p = path.join(d, f); return fs.statSync(p).isDirectory() ? walk(p) : /\.(js|jsx)$/.test(f) ? [p] : []; });
    // lib/ledger.js is the pure core: it only updates the map it is handed (by the ledger service, the migration or the checker)
    const allowed = ['services/materialLedgerService.js', 'services/inventoryService.js', 'lib/ledger.js', 'lib/migration.js', 'lib/schema.js', 'lib/db.js'].map((x) => path.join(srcRoot, x));
    const writes = /(INVENTORY_BALANCES|MATERIAL_MOVEMENTS)\s*(=[^=]|\.push|\.splice|\.length\s*=)|\.quantity\s*[-+]?=[^=]/;
    const offenders = walk(srcRoot).filter((f) => allowed.indexOf(f) === -1 && writes.test(fs.readFileSync(f, 'utf8')));
    // allocation records carry their own `quantity` (allocated, not stock); these two files may write that, never stock
    const allocFiles = ['services/allocationService.js', 'services/requestProgress.js'].map((x) => path.join(srcRoot, x));
    check('Allocation code writes allocation quantities only: never a movement or a balance directly', allocFiles.every((f) => {
      const src = fs.readFileSync(f, 'utf8'); return !/(INVENTORY_BALANCES|MATERIAL_MOVEMENTS)\s*(=[^=]|\.push|\.splice|\.length\s*=)/.test(src) && !/\bb(al|alance)?\.quantity\s*[-+]?=[^=]/.test(src); }));
    check('One stock write path: only the ledger service writes movements or balances', offenders.filter((f) => allocFiles.indexOf(f) === -1).length === 0 && !/MATERIAL_MOVEMENTS\.push|INVENTORY_BALANCES\.push/.test(fs.readFileSync(path.join(srcRoot, 'services/inventoryService.js'), 'utf8')));
    check('No code deletes or edits ledger history', !walk(srcRoot).some((f) => /MATERIAL_MOVEMENTS\.(splice|pop|shift)|MATERIAL_MOVEMENTS\s*=\s*[^=]*filter/.test(fs.readFileSync(f, 'utf8'))));
    const aw = fs.readFileSync(path.join(srcRoot, 'lib/actionsWarehouse.js'), 'utf8');
    check('Warehouse actions are thin: no direct data access', !/\bdb\./.test(aw) && !/INVENTORY/.test(aw) && !/changeStock|ensureInventoryEntry/.test(walk(srcRoot).map((f) => fs.readFileSync(f, 'utf8')).join('')));
    check('Sign-in never lists every company\'s users at once', !/allCompanies\(\)\.flatMap/.test(fs.readFileSync(path.join(srcRoot, 'screens/Login.jsx'), 'utf8')));
    check('Services leave 0 integrity problems', problems().length === 0);
  }

  console.log('TEST brand snapshots, catalog-independent history, receipt actor, names, session');
  {
    // stock first: the warehouse only sees what it was allocated
    ['pf-thhn::#10|Red|Stranded', 'pf-thhn::#10|Red|Stranded~ROLL'].forEach((v) => S.Inv.adjustInventory(U2('m1'), { productVariantId: v, locationId: 'loc-wh-main-bin-shelf-a-1', direction: 'IN', quantity: 20, reasonCode: 'FOUND_STOCK' }));
    const r = S.Wf.submitRequest(U2('f1'), { projectId: 'proj1', priority: 'NORMAL', neededBy: Date.now() + 86400000,
      lines: [{ productId: 'pf-thhn::#10|Red|Stranded', qty: 10, brandIdx: 1 }, { productId: 'pf-thhn::#10|Red|Stranded~ROLL', qty: 1, brandIdx: 0 }] }, { duplicateOverride: [] }).request;
    check('A chosen brand is stored as the brand itself', r.items[0].brandSnapshot.manufacturerName === 'Southwire' && r.items[0].brandSnapshot.selection === 'SPECIFIC');
    check('"Any Brand" is stored as an explicit choice', r.items[1].brandSnapshot.selection === 'ANY');
    const na = S.RM.canonicalItem({ productId: 'wd1', qty: 2, brandIdx: 3 }, 'X', 0);
    check('"Not Applicable" is stored as an explicit choice (legacy line keeps its old id)', na.brandSnapshot.selection === 'NOT_APPLICABLE' && na.legacyProductId === 'wd1' && na.productVariantId.includes('::'));
    const thhn = C.getProduct('pf-thhn::#10|Red|Stranded');
    check('Reorder finds the brand by name, not by array position', S.RM.brandIndexFor(thhn, r.items[0].brandSnapshot) === 1 &&
      S.RM.brandIndexFor({ brands: [{ mfr: 'Any Brand' }, { mfr: 'Encore Wire' }, { mfr: 'Southwire' }] }, r.items[0].brandSnapshot) === 2);
    const line = r.items[0]; const keep = line.productVariantId;
    line.productVariantId = 'pf-retired-family::#10|Red';   // the catalog no longer has it
    const dp = S.RM.displayProductFor(line);
    check('History stays readable if a catalog variant disappears (snapshot fallback)', dp.fromSnapshot && dp.displayName === line.productNameSnapshot && dp.size.includes('#10') && dp.unit === 'FT');
    await login('warehouse', 'Ana Martinez', '0000'); A.openOrder(r.id); await wait(10);
    check('...and the warehouse checklist still renders it', html().includes(r.id) && html().includes('THHN / THWN-2 Copper') && errors.length === 0);
    A.closeOrder(); line.productVariantId = keep;
    for (const to of ['READY_TO_SHIP', 'SHIPPED', 'COMPLETED']) S.Req.advanceWorkflow(U2('m1'), 'ORD-1002', to);
    check('Someone from another company cannot confirm the receipt', S.Req.recordReceipt(U2('fb1'), 'ORD-1002', null) === null);
    const o2 = S.Req.recordReceipt(U2('f1'), 'ORD-1002', { [db.REQUESTS.find((x) => x.id === 'ORD-1002').items[0].id]: 18 });
    check('Receipt stores the confirmer as a user id, with a name snapshot', o2.fieldConfirmedByUserId === 'f1' && o2.fieldConfirmedByNameSnapshot === 'Carlos Rodriguez' && !('fieldConfirmedBy' in o2));
    check('Receipt issues are keyed by line', o2.deliveryIssues.length === 1 && o2.deliveryIssues[0].requestItemId === o2.items[0].id && o2.deliveryIssues[0].missingQuantity === 2);
    S.Usr.setUserName(U2('f1'), 'Carlos A. Rodriguez');
    check('The shown confirmer follows the user record (the snapshot is history)', S.Req.receiptConfirmerName(o2) === 'Carlos A. Rodriguez' && o2.fieldConfirmedByNameSnapshot === 'Carlos Rodriguez');
    const f1 = U2('f1'); const desc = Object.getOwnPropertyDescriptor(f1, 'name');
    check('One name write path keeps first / last / full name in sync', f1.firstName === 'Carlos' && f1.lastName === 'A. Rodriguez' && f1.fullName === 'Carlos A. Rodriguez' && f1.name === 'Carlos A. Rodriguez');
    check('user.name is a read-only alias that is never saved', !!desc.get && !desc.set && !desc.enumerable && !('name' in JSON.parse(JSON.stringify(f1))));
    S.Usr.setUserName(f1, 'Carlos Rodriguez');
    A.logout(); await wait(10);
    S.Proj.addOrUpdateMembership('proj2', 'pm1', 'PROJECT_MANAGER', 'FULL_CONTROL', 'ow1');
    S.Sess.startSession(U2('pm1'));
    const pmProjects = db.MEMBERSHIPS.filter((m) => m.userId === 'pm1' && m.status === 'ACTIVE').map((m) => m.projectId);
    check('A Project Manager with memberships gets a valid project context of their own (no new screens)', pmProjects.length === 2 && pmProjects.indexOf(ui.session.currentProjectId) !== -1 &&
      ui.session.currentCompanyId === 'company1' && S.Perm.canUser(U2('pm1'), 'VIEW_PROJECT', { projectId: ui.session.currentProjectId }));
    check('The session stores references only', Object.keys(ui.session).join() === 'currentUserId,currentCompanyId,currentProjectId' && Object.values(ui.session).every((v) => v === null || typeof v === 'string'));
    S.Sess.startSession(U2('ow1'));
    check('An Owner without memberships gets no project context', ui.session.currentProjectId === null);
    S.Sess.endSession && S.Sess.endSession();
    ui.session = { currentUserId: null, currentCompanyId: null, currentProjectId: null };
    check('Snapshots, receipts and sessions leave 0 integrity problems', problems().length === 0);
  }

  console.log('TEST statuses, feature flags vs settings');
  {
    const St = CFG.Stat;
    check('Future status enums match the master architecture', [
      [St.REQUEST_STATUS, 'DRAFT,SUBMITTED,PENDING_APPROVAL,APPROVED,PROCESSING,PARTIALLY_FULFILLED,FULFILLED,CANCELLED'],
      [St.FULFILLMENT_STATUS, 'PENDING,ALLOCATED,PICKING,PARTIALLY_PICKED,PICKED,VERIFIED,PACKED,READY,CANCELLED'],
      [St.SHIPMENT_STATUS, 'PREPARING,READY,LOADED,DISPATCHED,IN_TRANSIT,DELIVERED,RECEIVED,ISSUE,CANCELLED'],
      [St.PURCHASE_ORDER_STATUS, 'DRAFT,SENT,CONFIRMED,PARTIALLY_RECEIVED,RECEIVED,BACKORDERED,CANCELLED,CLOSED'],
      [St.RETURN_STATUS, 'REQUESTED,APPROVED,IN_TRANSIT,RECEIVED,INSPECTING,RESTOCKED,PARTIALLY_RESTOCKED,CLOSED'],
    ].every(([e, keys]) => Object.keys(e).join() === keys));
    check('Scrap and Damage are dispositions, not steps of the return lifecycle', !('SCRAP' in St.RETURN_STATUS) && !('DAMAGED' in St.RETURN_STATUS) && 'SCRAP' in St.RETURN_DISPOSITIONS && 'DAMAGED' in St.RETURN_DISPOSITIONS);
    const reached = Object.keys(St.WORKFLOW).map((w) => ({ workflowStatus: w, items: [], fieldConfirmed: false }));
    check('Every status the current workflow can reach is marked implemented', reached.every((r) => St.FULFILLMENT_STATUS[St.fulfillmentStatusOf(r)].implemented &&
      (St.shipmentStatusOf(r) === null || St.SHIPMENT_STATUS[St.shipmentStatusOf(r)].implemented)));
    check('The screens still use the same combined workflow statuses', Object.keys(St.WORKFLOW).map((k) => St.WORKFLOW_STATUS[k].label).join() === 'Pending,In Progress,Partially Packed,Packed,Ready to Ship,Shipped,Completed');
    const co = db.COMPANIES[0];
    check('Feature flags (which modules) and settings (how to run them) are separate', !!co.features && !('features' in co.settings) && Object.keys(co.features).every((k) => !(k in co.settings)));
    check('Approvals: a module flag (available) and a separate company setting (required)', co.features.approvals === true && co.settings.approvalsEnabled === true && !('requestApprovalRequired' in co.settings));
    const emergencyDraft = { companyId: 'company1', projectId: 'proj1', priority: 'EMERGENCY', items: [] };
    co.features.approvals = false;
    check('Switching the approvals module off means no approval is evaluated, even with the setting on', S.Appr.evaluateApproval(emergencyDraft).required === false);
    co.features.approvals = true;
    check('Module on + setting on: an Emergency request needs its Project Manager', S.Appr.evaluateApproval(emergencyDraft).steps.map((x) => x.requiredRole).join() === 'PROJECT_MANAGER');
    co.features.advancedLogistics = true;
    check('Switching on an unbuilt module still shows nothing', !S.Co.isFeatureEnabled('company1', 'advancedLogistics'));
    co.features.advancedLogistics = false;
  }

  console.log('TEST unknown company onboarding (single-company sign-in)');
  {
    await reboot();
    const users0 = db.USERS.length, mems0 = db.MEMBERSHIPS.length;
    await click("I'm on the Field Team");
    check('One company: no company step, the simple sign-in is unchanged', !html().includes('Select your company') && html().includes('Carlos Rodriguez'));
    await click('Create new profile'); await click('Foreman');
    check('The company field starts with the one company', byId('np-company').value === 'Ali Electric');
    for (const [k, v] of [['name', 'Rita Unknown'], ['email', 'rita@example.com'], ['phone', '(555) 610-4321'], ['pin', '1357'], ['company', 'Random Unknown Contractor']]) await type(byId('np-' + k), v);
    await click('Create profile');
    check('Unknown company: the person sees the message', html().includes('That company is not available in ANT. Ask your company administrator for access.'));
    check('Unknown company: no user and no membership created, not added to Ali Electric', db.USERS.length === users0 && db.MEMBERSHIPS.length === mems0 && !db.USERS.some((u) => u.email === 'rita@example.com'));
    check('Unknown company: still on the form, nothing signed in', ui.screen === 'newProfile' && !ui.currentUser);
    A.setLanguage('es'); await wait(10); await click('Create profile'); await wait(10);
    check('The message is translated (Spanish)', html().includes('Esa empresa no está disponible en ANT'));
    A.setLanguage('en'); await wait(10);
    await type(byId('np-company'), 'ali electric');
    await click('Create profile');
    const rita = db.USERS.find((u) => u.email === 'rita@example.com');
    check('An exact company name (any capitalization) joins that company', !!rita && rita.companyId === 'company1' && rita.companyRoles.join() === 'FOREMAN' && rita.fullName === 'Rita Unknown' && ui.currentUser === rita);
    check('Onboarding leaves 0 integrity problems', problems().length === 0);
    A.logout(); await wait(10);
  }

  console.log('TEST extra regression: Apprentice / Journeyman rights, filters, worker lookup');
  {
    await reboot();
    await login('field', 'Daniel Perez', '3322');
    check('Apprentice (View Only): home shows the permission, cannot add', html().includes('Apprentice · View Only'));
    A.openFamily('pf-thhn'); A.selectFamilyVariant('gauge', '#12'); A.selectFamilyVariant('color', 'Black'); A.selectFamilyVariant('conductor', 'Stranded'); A.addFamilyToCart(); await wait(10);
    check('Apprentice (View Only): nothing reaches the cart', ui.cart.length === 0);
    A.closeFamily && A.closeFamily();
    S.Proj.setProjectPermission(U2('f1'), 'proj1', 'a1', 'CAN_EDIT');
    await login('field', 'Daniel Perez', '3322');
    check('Apprentice (Can Edit): home shows the new permission', html().includes('Apprentice · Can Request Materials'));
    A.openFamily('pf-thhn'); A.selectFamilyVariant('gauge', '#12'); A.selectFamilyVariant('color', 'Black'); A.selectFamilyVariant('conductor', 'Stranded'); A.addFamilyToCart(); await wait(10);
    const ra = await sendCurrentCart();
    check('Apprentice (Can Edit) submits a request', ra.requestedByUserId === 'a1' && ra.projectId === 'proj1');
    await login('field', 'John Martinez', '2211');
    A.openFamily('pf-thhn'); A.selectFamilyVariant('gauge', '#10'); A.selectFamilyVariant('color', 'Red'); A.selectFamilyVariant('conductor', 'Stranded'); A.addFamilyToCart(); await wait(10);
    const rj = await sendCurrentCart();
    check('Journeyman (Can Edit) submits a request', rj.requestedByUserId === 'j1');
    S.Proj.setProjectPermission(U2('f1'), 'proj1', 'j1', 'VIEWER');
    await login('field', 'John Martinez', '2211');
    check('Journeyman (View Only): home shows it and requests are blocked', html().includes('Journeyman · View Only') && !S.Perm.canUser(U2('j1'), 'REQUEST_MATERIALS', { projectId: 'proj1' }));
    S.Proj.setProjectPermission(U2('f1'), 'proj1', 'j1', 'CAN_EDIT');
    await login('warehouse', 'Ana Martinez', '0000');
    A.mNavTo('orders', 'mOrders'); await wait(10); await click('Packed'); await wait(10);
    const packedCount = db.REQUESTS.filter((r) => r.companyId === 'company1' && r.workflowStatus === 'PACKED').length;
    check('Manager filter: Packed shows only packed orders', packedCount === 1 && html().includes('1 order shown') && html().includes('12 Lincoln Ave') && !html().includes('7 Fairfield Rd'));
    await click('All'); await click('Emergency'); await wait(10);
    check('Manager filter: Emergency priority', !html().includes('ORD-1003') && (html().includes('No orders match') || html().includes('Emergency')));
    A.clearOrderFilters(); await wait(10);
    await login('warehouse', 'Michael Torres', '8899');
    A.mNavTo('inventory', 'mInventory'); await wait(10); await type(byId('inv-search-input'), 'THHN'); await wait(10);
    check('Worker inventory lookup: results with location, no stock editing', /\d+ results?/.test(html()) && html().includes('Location') && !html().includes('qty-stepper-sm'));
    A.logout(); await wait(10);
    check('Extra regression leaves 0 integrity problems', problems().length === 0);
  }

  console.log('PHASE 2: Material Ledger (spec tests 101-116)');
  {
    const v3 = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', 'v3-react-saved.json'), 'utf8'));
    const Cat = { getProduct: (id) => S.Cat.getProductVariant(id) };
    const onRequests = new Set(v3.materialRequests.flatMap((r) => r.items.map((i) => i.productVariantId)));
    const cands = Object.keys(v3.inventory.company1).filter((k) => k.includes('::') && !k.includes('Any') && v3.inventory.company1[k].locationId &&
      !onRequests.has(k) && Cat.getProduct(k) && Cat.getProduct(k).unit === 'EA' && v3.inventory.company1[k].qty > 40);
    const [X, Y, Z, Q, MLV] = cands;
    const C2 = 'loc-wh-main-bin-shelf-c-2';
    const v3x = JSON.parse(JSON.stringify(v3));
    v3x.inventory.company1[X] = { qty: 184, locationId: C2 };
    v3x.inventory.company1[MLV] = { qty: 100, locationId: C2 };
    W = boot(JSON.stringify(v3x)); await wait(80);
    ({ A, ui, db, C, S } = W.__ANT);
    const U = (id) => db.USERS.find((u) => u.id === id);
    const q = (vid, st, co) => S.Inv.getQuantityByState(co || 'company1', vid)[st];
    const phys = (vid) => S.Inv.getPhysicalOnHand('company1', vid);
    const movs = (vid) => S.MLS.getMovementsForVariant('company1', vid);
    // extra lines keep the order open (resolving every line packs the whole order)
    // Phase 2 primitives are kept as the COMPATIBILITY path for pre-v5 open orders (spec: legacy PICK stays
    // AVAILABLE -> PICKING). These tests exercise it on requests in exactly the shape the v4 -> v5 migration
    // gives existing open orders (allocationMode LEGACY). New v5 requests are covered in the Phase 3 section.
    const asLegacy = (r) => { if (!r || !r.id) return r;
      Object.assign(r, { allocationMode: 'LEGACY', workflowStatus: 'PENDING', legacyStatus: 'PENDING', approvalStatus: 'LEGACY', allocationStatus: 'LEGACY', status: 'PROCESSING', packedAt: null, shippedAt: null, completedAt: null });
      r.items.forEach((it) => S.RM.withV4Progress(it)); return r; };
    const mkReq = (vid, qty, extra) => { const res = S.Req.createRequest(U('f1'), { projectId: 'proj1', lines: [{ productId: vid, qty }].concat(extra || []), neededBy: Date.now() + 86400000, priority: 'NORMAL' }); return asLegacy(res.request) || res; };
    const setAvail = (vid, n) => { const cur = q(vid, 'AVAILABLE'); if (n !== cur) S.Inv.adjustInventory(U('m1'), { productVariantId: vid, direction: n > cur ? 'IN' : 'OUT', quantity: Math.abs(n - cur), reasonCode: 'PHYSICAL_COUNT_CORRECTION' }); };
    const noNegatives = () => db.INVENTORY_BALANCES.every((b) => b.quantity >= 0);
    check('Test data: five clean stocked EA variants in real bins', cands.length >= 5);

    // 101 opening balance
    const openX = movs(X).filter((m) => m.movementType === 'OPENING_BALANCE');
    check('101 v3 -> v4 creates ONE opening balance: 184 EA AVAILABLE at C-2', openX.length === 1 && openX[0].quantity === 184 && openX[0].toLocationId === C2 &&
      openX[0].toInventoryState === 'AVAILABLE' && !openX[0].fromLocationId && q(X, 'AVAILABLE') === 184);
    check('101 the opening balance is a system entry at the recorded cutover (no invented user or time)', openX[0].actorType === 'SYSTEM' && openX[0].performedByUserId === null &&
      openX[0].reasonCode === 'LEDGER_OPENING_BALANCE' && openX[0].timestamp === db.COMPANIES[0].inventoryLedgerStartedAt && db.COMPANIES[0].inventoryLedgerStartedAt > 0);
    check('72/114 the untouched v3 copy is backed up before the upgrade', !!W.localStorage.getItem(S.backupKeyFor(3)));
    const nMov = db.MATERIAL_MOVEMENTS.length;
    W = boot(W.localStorage.getItem(S.STORAGE_KEY)); await wait(80);
    ({ A, ui, db, C, S } = W.__ANT);
    check('101 reloading v4 keeps 184 and still ONE opening balance', q(X, 'AVAILABLE') === 184 && movs(X).filter((m) => m.movementType === 'OPENING_BALANCE').length === 1 && db.MATERIAL_MOVEMENTS.length === nMov);

    // 114 (v3 path in detail): current stock is the opening balance, held material is linked, history is kept apart
    const avail = (k) => q(k, 'AVAILABLE');
    check('114 v3: every stored v3 quantity is exactly the AVAILABLE balance (no replayed picks, no double deduction)', Object.keys(v3x.inventory.company1).every((k) => avail(k) === v3x.inventory.company1[k].qty));
    const o1 = db.REQUESTS.find((r) => r.id === 'ORD-1001'), o2 = db.REQUESTS.find((r) => r.id === 'ORD-1002'), o3 = db.REQUESTS.find((r) => r.id === 'ORD-1003'), o5 = db.REQUESTS.find((r) => r.id === 'ORD-1005');
    const heldM = (line) => S.MLS.getMovementsForRequestItem(line.id);
    check('114 v3: picked material of an in-progress order is an opening balance in PICKING, linked to its line', heldM(o1.items[0]).length === 1 && heldM(o1.items[0])[0].toInventoryState === 'PICKING' &&
      heldM(o1.items[0])[0].quantity === 50 && heldM(o1.items[0])[0].requestId === 'ORD-1001' && o1.items[0].pickedQuantity === 50 && o1.items[0].collected);
    check('114 v3: the short line keeps 3 picked / 47 short, with its real reporter from the v3 audit trail', o1.items[1].pickedQuantity === 3 && o1.items[1].shortQuantity === 47 &&
      o1.items[1].shortage.reportedByUserId === 'm1' && o1.items[1].shortage.legacy === true && heldM(o1.items[1])[0].quantity === 3);
    check('114 v3: a packed order\'s material is PACKED (not available, still in the warehouse)', o2.items.every((it) => it.packedQuantity === it.quantity && heldM(it).length === 1 && heldM(it)[0].toInventoryState === 'PACKED'));
    check('114 v3: an order in progress keeps its collected line', o3.items[0].collected && o3.items[0].pickedQuantity === o3.items[0].quantity && o3.items[0].packedQuantity === 0);
    check('114 v3: a delivered order is legacy history only (no stock held for it)', o5.items[0].legacyProgress && o5.items[0].legacyProgress.pickedQuantity === 120 && heldM(o5.items[0]).length === 0 && o5.fieldConfirmedByUserId === 'f1');
    check('114 v3: one INVENTORY_LEDGER_STARTED audit event per company', db.AUDIT_EVENTS.filter((e) => e.action === 'INVENTORY_LEDGER_STARTED').length === db.COMPANIES.length);
    check('114 v3: 0 integrity problems after migration', problems().length === 0);

    // 102 pick
    const r1 = mkReq(X, 25, [{ productId: Q, qty: 1 }]), l1 = r1.items[0];
    const p1 = S.Wsv.collectRequestItem(U('m3'), r1.id, l1.id);
    check('102 pick 25: AVAILABLE 159, PICKING 25, physical still 184, ONE PICK movement', p1.ok && q(X, 'AVAILABLE') === 159 && q(X, 'PICKING') === 25 && phys(X) === 184 &&
      movs(X).filter((m) => m.movementType === 'PICK').length === 1 && p1.movements[0].fromLocationId === C2 && p1.movements[0].toLocationId === C2);
    check('102 the PICK links request, line and project, and names the worker', p1.movements[0].requestId === r1.id && p1.movements[0].requestItemId === l1.id &&
      p1.movements[0].projectId === r1.projectId && p1.movements[0].performedByUserId === 'm3' && l1.pickedQuantity === 25 && l1.shortQuantity === 0);
    // 103 unpick
    const u1 = S.Inv.unpickMaterial(U('m3'), { requestId: r1.id, requestItemId: l1.id, quantity: 10 });
    check('103 unpick 10: AVAILABLE 169, PICKING 15, physical 184; the PICK is untouched, UNPICK links to it', u1.ok && q(X, 'AVAILABLE') === 169 && q(X, 'PICKING') === 15 && phys(X) === 184 &&
      S.MLS.getMovementById(p1.movements[0].id).quantity === 25 && u1.movements[0].movementType === 'UNPICK' && u1.movements[0].reversalOfMovementId === p1.movements[0].id);
    check('103 the line shows 15 picked and is no longer collected', l1.pickedQuantity === 15 && !l1.collected);
    check('83 a reversal can never exceed what is left: 15 remain reversible on that PICK', S.MLS.reversibleQuantity(p1.movements[0]) === 15 &&
      S.MLS.postMovements(U('m3'), [S.MLS.reversalDraftFor(p1.movements[0], 16)]).error === 'reversal_exceeds');
    S.Inv.pickMaterial(U('m3'), { requestId: r1.id, requestItemId: l1.id, quantity: 10 });
    // 104 pack
    const k1 = S.Inv.packMaterial(U('m3'), { requestId: r1.id, requestItemId: l1.id, quantity: 25 });
    check('104 pack 25: AVAILABLE 159, PICKING 0, PACKED 25, physical 184', k1.ok && q(X, 'AVAILABLE') === 159 && q(X, 'PICKING') === 0 && q(X, 'PACKED') === 25 && phys(X) === 184 && l1.packedQuantity === 25);
    const un = S.Inv.unpackMaterial(U('m1'), { requestId: r1.id, requestItemId: l1.id, quantity: 5 });
    check('32 unpack 5 (PACKED -> PICKING) links the PACK; 31 partial pack of 5 works', un.ok && q(X, 'PACKED') === 20 && q(X, 'PICKING') === 5 && un.movements[0].reversalOfMovementId === k1.movements[0].id &&
      S.Inv.packMaterial(U('m3'), { requestId: r1.id, requestItemId: l1.id, quantity: 5 }).ok && q(X, 'PACKED') === 25);

    // 105 partial pick (100 requested, 60 available)
    setAvail(Y, 60);
    const r2 = mkReq(Y, 100, [{ productId: Q, qty: 1 }]), l2 = r2.items[0];
    const s2 = S.Wsv.markRequestItemShort(U('m3'), r2.id, l2.id);
    const pr = S.Inv.requestItemProgress(l2);
    check('105 partial: AVAILABLE 0, PICKING 60, short 40, nothing negative', s2.ok && q(Y, 'AVAILABLE') === 0 && q(Y, 'PICKING') === 60 && l2.pickedQuantity === 60 && l2.shortQuantity === 40 && noNegatives());
    check('105 no movement is created for the missing 40 (a shortage is demand, not stock)', S.MLS.getMovementsForRequestItem(l2.id).length === 1 && S.MLS.getMovementsForRequestItem(l2.id)[0].quantity === 60);
    check('58/59 equations: requested 100 = picked 60 + outstanding 40; short 40 stays outstanding demand', pr.requested === 100 && pr.picked === 60 && pr.outstanding === 40 && pr.short === 40 && pr.packed === 0 &&
      pr.requested === pr.picked + pr.outstanding && pr.short <= pr.outstanding);
    check('27 shortage record: request, line, variant, requested, picked, short, reporter, time', l2.shortage.requestId === r2.id && l2.shortage.requestItemId === l2.id && l2.shortage.productVariantId === Y &&
      l2.shortage.requestedQuantity === 100 && l2.shortage.pickedQuantity === 60 && l2.shortage.shortQuantity === 40 && l2.shortage.reportedByUserId === 'm3' && l2.shortage.reportedAt > 0);

    // 106 overpick
    setAvail(Z, 20);
    const r3 = mkReq(Z, 25), l3 = r3.items[0], nm = db.MATERIAL_MOVEMENTS.length;
    const op = S.Inv.pickMaterial(U('m3'), { requestId: r3.id, requestItemId: l3.id, quantity: 25 });
    const zbin = S.Inv.inventoryItemFor('company1', Z).primaryLocationId;
    const raw = S.MLS.postMovements(U('m3'), [{ movementType: 'PICK', companyId: 'company1', productVariantId: Z, quantity: 25, unit: 'EA', fromLocationId: zbin, toLocationId: zbin, fromInventoryState: 'AVAILABLE', toInventoryState: 'PICKING' }]);
    check('106 overpick 25 of 20 is rejected (service and raw ledger); balance stays 20; no movement committed', op.error === 'insufficient_stock' && raw.error === 'insufficient_stock' &&
      S.Wsv.collectRequestItem(U('m3'), r3.id, l3.id).error === 'insufficient_stock' && q(Z, 'AVAILABLE') === 20 && db.MATERIAL_MOVEMENTS.length === nm && !l3.collected);

    // 107 / 108 adjustments
    setAvail(Q, 84);
    const aud0 = db.AUDIT_EVENTS.length, mv0 = db.MATERIAL_MOVEMENTS.length, ph0 = phys(Q);
    check('107 a reason is required (and must be a known one)', S.Inv.adjustInventory(U('m1'), { productVariantId: Q, direction: 'OUT', quantity: 5 }).error === 'reason_required' &&
      S.Inv.adjustInventory(U('m1'), { productVariantId: Q, direction: 'OUT', quantity: 5, reasonCode: 'BECAUSE' }).error === 'reason_required' && q(Q, 'AVAILABLE') === 84 && db.MATERIAL_MOVEMENTS.length === mv0);
    const out = S.Inv.adjustInventory(U('m1'), { productVariantId: Q, direction: 'OUT', quantity: 5, reasonCode: 'PHYSICAL_COUNT_CORRECTION', notes: 'cycle count' });
    const ae = db.AUDIT_EVENTS.find((e) => e.action === 'INVENTORY_ADJUSTED');
    check('107 adjust -5: 84 -> 79, one INVENTORY_ADJUSTMENT_OUT (AVAILABLE -> out of inventory), audited', out.ok && q(Q, 'AVAILABLE') === 79 && db.MATERIAL_MOVEMENTS.length === mv0 + 1 &&
      out.movements[0].movementType === 'INVENTORY_ADJUSTMENT_OUT' && out.movements[0].toLocationId === null && out.movements[0].notes === 'cycle count' &&
      db.AUDIT_EVENTS.length === aud0 + 1 && ae.after.movementIds[0] === out.movements[0].id && ae.after.quantity === -5 && ae.after.reasonCode === 'PHYSICAL_COUNT_CORRECTION');
    check('78 an adjustment DOES change physical stock', phys(Q) === ph0 - 5);
    const inn = S.Inv.adjustInventory(U('m1'), { productVariantId: Q, direction: 'IN', quantity: 5, reasonCode: 'FOUND_STOCK' });
    check('108 adjust +5: 79 -> 84, one INVENTORY_ADJUSTMENT_IN', inn.ok && q(Q, 'AVAILABLE') === 84 && inn.movements[0].movementType === 'INVENTORY_ADJUSTMENT_IN' && inn.movements[0].fromLocationId === null && db.MATERIAL_MOVEMENTS.length === mv0 + 2);
    check('42 a worker cannot adjust, post an arbitrary movement, or an opening balance', S.Inv.adjustInventory(U('m3'), { productVariantId: Q, direction: 'IN', quantity: 1, reasonCode: 'FOUND_STOCK' }).error === 'forbidden' &&
      S.MLS.postMovements(U('m3'), [{ movementType: 'INVENTORY_ADJUSTMENT_IN', companyId: 'company1', productVariantId: Q, quantity: 1, unit: 'EA', toLocationId: zbin, toInventoryState: 'AVAILABLE' }]).error === 'forbidden' &&
      S.MLS.postMovements(U('m1'), [{ movementType: 'OPENING_BALANCE', companyId: 'company1', productVariantId: Q, quantity: 1, unit: 'EA', toLocationId: zbin, toInventoryState: 'AVAILABLE' }]).error === 'forbidden' &&
      S.MLS.reverseMovement(U('m3'), inn.movements[0].id).error === 'forbidden' && db.MATERIAL_MOVEMENTS.length === mv0 + 2);
    const fix = S.Inv.correctMovement(U('m1'), inn.movements[0].id, { reasonCode: 'DATA_CORRECTION' });
    check('43 a manager corrects a movement with a REVERSAL (original untouched), and it is audited', fix.ok && fix.movements[0].movementType === 'REVERSAL' && fix.movements[0].reversalOfMovementId === inn.movements[0].id &&
      q(Q, 'AVAILABLE') === 79 && S.MLS.getMovementById(inn.movements[0].id).quantity === 5 && db.AUDIT_EVENTS[0].action === 'MATERIAL_MOVEMENT_CREATED');
    S.Inv.adjustInventory(U('m1'), { productVariantId: Q, direction: 'IN', quantity: 5, reasonCode: 'DATA_CORRECTION' });
    check('13 domain errors: wrong unit, future type, SCRAP state and unknown location are refused', S.MLS.postMovements(U('m3'), [{ movementType: 'PICK', companyId: 'company1', productVariantId: Q, quantity: 1, unit: 'FT', fromLocationId: zbin, toLocationId: zbin, fromInventoryState: 'AVAILABLE', toInventoryState: 'PICKING' }]).error === 'unit_mismatch' &&
      S.MLS.postMovements(U('m1'), [{ movementType: 'SHIP', companyId: 'company1', productVariantId: Q, quantity: 1, unit: 'EA', fromLocationId: zbin, toLocationId: zbin, fromInventoryState: 'PACKED', toInventoryState: 'IN_TRANSIT' }]).error === 'inactive_type' &&
      S.MLS.postMovements(U('m3'), [{ movementType: 'PICK', companyId: 'company1', productVariantId: Q, quantity: 1, unit: 'EA', fromLocationId: zbin, toLocationId: zbin, fromInventoryState: 'SCRAP', toInventoryState: 'PICKING' }]).error === 'invalid_transition' &&
      S.MLS.postMovements(U('m3'), [{ movementType: 'PICK', companyId: 'company1', productVariantId: Q, quantity: 1, unit: 'EA', fromLocationId: 'loc-nope', toLocationId: 'loc-nope', fromInventoryState: 'AVAILABLE', toInventoryState: 'PICKING' }]).error === 'unknown_location');

    // 109 multi-location
    const D4 = S.LM.ensureBin(db, 'loc-wh-main', 'Bin D-4');
    S.Inv.adjustInventory(U('m1'), { productVariantId: MLV, locationId: D4, direction: 'IN', quantity: 200, reasonCode: 'FOUND_STOCK' });
    check('109 same variant in two bins: C-2 100 + D-4 200 = 300 available', S.Inv.getInventoryBalance('company1', MLV, C2, 'AVAILABLE') === 100 && S.Inv.getInventoryBalance('company1', MLV, D4, 'AVAILABLE') === 200 && q(MLV, 'AVAILABLE') === 300);
    const r4 = mkReq(MLV, 150), l4 = r4.items[0];
    const plan = W.__ANT.I.pickPlanFor(l4, 'company1');
    check('66 pick plan: primary bin first, then the next (C-2 100, D-4 50)', plan.parts.length === 2 && plan.parts[0].locationId === C2 && plan.parts[0].quantity === 100 && plan.parts[1].locationId === D4 && plan.parts[1].quantity === 50);
    await login('warehouse', 'Michael Torres', '8899');
    A.startPackingMode(r4.id); await wait(10);
    check('68 Packing Mode lists every bin: "1. Shelf C-2 — Pick 100 EA", "2. Bin D-4 — Pick 50 EA"', html().includes('1. Shelf C-2 — Pick 100 EA') && html().includes('2. Bin D-4 — Pick 50 EA'));
    await click('Pack ');
    const pm = S.MLS.getMovementsForRequestItem(l4.id).filter((m) => m.movementType === 'PICK');
    check('109/67 picking 150 across bins = two PICK movements, one per bin (no warehouse-level movement)', pm.length === 2 && pm.every((m) => m.movementType === 'PICK') &&
      pm[0].fromLocationId === C2 && pm[0].quantity === 100 && pm[1].fromLocationId === D4 && pm[1].quantity === 50 && l4.pickedQuantity === 150 &&
      S.Inv.getInventoryBalance('company1', MLV, C2, 'AVAILABLE') === 0 && S.Inv.getInventoryBalance('company1', MLV, D4, 'AVAILABLE') === 150);
    check('13 the whole order packed on completion: PICKING -> PACKED in each bin, one MATERIAL_PACKED event', r4.workflowStatus === 'PACKED' && q(MLV, 'PACKED') === 150 && q(MLV, 'PICKING') === 0 &&
      db.AUDIT_EVENTS.find((e) => e.action === 'MATERIAL_PACKED').after.movementIds.length === 2);
    A.exitPackingMode(); await wait(10);

    // 113 double tap
    const r5 = mkReq(X, 4), l5 = r5.items[0];
    const key = 'test:' + l5.id + ':pick';
    const t1 = S.Inv.pickMaterial(U('m3'), { requestId: r5.id, requestItemId: l5.id, quantity: 2, operationKey: key });
    const t2 = S.Inv.pickMaterial(U('m3'), { requestId: r5.id, requestItemId: l5.id, quantity: 2, operationKey: key });
    check('113 the same operation posted twice moves stock ONCE (operation key)', t1.ok && t2.duplicate && S.MLS.getMovementsForRequestItem(l5.id).length === 1 && l5.pickedQuantity === 2);
    S.Inv.unpickMaterial(U('m3'), { requestId: r5.id, requestItemId: l5.id });
    const pk = 'test:' + l1.id + ':pack';
    S.Inv.unpackMaterial(U('m3'), { requestId: r1.id, requestItemId: l1.id, quantity: 3 });
    const d1 = S.Inv.packMaterial(U('m3'), { requestId: r1.id, requestItemId: l1.id, quantity: 3, operationKey: pk });
    const d2 = S.Inv.packMaterial(U('m3'), { requestId: r1.id, requestItemId: l1.id, quantity: 3, operationKey: pk });
    check('113 a duplicate PACK is not posted twice', d1.ok && d2.duplicate && q(X, 'PACKED') === 25 && q(X, 'PICKING') === 0);
    await TAP(); A.startPackingMode(r5.id); await wait(10);
    const before5 = db.MATERIAL_MOVEMENTS.length;
    A.packCurrentFull(); A.packCurrentFull(); await wait(10);
    check('113 a double tap on the Pack button acts once (one PICK; the order then packs once)', db.MATERIAL_MOVEMENTS.slice(before5).filter((m) => m.movementType === 'PICK').length === 1 &&
      db.MATERIAL_MOVEMENTS.slice(before5).filter((m) => m.movementType === 'PACK').length === 1 && l5.collected && l5.packedQuantity === 4);
    A.exitPackingMode(); await wait(10);
    await login('warehouse', 'Ana Martinez', '0000');
    A.openOrder(r5.id); await wait(10);
    const b6 = db.MATERIAL_MOVEMENTS.length;
    await TAP(); A.toggleItemCollected(r5.id, l5.id); A.toggleItemCollected(r5.id, l5.id); await wait(10);
    check('113 a double tap on a checklist line un-picks once (it is not re-picked by the second tap)', !l5.collected && db.MATERIAL_MOVEMENTS.length > b6 && q(X, 'PICKING') === 0 &&
      S.MLS.getMovementsForRequestItem(l5.id).slice(-1)[0].movementType === 'UNPICK');
    check('90 order detail shows the ledger activity for the request', html().includes('Inventory activity') && html().includes('4 EA returned to stock from ' + r5.id));
    A.closeOrder(); await wait(10);

    // 33/34 Ready to Ship / Shipped / Completed post no movement (Logistics phase)
    A.openOrder(r4.id); await wait(10);
    const b7 = db.MATERIAL_MOVEMENTS.length;
    await click('Mark as ready to ship'); await click('Mark as shipped'); await click('Mark as completed');
    check('33/34 Ready to Ship, Shipped, Completed post NO movement; packed stock is not deducted a second time', r4.workflowStatus === 'COMPLETED' && db.MATERIAL_MOVEMENTS.length === b7 && q(MLV, 'PACKED') === 150);

    // 38/40/88 inventory detail + history, 62 low stock, 91 Spanish
    A.mNavTo('inventory', 'mInventory'); A.openInventoryDetail(X); await wait(10);
    check('88 detail shows Available / Picking / Packed / Physical, location and reorder point', ['Available', 'Picking', 'Packed', 'Physical in warehouse', 'Primary location', 'Reorder point', 'Adjust inventory'].every((x) => html().includes(x)) &&
      html().includes(q(X, 'AVAILABLE') + ' EA') && html().includes(q(X, 'PACKED') + ' EA') && html().includes(phys(X) + ' EA') && html().includes('Shelf C-2'));
    // Y's whole story fits in Recent Activity: opening balance, one adjustment, one pick
    const openY = movs(Y).find((m) => m.movementType === 'OPENING_BALANCE').quantity;
    A.openInventoryDetail(Y); await wait(10);
    check('38/39 history in plain language: opening balance by the system, adjustment with reason, picked for the order', html().includes('Opening balance +' + openY + ' EA') &&
      html().includes('System (inventory ledger started)') && html().includes('Inventory adjusted -' + (openY - 60) + ' EA') && html().includes('Physical count correction') && html().includes('60 EA picked for ' + r2.id));
    A.openInventoryDetail(MLV); await wait(10);
    check('34 the detail says when packed stock belongs to orders already marked shipped', html().includes('150 EA of the packed quantity belongs to orders already marked shipped'));
    A.setLanguage('es'); A.openInventoryDetail(Y); await wait(10);
    check('91 Spanish: Disponible, En recolección, Empacado, Actividad reciente, and the movement text', ['Disponible', 'En recolección', 'Empacado', 'Actividad reciente', '60 EA recolectados para ' + r2.id, 'Corrección por conteo físico'].every((x) => html().includes(x)));
    A.setLanguage('en'); A.closeInventoryDetail(); await wait(10);
    const item = S.Inv.inventoryItemFor('company1', Q);
    check('62 low stock uses AVAILABLE against the reorder point (migrated default 15 EA)', item.reorderPoint === 15 && !S.Inv.isLowStock('company1', Q) &&
      (() => { item.reorderPoint = 90; const low = S.Inv.isLowStock('company1', Q) && S.Inv.lowStockVariantIds('company1').includes(Q); item.reorderPoint = 15; return low; })());
    check('60 inventory items hold no quantity (quantities come from balances)', db.INVENTORY_ITEMS.every((it) => !('qty' in it) && !('quantity' in it) && it.primaryLocationId));
    await login('warehouse', 'Michael Torres', '8899');
    A.mNavTo('inventory', 'mInventory'); A.openInventoryDetail(X); await wait(10);
    check('42/89 a worker sees no Adjust button and no ledger history', !html().includes('Adjust inventory') && !html().includes('Recent Activity'));
    A.closeInventoryDetail(); A.logout(); await wait(10);
    await login('warehouse', 'Ana Martinez', '0000');
    db.COMPANIES[0].features.inventory = false; A.mNavTo('inventory', 'mInventory'); A.openInventoryDetail(X); await wait(10);
    check('95 turning the inventory flag off hides history only: stock, pick and adjust keep working', !html().includes('Recent Activity') && html().includes('Adjust inventory') &&
      S.Inv.adjustInventory(U('m1'), { productVariantId: X, direction: 'IN', quantity: 1, reasonCode: 'FOUND_STOCK' }).ok && S.Co.isFeatureEnabled('company1', 'materialLedger'));
    S.Inv.adjustInventory(U('m1'), { productVariantId: X, direction: 'OUT', quantity: 1, reasonCode: 'DATA_CORRECTION' });
    db.COMPANIES[0].features.inventory = true; A.closeInventoryDetail(); A.logout(); await wait(10);

    // 50 immutability, 111 rebuild, 112 validate
    const m0 = db.MATERIAL_MOVEMENTS[0];
    try { m0.quantity = 999; } catch (e) { /* frozen */ }
    check('5/50 posted movements are frozen: an edit does not take', m0.quantity !== 999 && Object.isFrozen(m0) && Object.isFrozen(db.MATERIAL_MOVEMENTS.slice(-1)[0]));
    check('50 the ledger service offers no delete or edit', !Object.keys(S.MLS).some((k) => /delete|remove|edit|update/i.test(k)));
    check('Ledger invariants hold after all of that: no negatives, 0 integrity problems', noNegatives() && problems().length === 0);
    const good = JSON.stringify(db.INVENTORY_BALANCES.filter((b) => b.companyId === 'company1').map((b) => [b.id, b.quantity]).sort());
    db.INVENTORY_BALANCES = db.INVENTORY_BALANCES.filter((b) => b.companyId !== 'company1' || b.productVariantId !== X);
    const qb = db.INVENTORY_BALANCES.find((b) => b.productVariantId === Q && b.inventoryState === 'AVAILABLE');
    qb.quantity += 5;
    const vr = S.Inv.validateInventoryAgainstLedger('company1').find((x) => x.productVariantId === Q);
    check('112 validate reports the variance: stored 89, ledger 84, variance +5', vr && vr.stored === 89 && vr.ledger === 84 && vr.variance === 5);
    check('111/82 the checker flags the missing and the wrong balances', problems().some((x) => x.code === 'BALANCE_MISSING') && problems().some((x) => x.code === 'BALANCE_LEDGER_VARIANCE'));
    S.Inv.rebuildInventoryBalancesFromLedger('company1', { apply: true });
    check('111 rebuilding from the ledger restores every company1 balance exactly', JSON.stringify(db.INVENTORY_BALANCES.filter((b) => b.companyId === 'company1').map((b) => [b.id, b.quantity]).sort()) === good && problems().length === 0);
    const gone = db.MATERIAL_MOVEMENTS.splice(3, 1);
    check('50 a deleted movement is detected (ledger gap)', problems().some((x) => x.code === 'LEDGER_GAP'));
    db.MATERIAL_MOVEMENTS.splice(3, 0, gone[0]);

    // 110 multi-company isolation
    const saved = JSON.parse(W.localStorage.getItem(S.STORAGE_KEY));
    W = boot(JSON.stringify(MC.addCompanyB(saved))); await wait(80);
    ({ A, ui, db, C, S } = W.__ANT);
    const UB = db.USERS.find((u) => u.id === 'mb1'), UA = db.USERS.find((u) => u.id === 'm3');
    const rA = db.REQUESTS.find((r) => r.id === r5.id), lA = rA.items[0];
    const snapB = JSON.stringify([db.INVENTORY_BALANCES, db.MATERIAL_MOVEMENTS.length, db.AUDIT_EVENTS.length]);
    const binA = S.Inv.inventoryItemFor('company1', X).primaryLocationId;
    check('110 a Company B user cannot pick Company A material (service or raw ledger)', S.Wsv.collectRequestItem(UB, rA.id, lA.id).error === 'forbidden' &&
      S.Inv.pickMaterial(UB, { requestId: rA.id, requestItemId: lA.id }).error === 'forbidden' &&
      S.MLS.postMovements(UB, [{ movementType: 'PICK', companyId: 'company1', productVariantId: X, quantity: 1, unit: 'EA', fromLocationId: binA, toLocationId: binA, fromInventoryState: 'AVAILABLE', toInventoryState: 'PICKING' }]).error === 'company_mismatch' &&
      S.MLS.postMovements(UB, [{ movementType: 'INVENTORY_ADJUSTMENT_IN', companyId: 'company2', productVariantId: X, quantity: 1, unit: 'EA', toLocationId: binA, toInventoryState: 'AVAILABLE' }]).error === 'location_company');
    check('110 nothing changed: no movement, no balance change, no audit event', JSON.stringify([db.INVENTORY_BALANCES, db.MATERIAL_MOVEMENTS.length, db.AUDIT_EVENTS.length]) === snapB);
    check('53 every movement stays inside one company (locations, requests, users)', db.MATERIAL_MOVEMENTS.every((m) => [m.fromLocationId, m.toLocationId].filter(Boolean).every((l) => db.LOCATIONS.find((x) => x.id === l).companyId === m.companyId)) && problems().length === 0);
    check('110 Company B stock has its own opening balance and balance', q(MC.V12 || 'pf-thhn::#12|Black|Stranded', 'AVAILABLE', 'company2') === 500);

    // 114 every migration path -> v4 with 0 problems, no negatives, no duplicate opening balances, idempotent reload
    for (const f of ['v1-html-saved.json', 'v1-react-saved.json', 'v2-react-saved.json', 'v3-react-saved.json', null]) {
      W = boot(f ? fs.readFileSync(path.join(__dirname, 'fixtures', f), 'utf8') : undefined); await wait(80);
      ({ A, ui, db, C, S } = W.__ANT);
      const opens = db.MATERIAL_MOVEMENTS.filter((m) => m.movementType === 'OPENING_BALANCE' && !m.requestItemId).map((m) => m.companyId + m.productVariantId + m.toLocationId);
      const n = db.MATERIAL_MOVEMENTS.length;
      const ok1 = db.SCHEMA_VERSION === 6 && problems().length === 0 && noNegatives() && new Set(opens).size === opens.length;
      if (f) { W = boot(W.localStorage.getItem(S.STORAGE_KEY)); await wait(80); ({ A, ui, db, C, S } = W.__ANT); }
      check('114 ' + (f || 'fresh seed') + ' -> v4: 0 integrity problems, no negatives, no duplicate opening balances, reload adds nothing', ok1 && db.MATERIAL_MOVEMENTS.length === n && problems().length === 0);
    }
  }

  console.log('PHASE 2 CORRECTION 1: company-safe idempotency');
  W = boot(); await wait(80); ({ A, ui, db, C, S } = W.__ANT); A.setLanguage('en'); await wait(10);
  W = boot(JSON.stringify(MC.addCompanyB(JSON.parse(W.localStorage.getItem(S.STORAGE_KEY))))); await wait(80);
  ({ A, ui, db, C, S } = W.__ANT);
  const CU = (id) => db.USERS.find((u) => u.id === id);
  const cq = (vid, co) => S.Inv.getAvailableQuantity(co || 'company1', vid);
  const cbal = (vid, loc) => S.Inv.getInventoryBalance('company1', vid, loc, 'AVAILABLE');
  const CV = 'pf-thhn::#12|Black|Stranded', BBIN = 'loc-wh-company2-main-bin-shelf-m-9';
  const ccands = S.Inv.stockedVariantIds('company1').filter((k) => k.includes('::') && !k.includes('Any') && S.Cat.getProductVariant(k).unit === 'EA' && cq(k) > 50 &&
    S.Inv.adjustmentCandidates('company1', k).length === 1);
  const [P1, P2, P3, P4] = ccands;
  const creq = S.Req.createRequest(CU('f1'), { projectId: 'proj1', lines: [{ productId: P1, qty: 20 }, { productId: P2, qty: 1 }], neededBy: Date.now() + 864e5, priority: 'NORMAL' });
  // idempotency of the Phase 2 pick primitive: exercised on its compatibility path (a pre-v5-shaped open order)
  const cr = creq.request || creq, cline = cr.items[0];
  Object.assign(cr, { allocationMode: 'LEGACY', workflowStatus: 'PENDING', legacyStatus: 'PENDING', approvalStatus: 'LEGACY', allocationStatus: 'LEGACY', status: 'PROCESSING', packedAt: null, shippedAt: null, completedAt: null });
  cr.items.forEach((it) => S.RM.withV4Progress(it));
  const D4 = S.LM.ensureBin(db, 'loc-wh-main', 'Bin D-4');
  {
    check('Correction test data: four single-location EA variants and a Company B', ccands.length >= 4 && db.COMPANIES.some((c) => c.id === 'company2'));
    const n0 = db.MATERIAL_MOVEMENTS.length, a0 = cq(P1), KEY = 'pick:req1:item1:abc';
    const a1 = S.Inv.pickMaterial(CU('m3'), { requestId: cr.id, requestItemId: cline.id, quantity: 5, operationKey: KEY });
    const a2 = S.Inv.pickMaterial(CU('m3'), { requestId: cr.id, requestItemId: cline.id, quantity: 5, operationKey: KEY });
    check('IDEM A same company + key + payload: one effect, one set of movements, the same result returned', a1.ok && a2.duplicate &&
      a2.movements.map((m) => m.id).join() === a1.movements.map((m) => m.id).join() && db.MATERIAL_MOVEMENTS.length === n0 + 1 && cq(P1) === a0 - 5 && cline.pickedQuantity === 5);
    const rec = S.MLS.findOperation('company1', KEY);
    check('IDEM record: company, key, type, actor, entity, fingerprint, result ids and time (frozen)', rec && rec.companyId === 'company1' && rec.operationType === 'PICK_MATERIAL' &&
      rec.actorUserId === 'm3' && rec.entityId === cline.id && /^fp1:/.test(rec.payloadFingerprint) && rec.resultMovementIds.join() === a1.movements[0].id && rec.createdAt > 0 && Object.isFrozen(rec));
    const b1 = S.Inv.pickMaterial(CU('m3'), { requestId: cr.id, requestItemId: cline.id, quantity: 7, operationKey: KEY });
    check('IDEM B same key, different quantity: IDEMPOTENCY_CONFLICT, no movement, no balance change', b1.error === 'IDEMPOTENCY_CONFLICT' && !b1.movements &&
      db.MATERIAL_MOVEMENTS.length === n0 + 1 && cq(P1) === a0 - 5 && cline.pickedQuantity === 5);
    const c1 = S.Inv.adjustInventory(CU('m1'), { productVariantId: P2, direction: 'IN', quantity: 3, reasonCode: 'FOUND_STOCK', operationKey: 'adj:k2' });
    const nC = db.MATERIAL_MOVEMENTS.length, p3 = cq(P3);
    const c2 = S.Inv.adjustInventory(CU('m1'), { productVariantId: P3, direction: 'IN', quantity: 3, reasonCode: 'FOUND_STOCK', operationKey: 'adj:k2' });
    check('IDEM C same key, different productVariantId: IDEMPOTENCY_CONFLICT, nothing posted', c1.ok && c2.error === 'IDEMPOTENCY_CONFLICT' && db.MATERIAL_MOVEMENTS.length === nC && cq(P3) === p3);
    const L1 = S.Inv.adjustmentCandidates('company1', P2)[0];
    const d1 = S.Inv.adjustInventory(CU('m1'), { productVariantId: P2, locationId: L1, direction: 'IN', quantity: 2, reasonCode: 'FOUND_STOCK', operationKey: 'adj:k3' });
    const nD = db.MATERIAL_MOVEMENTS.length;
    const d2 = S.Inv.adjustInventory(CU('m1'), { productVariantId: P2, locationId: D4, direction: 'IN', quantity: 2, reasonCode: 'FOUND_STOCK', operationKey: 'adj:k3' });
    const inDraft = (loc) => ({ movementType: 'INVENTORY_ADJUSTMENT_IN', companyId: 'company1', productVariantId: P2, quantity: 1, unit: 'EA', toLocationId: loc, toInventoryState: 'AVAILABLE', reasonCode: 'FOUND_STOCK' });
    const e1 = S.MLS.postMovements(CU('m1'), [inDraft(L1)], { operationKey: 'raw:k4' });
    const e2 = S.MLS.postMovements(CU('m1'), [inDraft(L1)], { operationKey: 'raw:k4' });
    const e3 = S.MLS.postMovements(CU('m1'), [inDraft(D4)], { operationKey: 'raw:k4' });
    check('IDEM D same key, different location: IDEMPOTENCY_CONFLICT (service and raw ledger); an identical raw retry replays', d1.ok && d2.error === 'IDEMPOTENCY_CONFLICT' &&
      e1.ok && e2.duplicate && e2.movements[0].id === e1.movements[0].id && e3.error === 'IDEMPOTENCY_CONFLICT' && db.MATERIAL_MOVEMENTS.length === nD + 1 && cbal(P2, D4) === 0);
    const ea = S.Inv.adjustInventory(CU('m1'), { productVariantId: CV, direction: 'IN', quantity: 1, reasonCode: 'FOUND_STOCK', operationKey: 'same-key' });
    const bBefore = cq(CV, 'company2');
    const eb = S.Inv.adjustInventory(CU('mb1'), { productVariantId: CV, direction: 'IN', quantity: 1, reasonCode: 'FOUND_STOCK', operationKey: 'same-key' });
    check('IDEM E Company A and Company B use the same key: both succeed independently (B is not skipped)', ea.ok && !ea.duplicate && eb.ok && !eb.duplicate &&
      eb.movements[0].companyId === 'company2' && eb.movements[0].id !== ea.movements[0].id && cq(CV, 'company2') === bBefore + 1 &&
      S.MLS.findOperation('company1', 'same-key').resultMovementIds[0] === ea.movements[0].id && S.MLS.findOperation('company2', 'same-key').resultMovementIds[0] === eb.movements[0].id);
    const rb = db.REQUESTS.find((x) => x.companyId === 'company2'), lb = rb.items[0];
    const pa = S.Inv.pickMaterial(CU('m3'), { requestId: cr.id, requestItemId: cr.items[1].id, quantity: 1, operationKey: 'same-pick' });
    const pb = S.Inv.pickMaterial(CU('mb1'), { requestId: rb.id, requestItemId: lb.id, quantity: 1, operationKey: 'same-pick' });
    check('IDEM E also for picks: each company gets its own movement under the same key', pa.ok && pb.ok && !pb.duplicate && pa.movements[0].companyId === 'company1' && pb.movements[0].companyId === 'company2');
    const aIds = new Set(db.MATERIAL_MOVEMENTS.filter((m) => m.companyId === 'company1').map((m) => m.id));
    const bDraft = { movementType: 'INVENTORY_ADJUSTMENT_IN', companyId: 'company2', productVariantId: CV, quantity: 1, unit: 'FT', toLocationId: BBIN, toInventoryState: 'AVAILABLE', reasonCode: 'FOUND_STOCK' };
    const f1 = S.Inv.pickMaterial(CU('mb1'), { requestId: cr.id, requestItemId: cline.id, quantity: 5, operationKey: KEY });
    const f2 = S.MLS.checkOperation(CU('mb1'), KEY, 'PICK_MATERIAL', rec.payloadFingerprint);
    const hidden = S.MLS.findOperation('company2', KEY) === null;
    const f3 = S.MLS.postMovements(CU('mb1'), [bDraft], { operationKey: KEY });
    check('IDEM F Company B cannot retrieve or replay Company A\'s operation: refused, invisible, or treated as its own; never A data', f1.error === 'forbidden' && !f1.movements &&
      f2 === null && hidden && f3.ok && !f3.duplicate && f3.movements.every((m) => m.companyId === 'company2' && !aIds.has(m.id)));
    db.IDEMPOTENCY_RECORDS.push({ companyId: 'company2', operationKey: 'forged', operationType: 'POST_MOVEMENTS', actorUserId: 'mb1', entityType: null, entityId: null,
      payloadFingerprint: S.MLS.draftsFingerprint([bDraft]), resultMovementIds: [a1.movements[0].id], createdAt: Date.now() });
    const f4 = S.MLS.postMovements(CU('mb1'), [bDraft], { operationKey: 'forged' });
    check('1.8 a corrupted record pointing at Company A movements is never replayed to Company B, and integrity flags it', f4.error === 'IDEMPOTENCY_CONFLICT' && !f4.movements &&
      problems().some((x) => x.code === 'IDEMPOTENCY_RESULT'));
    db.IDEMPOTENCY_RECORDS.pop();
    const kept = db.IDEMPOTENCY_RECORDS.find((r) => r.operationKey === 'adj:k3');
    db.IDEMPOTENCY_RECORDS = db.IDEMPOTENCY_RECORDS.filter((r) => r !== kept);
    const g1 = S.Inv.adjustInventory(CU('m1'), { productVariantId: P2, locationId: L1, direction: 'IN', quantity: 2, reasonCode: 'FOUND_STOCK', operationKey: 'adj:k3' });
    check('A key found on movements without a record (older data) is refused as unverifiable, not replayed or re-posted', g1.error === 'IDEMPOTENCY_CONFLICT');
    db.IDEMPOTENCY_RECORDS.push(kept);
    check('Idempotency leaves 0 integrity problems', problems().length === 0);
    A.setLanguage('en'); await wait(10);
    W = boot(W.localStorage.getItem(S.STORAGE_KEY)); await wait(80);
    ({ A, ui, db, C, S } = W.__ANT);
    const h1 = S.Inv.pickMaterial(CU('m3'), { requestId: cr.id, requestItemId: cline.id, quantity: 5, operationKey: KEY });
    const h2 = S.Inv.pickMaterial(CU('m3'), { requestId: cr.id, requestItemId: cline.id, quantity: 7, operationKey: KEY });
    check('Records are saved: after a reload the same retry replays and a changed one conflicts (still schema v4)', h1.duplicate && h1.movements[0].id === a1.movements[0].id &&
      h2.error === 'IDEMPOTENCY_CONFLICT' && db.SCHEMA_VERSION === 6 && JSON.parse(W.localStorage.getItem(S.STORAGE_KEY)).idempotencyRecords.length === db.IDEMPOTENCY_RECORDS.length);
  }

  console.log('PHASE 2 CORRECTION 2: location-specific adjustments');
  {
    const setAt = (vid, loc, n) => { const cur = cbal(vid, loc); if (n !== cur) S.Inv.adjustInventory(CU('m1'), { productVariantId: vid, locationId: loc, direction: n > cur ? 'IN' : 'OUT', quantity: Math.abs(n - cur), reasonCode: 'DATA_CORRECTION' }); };
    const T = P3, C2 = S.Inv.adjustmentCandidates('company1', T)[0], C2name = db.LOCATIONS.find((l) => l.id === C2).name;
    setAt(T, C2, 100);
    const nA = db.MATERIAL_MOVEMENTS.length;
    const ra = S.Inv.adjustInventory(CU('m1'), { productVariantId: T, quantityDelta: -5, reasonCode: 'PHYSICAL_COUNT_CORRECTION' });
    check('ADJ A one location: it is used automatically (100 -> 95, total 95, one movement)', ra.ok && ra.locationId === C2 && cbal(T, C2) === 95 && cq(T) === 95 &&
      db.MATERIAL_MOVEMENTS.length === nA + 1 && S.Inv.defaultAdjustmentLocation('company1', T) === C2);
    setAt(T, C2, 100);
    S.Inv.adjustInventory(CU('m1'), { productVariantId: T, locationId: D4, direction: 'IN', quantity: 200, reasonCode: 'FOUND_STOCK' });
    check('Two bins set up: C-2 100 + D-4 200 = 300', cbal(T, C2) === 100 && cbal(T, D4) === 200 && cq(T) === 300);
    const snap = () => JSON.stringify([db.INVENTORY_BALANCES, db.MATERIAL_MOVEMENTS.length]);
    const s0 = snap();
    const rb1 = S.Inv.adjustInventory(CU('m1'), { productVariantId: T, quantityDelta: -5, reasonCode: 'PHYSICAL_COUNT_CORRECTION' });
    const rb2 = S.Inv.adjustInventory(CU('m1'), { productVariantId: T, direction: 'IN', quantity: 5, reasonCode: 'FOUND_STOCK' });
    check('ADJ B two bins, no location: LOCATION_REQUIRED for removing and for adding; no movement, no balance change', rb1.error === 'LOCATION_REQUIRED' && rb2.error === 'LOCATION_REQUIRED' &&
      snap() === s0 && S.Inv.defaultAdjustmentLocation('company1', T) === null && rb1.locations.length === 2);
    const rd = S.Inv.adjustInventory(CU('m1'), { productVariantId: T, locationId: C2, quantityDelta: -150, reasonCode: 'PHYSICAL_COUNT_CORRECTION' });
    check('ADJ D -150 at C-2 (holding 100) is rejected; nothing is taken from D-4 (100 / 200 / 300)', rd.error === 'insufficient_stock' && cbal(T, C2) === 100 && cbal(T, D4) === 200 && cq(T) === 300 && snap() === s0);
    const rc = S.Inv.adjustInventory(CU('m1'), { productVariantId: T, locationId: C2, quantityDelta: -5, reasonCode: 'PHYSICAL_COUNT_CORRECTION' });
    check('ADJ C C-2 selected, -5: C-2 95, D-4 200, total 295', rc.ok && rc.availableAtLocation === 95 && cbal(T, C2) === 95 && cbal(T, D4) === 200 && cq(T) === 295 && rc.available === 295);
    const ev = db.AUDIT_EVENTS.find((e) => e.action === 'INVENTORY_ADJUSTED');
    check('2.11 audit: company, variant, location, state, before / delta / after at the location, totals, reason, person, movement, time', ev.companyId === 'company1' &&
      ev.after.productVariantId === T && ev.after.locationId === C2 && ev.after.inventoryState === 'AVAILABLE' && ev.after.quantityBeforeAtLocation === 100 && ev.after.quantityDelta === -5 &&
      ev.after.quantityAfterAtLocation === 95 && ev.after.totalAvailableBefore === 300 && ev.after.totalAvailableAfter === 295 && ev.after.reasonCode === 'PHYSICAL_COUNT_CORRECTION' &&
      ev.userId === 'm1' && ev.after.performedByUserId === 'm1' && ev.after.movementId === rc.movements[0].id && ev.timestamp > 0 && ev.after.timestamp === rc.movements[0].timestamp);
    const E = P4, E0 = S.Inv.adjustmentCandidates('company1', E)[0];
    setAt(E, E0, 100);
    const hadRow = db.INVENTORY_BALANCES.some((b) => b.productVariantId === E && b.locationId === D4);
    const re = S.Inv.adjustInventory(CU('m1'), { productVariantId: E, locationId: D4, direction: 'IN', quantity: 25, reasonCode: 'FOUND_STOCK' });
    check('ADJ E +25 into an empty existing bin: C-2 100, D-4 25, total 125; the balance row is created by the ledger', !hadRow && re.ok && re.movements[0].movementType === 'INVENTORY_ADJUSTMENT_IN' &&
      re.movements[0].toLocationId === D4 && re.movements[0].toInventoryState === 'AVAILABLE' && cbal(E, E0) === 100 && cbal(E, D4) === 25 && cq(E) === 125);
    const nF = db.MATERIAL_MOVEMENTS.length;
    const rf1 = S.Inv.adjustInventory(CU('m1'), { productVariantId: T, locationId: BBIN, direction: 'IN', quantity: 1, reasonCode: 'FOUND_STOCK' });
    const rf2 = S.Inv.adjustInventory(CU('mb1'), { productVariantId: CV, locationId: C2, direction: 'IN', quantity: 1, reasonCode: 'FOUND_STOCK' });
    const site = db.LOCATIONS.find((l) => l.companyId === 'company1' && l.type === 'JOBSITE');
    const rf3 = S.Inv.adjustInventory(CU('m1'), { productVariantId: T, locationId: site.id, direction: 'IN', quantity: 1, reasonCode: 'FOUND_STOCK' });
    check('ADJ F another company\'s location (either way) and a jobsite are rejected; no movement', rf1.error === 'location_company' && rf2.error === 'location_company' &&
      rf3.error === 'location_not_warehouse' && db.MATERIAL_MOVEMENTS.length === nF);
    const opts = S.Inv.adjustableLocations('company1', T);
    const typeOf = (id) => db.LOCATIONS.find((l) => l.id === id);
    check('2.6 location list: this material\'s bins first with their quantities, then only this company\'s other warehouse bins', opts.filter((o) => o.stocked).map((o) => o.locationId).sort().join() === [C2, D4].sort().join() &&
      opts.find((o) => o.locationId === C2).available === 95 && opts.some((o) => !o.stocked) && opts.every((o) => typeOf(o.locationId).companyId === 'company1' && ['WAREHOUSE_BIN', 'WAREHOUSE'].indexOf(typeOf(o.locationId).type) !== -1));
    // the screen (two companies: choose the company first, as a real sign-in does)
    A.selectLoginCompany('company1'); await wait(15); await login('warehouse', 'Ana Martinez', '0000');
    A.mNavTo('inventory', 'mInventory'); A.openInventoryDetail(T); await wait(10); await click('Adjust inventory');
    check('2.4 two bins: no location preselected; the total is shown for context only', byId('adj-location').value === '' && html().includes('Choose the location you counted') &&
      html().includes('Total available') && html().includes('295 EA') && !html().includes('New quantity at'));
    await click('Remove'); await type(byId('adj-qty'), '5');
    const rs = byId('adj-reason'); rs.value = 'PHYSICAL_COUNT_CORRECTION'; rs.dispatchEvent(new W.Event('change', { bubbles: true })); await wait(10);
    await click('Save adjustment');
    check('2.2 saving without a location is refused with a clear message; nothing changes', html().includes('This material is in more than one location. Choose the location you are correcting.') && cbal(T, C2) === 95 && cbal(T, D4) === 200);
    const pickLoc = async (id) => { const el = byId('adj-location'); el.value = id; el.dispatchEvent(new W.Event('change', { bubbles: true })); await wait(10); };
    await pickLoc(D4);
    check('2.4/2.5 choosing D-4 calculates against D-4: available 200, new 195, total after 290', html().includes('Available at Bin D-4') && html().includes('200 EA') &&
      html().includes('New quantity at Bin D-4') && html().includes('195 EA') && html().includes('290 EA'));
    await pickLoc(C2);
    const rowVal = (label) => { const r = [...W.document.querySelectorAll('.sheet .spec-row')].find((x) => x.querySelector('.k').textContent.indexOf(label) === 0); return r ? r.querySelector('.v').textContent : null; };
    check('2.5 choosing C-2 calculates against C-2 (95 -> 90); the total is only context (295 -> 290)', rowVal('Available at ' + C2name) === '95 EA' &&
      rowVal('New quantity at ' + C2name) === '90 EA' && rowVal('Total after adjustment') === '290 EA' && rowVal('Total available') === '295 EA');
    await TAP(); await click('Save adjustment');
    check('2.9 after saving the detail refreshes by itself: C-2 90, total 290, history names the location', ui.adjustDraft === null && cbal(T, C2) === 90 && cq(T) === 290 &&
      html().includes('290 EA') && html().includes('Inventory adjusted -5 EA at ' + C2name));
    const P1bin = S.Inv.adjustmentCandidates('company1', P1)[0];
    A.openInventoryDetail(P1); await wait(10); await click('Adjust inventory');
    check('2.3 one location: it is preselected (no extra tap)', byId('adj-location').value === P1bin && html().includes('Available at'));
    A.closeAdjust(); A.closeInventoryDetail(); A.logout(); await wait(10);
    check('Corrections leave no negatives and 0 integrity problems', db.INVENTORY_BALANCES.every((b) => b.quantity >= 0) && problems().length === 0);
  }

  /* =====================================================================
     PHASE 3 — REQUESTS + ALLOCATION + APPROVALS (spec tests 117–136 + integrity)
     ===================================================================== */
  console.log('TEST Phase 3: requests, allocation, reservation, fulfillment, approvals');
  {
    W = boot(); await wait(80);
    ({ A, ui, db, C, S } = W.__ANT);
    const U = (id) => db.USERS.find((u) => u.id === id);
    const q = (vid, st) => S.Inv.getQuantityByState('company1', vid)[st] || 0;
    const phys = (vid) => S.Inv.getPhysicalOnHand('company1', vid);
    const bal = (vid, loc, st) => S.Inv.getInventoryBalance('company1', vid, loc, st);
    const P3 = () => S.Integrity.checkIntegrity(db);
    const noNeg = () => db.INVENTORY_BALANCES.every((b) => b.quantity >= 0);
    const setAvail = (vid, n) => { const cur = q(vid, 'AVAILABLE'); if (n !== cur) S.Inv.adjustInventory(U('m1'), { productVariantId: vid, direction: n > cur ? 'IN' : 'OUT', quantity: Math.abs(n - cur), reasonCode: 'PHYSICAL_COUNT_CORRECTION' }); };
    const V3 = S.Inv.stockedVariantIds('company1').filter((k) => k.includes('::') && !k.includes('Any') && S.Cat.getProductVariant(k).unit === 'EA' && S.Inv.adjustmentCandidates('company1', k).length === 1 && q(k, 'AVAILABLE') > 0);
    const [VA, VB, VC, VD, VE, VF, VG, VH, VI] = V3;
    let n3 = 0;
    const submit = (vid, qty, o) => S.Wf.submitRequest(U((o && o.by) || 'f1'), { projectId: (o && o.project) || 'proj1', priority: (o && o.priority) || 'NORMAL', neededBy: Date.now() + 864e5,
      lines: [{ productId: vid, qty }].concat((o && o.extra) || []) }, { submissionKey: 'p3-' + (++n3), duplicateOverride: o && o.checkDuplicates ? undefined : [] });
    const allocs = (r) => S.Alloc.getAllocationsForRequest(r.id);
    const resMovs = (r) => db.MATERIAL_MOVEMENTS.filter((m) => m.requestId === r.id && (m.movementType === 'RESERVE' || m.movementType === 'UNRESERVE'));
    const out = (r, i) => S.RP.getOutstandingQuantity(r.items[i || 0], r);
    const ful = (r) => S.Ful.warehouseFulfillmentFor(r.id);
    check('P3 test data: nine clean single-bin EA variants; fresh data is schema v5 with 0 problems', V3.length >= 9 && db.SCHEMA_VERSION === 6 && P3().length === 0);
    check('P3 fresh v5: the demo policy (Emergency -> Project Manager) and one demo Project Manager, no allocations yet',
      db.APPROVAL_POLICIES.length === 1 && db.APPROVAL_POLICIES[0].rules[0].value === 'EMERGENCY' && db.USERS.filter((u) => u.id === 'demo-pm1').length === 1 &&
      db.ALLOCATIONS.length === 0 && db.FULFILLMENTS.every((f) => f.legacyMigrated && f.allocationMode === 'LEGACY'));

    // 117 full allocation
    setAvail(VA, 100);
    const r1 = submit(VA, 60).request, l1 = r1.items[0];
    const a1 = allocs(r1), m1 = resMovs(r1);
    check('117 full: 60 ALLOCATED, 60 RESERVED, 40 AVAILABLE, 0 outstanding, physical still 100', a1.length === 1 && a1[0].quantity === 60 && a1[0].status === 'RESERVED' &&
      q(VA, 'RESERVED') === 60 && q(VA, 'AVAILABLE') === 40 && out(r1) === 0 && phys(VA) === 100 && r1.allocationStatus === 'ALLOCATED' && r1.status === 'PROCESSING');
    check('117 one warehouse fulfillment for the 60', !!ful(r1) && /^FUL-/.test(ful(r1).id) && ful(r1).items.length === 1 && ful(r1).items[0].allocatedQuantity === 60 && ful(r1).items[0].allocationIds[0] === a1[0].id &&
      ful(r1).projectId === r1.projectId && ful(r1).companyId === 'company1' && a1[0].fulfillmentId === ful(r1).id);
    check('15/16 RESERVE links company, variant, qty, unit, bin, request, line, project, allocation; posted by ANT (system actor), who triggered it recorded',
      m1.length === 1 && m1[0].movementType === 'RESERVE' && m1[0].fromInventoryState === 'AVAILABLE' && m1[0].toInventoryState === 'RESERVED' && m1[0].fromLocationId === m1[0].toLocationId &&
      m1[0].allocationId === a1[0].id && m1[0].requestItemId === l1.id && m1[0].projectId === 'proj1' && m1[0].quantity === 60 && m1[0].unit === 'EA' &&
      m1[0].actorType === 'SYSTEM' && m1[0].performedByUserId === null && m1[0].metadata.source === 'AUTO_ALLOCATION' && m1[0].metadata.triggeredByUserId === 'f1' && !db.USERS.some((u) => /system/i.test(u.fullName)));
    check('5 a v5 request line is demand only (no warehouse progress stored on it)', ['collected', 'pickedQuantity', 'packedQuantity', 'shortQuantity'].every((k) => !(k in l1)) && r1.allocationMode === 'V5');

    // 118 partial allocation
    setAvail(VB, 60);
    const r2 = submit(VB, 100).request, l2 = r2.items[0];
    const p2 = S.RP.getLineProgress(l2, r2);
    check('118 partial: 60 ALLOCATED, 60 RESERVED, 0 AVAILABLE, 40 OUTSTANDING; request not fulfilled', p2.requested === 100 && p2.allocated === 60 && p2.reserved === 60 && p2.outstanding === 40 &&
      q(VB, 'AVAILABLE') === 0 && q(VB, 'RESERVED') === 60 && noNeg() && r2.status === 'PROCESSING' && r2.allocationStatus === 'PARTIALLY_ALLOCATED');
    check('118 the warehouse is asked for 60, not 100 (fulfillment + warehouse view)', ful(r2).items[0].allocatedQuantity === 60 && WV(r2).items[0].quantity === 60 &&
      WV(r2).items[0].requestedQuantity === 100 && WV(r2).items[0].outstandingQuantity === 40);
    check('93/139 outstanding = requested - active allocated, never the old shortQuantity field', p2.outstanding === p2.requested - p2.allocated && !('shortQuantity' in l2));
    check('72 one business notification for the requester: "60 of 100 ... 40 remain outstanding" (not one per movement)', S.Ntf.notificationsForUser('f1').filter((n) => n.entityId === r2.id && n.type === 'ALLOCATION_SUMMARY').length === 1 &&
      S.Ntf.notificationsForUser('f1').find((n) => n.entityId === r2.id && n.type === 'ALLOCATION_SUMMARY').message === '60 of 100 are available from the warehouse. 40 remain outstanding.');
    check('70/112 outstanding demand is queryable for future Purchasing (by line, request and variant)', S.RP.getUnresolvedRequestItems('company1').some((x) => x.item.id === l2.id && x.outstanding === 40) &&
      S.RP.getRequestsWithOutstandingDemand('company1').some((r) => r.id === r2.id) && S.RP.outstandingDemandByVariant('company1').some((g) => g.productVariantId === VB && g.quantity >= 40));

    // 119 zero stock
    setAvail(VC, 0);
    const r3 = submit(VC, 100).request, l3 = r3.items[0], mv3 = db.MATERIAL_MOVEMENTS.length;
    check('119 zero stock: no allocation, 100 outstanding, no RESERVE, nothing negative', allocs(r3).length === 0 && out(r3) === 100 && resMovs(r3).length === 0 && noNeg() && q(VC, 'AVAILABLE') === 0 && r3.allocationStatus === 'UNALLOCATED');
    check('119 no warehouse fulfillment for 100 unavailable units; not in the warehouse list; flagged as a failed allocation', !ful(r3) &&
      !S.Ful.warehouseOrdersForCompany('company1').some((o) => o.id === r3.id) && S.Ful.stageOf(r3) === 'AWAITING_STOCK' && S.RP.getFailedAllocations('company1').some((r) => r.id === r3.id));

    // 120 competing requests
    setAvail(VD, 100);
    const rA = submit(VD, 80).request;
    const availAfterA = q(VD, 'AVAILABLE');
    const rB = submit(VD, 50).request;
    check('120 competing: A reserves 80 -> 20 left; B gets 20, 30 outstanding; no over-allocation', availAfterA === 20 && S.RP.getAllocatedQuantity(rA.items[0]) === 80 &&
      S.RP.getAllocatedQuantity(rB.items[0]) === 20 && out(rB) === 30 && q(VD, 'AVAILABLE') === 0 && q(VD, 'RESERVED') === 100 && phys(VD) === 100 && noNeg());

    // 121 multi-location
    const D4 = S.LM.ensureBin(db, 'loc-wh-main', 'Bin D-4');
    const E1 = S.Inv.adjustmentCandidates('company1', VE)[0];
    setAvail(VE, 40);
    S.Inv.adjustInventory(U('m1'), { productVariantId: VE, locationId: D4, direction: 'IN', quantity: 60, reasonCode: 'FOUND_STOCK' });
    const r4 = submit(VE, 75).request, a4 = allocs(r4);
    const aC2 = a4.find((a) => a.sourceLocationId === E1), aD4 = a4.find((a) => a.sourceLocationId === D4);
    check('121 multi-location: 40 reserved at the primary bin, 35 at D-4 (separate allocations + RESERVE movements), 25 left at D-4, 0 outstanding',
      a4.length === 2 && aC2 && aC2.quantity === 40 && aD4 && aD4.quantity === 35 && resMovs(r4).length === 2 && resMovs(r4).every((m) => m.allocationId === (m.fromLocationId === E1 ? aC2.id : aD4.id)) &&
      bal(VE, D4, 'AVAILABLE') === 25 && bal(VE, E1, 'AVAILABLE') === 0 && bal(VE, D4, 'RESERVED') === 35 && out(r4) === 0 && a4[0].sourceLocationId === E1);
    // 90/91 only the project's assigned warehouse
    const northId = 'loc-wh-north';
    db.LOCATIONS.push({ id: northId, companyId: 'company1', name: 'North Yard', type: 'WAREHOUSE', parentLocationId: null, projectId: null, address: '', status: 'ACTIVE', metadata: {}, createdAt: Date.now(), updatedAt: Date.now() });
    const N1 = S.LM.ensureBin(db, northId, 'Bin N-1');
    setAvail(VF, 0);
    S.Inv.adjustInventory(U('m1'), { productVariantId: VF, locationId: N1, direction: 'IN', quantity: 50, reasonCode: 'FOUND_STOCK' });
    const rN = submit(VF, 30).request;
    check('90 allocation uses the project\'s assigned warehouse only (50 in another warehouse is not touched)', allocs(rN).length === 0 && out(rN) === 30 && bal(VF, N1, 'AVAILABLE') === 50);

    // 122 pick reserved
    const pk = S.Ful.pickLine(U('m3'), r1, l1.id, { quantity: 25 });
    check('122 pick 25 of 60 reserved: RESERVED 35, PICKING 25, AVAILABLE unchanged (40), physical 100', pk.ok && q(VA, 'RESERVED') === 35 && q(VA, 'PICKING') === 25 && q(VA, 'AVAILABLE') === 40 && phys(VA) === 100);
    check('57/62 the PICK moves the request\'s own reservation (RESERVED -> PICKING, same allocation); allocation 60 = reserved 35 + picked 25',
      pk.movements.length === 1 && pk.movements[0].fromInventoryState === 'RESERVED' && pk.movements[0].toInventoryState === 'PICKING' && pk.movements[0].allocationId === a1[0].id &&
      pk.movements[0].fulfillmentId === ful(r1).id && pk.movements[0].performedByUserId === 'm3' && a1[0].status === 'PARTIALLY_FULFILLED' &&
      S.RP.allocationState(a1[0].id).RESERVED + S.RP.allocationState(a1[0].id).PICKING === a1[0].quantity && ful(r1).status === 'PICKING');
    const pk2 = S.Wsv.collectRequestItem(U('m3'), r1.id, l1.id);
    check('96 every line picked -> packed; request still PROCESSING (packed is not received)', pk2.ok && q(VA, 'PACKED') === 60 && q(VA, 'RESERVED') === 0 && ful(r1).status === 'PACKED' &&
      r1.status === 'PROCESSING' && S.Ful.stageOf(r1) === 'PACKED' && a1[0].status === 'FULFILLED');
    const up = S.Wsv.uncollectRequestItem(U('m3'), r1.id, l1.id);
    check('58 un-pick a v5 line: it goes back to ITS reservation (RESERVED 60), not to AVAILABLE; UNPACK / UNPICK are linked reversals',
      up.ok && q(VA, 'RESERVED') === 60 && q(VA, 'AVAILABLE') === 40 && q(VA, 'PACKED') === 0 && up.movements.some((m) => m.movementType === 'UNPACK' && m.reversalOfMovementId) &&
      up.movements.some((m) => m.movementType === 'UNPICK' && m.toInventoryState === 'RESERVED' && m.reversalOfMovementId) && up.movements.every((m) => m.allocationId === a1[0].id) && ful(r1).status === 'ALLOCATED');
    check('58 the Phase 2 AVAILABLE pick refuses a v5 request (it must use its reservation)', S.Inv.pickMaterial(U('m3'), { requestId: r1.id, requestItemId: l1.id, quantity: 1 }).error === 'use_fulfillment' &&
      S.Wsv.markRequestItemShort(U('m3'), r1.id, l1.id).error === 'not_applicable');

    // 123 wrong request reservation
    const aA = allocs(rA)[0], aB = allocs(rB)[0], nWrong = db.MATERIAL_MOVEMENTS.length;
    const steal = S.MLS.postMovements(U('m3'), [{ movementType: 'PICK', companyId: 'company1', productVariantId: VD, quantity: 50, unit: 'EA', fromLocationId: aA.sourceLocationId, toLocationId: aA.sourceLocationId,
      fromInventoryState: 'RESERVED', toInventoryState: 'PICKING', projectId: rB.projectId, requestId: rB.id, requestItemId: rB.items[0].id, allocationId: aA.id }]);
    const anon = S.MLS.postMovements(U('m3'), [{ movementType: 'PICK', companyId: 'company1', productVariantId: VD, quantity: 5, unit: 'EA', fromLocationId: aA.sourceLocationId, toLocationId: aA.sourceLocationId,
      fromInventoryState: 'RESERVED', toInventoryState: 'PICKING', projectId: rB.projectId, requestId: rB.id, requestItemId: rB.items[0].id }]);
    const over = S.Ful.pickLine(U('m3'), rB, rB.items[0].id, { quantity: 25 });
    check('123 Request B cannot pick Request A\'s reservation (mismatch, no allocation, or more than its own 20)', steal.error === 'allocation_mismatch' && anon.error === 'allocation_required' &&
      over.error === 'insufficient_reservation' && db.MATERIAL_MOVEMENTS.length === nWrong && S.RP.allocationState(aA.id).RESERVED === 80 && S.RP.allocationState(aB.id).RESERVED === 20);
    check('60/61 reservation ownership lives in allocations + the ledger, not in the balance key', q(VD, 'RESERVED') === 100 && db.INVENTORY_BALANCES.filter((b) => b.productVariantId === VD && b.inventoryState === 'RESERVED').length === 1);

    // 124 release / modify allocation
    setAvail(VG, 60);
    const r7 = submit(VG, 100).request, a7 = allocs(r7)[0];
    const rel = S.Wf.managerSetAllocation(U('m1'), a7.id, 40);
    check('124 release 20: allocated 40, outstanding 60, 20 back to AVAILABLE by an UNRESERVE (the RESERVE is untouched)', rel.ok && a7.quantity === 40 && out(r7) === 60 && q(VG, 'AVAILABLE') === 20 && q(VG, 'RESERVED') === 40 &&
      resMovs(r7).length === 2 && resMovs(r7)[0].quantity === 60 && resMovs(r7)[1].movementType === 'UNRESERVE' && resMovs(r7)[1].quantity === 20 && resMovs(r7)[1].allocationId === a7.id && ful(r7).items[0].allocatedQuantity === 40);
    check('73 release is audited (ALLOCATION_RELEASED + MATERIAL_UNRESERVED)', db.AUDIT_EVENTS.some((e) => e.action === 'ALLOCATION_RELEASED' && e.entityId === a7.id && e.after.released === 20 && e.userId === 'm1') &&
      db.AUDIT_EVENTS.some((e) => e.action === 'MATERIAL_UNRESERVED' && e.after.allocationIds[0] === a7.id));
    const inc = S.Wf.managerSetAllocation(U('m1'), a7.id, 60);
    check('84 increase 40 -> 60 reserves only the extra 20 (one RESERVE of 20)', inc.ok && a7.quantity === 60 && q(VG, 'RESERVED') === 60 && q(VG, 'AVAILABLE') === 0 && resMovs(r7)[2].movementType === 'RESERVE' && resMovs(r7)[2].quantity === 20);
    const nx = db.MATERIAL_MOVEMENTS.length;
    check('23/24 cannot exceed demand or AVAILABLE; negative stock never happens', S.Wf.managerSetAllocation(U('m1'), a7.id, 101).error === 'exceeds_demand' &&
      S.Wf.managerSetAllocation(U('m1'), a7.id, 80).error === 'insufficient_stock' && db.MATERIAL_MOVEMENTS.length === nx && a7.quantity === 60 && noNeg());
    S.Ful.pickLine(U('m3'), r7, r7.items[0].id, { quantity: 10 });
    check('83 cannot reduce below what is already picked; workers and field users cannot change allocations', S.Wf.managerSetAllocation(U('m1'), a7.id, 5).error === 'below_picked' &&
      S.Wf.managerSetAllocation(U('m3'), a7.id, 50).error === 'forbidden' && S.Wf.managerSetAllocation(U('f1'), a7.id, 50).error === 'forbidden' && a7.quantity === 60);
    const mvC2 = S.Wf.managerSetAllocation(U('m1'), aC2.id, 30), mvD4 = S.Wf.managerSetAllocation(U('m1'), aD4.id, 45);
    check('22 manager override C-2 40 -> 30, D-4 35 -> 45 (total still 75, balances consistent)', mvC2.ok && mvD4.ok && aC2.quantity + aD4.quantity === 75 && bal(VE, E1, 'RESERVED') === 30 &&
      bal(VE, E1, 'AVAILABLE') === 10 && bal(VE, D4, 'RESERVED') === 45 && bal(VE, D4, 'AVAILABLE') === 15 && out(r4) === 0 && phys(VE) === 100);
    setAvail(VC, 30);
    const more = S.Wf.managerAllocateAvailable(U('m1'), r3.id);
    check('stock arrives later: the manager allocates what is available now (30), 70 stay outstanding, a fulfillment appears', more.ok && S.RP.getAllocatedQuantity(l3) === 30 && out(r3) === 70 &&
      !!ful(r3) && ful(r3).items[0].allocatedQuantity === 30 && r3.allocationStatus === 'PARTIALLY_ALLOCATED' && S.Ful.stageOf(r3) === 'PENDING');

    // 125–127 approvals
    setAvail(VH, 100);
    const nm0 = db.MATERIAL_MOVEMENTS.length, fu0 = db.FULFILLMENTS.length;
    const e1 = submit(VH, 10, { priority: 'EMERGENCY' }), re = e1.request, ap = e1.approval;
    check('125 Emergency triggers Project Manager approval: PENDING_APPROVAL, no allocation, no reservation, no fulfillment', re.status === 'PENDING_APPROVAL' && re.approvalStatus === 'PENDING' &&
      allocs(re).length === 0 && resMovs(re).length === 0 && db.MATERIAL_MOVEMENTS.length === nm0 && db.FULFILLMENTS.length === fu0 && q(VH, 'AVAILABLE') === 100 &&
      /^APR-/.test(ap.id) && ap.steps.length === 1 && ap.steps[0].requiredRole === 'PROJECT_MANAGER' && ap.reasons[0].ruleId === 'rule-emergency-pm');
    check('71 approver notified; requester told it awaits approval; the warehouse is NOT notified yet', S.Ntf.notificationsForUser('demo-pm1').some((n) => n.type === 'APPROVAL_REQUIRED' && n.entityId === ap.id) &&
      S.Ntf.notificationsForUser('f1').some((n) => n.type === 'REQUEST_AWAITING_APPROVAL' && n.entityId === re.id) && !db.NOTIFICATIONS.some((n) => n.entityId === re.id && n.type === 'FULFILLMENT_CREATED'));
    check('42 a Foreman (Full Control), the warehouse and the requester cannot approve; the service refuses', S.Wf.approveRequest(U('f1'), ap.id).error === 'forbidden' &&
      S.Wf.approveRequest(U('m1'), ap.id).error === 'forbidden' && !S.Appr.canResolveStep(U('f1'), ap, ap.steps[0]) && ap.status === 'PENDING' &&
      !S.Perm.canUser(U('f1'), 'RESOLVE_PROJECT_APPROVAL', { projectId: 'proj1' }) && S.Perm.canUser(U('demo-pm1'), 'RESOLVE_PROJECT_APPROVAL', { projectId: 'proj1' }) &&
      !S.Perm.canUser(U('demo-pm1'), 'RESOLVE_PROJECT_APPROVAL', { projectId: 'proj3' }));
    check('78 the PM sees approvals only for projects they are assigned to', S.Appr.approvalsVisibleTo(U('demo-pm1')).every((x) => ['proj1', 'proj2', 'proj4'].indexOf(x.projectId) !== -1) &&
      S.Appr.pendingApprovalsFor(U('demo-pm1')).some((x) => x.id === ap.id) && S.Appr.pendingApprovalsFor(U('f1')).length === 0);
    // UI: the PM signs in with the Field Team, sees the card, approves with one tap
    await login('field', 'Sofia Reyes', '7272');
    check('78/101 PM signs in with the Field Team and sees "waiting for your approval" on Home', ui.screen === 'fHome' && html().includes('waiting for your approval') && !html().includes('request(s)'));
    A.openApprovals(); await wait(10); A.openApproval(ap.id); await wait(10);
    check('41/101 the decision screen shows request, project, requester, priority, needed, materials, value unavailable and the reason',
      html().includes(re.id) && html().includes('7 Fairfield Rd') && html().includes('Carlos Rodriguez') && html().includes('Emergency') && html().includes('Value unavailable') &&
      html().includes('Emergency request') && html().includes('Materials (1)') && html().includes('Reject') && html().includes('Approve'));
    const aud0 = db.AUDIT_EVENTS.length;
    A.approveApproval(ap.id); A.approveApproval(ap.id); await wait(10);
    const reA = allocs(re);
    check('126 approved: request APPROVED -> allocated once, reserved once, one fulfillment', ap.status === 'APPROVED' && re.approvalStatus === 'APPROVED' && re.status === 'PROCESSING' &&
      reA.length === 1 && reA[0].quantity === 10 && resMovs(re).length === 1 && S.Ful.fulfillmentsForRequest(re.id).length === 1 && q(VH, 'RESERVED') === 10);
    check('127 double approve: one decision, one allocation, one reservation, one fulfillment', ap.steps[0].resolvedByUserId === 'demo-pm1' &&
      db.AUDIT_EVENTS.slice(0, db.AUDIT_EVENTS.length - aud0).filter((e) => e.action === 'MATERIAL_REQUEST_APPROVED').length === 1 &&
      S.Wf.approveRequest(U('demo-pm1'), ap.id).error === 'already_resolved' && allocs(re).length === 1 && resMovs(re).length === 1 && S.Ful.fulfillmentsForRequest(re.id).length === 1);
    check('110 the business story is reconstructable: submitted -> approval created -> approved (Sofia) -> ANT allocated + reserved -> fulfillment created',
      ['MATERIAL_REQUEST_SUBMITTED', 'APPROVAL_REQUEST_CREATED', 'MATERIAL_REQUEST_APPROVED', 'ALLOCATION_CREATED', 'MATERIAL_RESERVED', 'FULFILLMENT_CREATED'].every((act) =>
        db.AUDIT_EVENTS.some((e) => e.action === act && (e.entityId === re.id || e.entityId === ap.id || (e.after && e.after.requestId === re.id)))) &&
      db.AUDIT_EVENTS.find((e) => e.action === 'ALLOCATION_CREATED' && e.after.requestId === re.id).after.triggeredByUserId === 'demo-pm1' &&
      db.AUDIT_EVENTS.find((e) => e.action === 'ALLOCATION_CREATED' && e.after.requestId === re.id).actorType === 'SYSTEM' &&
      S.Ntf.notificationsForUser('f1').some((n) => n.type === 'REQUEST_APPROVED' && n.entityId === re.id) && S.Ntf.notificationsForUser('m1').some((n) => n.type === 'FULFILLMENT_CREATED' && n.entityId === re.id));

    // 128 rejection (UI)
    const e2 = submit(VH, 15, { priority: 'EMERGENCY' }), rj = e2.request, apj = e2.approval, mvj = db.MATERIAL_MOVEMENTS.length;
    A.openApprovals(); await wait(10); A.openApproval(apj.id); await wait(10);
    await type(byId('approval-notes'), 'Quantity needs review.');
    await click('Reject');
    check('128 rejected: CANCELLED with approvalStatus REJECTED; no allocation, reservation or fulfillment; history kept', rj.status === 'CANCELLED' && rj.approvalStatus === 'REJECTED' &&
      apj.status === 'REJECTED' && apj.decisionNotes === 'Quantity needs review.' && apj.steps[0].resolvedByUserId === 'demo-pm1' && allocs(rj).length === 0 &&
      db.MATERIAL_MOVEMENTS.length === mvj && S.Ful.fulfillmentsForRequest(rj.id).length === 0 && !!db.REQUESTS.find((x) => x.id === rj.id) && S.Ful.stageOf(rj) === 'REJECTED');
    check('45/71 the requester is told, with the reason', S.Ntf.notificationsForUser('f1').some((n) => n.type === 'REQUEST_REJECTED' && n.entityId === rj.id && n.message.includes('Quantity needs review.')));
    A.closeApprovals();
    await login('field', 'Carlos', '4827');
    A.openRequestDetail(rj.id); await wait(10);
    check('102 the requester sees Rejected, by whom, and the note (no internal ids)', html().includes('Rejected by Sofia Reyes') && html().includes('Quantity needs review.') && !html().includes('APR-'));
    A.closeRequestDetail();

    // 129 unknown cost
    const pol = db.APPROVAL_POLICIES[0];
    pol.rules.push({ id: 'rule-value-500', type: 'REQUEST_VALUE', operator: 'GREATER_THAN', value: 500, approverRole: 'PROJECT_MANAGER', priority: 2, active: true });
    const vx = submit(VI, 5).request;
    const vAp = db.APPROVAL_REQUESTS.find((x) => x.requestId === vx.id);
    check('129 unknown cost is never $0: a value rule routes to manual review (COST_UNKNOWN_REVIEW_REQUIRED), nothing reserved', vx.status === 'PENDING_APPROVAL' && !!vAp &&
      vAp.reasons.some((x) => x.code === 'COST_UNKNOWN_REVIEW_REQUIRED') && vAp.steps[0].requiredRole === 'PROJECT_MANAGER' && allocs(vx).length === 0 &&
      S.Appr.estimatedMaterialValue(vx).known === false && S.Appr.estimatedMaterialValue(vx).value === null && S.Appr.estimatedMaterialValue(vx).label === 'Value unavailable');
    const pv = C.getProduct('wc1'); pv.unitCost = 2; pv.unitCostTrusted = true;   // TEST-ONLY trusted price (the real catalog has none)
    const ev = S.Appr.evaluateApproval({ companyId: 'company1', projectId: 'proj1', priority: 'NORMAL', items: [{ productVariantId: 'wc1', quantity: 10 }] });
    const ev2 = S.Appr.evaluateApproval({ companyId: 'company1', projectId: 'proj1', priority: 'NORMAL', items: [{ productVariantId: 'wc1', quantity: 300 }] });
    const est = S.Appr.estimatedMaterialValue({ items: [{ productVariantId: 'wc1', quantity: 10 }] });
    check('37/74 with trusted prices the value is estimated and labeled (20 -> no approval; 600 -> PM)', ev.required === false && ev2.required === true && ev2.reasons[0].code === 'RULE_MATCHED' &&
      est.known && est.value === 20 && est.label === 'Estimated Material Value');
    delete pv.unitCost; delete pv.unitCostTrusted;
    pol.rules = pol.rules.filter((x) => x.id !== 'rule-value-500');
    // 44 multi-step
    pol.rules.push({ id: 'rule-qty-purch', type: 'QUANTITY', operator: 'GREATER_THAN', value: 1000, approverRole: 'PURCHASING_MANAGER', priority: 3, active: true });
    const ms = submit(VH, 1500, { priority: 'EMERGENCY' }), msAp = ms.approval;
    const st1 = S.Wf.approveRequest(U('demo-pm1'), msAp.id);
    check('44 ordered steps (PM then Purchasing): after the PM the request still waits, nothing allocated', msAp.steps.map((x) => x.requiredRole).join() === 'PROJECT_MANAGER,PURCHASING_MANAGER' &&
      st1.ok && st1.nextStep && msAp.status === 'PENDING' && msAp.steps[0].status === 'APPROVED' && msAp.steps[1].status === 'PENDING' && allocs(ms.request).length === 0 &&
      S.Appr.currentStep(msAp).requiredRole === 'PURCHASING_MANAGER' && S.Wf.approveRequest(U('demo-pm1'), msAp.id).error === 'forbidden');
    pol.rules = pol.rules.filter((x) => x.id !== 'rule-qty-purch');
    const cx = S.Wf.cancelRequest(U('f1'), ms.request.id);
    check('80 the requester may withdraw a pending request; its approval is cancelled, nothing was reserved', cx.ok && msAp.status === 'CANCELLED' && ms.request.status === 'CANCELLED' && resMovs(ms.request).length === 0);
    S.Wf.cancelRequest(U('f1'), vx.id);

    // 130 / 131 duplicate detection (UI)
    const dupBase = submit(VA, 50).request;
    const dres = S.Wf.submitRequest(U('f1'), { projectId: 'proj1', priority: 'NORMAL', neededBy: Date.now() + 864e5, lines: [{ productId: VA, qty: 50 }] }, { submissionKey: 'dup-probe' });
    check('130 same project + same variant within 24 h: a warning, nothing saved yet', !!dres.duplicates && dres.duplicates.some((m) => m.requestId === dupBase.id && m.quantity === 50) && !db.REQUESTS.some((r) => r.submissionKey === 'dup-probe'));
    A.selectProject('proj1'); await wait(10);
    ui.cart = [{ productId: VA, qty: 50, brandIdx: 0 }];
    const nReq = db.REQUESTS.length;
    await sendCurrentCart();
    check('103 the warning sheet: "Possible duplicate request", the material, View / Continue anyway / Go back', html().includes('Possible duplicate request') && html().includes('Continue anyway') &&
      html().includes('Go back') && html().includes('View request') && html().includes(dupBase.id) && db.REQUESTS.length === nReq && !html().includes('[object Object]') &&
      db.AUDIT_EVENTS.some((e) => e.action === 'DUPLICATE_WARNING_SHOWN' && e.after.matchingRequestIds.indexOf(dupBase.id) !== -1));
    await click('Continue anyway'); await wait(560);
    const dupNew = newest();
    const ov = db.AUDIT_EVENTS.find((e) => e.action === 'DUPLICATE_WARNING_OVERRIDDEN');
    check('48/50 continue anyway: the request is sent, and the override is audited (requester, project, matching request, variants)', db.REQUESTS.length === nReq + 1 && dupNew.items[0].productVariantId === VA &&
      ov && ov.entityId === dupNew.id && ov.after.requesterUserId === 'f1' && ov.after.projectId === 'proj1' && ov.after.matchingRequestIds.indexOf(dupBase.id) !== -1 && ov.after.productVariantIds.indexOf(VA) !== -1);
    ui.cart = [{ productId: VA, qty: 5, brandIdx: 0 }];
    await sendCurrentCart(); await click('Go back');
    check('103 go back closes the warning and keeps the cart; nothing is saved', !ui.requestDuplicate && ui.cart.length === 1 && db.REQUESTS.length === nReq + 1);
    ui.cart = [];
    check('131 a different project requesting the same variant gets no warning', S.Wf.findPossibleDuplicates(U('f1'), 'proj2', [{ productId: VA, qty: 50 }]).length === 0);
    const co = db.COMPANIES[0];
    co.settings.duplicateWindowHours = 0;
    check('49 the window is a company setting (0 h -> no warning); detection can be switched off', S.Wf.findPossibleDuplicates(U('f1'), 'proj1', [{ productId: VA, qty: 1 }]).length === 0 &&
      (() => { co.settings.duplicateWindowHours = 24; co.settings.duplicateDetectionEnabled = false; const n = S.Wf.findPossibleDuplicates(U('f1'), 'proj1', [{ productId: VA, qty: 1 }]).length; co.settings.duplicateDetectionEnabled = true; return n === 0; })());

    // 87 submit double tap
    ui.cart = [{ productId: VB, qty: 1, brandIdx: 0 }];
    const nDT = db.REQUESTS.length;
    A.goto('fOrderForm'); await wait(10); await click('Review request');
    const sk = ui.submissionKey;
    const sameNeed = Date.now() + 864e5;   // a real retry sends exactly the same payload
    const again = S.Wf.submitRequest(U('f1'), { projectId: 'proj1', priority: 'NORMAL', neededBy: sameNeed, lines: [{ productId: VB, qty: 1 }] }, { submissionKey: sk, duplicateOverride: [] });
    const again2 = S.Wf.submitRequest(U('f1'), { projectId: 'proj1', priority: 'NORMAL', neededBy: sameNeed, lines: [{ productId: VB, qty: 1 }] }, { submissionKey: sk, duplicateOverride: [] });
    check('87 a retry with the same submission key returns the same request (one request, one allocation)', again.request && again2.duplicateSubmission && again2.request.id === again.request.id &&
      db.REQUESTS.length === nDT + 1 && allocs(again.request).length <= 1);
    A.closeReview && A.closeReview(); ui.cart = []; ui.submissionKey = null;

    // 100/65 field detail: plain words, no ledger jargon
    A.openRequestDetail(r2.id); await wait(10);
    check('65/100/111 field request detail: Requested 100 / Warehouse 60 / Needs sourcing 40, "Partially available", no ids or ledger terms',
      html().includes('Requested') && html().includes('100 EA') && html().includes('Warehouse') && html().includes('60 EA') && html().includes('Needs sourcing') && html().includes('40 EA') &&
      html().includes('Partially available') && !html().includes('ALC-') && !html().includes('FUL-') && !html().includes('RESERVED'));
    A.closeRequestDetail();
    A.fNavTo('orders', 'fMyOrders'); await wait(10);
    check('field Orders shows outstanding lines in plain words', (html().includes('lines still outstanding') || html().includes('line still outstanding')));

    // 133 / 134 cancellation (UI + service)
    setAvail(VB, 30);
    const cr1 = submit(VB, 12).request, ca = allocs(cr1)[0], av0 = q(VB, 'AVAILABLE');
    A.openRequestDetail(cr1.id); await wait(10); await click('Cancel request');
    check('133 cancel before picking: reservation released (UNRESERVE), AVAILABLE restored, allocation + fulfillment cancelled', cr1.status === 'CANCELLED' && ca.status === 'CANCELLED' &&
      q(VB, 'AVAILABLE') === av0 + 12 && resMovs(cr1).map((m) => m.movementType).join() === 'RESERVE,UNRESERVE' && resMovs(cr1)[1].actorType === 'SYSTEM' &&
      resMovs(cr1)[1].metadata.source === 'REQUEST_CANCELLED' && resMovs(cr1)[1].metadata.triggeredByUserId === 'f1' && ful(cr1).status === 'CANCELLED' &&
      !S.Ful.warehouseOrdersForCompany('company1').some((o) => o.id === cr1.id) && out(cr1) === 0 && db.AUDIT_EVENTS.some((e) => e.action === 'MATERIAL_REQUEST_CANCELLED' && e.entityId === cr1.id));
    const cr2 = submit(VB, 5).request;
    S.Ful.pickLine(U('m3'), cr2, cr2.items[0].id, { quantity: 2 });
    const pick0 = q(VB, 'PICKING'), cres = S.Wf.cancelRequest(U('f1'), cr2.id);
    check('134 cancel after picking is blocked with a clear message; stock is not silently returned', cres.error === 'processing_started' && /picked/.test(cres.message) &&
      cr2.status === 'PROCESSING' && q(VB, 'PICKING') === pick0 && allocs(cr2)[0].status !== 'CANCELLED');
    check('cancel is only for the requester or the project lead', S.Wf.cancelRequest(U('a1'), cr2.id).error === 'forbidden');

    // 132 quick reorder (UI)
    const oldAllocs = JSON.stringify(allocs(r1).map((a) => [a.id, a.quantity, a.status]));
    setAvail(VA, 200);   // current stock for the reorder to draw from
    A.reorder(r1.id); await wait(10);
    await sendCurrentCart();
    if (ui.requestDuplicate) { await click('Continue anyway'); await wait(560); }
    const ro = newest();
    check('132 quick reorder: a NEW request with NEW allocations from current stock; the old allocations are untouched', ro.id !== r1.id && ro.items[0].productVariantId === VA &&
      allocs(ro).length >= 1 && allocs(ro).every((a) => a.requestId === ro.id && allocs(r1).indexOf(a) === -1) &&
      JSON.stringify(allocs(r1).map((a) => [a.id, a.quantity, a.status])) === oldAllocs && resMovs(ro).every((m) => m.requestId === ro.id));

    // 104 job kits
    const kit = db.JOB_KITS.find((k) => k.id === 'kit-panel');
    A.openKit(kit.id); await wait(10); A.addKitToRequest(); await wait(10);
    await sendCurrentCart();
    if (ui.requestDuplicate) { await click('Continue anyway'); await wait(560); }
    const rk = newest();
    check('104 a Job Kit becomes normal request lines; each is allocated per variant (allocated + outstanding = requested)', rk.items.length === kit.materials.length &&
      rk.items.every((it) => S.RP.getAllocatedQuantity(it) + S.RP.getOutstandingQuantity(it, rk) === it.quantity));

    // warehouse UX
    await login('warehouse', 'Michael Torres', '8899');
    A.startPackingMode(r2.id); await wait(10);
    check('68 Packing Mode: ALLOCATED 60, LOCATION, RESERVED 60, [Pick 60 EA]; never "Need 100"', html().includes('Allocated') && html().includes('60 EA') && html().includes('Reserved') &&
      html().includes('Pick 60 EA') && html().includes('Requested 100 · 40 EA outstanding') && !html().includes('100 EA</div>'));
    await click('Pick 60');
    check('Packing Mode picks the reservation and the single-line order packs', ful(r2).status === 'PACKED' && q(VB, 'PACKED') >= 60);
    A.exitPackingMode(); await wait(10);
    check('64 warehouse fulfillment PACKED, request PARTIALLY_FULFILLED (40 outstanding), never FULFILLED', r2.status === 'PARTIALLY_FULFILLED' && ful(r2).status === 'PACKED');
    await login('warehouse', 'Ana', '0000');
    A.openOrder(r2.id); await wait(10);
    check('67/69 manager order detail: what the warehouse prepares, and that the rest stays outstanding (no fake supplier data)', html().includes('Warehouse prepares only what is reserved') &&
      html().includes('Requested 100 · 40 EA outstanding') && html().includes('Review allocation'));
    for (const to of ['Mark as ready to ship', 'Mark as shipped', 'Mark as completed']) { await click(to); await wait(10); A.openOrder(r2.id); await wait(10); }
    check('7 delivered with 40 still outstanding: PARTIALLY_FULFILLED, not FULFILLED', S.Ful.stageOf(r2) === 'COMPLETED' && r2.status === 'PARTIALLY_FULFILLED');
    A.closeOrder();
    A.openOrder(r7.id); await wait(10); await click('Review allocation');
    const a7in = byId('alloc-' + a7.id); a7in.setAttribute('data-mark', 'k');
    await type(a7in, '5'); await type(byId('alloc-' + a7.id), '50');
    check('22 the allocation sheet keeps the same input while typing (mobile)', byId('alloc-' + a7.id).getAttribute('data-mark') === 'k');
    await TAP(); await click('Save');
    check('22 manager saves 60 -> 50 in the allocation sheet: UNRESERVE 10, outstanding 50', a7.quantity === 50 && out(r7) === 50 && html().includes('Allocation updated'));
    A.closeAllocation(); A.closeOrder();
    A.goto('mInventory'); await wait(10);
    check('69 Restock lists outstanding demand as "not yet sourced" (no invented supplier)', html().includes('Outstanding 40 EA') && html().includes('not yet sourced'));
    A.openInventoryDetail(VD); await wait(10);
    check('inventory detail shows RESERVED next to Available / Picking / Packed', html().includes('Reserved') && html().includes('100'));
    A.closeInventoryDetail(); A.logout(); await wait(10);

    // 137 / 138 integrity
    check('138 every v5 line: requested = allocated + outstanding; every allocation = reserved + picked + packed', db.REQUESTS.filter((r) => r.allocationMode === 'V5' && r.status !== 'CANCELLED').every((r) =>
      r.items.every((it) => S.RP.getAllocatedQuantity(it) + S.RP.getOutstandingQuantity(it, r) === it.quantity)) &&
      db.ALLOCATIONS.filter(S.RP.isActiveAllocation).every((a) => { const s = S.RP.allocationState(a.id); return s.RESERVED + s.PICKING + s.PACKED === a.quantity; }));
    check('143 after all of Phase 3: 0 integrity problems, no negatives', P3().length === 0 && noNeg());
    const codes = () => P3().map((x) => x.code);
    const tA = db.ALLOCATIONS.find((a) => a.requestId === r7.id);
    const keepP = tA.projectId; tA.projectId = 'proj2';
    const c1 = codes(); tA.projectId = keepP;
    tA.quantity += 1; const c2 = codes(); tA.quantity -= 1;
    const keepR = tA.requestId; tA.requestId = 'ORD-NOPE'; const c3 = codes(); tA.requestId = keepR;
    const fx = db.FULFILLMENTS.find((f) => f.requestId === r7.id); const keepFR = fx.requestId; fx.requestId = 'ORD-NOPE'; const c4 = codes(); fx.requestId = keepFR;
    const ax = db.APPROVAL_REQUESTS[0]; const keepAR = ax.requestId; ax.requestId = 'ORD-NOPE'; const c5 = codes(); ax.requestId = keepAR;
    r7.items[0].collected = true; const c6 = codes(); delete r7.items[0].collected;
    const keepAS = r7.approvalStatus; r7.approvalStatus = 'PENDING'; const c7 = codes(); r7.approvalStatus = keepAS;
    check('137 integrity catches: wrong project, broken equation, orphan allocation, orphan fulfillment, orphan approval, v5 progress field, allocation before approval',
      c1.indexOf('ALLOCATION_PROJECT') !== -1 && c2.indexOf('ALLOCATION_EQUATION') !== -1 && c3.indexOf('ALLOCATION_ORPHAN') !== -1 && c4.indexOf('FULFILLMENT_ORPHAN') !== -1 &&
      c5.indexOf('APPROVAL_REQUEST') !== -1 && c6.indexOf('REQUEST_V5_PROGRESS_FIELD') !== -1 && c7.indexOf('REQUEST_ALLOCATED_BEFORE_APPROVAL') !== -1 && P3().length === 0);

    // 115 transaction boundary
    const snap = JSON.stringify([db.REQUESTS.length, db.ALLOCATIONS.length, db.MATERIAL_MOVEMENTS.length, db.INVENTORY_BALANCES, db.MOVEMENT_SEQ, db.ORDER_SEQ]);
    const tx = S.Tx.transaction(() => {
      const r = S.Req.createRequest(U('f1'), { projectId: 'proj1', priority: 'NORMAL', neededBy: Date.now() + 864e5, lines: [{ productId: VA, qty: 3 }] }).request;
      S.Alloc.allocateRequest(S.MLS.systemActor('company1', 'TEST', 'f1'), r);
      return { error: 'simulated_failure' };
    });
    const txThrow = S.Tx.transaction(() => { S.Req.createRequest(U('f1'), { projectId: 'proj1', priority: 'NORMAL', neededBy: Date.now() + 864e5, lines: [{ productId: VA, qty: 3 }] }); throw new Error('boom'); });
    const heldRef = db.REQUESTS[0], heldId = heldRef.id;
    S.Tx.transaction(() => { heldRef.notes = 'changed inside a failed transaction'; return { error: 'x' }; });
    check('115 rollback restores records in place (a held reference stays live and unchanged)', db.REQUESTS[0] === heldRef && heldRef.id === heldId && heldRef.notes !== 'changed inside a failed transaction');
    check('115 a failed step leaves no half-finished state (request, allocation, RESERVE, balances and ids all rolled back)', tx.rolledBack && txThrow.rolledBack && txThrow.error === 'transaction_failed' &&
      JSON.stringify([db.REQUESTS.length, db.ALLOCATIONS.length, db.MATERIAL_MOVEMENTS.length, db.INVENTORY_BALANCES, db.MOVEMENT_SEQ, db.ORDER_SEQ]) === snap && P3().length === 0);
    check('16 the system actor may only reserve / unreserve (never adjust or pick)', S.MLS.postMovements(S.MLS.systemActor('company1', 'TEST', null), [{ movementType: 'INVENTORY_ADJUSTMENT_IN', companyId: 'company1',
      productVariantId: VA, quantity: 1, unit: 'EA', toLocationId: S.Inv.adjustmentCandidates('company1', VA)[0], toInventoryState: 'AVAILABLE', reasonCode: 'FOUND_STOCK' }]).error === 'actor_required');
    const t0 = Date.now();
    const big = S.Wf.submitRequest(U('f1'), { projectId: 'proj1', priority: 'NORMAL', neededBy: Date.now() + 864e5, lines: V3.slice(0, 9).map((v) => ({ productId: v, qty: 1 })) }, { submissionKey: 'perf', duplicateOverride: [] });
    check('114 allocation stays fast (9-line request allocated in well under a second)', !!big.request && Date.now() - t0 < 1000);
    const saved5 = W.localStorage.getItem(S.STORAGE_KEY);
    W = boot(saved5); await wait(80); ({ A, ui, db, C, S } = W.__ANT);
    check('persisted: allocations, fulfillments and approvals survive a refresh; 0 problems', db.ALLOCATIONS.length > 10 && db.FULFILLMENTS.some((f) => f.allocationMode === 'V5') &&
      db.APPROVAL_REQUESTS.length >= 4 && S.Integrity.checkIntegrity(db).length === 0 && db.SCHEMA_VERSION === 6);
  }

  console.log('TEST Phase 3: cross-company isolation (135)');
  {
    const MC = require('./fixtures/multi-company.cjs');
    W = boot(JSON.stringify(MC.addRoleTestUsers(MC.addCompanyB(JSON.parse(W.localStorage.getItem(S.STORAGE_KEY)))))); await wait(80);
    ({ A, ui, db, C, S } = W.__ANT);
    const U = (id) => db.USERS.find((u) => u.id === id);
    const rA = db.REQUESTS.find((r) => r.companyId === 'company1' && r.allocationMode === 'V5' && S.Alloc.getAllocationsForRequest(r.id).some(S.RP.isActiveAllocation));
    const aA = S.Alloc.getAllocationsForRequest(rA.id).find(S.RP.isActiveAllocation);
    const apA = db.APPROVAL_REQUESTS.find((x) => x.companyId === 'company1');
    const n0 = db.MATERIAL_MOVEMENTS.length, q0 = aA.quantity;
    check('135 Company B cannot approve, allocate, reserve, modify, cancel or even see Company A\'s demand',
      S.Wf.approveRequest(U('mb1'), apA.id).error === 'forbidden' && S.Wf.rejectRequest(U('mb1'), apA.id).error === 'forbidden' &&
      S.Alloc.allocateRequestItem(U('mb1'), rA, rA.items[0]).error === 'forbidden' && S.Wf.managerSetAllocation(U('mb1'), aA.id, 1).error === 'forbidden' &&
      S.Wf.managerAllocateAvailable(U('mb1'), rA.id).error === 'forbidden' && S.Wf.cancelRequest(U('mb1'), rA.id).error === 'forbidden' &&
      S.MLS.postMovements(U('mb1'), [{ movementType: 'RESERVE', companyId: 'company1', productVariantId: aA.productVariantId, quantity: 1, unit: aA.unit, fromLocationId: aA.sourceLocationId, toLocationId: aA.sourceLocationId,
        fromInventoryState: 'AVAILABLE', toInventoryState: 'RESERVED', requestId: rA.id, requestItemId: rA.items[0].id, projectId: rA.projectId, allocationId: aA.id }]).error === 'company_mismatch' &&
      S.Appr.approvalsVisibleTo(U('mb1')).length === 0 && S.RP.getUnresolvedRequestItems('company2').every((x) => x.request.companyId === 'company2') &&
      db.MATERIAL_MOVEMENTS.length === n0 && aA.quantity === q0);
    const bBal = db.INVENTORY_BALANCES.find((b) => b.companyId === 'company2'), bVar = bBal.productVariantId;
    check('88 ANT itself (system actor for A) cannot reserve Company B stock', S.MLS.postMovements(S.MLS.systemActor('company1', 'TEST', null), [{ movementType: 'RESERVE', companyId: 'company2',
      productVariantId: bVar, quantity: 1, unit: bBal.unit, fromLocationId: bBal.locationId, toLocationId: bBal.locationId, fromInventoryState: 'AVAILABLE', toInventoryState: 'RESERVED' }]).error === 'company_mismatch');
    const aOnB = S.Wf.submitRequest(U('f1'), { projectId: 'proj1', priority: 'NORMAL', neededBy: Date.now() + 864e5, lines: [{ productId: bVar, qty: 5 }] }, { submissionKey: 'iso-b', duplicateOverride: [] }).request;
    check('88/90 an A request never allocates B\'s stock of the same variant', S.Alloc.getAllocationsForRequest(aOnB.id).every((a) => a.companyId === 'company1') &&
      S.Inv.getQuantityByState('company2', bVar).AVAILABLE === 500);
    const bProj = db.PROJECTS.find((p) => p.companyId === 'company2');
    check('89 a Company A user cannot submit into a Company B project', !!S.Wf.submitRequest(U('f1'), { projectId: bProj.id, priority: 'NORMAL', neededBy: Date.now() + 864e5, lines: [{ productId: bVar, qty: 1 }] }, { duplicateOverride: [] }).error);
    check('79 an Owner approves company-wide (capability, not a hard-coded role check)', S.Perm.canUser(U('ow1'), 'RESOLVE_PROJECT_APPROVAL', { projectId: 'proj3' }) &&
      S.Perm.canUser(U('ow1'), 'RESOLVE_COMPANY_APPROVAL', { companyId: 'company1' }));
    check('isolation leaves 0 integrity problems', S.Integrity.checkIntegrity(db).length === 0);
  }

  console.log('TEST Phase 3: migrations to v5 (136)');
  for (const [tag, file, from] of [['v4 (Phase 2 save)', 'v4-react-saved.json', 4], ['v3', 'v3-react-saved.json', 3], ['v2', 'v2-react-saved.json', 2], ['v1', 'v1-react-saved.json', 1]]) {
    const raw = fs.readFileSync(path.join(__dirname, 'fixtures', file), 'utf8'), src = JSON.parse(raw);
    W = boot(raw); await wait(80); ({ A, ui, db, C, S } = W.__ANT);
    const saved = JSON.parse(W.localStorage.getItem(S.STORAGE_KEY));
    const chain = db.MIGRATIONS.map((m) => m.from + '>' + m.to).join();
    check('136 ' + tag + ': upgraded to v5 (' + chain + '), backup kept, 0 problems', saved.schemaVersion === 6 && S.loadReport.migratedFrom === from && /5>6$/.test(chain) &&
      W.localStorage.getItem(S.backupKeyFor(from)) === raw && S.Integrity.checkIntegrity(db).length === 0);
    check('136 ' + tag + ': no fabricated allocations, reservations or approvals; every old request is LEGACY with a compatibility fulfillment',
      db.ALLOCATIONS.length === 0 && db.APPROVAL_REQUESTS.length === 0 && !db.MATERIAL_MOVEMENTS.some((m) => m.movementType === 'RESERVE') &&
      db.REQUESTS.every((r) => r.allocationMode === 'LEGACY' && r.approvalStatus === 'LEGACY' && db.FULFILLMENTS.filter((f) => f.requestId === r.id && f.legacyMigrated).length === 1));
    if (from === 4) {
      const r4 = db.REQUESTS.find((r) => r.id === 'ORD-1004'), l4 = r4.items[0];
      check('136 v4: balances and ledger untouched (same movements, same balances)', db.MATERIAL_MOVEMENTS.length === src.materialMovements.length &&
        src.inventoryBalances.every((b) => db.INVENTORY_BALANCES.some((x) => x.id === b.id && x.quantity === b.quantity)));
      check('99 v4: an open order keeps its progress (10 of 30 still PICKING, linked to its line) and keeps the legacy AVAILABLE -> PICKING pick',
        r4.workflowStatus === 'PENDING' && l4.pickedQuantity === 10 && S.MLS.getMovementsForRequestItem(l4.id).some((m) => m.toInventoryState === 'PICKING' && m.quantity === 10) &&
        (() => { const res = S.Wsv.collectRequestItem(db.USERS.find((u) => u.id === 'm3'), r4.id, l4.id); return res.ok && res.movements.every((m) => m.fromInventoryState === 'AVAILABLE' && !m.allocationId); })());
      const once = db.USERS.length + ':' + db.FULFILLMENTS.length + ':' + db.APPROVAL_POLICIES.length;
      W = boot(W.localStorage.getItem(S.STORAGE_KEY)); await wait(80); ({ A, ui, db, C, S } = W.__ANT);
      check('136 idempotent: reloading v5 adds nothing (users, compatibility fulfillments, policies)', db.USERS.length + ':' + db.FULFILLMENTS.length + ':' + db.APPROVAL_POLICIES.length === once && db.MIGRATIONS.length === 5);
    }
  }

  /* =====================================================================
     PHASE 3 CORRECTION PASS — approval chains, outstanding demand access,
     multiple fulfillments per request, submission idempotency
     ===================================================================== */
  console.log('TEST Phase 3 correction: approval chains, outstanding demand, batches, submission idempotency');
  {
    const MC = require('./fixtures/multi-company.cjs');
    W = boot(); await wait(80);
    ({ A, ui, db, C, S } = W.__ANT);
    A.setLanguage('en'); await wait(10);   // a persisting commit, so the fresh demo data is in storage
    W = boot(JSON.stringify(MC.addApproverTestUsers(MC.addRoleTestUsers(MC.addCompanyB(JSON.parse(W.localStorage.getItem(S.STORAGE_KEY))))))); await wait(80);
    ({ A, ui, db, C, S } = W.__ANT);
    const U = (id) => db.USERS.find((u) => u.id === id);
    const loginA = async (team, name, pin) => { if (ui.currentUser) { A.logout(); await wait(15); } A.selectLoginCompany('company1'); await wait(15); await login(team, name, pin); };
    const q = (vid, st) => S.Inv.getQuantityByState('company1', vid)[st] || 0;
    const P = () => S.Integrity.checkIntegrity(db);
    const setAvail = (vid, n) => { const cur = q(vid, 'AVAILABLE'); if (n !== cur) S.Inv.adjustInventory(U('m1'), { productVariantId: vid, direction: n > cur ? 'IN' : 'OUT', quantity: Math.abs(n - cur), reasonCode: 'PHYSICAL_COUNT_CORRECTION' }); };
    const VV = S.Inv.stockedVariantIds('company1').filter((k) => k.includes('::') && !k.includes('Any') && S.Cat.getProductVariant(k).unit === 'EA' && S.Inv.adjustmentCandidates('company1', k).length === 1 && q(k, 'AVAILABLE') > 0);
    const [K1, K2, K3, K4, K5, K6, K7, K8] = VV;
    let nk = 0;
    const need = Date.now() + 2 * 864e5;
    const submit = (by, vid, qty, o) => S.Wf.submitRequest(U(by), { projectId: (o && o.project) || 'proj1', priority: (o && o.priority) || 'NORMAL', neededBy: (o && o.neededBy) || need,
      lines: [{ productId: vid, qty }] }, { submissionKey: (o && o.key) || 'c-' + (++nk), duplicateOverride: [] });
    const allocs = (r) => S.Alloc.getAllocationsForRequest(r.id);
    const reserves = (r) => db.MATERIAL_MOVEMENTS.filter((m) => m.requestId === r.id && m.movementType === 'RESERVE');
    const batches = (r) => S.Ful.warehouseFulfillmentsFor(r.id);
    const notes = (uid, apId) => S.Ntf.notificationsForUser(uid).filter((n) => n.type === 'APPROVAL_REQUIRED' && n.entityId === apId);
    check('C test data: Purchasing Managers in both companies (company role only, no project membership), 8 clean variants, 0 problems',
      VV.length >= 8 && U('pu1').companyRoles.join() === 'PURCHASING_MANAGER' && U('pb1').companyId === 'company2' && !db.MEMBERSHIPS.some((m) => m.userId === 'pu1') && P().length === 0);

    /* ---------- 1. approval chains ---------- */
    const pol = db.APPROVAL_POLICIES.find((p) => p.companyId === 'company1');
    pol.rules.push({ id: 'rule-big-purch', type: 'QUANTITY', operator: 'GREATER_THAN', value: 1000, approverRole: 'PURCHASING_MANAGER', priority: 2, active: true, label: 'Large quantity' });
    setAvail(K1, 3000);
    const ch = submit('f1', K1, 1500, { priority: 'EMERGENCY' }), cr = ch.request, cap = ch.approval;
    check('1.7 chain PM -> Purchasing: step 1 PENDING (active), step 2 WAITING; request PENDING_APPROVAL', cap.steps.map((x) => x.requiredRole + ':' + x.status).join() === 'PROJECT_MANAGER:PENDING,PURCHASING_MANAGER:WAITING' &&
      cr.status === 'PENDING_APPROVAL' && allocs(cr).length === 0);
    check('1.9/TEST G only the ACTIVE step is notified: the PM now, the Purchasing Manager not yet', notes('demo-pm1', cap.id).length === 1 && notes('pu1', cap.id).length === 0 &&
      S.Appr.pendingApprovalsFor(U('pu1')).every((x) => x.id !== cap.id));
    check('TEST C the PM cannot resolve the Purchasing step (and B\'s Purchasing Manager nothing at all)', !S.Appr.canResolveStep(U('demo-pm1'), cap, cap.steps[1]) &&
      S.Wf.approveRequest(U('pb1'), cap.id).error === 'forbidden' && S.Wf.approveRequest(U('pu1'), cap.id).error === 'forbidden' && cap.steps[0].status === 'PENDING');
    const s1 = S.Wf.approveRequest(U('demo-pm1'), cap.id, 'OK for site');
    check('TEST A PM approves step 1: step 2 becomes active; request still pending; nothing allocated, reserved or created', s1.ok && s1.nextStep &&
      cap.steps[0].status === 'APPROVED' && cap.steps[1].status === 'PENDING' && cap.steps[1].activatedAt > 0 && cap.status === 'PENDING' && cr.status === 'PENDING_APPROVAL' &&
      allocs(cr).length === 0 && reserves(cr).length === 0 && batches(cr).length === 0 && q(K1, 'RESERVED') === 0);
    check('9 audited: APPROVAL_STEP_COMPLETED (step 1) and APPROVAL_STEP_ACTIVATED (step 2, company scope)', db.AUDIT_EVENTS.some((e) => e.action === 'APPROVAL_STEP_COMPLETED' && e.entityId === cap.id && e.after.step === 1 && e.userId === 'demo-pm1') &&
      db.AUDIT_EVENTS.some((e) => e.action === 'APPROVAL_STEP_ACTIVATED' && e.entityId === cap.id && e.after.step === 2 && e.after.scope === 'COMPANY'));
    check('TEST G / 1.8 the next approver is notified only now: "requires Purchasing approval"', notes('pu1', cap.id).length === 1 && notes('pu1', cap.id)[0].title === 'Material request ' + cr.id + ' requires Purchasing approval' &&
      notes('demo-pm1', cap.id).length === 1 && S.Appr.pendingApprovalsFor(U('pu1')).some((x) => x.id === cap.id));
    check('TEST C/D after step 1: the PM still cannot resolve step 2; Company B\'s Purchasing Manager is refused', S.Wf.approveRequest(U('demo-pm1'), cap.id).error === 'forbidden' &&
      S.Wf.approveRequest(U('pb1'), cap.id).error === 'forbidden' && S.Appr.approvalsVisibleTo(U('pb1')).every((x) => x.companyId === 'company2') && cap.steps[1].status === 'PENDING');
    const nBefore = db.NOTIFICATIONS.length;
    // the Purchasing Manager signs in (Phase 4: the Purchasing Team), sees the card, approves in the UI (double tap)
    await loginA('purchasing', 'Paula Ueda', '1111');
    check('1.1 a Purchasing Manager (company role, no projects) signs in to the Purchasing home and sees the approval waiting', ui.screen === 'pHome' && html().includes('waiting for your approval') &&
      html().includes('Purchase Requirements'));
    A.openApprovals(); await wait(10); A.openApproval(cap.id); await wait(10);
    check('the decision screen shows step 2 of 2 for Purchasing', html().includes(cr.id) && html().includes('Purchasing Manager (2/2)') && html().includes('Large quantity'));
    A.approveApproval(cap.id); A.approveApproval(cap.id); await wait(10);
    const ca = allocs(cr);
    check('TEST B / TEST E Purchasing approves step 2 without any project membership: workflow APPROVED, request APPROVED -> allocated once', cap.status === 'APPROVED' &&
      cap.steps[1].status === 'APPROVED' && cap.steps[1].resolvedByUserId === 'pu1' && cr.approvalStatus === 'APPROVED' && cr.status === 'PROCESSING' &&
      ca.length === 1 && ca[0].quantity === 1500 && reserves(cr).length === 1 && batches(cr).length === 1 && q(K1, 'RESERVED') === 1500);
    check('1.11 the double tap resolved nothing twice (one step decision, one allocation run, no second notification chain)',
      db.AUDIT_EVENTS.filter((e) => e.action === 'APPROVAL_STEP_COMPLETED' && e.entityId === cap.id).length === 2 && db.AUDIT_EVENTS.filter((e) => e.action === 'MATERIAL_REQUEST_APPROVED' && e.entityId === cr.id).length === 1 &&
      db.NOTIFICATIONS.slice(0, db.NOTIFICATIONS.length - nBefore).filter((n) => n.type === 'APPROVAL_REQUIRED').length === 0 && S.Wf.approveRequest(U('pu1'), cap.id).error === 'already_resolved');
    A.closeApprovals();
    // TEST F project scope: a PM of ANOTHER project can't approve Project A
    S.Proj.addOrUpdateMembership('proj4', 'pm1', 'PROJECT_MANAGER', 'FULL_CONTROL', 'ow1');
    const e2 = submit('f1', K1, 5, { priority: 'EMERGENCY' });
    check('TEST F a Project Manager of an unrelated project cannot approve Project A (primaryRole alone is not enough)', U('pm1').primaryRole === 'PROJECT_MANAGER' &&
      !S.Appr.canResolveStep(U('pm1'), e2.approval, e2.approval.steps[0]) && S.Wf.approveRequest(U('pm1'), e2.approval.id).error === 'forbidden' &&
      S.Appr.canResolveStep(U('demo-pm1'), e2.approval, e2.approval.steps[0]) && notes('pm1', e2.approval.id).length === 0);
    check('1.6 Owner / Admin: override allowed where configured; an OWNER step needs the Owner role', S.Appr.canResolveStep(U('ow1'), e2.approval, e2.approval.steps[0]) &&
      S.Appr.canResolveStep(U('ow1'), e2.approval, { requiredRole: 'OWNER', status: 'PENDING' }) && !S.Appr.canResolveStep(U('ad1'), e2.approval, { requiredRole: 'OWNER', status: 'PENDING' }) &&
      !S.Appr.canResolveStep(U('pu1'), e2.approval, { requiredRole: 'OWNER', status: 'PENDING' }));
    // 1.10 rejection ends the chain; later steps are never activated
    const e3 = submit('f1', K1, 2000, { priority: 'EMERGENCY' }), ap3 = e3.approval;
    const rj = S.Wf.rejectRequest(U('demo-pm1'), ap3.id, 'Too much at once');
    check('1.10 rejecting step 1 ends the workflow: REJECTED, step 2 cancelled and never activated or notified; nothing reserved',
      rj.ok && ap3.status === 'REJECTED' && e3.request.approvalStatus === 'REJECTED' && ap3.steps[1].status === 'CANCELLED' && !ap3.steps[1].activatedAt &&
      notes('pu1', ap3.id).length === 0 && allocs(e3.request).length === 0 && batches(e3.request).length === 0 && S.Wf.approveRequest(U('pu1'), ap3.id).error === 'already_resolved');
    S.Wf.approveRequest(U('demo-pm1'), e2.approval.id);
    pol.rules = pol.rules.filter((x) => x.id !== 'rule-big-purch');
    check('11 integrity: step roles resolvable, one active step per pending approval, order respected', P().filter((x) => /^APPROVAL/.test(x.code)).length === 0);
    // v5 data saved before sequential steps: normalized on load (no schema change)
    const oldStyle = db.APPROVAL_REQUESTS.find((x) => x.id === ap3.id);
    const snapOld = JSON.parse(W.localStorage.getItem(S.STORAGE_KEY));
    snapOld.approvalRequests.push(Object.assign(JSON.parse(JSON.stringify(oldStyle)), { id: 'APR-OLD', status: 'PENDING', resolvedAt: null,
      steps: oldStyle.steps.map((x) => Object.assign({}, x, { status: 'PENDING', resolvedByUserId: null, resolvedAt: null })) }));
    const Wold = boot(JSON.stringify(snapOld)); await wait(80);
    const old = Wold.__ANT.db.APPROVAL_REQUESTS.find((x) => x.id === 'APR-OLD');
    check('8 Phase 3 saves (every step PENDING) load as one active step + WAITING; still schema v5', old.steps.map((x) => x.status).join() === 'PENDING,WAITING' && Wold.__ANT.db.SCHEMA_VERSION === 6);

    /* ---------- 2. outstanding demand has a warehouse path ---------- */
    const WOR = () => S.RP.getWarehouseOutstandingRequests('company1');
    setAvail(K2, 0);
    const z = submit('f1', K2, 100).request;
    check('2 TEST A approved request, 100 requested, 0 stock: no fulfillment, 100 outstanding, listed in Outstanding requests',
      z.status === 'PROCESSING' && batches(z).length === 0 && S.RP.getOutstandingQuantity(z.items[0], z) === 100 && WOR().some((x) => x.request.id === z.id && x.allocated === 0 && x.outstanding === 100) &&
      S.Ntf.notificationsForUser('m1').some((n) => n.type === 'OUTSTANDING_DEMAND' && n.entityId === z.id));
    check('2.8 the selector can be scoped to one warehouse; other warehouses see nothing of it', S.RP.getWarehouseOutstandingRequests('company1', 'loc-wh-main').some((x) => x.request.id === z.id) &&
      !S.RP.getWarehouseOutstandingRequests('company1', 'loc-wh-elsewhere').length && !S.RP.getWarehouseOutstandingRequests('company2').some((x) => x.request.companyId === 'company1'));
    await loginA('warehouse', 'Ana', '0000');
    check('2.1 Manager Home shows Outstanding requests, with the zero-allocation request ("Nothing allocated yet")', html().includes('Outstanding requests') && html().includes(z.id) && html().includes('100 EA outstanding') && html().includes('nothing allocated yet'));
    A.openAllocation(z.id); await wait(10);
    check('2.3 the request allocation detail opens without any fulfillment: project, number, needed by, priority, requested / warehouse / available now / outstanding',
      html().includes('Request allocation') && html().includes(z.id) && html().includes('7 Fairfield Rd') && html().includes('Available now') && html().includes('Outstanding') &&
      html().includes('Normal') && html().includes('No stock available in this project') && !/\\u00[0-9a-f]{2}/.test(html()));
    setAvail(K2, 100);
    A.closeAllocation(); A.openAllocation(z.id); await wait(10);
    await click('Allocate available stock');
    check('2 TEST B stock arrives: Allocate available -> 100 allocated, 100 reserved, 0 outstanding, fulfillment created; gone from the list',
      S.RP.getAllocatedQuantity(z.items[0]) === 100 && q(K2, 'RESERVED') === 100 && S.RP.getOutstandingQuantity(z.items[0], z) === 0 && batches(z).length === 1 &&
      batches(z)[0].items[0].allocatedQuantity === 100 && !WOR().some((x) => x.request.id === z.id));
    A.closeAllocation();
    const co = db.COMPANIES.find((c) => c.id === 'company1');
    co.settings.autoAllocateWarehouseStock = false;
    setAvail(K3, 50);
    const man = submit('f1', K3, 20).request;
    check('2 TEST C auto-allocation off: the approved request is NOT hidden; it waits in Outstanding requests (managers told)', man.status === 'APPROVED' && allocs(man).length === 0 &&
      WOR().some((x) => x.request.id === man.id && x.outstanding === 20) && S.Ntf.notificationsForUser('m1').some((n) => n.type === 'OUTSTANDING_DEMAND' && n.entityId === man.id && /manual/.test(n.message)));
    const manRes = S.Wf.managerAllocateAvailable(U('m1'), man.id);
    check('2.5 the manager allocates it by hand: reserved, fulfillment created, out of the list', manRes.ok && S.RP.getAllocatedQuantity(man.items[0]) === 20 && batches(man).length === 1 && !WOR().some((x) => x.request.id === man.id));
    co.settings.autoAllocateWarehouseStock = true;
    setAvail(K4, 60);
    const part = submit('f1', K4, 100).request;
    check('2 TEST D partially allocated (60 of 100) stays visible with 40 outstanding although a fulfillment exists', batches(part).length === 1 && WOR().some((x) => x.request.id === part.id && x.allocated === 60 && x.outstanding === 40));
    // sorting: Emergency first, then earliest needed by, then High / Normal / Low, then oldest
    setAvail(K5, 0);
    const sLate = submit('f1', K5, 10, { priority: 'HIGH', neededBy: need + 5 * 864e5 }).request, sEarly = submit('f1', K5, 10, { priority: 'LOW', neededBy: need - 864e5 }).request;
    const sEm = submit('f1', K5, 10, { priority: 'EMERGENCY', neededBy: need + 9 * 864e5 }); S.Wf.approveRequest(U('demo-pm1'), sEm.approval.id);
    const order = WOR().map((x) => x.request.id);
    check('2.9 sorted: Emergency first, then earliest Needed By', order.indexOf(sEm.request.id) === 0 && order.indexOf(sEarly.id) < order.indexOf(sLate.id));
    const pend = submit('f1', K5, 3, { priority: 'EMERGENCY' });
    check('2.8 pending approval, rejected, cancelled and legacy requests are never listed', !WOR().some((x) => x.request.id === pend.request.id || x.request.id === e3.request.id || x.request.allocationMode === 'LEGACY'));
    S.Wf.cancelRequest(U('f1'), pend.request.id);

    /* ---------- 3. one request, many fulfillments ---------- */
    setAvail(K6, 60);
    const mr = submit('f1', K6, 100).request, ml = mr.items[0];
    const F1 = batches(mr)[0];
    check('3 TEST A request 100, stock 60: batch 1 = 60, outstanding 40', batches(mr).length === 1 && F1.items[0].allocatedQuantity === 60 && S.RP.getOutstandingQuantity(ml, mr) === 40);
    S.Wsv.collectRequestItem(U('m3'), mr.id, ml.id);
    check('3.8 batch 1 PACKED with 40 outstanding: request PARTIALLY_FULFILLED, never FULFILLED', F1.status === 'PACKED' && mr.status === 'PARTIALLY_FULFILLED');
    const f1Before = JSON.stringify({ s: F1.status, i: F1.items.map((i) => [i.allocatedQuantity, i.pickedQuantity, i.packedQuantity, i.allocationIds.join()]), p: F1.packedAt });
    const nReq = db.REQUESTS.length;
    setAvail(K6, 40);
    const more = S.Wf.managerAllocateAvailable(U('m1'), mr.id);
    const F2 = batches(mr)[1];
    check('3 TEST B allocate the new 40: batch 2 = 40 for the SAME request / project / line; outstanding 0', more.ok && batches(mr).length === 2 && F2 && F2.id !== F1.id &&
      F2.requestId === mr.id && F2.projectId === mr.projectId && F2.items[0].requestItemId === ml.id && F2.items[0].allocatedQuantity === 40 && S.RP.getOutstandingQuantity(ml, mr) === 0 &&
      /^FUL-\d+$/.test(F2.id) && parseInt(F2.id.slice(4), 10) > parseInt(F1.id.slice(4), 10));
    check('3 TEST C no new Material Request was created', db.REQUESTS.length === nReq);
    check('3 TEST D batch 1 is untouched (status, quantities, allocations, packed time)', JSON.stringify({ s: F1.status, i: F1.items.map((i) => [i.allocatedQuantity, i.pickedQuantity, i.packedQuantity, i.allocationIds.join()]), p: F1.packedAt }) === f1Before);
    check('9/10 audited and told: FULFILLMENT_CREATED_FOR_OUTSTANDING_DEMAND (batch 2), WAREHOUSE_ALLOCATION_REOPENED; the foreman hears "Now also allocated: 40 EA"',
      db.AUDIT_EVENTS.some((e) => e.action === 'FULFILLMENT_CREATED_FOR_OUTSTANDING_DEMAND' && e.entityId === F2.id && e.after.batch === 2) &&
      db.AUDIT_EVENTS.some((e) => e.action === 'WAREHOUSE_ALLOCATION_REOPENED' && e.entityId === mr.id && e.after.quantity === 40) &&
      S.Ntf.notificationsForUser('f1').some((n) => n.type === 'ADDITIONAL_ALLOCATION' && n.entityId === mr.id && /^Now also allocated: 40 EA/.test(n.message)));
    const fv = S.Ful.fieldRequestView(mr);
    check('3 TEST E the request exposes both batches (field view, warehouse tasks); the field still sees ONE request', fv.batches.length === 2 && fv.items[0].batches.map((b) => b.number + ':' + b.quantity).join() === '1:60,2:40' &&
      S.Ful.warehouseOrdersForCompany('company1').filter((o) => o.requestId === mr.id).map((o) => o.batchNumber + '/' + o.batchCount).join() === '1/2,2/2' &&
      S.Ful.fulfillmentsForRequest(mr.id).length === 2 && !('fulfillmentId' in mr));
    const aB = allocs(mr).find((a) => a.fulfillmentId === F2.id), nMv = db.MATERIAL_MOVEMENTS.length;
    const wrong = S.MLS.postMovements(U('m3'), [{ movementType: 'PICK', companyId: 'company1', productVariantId: aB.productVariantId, quantity: 40, unit: aB.unit, fromLocationId: aB.sourceLocationId,
      toLocationId: aB.sourceLocationId, fromInventoryState: 'RESERVED', toInventoryState: 'PICKING', projectId: mr.projectId, requestId: mr.id, requestItemId: ml.id, allocationId: aB.id, fulfillmentId: F1.id }]);
    check('3 TEST F batch 2\'s reservation cannot be consumed by batch 1 (service and raw ledger)', S.Ful.pickLine(U('m3'), mr, ml.id, { fulfillmentId: F1.id }).error === 'nothing_reserved' &&
      wrong.error === 'allocation_mismatch' && db.MATERIAL_MOVEMENTS.length === nMv && S.RP.allocationState(aB.id).RESERVED === 40);
    check('3 TEST G batches reconcile: 60 + 40 = 100 allocated = requested; not FULFILLED (allocated is not delivered)', F1.items[0].allocatedQuantity + F2.items[0].allocatedQuantity === 100 &&
      S.RP.getAllocatedQuantity(ml) === ml.quantity && mr.status === 'PROCESSING' && P().length === 0);
    const inc = S.Wf.managerSetAllocation(U('m1'), allocs(mr).find((a) => a.fulfillmentId === F1.id).id, 70);
    check('3.2 a started / packed batch can never grow (use a new batch instead)', inc.error === 'batch_started' || inc.error === 'exceeds_demand');
    // the worker sees two tasks with the same request number, batch 2 labeled
    await loginA('warehouse', 'Michael Torres', '8899');
    check('3.11 the worker sees the request number with "Batch 2 of 2" (not a new request)', html().includes(mr.id) && html().includes('Batch 2 of 2'));
    A.startPackingMode(F2.id); await wait(10);
    check('3.11 Packing Mode opens batch 2 by its own id: Pick 40, labeled with the request number', html().includes(mr.id + ' · Batch 2 of 2') && html().includes('Pick 40 EA'));
    await click('Pick 40');
    check('batch 2 is picked from its own reservation and packs; batch 1 still packed', F2.status === 'PACKED' && F1.status === 'PACKED' && q(K6, 'PACKED') >= 100);
    A.exitPackingMode();
    await loginA('warehouse', 'Ana', '0000');
    A.openOrder(F2.id); await wait(10);
    check('the manager opens batch 2 as its own task', html().includes('Batch 2 of 2') && html().includes('Mark as ready to ship'));
    await click('Mark as ready to ship');
    check('dispatching batch 2 moves only batch 2', F2.status === 'READY' && F1.status === 'PACKED');
    for (const fid of [F1.id, F2.id]) for (const to of ['READY_TO_SHIP', 'SHIPPED', 'COMPLETED']) S.Req.advanceWorkflow(U('m1'), mr.id, to, { fulfillmentId: fid });
    check('3.7 every batch delivered and nothing outstanding: now FULFILLED', F1.dispatchStatus === 'DELIVERED' && F2.dispatchStatus === 'DELIVERED' && mr.status === 'FULFILLED' && S.Ful.stageOf(mr) === 'COMPLETED');
    await loginA('field', 'Carlos', '4827');
    A.openRequestDetail(mr.id); await wait(10);
    check('3.12 field detail: one request, "Warehouse batch 1: 60", "Warehouse batch 2: 40", Outstanding 0', html().includes('Warehouse batch 1') && html().includes('Warehouse batch 2') && !/\\u00[0-9a-f]{2}/.test(html()) &&
      html().includes('60 EA · Completed') && html().includes('40 EA · Completed') && html().includes('0 EA'));
    A.closeRequestDetail();
    // 3.4 reuse: new stock joins a batch nobody has started
    setAvail(K7, 30);
    const ru = submit('f1', K7, 100).request;
    setAvail(K7, 20);
    S.Wf.managerAllocateAvailable(U('m1'), ru.id);
    check('3.4 a batch nobody started is reused (still one batch, now 50); no new batch', batches(ru).length === 1 && batches(ru)[0].items[0].allocatedQuantity === 50 &&
      batches(ru)[0].items[0].allocationIds.length === 2 && S.RP.getOutstandingQuantity(ru.items[0], ru) === 50);
    S.Ful.pickLine(U('m3'), ru, ru.items[0].id, { quantity: 5 });
    setAvail(K7, 10);
    S.Wf.managerAllocateAvailable(U('m1'), ru.id);
    check('3.4/3.5 once picking started, more stock gets a NEW batch (the started one is not enlarged)', batches(ru).length === 2 && batches(ru)[0].items[0].allocatedQuantity === 50 &&
      batches(ru)[1].items[0].allocatedQuantity === 10 && S.Wf.managerSetAllocation(U('m1'), allocs(ru).find((a) => a.fulfillmentId === batches(ru)[0].id).id, 60).error === 'batch_started');
    setAvail(K7, 5);
    const binRes = S.Wf.managerAllocateFromLocation(U('m1'), ru.id, ru.items[0].id, S.Inv.adjustmentCandidates('company1', K7)[0], 5);
    check('3.4 allocating from a specific bin also lands in a batch (never a reservation without a warehouse task)', binRes.ok && !!binRes.allocation.fulfillmentId &&
      batches(ru).some((f) => f.id === binRes.allocation.fulfillmentId && f.items[0].allocationIds.indexOf(binRes.allocation.id) !== -1));
    check('11 integrity: every allocation in exactly one batch, no batch over-picked, totals <= requested', P().length === 0);

    /* ---------- 4. submission idempotency ---------- */
    setAvail(K8, 500);
    const pay = (qty, project, lines) => ({ projectId: project || 'proj1', priority: 'NORMAL', neededBy: need, notes: 'dock 3', lines: lines || [{ productId: K8, qty }, { productId: K3, qty: 2 }] });
    const nR0 = db.REQUESTS.length, nA0 = db.ALLOCATIONS.length, nM0 = db.MATERIAL_MOVEMENTS.length, nF0 = db.FULFILLMENTS.length;
    const i1 = S.Wf.submitRequest(U('f1'), pay(50), { submissionKey: 'abc123', duplicateOverride: [] });
    const cA = [db.REQUESTS.length, db.ALLOCATIONS.length, db.MATERIAL_MOVEMENTS.length, db.FULFILLMENTS.length].join();
    const i2 = S.Wf.submitRequest(U('f1'), pay(50), { submissionKey: 'abc123', duplicateOverride: [] });
    check('4 TEST A same user + key + payload: one request, the same one returned', !!i1.request && i2.duplicateSubmission && i2.request.id === i1.request.id && db.REQUESTS.length === nR0 + 1);
    check('4 TEST F the retry duplicated no allocation, reservation or fulfillment', [db.REQUESTS.length, db.ALLOCATIONS.length, db.MATERIAL_MOVEMENTS.length, db.FULFILLMENTS.length].join() === cA &&
      db.ALLOCATIONS.length > nA0 && db.MATERIAL_MOVEMENTS.length > nM0 && db.FULFILLMENTS.length === nF0 + 1);
    const reordered = S.Wf.submitRequest(U('f1'), pay(0, null, [{ productId: K3, qty: 2 }, { productId: K8, qty: 50 }]), { submissionKey: 'abc123', duplicateOverride: [] });
    check('4.6 the same items in another order are the same submission', reordered.duplicateSubmission && reordered.request.id === i1.request.id);
    const i3 = S.Wf.submitRequest(U('f1'), pay(75), { submissionKey: 'abc123', duplicateOverride: [] });
    const i4 = S.Wf.submitRequest(U('f1'), pay(50, 'proj2'), { submissionKey: 'abc123', duplicateOverride: [] });
    check('4 TEST B/C same key, different quantity or project: IDEMPOTENCY_CONFLICT; nothing created or changed; audited', i3.error === 'IDEMPOTENCY_CONFLICT' && i4.error === 'IDEMPOTENCY_CONFLICT' &&
      db.REQUESTS.length === nR0 + 1 && i1.request.items.find((x) => x.productVariantId === K8).quantity === 50 && i1.request.projectId === 'proj1' &&
      db.AUDIT_EVENTS.filter((e) => e.action === 'REQUEST_SUBMISSION_IDEMPOTENCY_CONFLICT' && e.after.requesterUserId === 'f1').length === 2);
    const j = S.Wf.submitRequest(U('j1'), pay(50), { submissionKey: 'abc123', duplicateOverride: [] });
    check('4 TEST D another user, same company, same key: an independent request (never Carlos\'s)', !!j.request && !j.duplicateSubmission && j.request.id !== i1.request.id && j.request.requestedByUserId === 'j1');
    const bProj = db.PROJECTS.find((p) => p.companyId === 'company2');
    const bUser = db.USERS.find((u) => u.companyId === 'company2' && S.Perm.canUser(u, 'REQUEST_MATERIALS', { projectId: bProj.id }));
    const bVar = db.INVENTORY_BALANCES.find((b) => b.companyId === 'company2').productVariantId;
    const b = S.Wf.submitRequest(bUser, { projectId: bProj.id, priority: 'NORMAL', neededBy: need, lines: [{ productId: bVar, qty: 5 }] }, { submissionKey: 'abc123', duplicateOverride: [] });
    check('4 TEST E the same key in another company is independent (no leakage either way)', !!b.request && b.request.companyId === 'company2' && !b.duplicateSubmission && b.request.id !== i1.request.id);
    const rec = db.IDEMPOTENCY_RECORDS.find((x) => x.companyId === 'company1' && x.operationKey === 'submit:f1:abc123');
    check('4.1 the record: company + requester + key, fingerprint, the request it created (frozen)', rec && rec.operationType === 'SUBMIT_MATERIAL_REQUEST' && rec.actorUserId === 'f1' &&
      rec.resultEntityId === i1.request.id && rec.payloadFingerprint === i1.request.submissionFingerprint && /^fp1:/.test(rec.payloadFingerprint) && Object.isFrozen(rec));
    // 4.8 a tampered record never leaks another user's request
    const idx = db.IDEMPOTENCY_RECORDS.indexOf(rec);
    db.IDEMPOTENCY_RECORDS[idx] = Object.freeze(Object.assign({}, rec, { resultEntityId: j.request.id }));
    const leak = S.Wf.submitRequest(U('f1'), pay(50), { submissionKey: 'abc123', duplicateOverride: [] });
    check('4.8 a record pointing at someone else\'s request is refused safely (IDEMPOTENCY_INTEGRITY), and integrity flags it', leak.error === 'IDEMPOTENCY_INTEGRITY' && !leak.request &&
      P().some((x) => x.code === 'SUBMISSION_IDEMPOTENCY'));
    db.IDEMPOTENCY_RECORDS[idx] = rec;
    // v5 data from before submission records: the request itself carries the key
    const legacyKey = submit('f1', K8, 3, { key: 'old-key' }).request;
    db.IDEMPOTENCY_RECORDS = db.IDEMPOTENCY_RECORDS.filter((x) => x.operationKey !== 'submit:f1:old-key'); delete legacyKey.submissionFingerprint;
    const lk = S.Wf.submitRequest(U('f1'), { projectId: 'proj1', priority: 'NORMAL', neededBy: need, lines: [{ productId: K8, qty: 3 }] }, { submissionKey: 'old-key', duplicateOverride: [] });
    const lk2 = S.Wf.submitRequest(U('j1'), { projectId: 'proj1', priority: 'NORMAL', neededBy: need, lines: [{ productId: K8, qty: 3 }] }, { submissionKey: 'old-key', duplicateOverride: [] });
    check('4 Phase 3 requests without a record still replay for their own requester only (fingerprint computed from the request)', lk.duplicateSubmission && lk.request.id === legacyKey.id &&
      !!lk2.request && lk2.request.id !== legacyKey.id);
    // UI: a conflicting resend shows a clear message and a fresh key
    ui.submissionKey = 'abc123'; ui.cart = [{ productId: K8, qty: 99, brandIdx: 0 }];
    A.selectProject('proj1'); A.goto('fOrderForm'); await wait(10); A.reviewOrder(); A.sendOrder(); await wait(560);
    check('4.3 in the app: a changed payload under the same key shows a clear message and gets a fresh key (no silent old request)', html().includes('already sent with different details') && ui.submissionKey === null);
    ui.cart = [];
    check('Phase 3 correction pass leaves 0 integrity problems and no negative stock', P().length === 0 && db.INVENTORY_BALANCES.every((x) => x.quantity >= 0));
  }


  /* =====================================================================
     PHASE 3 MICRO CORRECTION: every outstanding request is reachable
     (Home preview of 5 + "View all N outstanding requests" + full list)
     ===================================================================== */
  console.log('TEST Phase 3 micro correction: View all outstanding requests');
  {
    const MC = require('./fixtures/multi-company.cjs');
    W = boot(); await wait(80);
    ({ A, ui, db, C, S } = W.__ANT);
    A.setLanguage('en'); await wait(10);
    W = boot(JSON.stringify(MC.addCompanyB(JSON.parse(W.localStorage.getItem(S.STORAGE_KEY))))); await wait(80);
    ({ A, ui, db, C, S } = W.__ANT);
    const U = (id) => db.USERS.find((u) => u.id === id);
    const loginA = async (team, name, pin) => { if (ui.currentUser) { A.logout(); await wait(15); } A.selectLoginCompany('company1'); await wait(15); await login(team, name, pin); };
    const q = (vid) => S.Inv.getQuantityByState('company1', vid).AVAILABLE || 0;
    const setAvail = (vid, n) => { const cur = q(vid); if (n !== cur) S.Inv.adjustInventory(U('m1'), { productVariantId: vid, direction: n > cur ? 'IN' : 'OUT', quantity: Math.abs(n - cur), reasonCode: 'PHYSICAL_COUNT_CORRECTION' }); };
    const VV = S.Inv.stockedVariantIds('company1').filter((k) => k.includes('::') && !k.includes('Any') && S.Cat.getProductVariant(k).unit === 'EA' && S.Inv.adjustmentCandidates('company1', k).length === 1 && q(k) > 0);
    let n = 0;
    const mk = (vid, qty, o) => S.Wf.submitRequest(U('f1'), { projectId: (o && o.project) || 'proj1', priority: (o && o.priority) || 'NORMAL', neededBy: Date.now() + (o && o.days || 1) * 864e5,
      lines: [{ productId: vid, qty }].concat((o && o.extra) || []) }, { submissionKey: 'm-' + (++n), duplicateOverride: [] }).request;
    const cardIds = () => [...W.document.querySelectorAll('[data-outstanding]')].map((b) => b.getAttribute('data-outstanding'));
    const WOR = () => S.RP.outstandingRequestsFor(U('m1'));
    // TEST A: 8 outstanding requests (zero stock), different urgency
    const zv = VV.slice(0, 8); zv.forEach((v) => setAvail(v, 0));
    const reqs = zv.map((v, i) => mk(v, 10 + i, { days: 1 + i }));
    check('M test data: 8 approved requests with outstanding demand, the list has exactly those 8 (0 problems)', WOR().length === 8 && reqs.every((r) => WOR().some((x) => x.request.id === r.id)) &&
      S.Integrity.checkIntegrity(db).length === 0);
    await loginA('warehouse', 'Ana', '0000');
    check('TEST A Home preview shows 5 of 8 and "View all 8 outstanding requests" (no plain "+ 3 more")', cardIds().length === 5 && html().includes('View all 8 outstanding requests') &&
      !html().includes('and 3 more') && JSON.stringify(cardIds()) === JSON.stringify(WOR().slice(0, 5).map((x) => x.request.id)));
    await click('View all 8 outstanding requests');
    check('TEST A the full list opens (no new bottom tab) and shows all 8, in the same order as the preview', ui.screen === 'mOutstanding' && cardIds().length === 8 &&
      JSON.stringify(cardIds()) === JSON.stringify(WOR().map((x) => x.request.id)) && html().includes('8 requests') && W.document.querySelectorAll('.bottomnav .navitem').length === 4);
    const sixth = WOR()[5].request.id;
    W.document.querySelector('[data-outstanding="' + sixth + '"]').dispatchEvent(new W.MouseEvent('click', { bubbles: true })); await wait(10);
    check('TEST B a request that was NOT in the preview opens the existing allocation detail', ui.allocationOrderId === sixth && html().includes('Request allocation · ' + sixth) &&
      html().includes('Available now') && html().includes('Allocate available stock'));
    A.closeAllocation(); await wait(10);
    // TEST C zero allocation; TEST D partial (60 of 100, a batch exists)
    const zr = reqs[0];
    check('TEST C zero allocation, zero fulfillment: listed with its outstanding quantity', S.Ful.warehouseFulfillmentsFor(zr.id).length === 0 && cardIds().indexOf(zr.id) !== -1 &&
      html().includes('10 EA outstanding · nothing allocated yet'));
    const pv = VV[8]; setAvail(pv, 60);
    const pr = mk(pv, 100, { days: 20 });
    A.mNavTo('home', 'mHome'); await wait(10); await click('View all 9 outstanding requests');
    check('TEST D partially allocated (60 of 100, batch 1 exists): listed with 40 outstanding', S.Ful.warehouseFulfillmentsFor(pr.id).length === 1 && cardIds().indexOf(pr.id) !== -1 &&
      html().includes('40 EA outstanding · partly allocated'));
    // several materials with different units: never one misleading quantity
    const ft = S.Inv.stockedVariantIds('company1').find((k) => k.includes('::') && !k.includes('Any') && S.Cat.getProductVariant(k).unit === 'FT' && S.Inv.adjustmentCandidates('company1', k).length === 1);
    setAvail(ft, 0);
    const multi = mk(zv[1], 5, { days: 30, extra: [{ productId: ft, qty: 500 }] });
    A.mNavTo('home', 'mHome'); await wait(10); await click('View all 10 outstanding requests');
    const mcard = W.document.querySelector('[data-outstanding="' + multi.id + '"]').textContent;
    check('9 a request with several materials (EA and FT) says "2 materials need sourcing", not one quantity', mcard.includes('2 materials need sourcing') && !/\d+ (EA|FT) outstanding/.test(mcard));
    W.document.querySelector('[data-outstanding="' + multi.id + '"]').dispatchEvent(new W.MouseEvent('click', { bubbles: true })); await wait(10);
    check('9 its detail shows each material separately (EA and FT outstanding)', html().includes('5 EA') && html().includes('500 FT'));
    A.closeAllocation(); await wait(10);
    // TEST E resolve: 40 arrive for the partial request; the list and Home update without a reload
    setAvail(pv, 40);
    W.document.querySelector('[data-outstanding="' + pr.id + '"]').dispatchEvent(new W.MouseEvent('click', { bubbles: true })); await wait(10);
    await click('Allocate available stock');
    A.closeAllocation(); await wait(10);
    check('TEST E remaining 40 allocated: outstanding 0, gone from the full list, count 9', S.RP.getOutstandingQuantity(pr.items[0], pr) === 0 && cardIds().indexOf(pr.id) === -1 &&
      cardIds().length === 9 && html().includes('9 requests'));
    // 11/13 stock arrives for a request that IS in the preview: the next one moves up
    A.mNavTo('home', 'mHome'); await wait(10);
    const before = cardIds(), next = WOR()[5].request.id, gone = before[2];
    const gr = db.REQUESTS.find((r) => r.id === gone);
    setAvail(gr.items[0].productVariantId, gr.items[0].quantity);
    A.openAllocation(gone); await wait(10); await click('Allocate available stock'); A.closeAllocation(); await wait(10);
    check('11/13 morning 0 stock -> later stock arrives -> Allocate available: the request leaves the preview, the 6th moves up, "View all 8"',
      cardIds().indexOf(gone) === -1 && cardIds().length === 5 && cardIds().indexOf(next) !== -1 && html().includes('View all 8 outstanding requests') &&
      S.Ful.warehouseFulfillmentsFor(gone).length === 1 && S.RP.getOutstandingQuantity(gr.items[0], gr) === 0);
    // TEST F company isolation
    const bProj = db.PROJECTS.find((p) => p.companyId === 'company2');
    const bUser = db.USERS.find((u) => u.companyId === 'company2' && S.Perm.canUser(u, 'REQUEST_MATERIALS', { projectId: bProj.id }));
    const bReq = S.Wf.submitRequest(bUser, { projectId: bProj.id, priority: 'EMERGENCY', neededBy: Date.now(), lines: [{ productId: zv[0], qty: 3 }] }, { submissionKey: 'b-1', duplicateOverride: [] }).request;
    const bMgr = db.USERS.find((u) => u.companyId === 'company2' && S.Perm.canUser(u, 'MANAGE_ALLOCATIONS'));
    check('TEST F Company B\'s outstanding request never appears for Company A (and A never appears for B)', !!bReq && !WOR().some((x) => x.request.companyId !== 'company1') &&
      cardIds().indexOf(bReq.id) === -1 && (!bMgr || S.RP.outstandingRequestsFor(bMgr).every((x) => x.request.companyId === 'company2')));
    // TEST G warehouse isolation: a second warehouse; proj4 is assigned to it
    db.LOCATIONS.push({ id: 'loc-wh-north', companyId: 'company1', name: 'North Yard', type: 'WAREHOUSE', parentLocationId: null, projectId: null, address: '', status: 'ACTIVE', metadata: {}, createdAt: Date.now(), updatedAt: Date.now() });
    const p4 = db.PROJECTS.find((p) => p.id === 'proj4'); const keepWh = p4.assignedWarehouseId; p4.assignedWarehouseId = 'loc-wh-north';
    const nr = S.Wf.submitRequest(U('f4'), { projectId: 'proj4', priority: 'NORMAL', neededBy: Date.now() + 864e5, lines: [{ productId: zv[3], qty: 7 }] }, { submissionKey: 'n-1', duplicateOverride: [] }).request;
    U('m1').warehouseId = 'loc-wh-main';
    const mainOnly = WOR().map((x) => x.request.id);
    delete U('m1').warehouseId;
    const allWh = WOR().map((x) => x.request.id);
    A.mNavTo('home', 'mHome'); await wait(10); await click('View all');
    check('TEST G a manager of the Main Warehouse never sees North Yard\'s request; with no warehouse set, both (labeled by warehouse)', !!nr && mainOnly.indexOf(nr.id) === -1 &&
      allWh.indexOf(nr.id) !== -1 && W.document.querySelector('[data-outstanding="' + nr.id + '"]').textContent.includes('North Yard'));
    U('m1').warehouseId = 'loc-wh-other-company';
    check('0/20 an invalid assigned warehouse is flagged by integrity and SAFE-DENIES (no records), never widening to the company',
      S.Integrity.checkIntegrity(db).some((x) => x.code === 'USER_WAREHOUSE') && S.RP.warehouseScopeFor(U('m1')) === S.RP.WAREHOUSE_SCOPE_DENIED && WOR().length === 0 &&
      (() => { U('m1').warehouseId = 'loc-wh-north'; db.LOCATIONS.find((l) => l.id === 'loc-wh-north').status = 'INACTIVE'; const n = WOR().length; db.LOCATIONS.find((l) => l.id === 'loc-wh-north').status = 'ACTIVE'; return n === 0; })());
    delete U('m1').warehouseId; p4.assignedWarehouseId = keepWh;
    // 19 permissions: a worker gets no outstanding list and no allocation authority
    await loginA('warehouse', 'Michael Torres', '8899');
    A.openOutstandingRequests(); await wait(10);
    check('19 a Warehouse Worker sees no Outstanding requests, cannot open the full list, and cannot allocate', !html().includes('Outstanding requests') && ui.screen !== 'mOutstanding' &&
      S.Wf.managerAllocateAvailable(U('m3'), reqs[1].id).error === 'forbidden');
    // 14 empty state: everything allocated
    await loginA('warehouse', 'Ana', '0000');
    WOR().forEach((x) => { x.items.forEach((l) => { if (l.outstanding > 0) setAvail(W.__ANT.I.stockKey(l.item.productVariantId, 'company1'), q(W.__ANT.I.stockKey(l.item.productVariantId, 'company1')) + l.outstanding); }); S.Wf.managerAllocateAvailable(U('m1'), x.request.id); });
    A.mNavTo('home', 'mHome'); await wait(10);
    check('14 nothing outstanding: no preview and no "View all 0"', WOR().length === 0 && !html().includes('View all') && !html().includes('Outstanding requests'));
    A.openOutstandingRequests(); await wait(10);
    check('14 the full list shows a positive empty state', ui.screen === 'mOutstanding' && html().includes('All warehouse demand is currently allocated.'));
    A.setLanguage('es'); await wait(10);
    check('17 Spanish: the empty state is translated', html().includes('Toda la demanda del almacén está asignada.') && html().includes('Solicitudes pendientes'));
    A.setLanguage('en'); A.mNavTo('home', 'mHome'); A.logout(); await wait(10);
    check('micro correction leaves 0 integrity problems and no negative stock', S.Integrity.checkIntegrity(db).length === 0 && db.INVENTORY_BALANCES.every((b) => b.quantity >= 0));
  }

  /* =====================================================================
     PHASE 4 — PURCHASING + SUPPLIERS + PURCHASE ORDERS (service level,
     spec tests 133–155 + integrity)
     ===================================================================== */
  console.log('TEST Phase 4: purchasing services');
  {
    const MC = require('./fixtures/multi-company.cjs');
    W = boot(); await wait(80);
    ({ A, ui, db, C, S } = W.__ANT);
    A.setLanguage('en'); await wait(10);
    W = boot(JSON.stringify(MC.addApproverTestUsers(MC.addCompanyB(JSON.parse(W.localStorage.getItem(S.STORAGE_KEY)))))); await wait(80);
    ({ A, ui, db, C, S } = W.__ANT);
    const U = (id) => db.USERS.find((u) => u.id === id);
    const PUR = U('demo-pur1'), WM = U('m1'), F = U('f1');
    const q = (vid, st, co) => S.Inv.getQuantityByState(co || 'company1', vid)[st] || 0;
    const phys = (vid) => S.Inv.getPhysicalOnHand('company1', vid);
    const P = () => S.Integrity.checkIntegrity(db);
    const setAvail = (vid, n) => { const cur = q(vid, 'AVAILABLE'); if (n !== cur) S.Inv.adjustInventory(WM, { productVariantId: vid, direction: n > cur ? 'IN' : 'OUT', quantity: Math.abs(n - cur), reasonCode: 'PHYSICAL_COUNT_CORRECTION' }); };
    const VV = S.Inv.stockedVariantIds('company1').filter((k) => k.includes('::') && !k.includes('Any') && S.Cat.getProductVariant(k).unit === 'EA' && S.Inv.adjustmentCandidates('company1', k).length === 1 && q(k, 'AVAILABLE') > 0);
    const [K1, K2, K3, K4, K5, K6, K7, K8, K9] = VV;
    let n4 = 0;
    const submit = (vid, qty, o) => S.Wf.submitRequest(U((o && o.by) || 'f1'), { projectId: (o && o.project) || 'proj1', priority: (o && o.priority) || 'NORMAL',
      neededBy: Date.now() + ((o && o.days) || 2) * 864e5, lines: [{ productId: vid, qty }] }, { submissionKey: 'p4-' + (++n4), duplicateOverride: [] });
    const prsOf = (r) => S.PRS.getRequirementsForRequest(r.id);
    const prog = (pr) => S.PRS.getRequirementProgress(pr);
    const line = (r) => r.items[0];
    const lp = (r) => S.RP.getLineProgress(line(r), r);
    const movs = () => db.MATERIAL_MOVEMENTS.length;
    const draft = (pr, qty, o) => S.POS.createDraft(PUR, Object.assign({ supplierId: (o && o.supplier) || sup.id, expectedDeliveryDate: (o && o.expected) || '2026-10-02',
      lines: [{ productVariantId: pr.productVariantId, unit: pr.unit, unitPrice: (o && o.price) != null ? o.price : 1.2, stockOverageQuantity: (o && o.overage) || 0,
        demand: [{ purchaseRequirementId: pr.id, quantity: qty }] }] }, o), { operationKey: (o && o.key) || 'po-' + (++n4) });
    const sendNew = (pr, qty, o) => { const d = draft(pr, qty, o); const s2 = S.POS.sendPurchaseOrder(PUR, d.purchaseOrder.id); return s2.purchaseOrder || d.purchaseOrder; };
    const recv = (po, good, o) => S.Rcv.receivePurchaseOrder((o && o.by) || WM, po.id, { lines: [{ purchaseOrderItemId: po.items[0].id, quantityGood: good, quantityDamaged: (o && o.damaged) || 0,
      locationId: (o && o.loc) || S.Rcv.defaultReceivingLocation(po, po.items[0]) }] }, { operationKey: (o && o.key) || 'rc-' + (++n4) });
    check('P4 test data: fresh v6, a demo Purchasing Manager and 3 fictional demo suppliers, 9 clean variants, 0 problems', db.SCHEMA_VERSION === 6 && PUR && PUR.workerType === 'PURCHASING' &&
      db.SUPPLIERS.filter((s) => s.companyId === 'company1').length === 3 && db.SUPPLIERS.every((s) => /fictional/.test(s.notes)) && VV.length >= 9 && P().length === 0);

    // 133 requirement creation
    setAvail(K1, 60);
    const r1 = submit(K1, 100).request, pr1 = prsOf(r1)[0];
    check('133 request 100, warehouse 60: ONE requirement for 40, linked to request / line / project / variant / warehouse', prsOf(r1).length === 1 && /^PR-\d+$/.test(pr1.requirementNumber) &&
      pr1.id !== pr1.requirementNumber && pr1.quantityRequired === 40 && pr1.requestId === r1.id && pr1.requestItemId === line(r1).id && pr1.projectId === r1.projectId &&
      pr1.productVariantId === K1 && pr1.unit === 'EA' && pr1.destinationWarehouseId === 'loc-wh-main' && pr1.status === 'OPEN' && pr1.createdByActor.actorType === 'SYSTEM');
    check('7/110 created automatically, audited, and Purchasing is told "40 EA … need sourcing for ORD-…"', db.AUDIT_EVENTS.some((e) => e.action === 'PURCHASE_REQUIREMENT_CREATED' && e.entityId === pr1.id) &&
      S.Ntf.notificationsForUser('demo-pur1').some((n) => n.type === 'PURCHASE_REQUIREMENT_CREATED' && n.entityId === pr1.id && n.title.indexOf('40 EA') === 0 && n.title.indexOf('need sourcing for ' + r1.id) !== -1));
    S.PRS.syncForRequest(r1, S.MLS.systemActor('company1', 'TEST', null)); S.PRS.syncForRequest(r1, S.MLS.systemActor('company1', 'TEST', null));
    check('8 a retried / repeated sync never creates a second requirement', prsOf(r1).length === 1 && db.PURCHASE_REQUIREMENTS.filter((x) => x.requestItemId === line(r1).id).length === 1);
    setAvail(K2, 100);
    const r2 = submit(K2, 100).request;
    check('134 fully covered by the warehouse: no requirement', prsOf(r2).length === 0);
    const pend = submit(K9, 5000, { priority: 'EMERGENCY' });
    check('13 pending approval: no requirement until approved', prsOf(pend.request).length === 0);
    S.Wf.approveRequest(U('demo-pm1'), pend.approval.id);
    check('13 approved: the unsourced part becomes a requirement', prsOf(pend.request).length === 1 && prsOf(pend.request)[0].quantityRequired === 5000 - S.RP.getAllocatedQuantity(line(pend.request)));

    // suppliers + quotes
    const sup = S.Sup.createSupplier(PUR, { name: 'Graybar', accountNumber: 'GB-A1', contactName: 'Dana', email: 'dana@graybar.example', paymentTerms: 'Net 30', preferred: true }).supplier;
    const supB2 = S.Sup.createSupplier(PUR, { name: 'Crescent', defaultLeadTimeDays: 5 }).supplier;
    const qt = S.Sup.addSupplierQuote(PUR, { supplierId: sup.id, purchaseRequirementId: pr1.id, unitPrice: 1.2, leadTimeDays: 2, quoteNumber: 'Q-77' });
    S.Sup.addSupplierQuote(PUR, { supplierId: supB2.id, purchaseRequirementId: pr1.id, unitPrice: 1.1, leadTimeDays: 5 });
    check('17/19 manual quotes: stored, compared cheapest first, requirement SOURCING, nothing ordered automatically', qt.ok && S.Sup.getQuotesForRequirement(PUR, pr1.id).map((x) => x.unitPrice).join() === '1.1,1.2' &&
      pr1.status === 'SOURCING' && !db.PURCHASE_ORDERS.length && S.Sup.getQuotesForRequirement(F, pr1.id).length === 0);
    check('14/16 supplier management: preferred first, search, a unit other than the variant\'s is refused on quotes', S.Sup.getSuppliers(PUR)[0].name === 'Graybar' &&
      S.Sup.getSuppliers(PUR, { search: 'gb-a1' }).length === 1 && S.Sup.addSupplierQuote(PUR, { supplierId: sup.id, purchaseRequirementId: pr1.id, unitPrice: 5, unit: 'BOX' }).error === 'unit_mismatch');

    // 136 draft
    const mv0 = movs();
    const d1 = draft(pr1, 40, { key: 'po-A' });
    const po1 = d1.purchaseOrder;
    check('136 draft for 40: PO DRAFT (PO-…), requirement IN_DRAFT; the field does NOT see On Order; no inventory movement', d1.ok && po1.status === 'DRAFT' && /^PO-\d+$/.test(po1.purchaseOrderNumber) &&
      po1.id !== po1.purchaseOrderNumber && pr1.status === 'IN_DRAFT' && prog(pr1).inDraft === 40 && lp(r1).onOrder === 0 && lp(r1).inDraft === 40 && lp(r1).outstanding === 40 && movs() === mv0);
    check('27 the drafted quantity is protected: a second draft for the same 40 is refused', draft(pr1, 40).error === 'exceeds_requirement' && draft(pr1, 1).error === 'exceeds_requirement');
    check('106 double tap Create PO: same key + payload replays the SAME draft; same key + other payload conflicts', draft(pr1, 40, { key: 'po-A' }).purchaseOrder === po1 &&
      draft(pr1, 39, { key: 'po-A' }).error === 'IDEMPOTENCY_CONFLICT' && db.PURCHASE_ORDERS.length === 1);
    S.POS.updateDraft(PUR, po1.id, { shipping: 5, tax: 2.5 });
    check('36/37/38 totals and snapshots: line 40 × $1.20 = $48, subtotal 48 + shipping 5 + tax 2.50 = $55.50; supplier + product snapshots stored', po1.items[0].lineSubtotal === 48 &&
      po1.subtotal === 48 && po1.total === 55.5 && po1.supplierSnapshot.name === 'Graybar' && po1.supplierSnapshot.accountNumber === 'GB-A1' && !!po1.items[0].productNameSnapshot && po1.items[0].unitPrice === 1.2);
    check('86 units are validated: BOX against an EA demand is refused (no trusted conversion)', S.POS.createDraft(PUR, { supplierId: sup.id, lines: [{ productVariantId: K1, unit: 'BOX', unitPrice: 1,
      demand: [{ purchaseRequirementId: prsOf(pend.request)[0].id, quantity: 1 }] }] }).error !== undefined);

    // 137 / 138 send
    const s1 = S.POS.sendPurchaseOrder(PUR, po1.id), aSup = S.RP.supplierAllocationsForItem(line(r1).id);
    check('137 Mark as Sent: supplier commitment 40; request Warehouse 60 / On Order 40 / Unsourced 0; still no inventory', s1.ok && po1.status === 'SENT' && po1.sentByUserId === 'demo-pur1' &&
      aSup.length === 1 && aSup[0].status === 'ORDERED' && lp(r1).allocated === 60 && lp(r1).onOrder === 40 && lp(r1).outstanding === 0 && movs() === mv0 && pr1.status === 'ORDERED' && phys(K1) === 60);
    const nNot = db.NOTIFICATIONS.length;
    const s2 = S.POS.sendPurchaseOrder(PUR, po1.id);
    check('138 double send: one commitment, no second allocation or notification', s2.duplicate && S.RP.supplierAllocationsForItem(line(r1).id).length === 1 && db.NOTIFICATIONS.length === nNot);
    check('41/158 a sent PO is locked (no silent edit of quantity, price or supplier)', S.POS.updateDraft(PUR, po1.id, { shipping: 9 }).error === 'not_draft' && po1.shipping === 5);
    check('110 the foreman hears "on order" (no price); the warehouse hears what to expect', S.Ntf.notificationsForUser('f1').some((n) => n.type === 'ON_ORDER' && n.entityId === r1.id && !/\$/.test(n.message)) &&
      S.Ntf.notificationsForUser('m1').some((n) => n.type === 'PURCHASE_ORDER_INCOMING' && n.entityId === po1.id));
    S.POS.confirmPurchaseOrder(PUR, po1.id, { supplierConfirmationNumber: 'GB-99', expectedDeliveryDate: '2026-10-03' });
    check('40 confirmed: CONFIRMED with confirmation number and updated expected date', po1.status === 'CONFIRMED' && po1.supplierConfirmationNumber === 'GB-99' && po1.expectedDeliveryDate === '2026-10-03');
    check('56/93 the Warehouse Manager can\'t create or send POs; the Purchasing Manager can\'t receive or adjust stock', S.POS.createDraft(WM, { supplierId: sup.id, lines: [] }).error === 'forbidden' &&
      S.POS.sendPurchaseOrder(WM, po1.id).error === 'forbidden' && recv(po1, 1, { by: PUR }).error === 'forbidden' &&
      S.Inv.adjustInventory(PUR, { productVariantId: K1, direction: 'IN', quantity: 1, reasonCode: 'FOUND_STOCK' }).error === 'forbidden');

    // 139 partial receipt (batch 1 already packed -> a new batch)
    S.Wsv.collectRequestItem(U('m3'), r1.id, line(r1).id);
    const b1 = S.Ful.warehouseFulfillmentsFor(r1.id)[0];
    const mvA = movs(), rv1 = recv(po1, 25, { key: 'rc-A' });
    const rcMov = db.MATERIAL_MOVEMENTS.slice(mvA);
    const conv = S.Alloc.getAllocationsForRequestItem(line(r1).id).filter((a) => a.metadata && a.metadata.supplierAllocationId);
    check('139 receive 25: one PURCHASE_RECEIPT (25 -> AVAILABLE, linked to the PO), then RESERVE 25 for the ORIGINAL request', rv1.ok && /^REC-\d+$/.test(rv1.receipt.receiptNumber) &&
      rcMov.filter((m) => m.movementType === 'PURCHASE_RECEIPT').length === 1 && rcMov[0].quantity === 25 && rcMov[0].toInventoryState === 'AVAILABLE' && rcMov[0].purchaseOrderId === po1.id &&
      rcMov.some((m) => m.movementType === 'RESERVE' && m.quantity === 25 && m.requestId === r1.id) && conv.length === 1 && conv[0].quantity === 25 && q(K1, 'RESERVED') === 25);
    check('73/139 batch 1 (60, packed) is untouched; the 25 are a NEW batch of the same request', S.Ful.warehouseFulfillmentsFor(r1.id).length === 2 && b1.status === 'PACKED' &&
      S.Ful.warehouseFulfillmentsFor(r1.id)[1].items[0].allocatedQuantity === 25 && S.Ful.warehouseFulfillmentsFor(r1.id)[1].requestId === r1.id);
    check('139/151 supplier still owes 15; PO PARTIALLY_RECEIVED; coverage stays 100 (60 + 25 + 15), never 125', lp(r1).onOrder === 15 && lp(r1).allocated === 85 && S.RP.getDemandCoverage(line(r1)) === 100 &&
      po1.status === 'PARTIALLY_RECEIVED' && pr1.status === 'PARTIALLY_RECEIVED' && prog(pr1).received === 25 && prog(pr1).expected === 15 && phys(K1) === 85);
    check('110 notified: Purchasing "partially received", the foreman "arrived and being prepared"', S.Ntf.notificationsForUser('demo-pur1').some((n) => n.type === 'PURCHASE_ORDER_RECEIVED' && /partially received/.test(n.title)) &&
      S.Ntf.notificationsForUser('f1').some((n) => n.type === 'PURCHASED_MATERIAL_ARRIVED' && n.entityId === r1.id && /25 EA/.test(n.message) && /being prepared/.test(n.message)));
    const mvB = movs(), nRc = db.PURCHASE_RECEIPTS.length, nAl = db.ALLOCATIONS.length;
    const again = recv(po1, 25, { key: 'rc-A' });
    check('149 double tap Receive (same key + payload): the same receipt, no second movement, allocation or reservation', again.duplicate && again.receipt.id === rv1.receipt.id &&
      movs() === mvB && db.PURCHASE_RECEIPTS.length === nRc && db.ALLOCATIONS.length === nAl && recv(po1, 24, { key: 'rc-A' }).error === 'IDEMPOTENCY_CONFLICT');
    check('150 over-receipt: 20 against 15 remaining is refused, nothing posted', recv(po1, 20).error === 'over_receipt' && movs() === mvB);
    const bBin = db.LOCATIONS.find((l) => l.companyId === 'company2' && l.type === 'WAREHOUSE_BIN');
    check('148 receiving into another company\'s warehouse is refused, no movement', recv(po1, 5, { loc: bBin && bBin.id }).error === 'invalid_location' && movs() === mvB);
    check('67 a posted receipt is immutable', Object.isFrozen(rv1.receipt) && Object.isFrozen(rv1.receipt.items[0]));
    const rv2 = recv(po1, 15);
    check('140 receive the last 15: PO RECEIVED, supplier owes 0, requirement RECEIVED; warehouse coverage 100 (handoff exact)', rv2.ok && po1.status === 'RECEIVED' && lp(r1).onOrder === 0 &&
      lp(r1).allocated === 100 && pr1.status === 'RECEIVED' && S.RP.getDemandCoverage(line(r1)) === 100 && q(K1, 'RESERVED') === 40);
    check('77 PO RECEIVED does not make the request FULFILLED (nothing delivered to the jobsite yet)', r1.status !== 'FULFILLED');
    const sa1 = S.RP.supplierAllocationsForItem(line(r1).id)[0];
    check('70/129 supplier allocation history kept: 40 ordered = 40 converted, status RECEIVED', sa1.quantity === 40 && sa1.convertedQuantity === 40 && sa1.status === 'RECEIVED');

    // 141 stock overage
    setAvail(K3, 0);
    const r3 = submit(K3, 40).request, pr3 = prsOf(r3)[0];
    const po3 = sendNew(pr3, 40, { overage: 10 });
    check('35 an explicit stock overage: line 50 = 40 demand-linked + 10 for stock', po3.items[0].quantityOrdered === 50 && po3.items[0].stockOverageQuantity === 10 &&
      po3.items[0].demandLinks.length === 1 && po3.items[0].demandLinks[0].quantity === 40);
    recv(po3, 50);
    check('141 receive 50: 40 reserved for the request, 10 plain AVAILABLE stock (never reserved to the project)', q(K3, 'RESERVED') === 40 && q(K3, 'AVAILABLE') === 10 &&
      S.RP.getAllocatedQuantity(line(r3)) === 40 && po3.status === 'RECEIVED');

    // 142 competing requirements on one line
    setAvail(K4, 0);
    const rA = submit(K4, 40, { days: 1 }).request, rB = submit(K4, 60, { days: 6 }).request;
    const prA = prsOf(rA)[0], prB = prsOf(rB)[0];
    const dc = S.POS.createDraft(PUR, { supplierId: sup.id, lines: [{ productVariantId: K4, unit: 'EA', unitPrice: 2,
      demand: [{ purchaseRequirementId: prB.id, quantity: 60 }, { purchaseRequirementId: prA.id, quantity: 40 }] }] }, { operationKey: 'po-comb' });
    check('24 consolidated: ONE line of 100 keeping 40 for Project A and 60 for Project B', dc.ok && dc.purchaseOrder.items.length === 1 && dc.purchaseOrder.items[0].quantityOrdered === 100 &&
      dc.purchaseOrder.items[0].demandLinks.map((l) => l.requestId + ':' + l.quantity).sort().join() === [rA.id + ':40', rB.id + ':60'].sort().join());
    S.POS.sendPurchaseOrder(PUR, dc.purchaseOrder.id);
    recv(dc.purchaseOrder, 50);
    check('142 receipt of 50 follows the documented policy (earliest Needed By first): A 40, B 10; not all to one project', S.RP.getAllocatedQuantity(line(rA)) === 40 &&
      S.RP.getAllocatedQuantity(line(rB)) === 10 && S.RP.getLineProgress(line(rB), rB).onOrder === 50);
    check('25 incompatible consolidation is refused (different variant on the same line)', S.POS.createDraft(PUR, { supplierId: sup.id, lines: [{ productVariantId: K5, unit: 'EA', unitPrice: 1,
      demand: [{ purchaseRequirementId: prB.id, quantity: 1 }] }] }).error === 'incompatible_material');

    // 143 cancel before receipt
    setAvail(K5, 0);
    const r5 = submit(K5, 40).request, pr5 = prsOf(r5)[0], po5 = sendNew(pr5, 40);
    const mv5 = movs(), c5 = S.POS.cancelRemaining(PUR, po5.id);
    check('143 cancel a sent PO before receipt: CANCELLED (kept), commitment released, requirement open for 40 again, request unsourced 40, no movement',
      c5.ok && po5.status === 'CANCELLED' && !!db.PURCHASE_ORDERS.find((x) => x.id === po5.id) && lp(r5).onOrder === 0 && lp(r5).outstanding === 40 &&
      prog(pr5).toSource === 40 && ['OPEN', 'SOURCING'].indexOf(pr5.status) !== -1 && movs() === mv5 && S.PRS.getOpenRequirements(PUR).some((x) => x.id === pr5.id));
    // 144 partial cancel
    setAvail(K6, 0);
    const r6 = submit(K6, 40).request, pr6 = prsOf(r6)[0], po6 = sendNew(pr6, 40);
    recv(po6, 15);
    const rcv6 = movs();
    S.POS.cancelRemaining(PUR, po6.id);
    check('144 received 15, cancel the remaining 25: the 15 stay (no reversal), 25 reopen as unsourced', movs() === rcv6 && S.RP.getAllocatedQuantity(line(r6)) === 15 && lp(r6).onOrder === 0 &&
      lp(r6).outstanding === 25 && prog(pr6).toSource === 25 && po6.status === 'RECEIVED' && db.MATERIAL_MOVEMENTS.some((m) => m.movementType === 'PURCHASE_RECEIPT' && m.purchaseOrderId === po6.id && m.quantity === 15));
    // 145 / 146 backorder
    setAvail(K7, 0);
    const r7 = submit(K7, 40).request, pr7 = prsOf(r7)[0], po7 = sendNew(pr7, 40);
    S.POS.markBackordered(PUR, po7.id, po7.items[0].id, 20, '2026-10-09');
    check('145 backorder 20: PO BACKORDERED, supplier still covers all 40 (demand not reopened)', po7.status === 'BACKORDERED' && S.POS.lineProgress(po7, po7.items[0]).backordered === 20 &&
      lp(r7).onOrder === 40 && lp(r7).outstanding === 0 && prog(pr7).toSource === 0);
    S.POS.releaseBackorderedQuantity(PUR, po7.id, po7.items[0].id, 20);
    check('146 release the backordered 20: coverage 20, requirement reopens 20, request unsourced 20; the rest stays on order', lp(r7).onOrder === 20 && lp(r7).outstanding === 20 &&
      prog(pr7).toSource === 20 && S.POS.lineProgress(po7, po7.items[0]).backordered === 0 && ['SENT', 'CONFIRMED'].indexOf(po7.status) !== -1);

    // 152 already satisfied before the supplier delivers
    setAvail(K8, 60);
    const r8 = submit(K8, 100).request, pr8 = prsOf(r8)[0], po8 = sendNew(pr8, 40);
    setAvail(K8, 40);
    const plain = S.Wf.managerAllocateAvailable(WM, r8.id);
    check('130 plain "Allocate available" never covers on-order demand twice (nothing allocated, coverage 100)', plain.ok && plain.allocations.length === 0 && S.RP.getDemandCoverage(line(r8)) === 100);
    const cover = S.Wf.managerAllocateAvailable(WM, r8.id, { coverOnOrder: true });
    check('132 explicit "use warehouse stock instead": warehouse 100, supplier coverage superseded (never 140), PO unchanged, Purchasing warned',
      cover.ok && S.RP.getAllocatedQuantity(line(r8)) === 100 && lp(r8).onOrder === 0 && S.RP.getDemandCoverage(line(r8)) === 100 && po8.items[0].quantityOrdered === 40 &&
      S.POS.commitmentWarnings(PUR).some((w) => w.purchaseOrder.id === po8.id && w.quantity === 40));
    const res8 = q(K8, 'RESERVED');
    recv(po8, 40);
    check('152/131 the supplier still delivers 40: all become plain AVAILABLE stock, nothing more reserved to the project', q(K8, 'RESERVED') === res8 && q(K8, 'AVAILABLE') === 40 &&
      S.RP.getAllocatedQuantity(line(r8)) === 100 && S.RP.getDemandCoverage(line(r8)) === 100 && !S.POS.commitmentWarnings(PUR).some((w) => w.purchaseOrder.id === po8.id));

    // damaged + wrong material
    setAvail(K9, 0);
    const rD = submit(K9, 30, { days: 9 }).request, prD = prsOf(rD)[0], poD = sendNew(prD, 30);
    const rvD = recv(poD, 25, { damaged: 5 });
    check('63 25 good + 5 damaged: DAMAGED stock recorded, damaged units don\'t satisfy demand (5 reopen for Purchasing)', rvD.ok && q(K9, 'DAMAGED') === 5 &&
      S.RP.getAllocatedQuantity(line(rD)) === 25 && lp(rD).outstanding === 5 && prog(prD).toSource === 5 && poD.status === 'RECEIVED' &&
      db.AUDIT_EVENTS.some((e) => e.action === 'PURCHASE_RECEIPT_ISSUE_REPORTED' && e.entityId === rvD.receipt.id));
    const po9 = sendNew(prD, 5);
    const wr = S.Rcv.receivePurchaseOrder(WM, po9.id, { lines: [], issues: [{ purchaseOrderItemId: po9.items[0].id, type: 'WRONG_MATERIAL', notes: '1" instead of 3/4"' }] }, { operationKey: 'wrong-1' });
    check('64 wrong material: an issue is recorded, nothing is received and no inventory is invented', wr.ok && wr.receipt.items.length === 0 && wr.receipt.issues[0].type === 'WRONG_MATERIAL' &&
      S.POS.lineProgress(po9, po9.items[0]).remaining === 5 && !db.MATERIAL_MOVEMENTS.some((m) => m.purchaseOrderId === po9.id));

    // late
    const late = sendNew(prsOf(pend.request)[0], 10, { expected: '2020-01-01' });
    check('78/125 late is derived: expected date passed + something still to receive (no fake status)', S.POS.isPurchaseOrderLate(late) && late.status === 'SENT' && !S.POS.isPurchaseOrderLate(po1));
    check('57 incoming purchases for the warehouse: receivable POs to its warehouse, late first', S.POS.getIncomingPurchaseOrders(WM)[0].id === late.id &&
      S.POS.getIncomingPurchaseOrders(WM).every((p) => p.shipToWarehouseId === 'loc-wh-main' && S.POS.poRemaining(p) > 0) && S.POS.getIncomingPurchaseOrders(F).length === 0);

    // request cancellation with purchasing involvement
    setAvail(K5, 0);
    const rX = submit(K5, 12, { days: 12 }).request, prX = prsOf(rX)[0];
    draft(prX, 12);
    check('drafts are internal: cancelling the request drops its draft claim and releases the requirement', S.Wf.cancelRequest(F, rX.id).ok && S.RP.getSupplierDraftQuantity(line(rX)) === 0 &&
      prX.status === 'CANCELLED');
    const rY = submit(K5, 7, { days: 13 }).request; sendNew(prsOf(rY)[0], 7);
    check('a request with material already on order can\'t just vanish: Purchasing releases it first', S.Wf.cancelRequest(F, rY.id).error === 'purchasing_committed');

    // 147 / 153 multi-company
    const PB = U('pb1'), bSup = S.Sup.createSupplier(PB, { name: 'Graybar', accountNumber: 'GB-B7' }).supplier;
    S.Sup.updateSupplier(PUR, sup.id, { accountNumber: 'GB-A2' });
    check('153 two companies, two independent "Graybar" records: editing A never changes B', bSup.id !== sup.id && bSup.companyId === 'company2' && bSup.accountNumber === 'GB-B7' && sup.accountNumber === 'GB-A2');
    const mb1 = U('mb1');
    check('147/95 Company B can\'t use A\'s supplier, see A\'s requirements, send A\'s PO, quote on A, or receive A\'s PO', S.POS.createDraft(PB, { supplierId: sup.id, lines: [] }).error === 'supplier_invalid' &&
      S.PRS.getOpenRequirements(PB).every((x) => x.companyId === 'company2') && S.POS.sendPurchaseOrder(PB, po7.id).error === 'forbidden' &&
      S.Sup.addSupplierQuote(PB, { supplierId: sup.id, unitPrice: 1, productVariantId: K1 }).error === 'supplier_company' && !S.Sup.getSuppliers(PB).some((s) => s.companyId === 'company1') &&
      (!mb1 || S.Rcv.receivePurchaseOrder(mb1, po7.id, { lines: [{ purchaseOrderItemId: po7.items[0].id, quantityGood: 1, locationId: S.Rcv.defaultReceivingLocation(po7, po7.items[0]) }] }).error === 'forbidden') &&
      S.POS.getPurchaseOrder(PB, po7.id) === null);

    // 156 / 157 integrity
    check('156/157 all Phase 4 work leaves 0 integrity problems and no negative stock', P().length === 0 && db.INVENTORY_BALANCES.every((b) => b.quantity >= 0));
    const codes = () => P().map((x) => x.code);
    const keepP = pr1.projectId; pr1.projectId = 'proj2'; const i1 = codes(); pr1.projectId = keepP;
    const lk = po3.items[0].demandLinks[0], keepQ = lk.quantity; lk.quantity = 41; const i2 = codes(); lk.quantity = keepQ;
    const saX = S.RP.supplierAllocationsForItem(line(r7).id)[0], keepS = saX.supersededQuantity; saX.supersededQuantity = -25; const i3 = codes(); saX.supersededQuantity = keepS;
    check('156 integrity catches a requirement on the wrong project, a broken demand link and double coverage', i1.indexOf('PR_REQUEST') !== -1 && i2.indexOf('PO_ITEM_LINKS') !== -1 &&
      (i3.indexOf('REQUEST_OVER_COVERED') !== -1 || i3.indexOf('SUPPLIER_ALLOCATION_QUANTITY') !== -1) && P().length === 0);

    // persistence (services don't save by themselves; any app commit does)
    A.setLanguage('en'); await wait(10);
    W = boot(W.localStorage.getItem(S.STORAGE_KEY)); await wait(80); ({ A, ui, db, C, S } = W.__ANT);
    check('Phase 4 records survive a refresh (no duplicates), 0 problems', db.PURCHASE_ORDERS.length > 5 && db.PURCHASE_RECEIPTS.length > 5 && S.Integrity.checkIntegrity(db).length === 0 &&
      new Set(db.PURCHASE_REQUIREMENTS.map((x) => x.companyId + x.sourceKey)).size === db.PURCHASE_REQUIREMENTS.length && db.PURCHASE_RECEIPTS.every((x) => Object.isFrozen(x)));
  }

  console.log('TEST Phase 4: purchasing through the screens');
  {
    W = boot(); await wait(80);
    ({ A, ui, db, C, S } = W.__ANT);
    A.setLanguage('en'); await wait(10);
    const U = (id) => db.USERS.find((u) => u.id === id);
    const q = (vid, st) => S.Inv.getQuantityByState('company1', vid)[st] || 0;
    const nav = async (i) => { W.document.querySelectorAll('.bottomnav .navitem')[i].dispatchEvent(new W.MouseEvent('click', { bubbles: true })); await wait(10); };
    const choose = async (el, value) => { Object.getOwnPropertyDescriptor(W.HTMLSelectElement.prototype, 'value').set.call(el, value); el.dispatchEvent(new W.Event('change', { bubbles: true })); await wait(5); };
    const setAvail = (vid, n) => { const cur = q(vid, 'AVAILABLE'); if (n !== cur) S.Inv.adjustInventory(U('m1'), { productVariantId: vid, direction: n > cur ? 'IN' : 'OUT', quantity: Math.abs(n - cur), reasonCode: 'PHYSICAL_COUNT_CORRECTION' }); };
    const K = S.Inv.stockedVariantIds('company1').filter((k) => k.includes('::') && !k.includes('Any') && S.Cat.getProductVariant(k).unit === 'EA' && S.Inv.adjustmentCandidates('company1', k).length === 1 && q(k, 'AVAILABLE') > 0)[3];
    setAvail(K, 60);
    const r = S.Wf.submitRequest(U('f1'), { projectId: 'proj1', priority: 'HIGH', neededBy: Date.now() + 2 * 864e5, lines: [{ productId: K, qty: 100 }] }, { submissionKey: 'ui4-1', duplicateOverride: [] }).request;
    const pr = S.PRS.getRequirementsForRequest(r.id)[0];
    if (ui.currentUser) A.logout(); await wait(10);
    check('46 Role select offers a Purchasing Team (Field / Warehouse unchanged); its list is purchasing people only', html().includes("I'm on the Purchasing Team") && html().includes("I'm on the Field Team") &&
      html().includes("I'm on the Warehouse Team"));
    await click("I'm on the Purchasing Team");
    check('46 the Purchasing profile list shows Marcus Lee (and no field or warehouse people)', html().includes('Marcus Lee') && !html().includes('Carlos Rodriguez') && !html().includes('Ana Martinez'));
    await click('Marcus Lee'); for (const d of '5151') await click(d); await wait(15);
    check('47/48 Marcus lands on Purchasing Home: Needs attention tiles, the requirement card, 4 nav items (Requirements / POs / Suppliers / Profile)', ui.screen === 'pHome' &&
      html().includes('Need sourcing') && html().includes('Unsent drafts') && html().includes('Overdue POs') && W.document.querySelector('[data-requirement="' + pr.id + '"]') &&
      W.document.querySelectorAll('.bottomnav .navitem').length === 4 && html().includes('Requirements') && html().includes('Suppliers'));
    const card = W.document.querySelector('[data-requirement="' + pr.id + '"]').textContent;
    check('49 the requirement card: PR number, project, request, material, "40 EA needed", priority, needed by, status', card.includes(pr.requirementNumber) && card.includes('7 Fairfield Rd') &&
      card.includes(r.id) && card.includes('40 EA needed') && card.includes('High') && card.includes('Needed') && card.includes('Open'));
    await type(byId('req-search-input'), r.id);
    check('114 search by request number finds it; by a nonsense term, nothing', W.document.querySelectorAll('[data-requirement]').length === 1);
    await type(byId('req-search-input'), 'zzz-nothing'); check('114 no match shows an empty state', W.document.querySelectorAll('[data-requirement]').length === 0 && html().includes('No requirements match.'));
    await type(byId('req-search-input'), '');
    W.document.querySelector('[data-requirement="' + pr.id + '"]').dispatchEvent(new W.MouseEvent('click', { bubbles: true })); await wait(10);
    check('51 requirement detail: request, project, requester, requested 100 / from warehouse 60 / needs buying 40 / still to order 40, ship-to', html().includes(pr.requirementNumber) &&
      html().includes('Carlos Rodriguez') && html().includes('From the warehouse') && html().includes('60 EA') && html().includes('Needs buying') && html().includes('Still to order') && html().includes('Main Warehouse'));
    await click('Add quote');
    await type(byId('q-unitPrice'), '1.35'); await type(byId('q-leadTimeDays'), '3');
    await click('Save quote');
    check('17/19 a manual quote shows under supplier options with price and lead time', html().includes('$1.35') && html().includes('3 day lead time') && html().includes('entered by hand'));
    await click('Create purchase order');
    check('19/52 create PO: suppliers listed (preferred first) with their quotes, NONE chosen for the person, Create disabled until one is picked', html().includes('New purchase order') &&
      html().includes('Metro Electrical Supply') && ui.poDraft.supplierId === null && [...W.document.querySelectorAll('button')].find((b) => b.textContent.includes('Create draft PO')).disabled &&
      byId('po-qty').value === '40' && html().includes('A draft is internal'));
    await click('Metro Electrical Supply');
    check('52 picking a supplier fills in its quoted price ($1.35)', ui.poDraft.supplierId && byId('po-price').value === '1.35');
    await type(byId('po-expected'), '2026-10-02');
    await click('Create draft PO');
    const po = db.PURCHASE_ORDERS.find((p) => p.items.some((it) => it.demandLinks.some((l) => l.purchaseRequirementId === pr.id)));
    check('26 draft created and opened: DRAFT, 40 × $1.35 = $54.00, Mark as sent (with the honest "ANT does not email" note)', !!po && po.status === 'DRAFT' && ui.poId === po.id &&
      html().includes('$54.00') && html().includes('Mark as sent') && html().includes('ANT does not email the supplier'));
    await click('Mark as sent'); await click('Mark as sent').catch(() => {});
    check('30/107 marked sent once (double tap): SENT, one commitment', po.status === 'SENT' && S.RP.supplierAllocationsForItem(r.items[0].id).length === 1 && html().includes('Mark as confirmed'));
    W.__ANT.PU.closePo(); await wait(10);
    // field view
    A.logout(); await wait(10); await login('field', 'Carlos', '4827');
    A.openRequestDetail(r.id); await wait(10);
    check('111/113 field sees Requested 100 / Warehouse 60 / On order 40 / Needs sourcing 0, "Expected from supplier: Oct 2 (to the warehouse, not the jobsite)"', html().includes('On order') &&
      html().includes('40 EA') && html().includes('Needs sourcing') && html().includes('Expected from supplier') && html().includes('not the jobsite') && html().includes('Rest is on order'));
    check('112/160 the field sees no price, no PR / PO ids and no internal terms', !html().includes('$') && !html().includes(pr.requirementNumber) && !html().includes(po.purchaseOrderNumber) &&
      !/convertedQuantity|demandLink|payloadFingerprint|schemaVersion/.test(html()));
    A.closeRequestDetail(); await wait(10);
    // warehouse receives
    await login('warehouse', 'Ana', '0000');
    check('57 Warehouse Manager Home shows Incoming purchases: PO, supplier, expected, lines, "Receive materials" (no prices)', !!W.document.querySelector('[data-incoming="' + po.id + '"]') &&
      W.document.querySelector('[data-incoming="' + po.id + '"]').textContent.includes('Metro Electrical Supply') && !W.document.querySelector('[data-incoming="' + po.id + '"]').textContent.includes('$'));
    W.document.querySelector('[data-incoming="' + po.id + '"] button').dispatchEvent(new W.MouseEvent('click', { bubbles: true })); await wait(10);
    const it = po.items[0];
    check('62 the Receive sheet prefills the remaining 40 and the product\'s own bin', html().includes('Receive ' + po.purchaseOrderNumber) && byId('rg-' + it.id).value === '40' && !!byId('rl-' + it.id).value);
    await type(byId('rg-' + it.id), '25');
    await click('Receive materials', 1); await click('Receive materials', 1).catch(() => {});
    check('59/108 receive 25 (double tap): one receipt, PO Partially received, 25 reserved for the request, a new batch', db.PURCHASE_RECEIPTS.filter((x) => x.purchaseOrderId === po.id).length === 1 &&
      po.status === 'PARTIALLY_RECEIVED' && S.RP.getAllocatedQuantity(r.items[0]) === 85 && q(K, 'RESERVED') >= 25 && !ui.receivePoId);
    const worker = U('m3');
    await login('warehouse', 'Michael Torres', '8899');
    check('56 a Warehouse Worker sees no Incoming purchases and cannot receive', !html().includes('Incoming purchases') &&
      S.Rcv.receivePurchaseOrder(worker, po.id, { lines: [{ purchaseOrderItemId: it.id, quantityGood: 1, locationId: S.Rcv.defaultReceivingLocation(po, it) }] }).error === 'forbidden');
    // purchasing: PO list, detail, backorder
    await login('purchasing', 'Marcus Lee', '5151');
    await nav(1);
    check('53 PO list: card with number, supplier, total, lines, status; filters include Partial / Backordered / Late', ui.screen === 'pOrders' && !!W.document.querySelector('[data-po="' + po.id + '"]') &&
      W.document.querySelector('[data-po="' + po.id + '"]').textContent.includes('Partially received') && html().includes('Backordered') && html().includes('Late'));
    W.document.querySelector('[data-po="' + po.id + '"]').dispatchEvent(new W.MouseEvent('click', { bubbles: true })); await wait(10);
    check('54/126 PO detail: ship to, buyer, lines with ordered / received / still expected, demand link to the request, totals', html().includes('Main Warehouse') && html().includes('Marcus Lee') &&
      html().includes('Still expected') && html().includes('15 EA') && html().includes(r.id) && html().includes('Subtotal') && html().includes('REC-'));
    await type(byId('bo-' + it.id), '15'); await type(byId('bod-' + it.id), '2026-10-09');
    await click('Save backorder');
    check('80 backorder saved in the UI: 15 backordered, PO Backordered, still on order for the field', po.status === 'BACKORDERED' && S.RP.getLineProgress(r.items[0], r).onOrder === 15 &&
      html().includes('Release for another supplier'));
    await click('Release for another supplier');
    check('45/81 release the backorder: requirement reopens 15, the request needs sourcing 15 (no new field request)', S.PRS.getRequirementProgress(pr).toSource === 15 &&
      S.RP.getLineProgress(r.items[0], r).outstanding === 15 && db.REQUESTS.filter((x) => x.projectId === 'proj1' && x.createdAt > r.createdAt).length === 0);
    W.__ANT.PU && W.__ANT.PU.closePo(); await wait(10);
    // suppliers
    await nav(2);
    check('16 Suppliers: the 3 fictional demo records, preferred first', ui.screen === 'pSuppliers' && W.document.querySelectorAll('[data-supplier]').length === 3 &&
      W.document.querySelector('[data-supplier]').textContent.includes('Preferred'));
    await click('Add supplier');
    await type(byId('sup-name'), 'Graybar'); await type(byId('sup-accountNumber'), 'GB-100'); await type(byId('sup-email'), 'not-an-email');
    await click('Add supplier', 1);
    check('16 validation: an invalid email is refused in the form', html().includes('Enter a valid email') && !db.SUPPLIERS.some((s) => s.name === 'Graybar'));
    await type(byId('sup-email'), 'orders@graybar.example');
    await TAP(); await click('Add supplier', 1);
    check('16 supplier added and listed', db.SUPPLIERS.some((s) => s.name === 'Graybar' && s.accountNumber === 'GB-100' && s.companyId === 'company1') && W.document.querySelectorAll('[data-supplier]').length === 4);
    await type(byId('supplier-search-input'), 'gb-100');
    check('115 supplier search by account number', W.document.querySelectorAll('[data-supplier]').length === 1);
    W.document.querySelector('[data-supplier]').dispatchEvent(new W.MouseEvent('click', { bubbles: true })); await wait(10);
    await click('Deactivate supplier');
    check('16 deactivate (never delete): INACTIVE, still listed as Inactive', db.SUPPLIERS.find((s) => s.name === 'Graybar').status === 'INACTIVE' && html().includes('Inactive'));
    await type(byId('supplier-search-input'), '');
    A.setLanguage('es'); await wait(10);
    await nav(1);
    check('117 Spanish: Órdenes de compra, Recibido parcialmente / Pedido pendiente wording, nav translated', html().includes('Órdenes de compra') && html().includes('Proveedores') && html().includes('Requerim.'));
    A.setLanguage('en'); await wait(10);
    // warehouse explicit "use warehouse stock instead"
    setAvail(K, q(K, 'AVAILABLE') + 15);
    const po2 = S.POS.createDraft(U('demo-pur1'), { supplierId: po.supplierId, lines: [{ productVariantId: K, unit: 'EA', unitPrice: 1.4, demand: [{ purchaseRequirementId: pr.id, quantity: 15 }] }] }).purchaseOrder;
    S.POS.sendPurchaseOrder(U('demo-pur1'), po2.id);
    await login('warehouse', 'Ana', '0000');
    A.openAllocation(r.id); await wait(10);
    check('132 allocation detail shows On order and offers the explicit "Use warehouse stock instead" (with the note)', html().includes('On order') && html().includes('Use warehouse stock instead') &&
      html().includes('supplier order stays as it is'));
    await click('Use warehouse stock instead');
    check('132 used: warehouse covers 100, supplier coverage superseded (never above 100), Purchasing warned', S.RP.getAllocatedQuantity(r.items[0]) === 100 && S.RP.getDemandCoverage(r.items[0]) === 100 &&
      S.POS.commitmentWarnings(U('demo-pur1')).some((w) => w.purchaseOrder.id === po2.id));
    A.closeAllocation(); await wait(10);
    await login('purchasing', 'Marcus Lee', '5151');
    check('132 Purchasing Home shows the warning "15 EA on PO-… may no longer be required for ORD-…"', html().includes('may no longer be required for ' + r.id));
    A.logout(); await wait(10);
    check('Phase 4 UI flows leave 0 integrity problems', S.Integrity.checkIntegrity(db).length === 0);
  }

  console.log('TEST Phase 4 micro correction: exactly one DAMAGED issue per damaged receipt line');
  {
    W = boot(); await wait(80);
    ({ A, ui, db, C, S } = W.__ANT);
    const U = (id) => db.USERS.find((u) => u.id === id), PUR = U('demo-pur1'), WM = U('m1');
    const q = (vid, st) => S.Inv.getQuantityByState('company1', vid)[st] || 0;
    const setAvail = (vid, n) => { const cur = q(vid, 'AVAILABLE'); if (n !== cur) S.Inv.adjustInventory(WM, { productVariantId: vid, direction: n > cur ? 'IN' : 'OUT', quantity: Math.abs(n - cur), reasonCode: 'PHYSICAL_COUNT_CORRECTION' }); };
    const VV = S.Inv.stockedVariantIds('company1').filter((k) => k.includes('::') && !k.includes('Any') && S.Cat.getProductVariant(k).unit === 'EA' && S.Inv.adjustmentCandidates('company1', k).length === 1 && q(k, 'AVAILABLE') > 0);
    const mkPo = (vid, qty, key) => {
      setAvail(vid, 0);
      const r = S.Wf.submitRequest(U('f1'), { projectId: 'proj1', priority: 'NORMAL', neededBy: Date.now() + 3 * 864e5, lines: [{ productId: vid, qty }] }, { submissionKey: key, duplicateOverride: [] }).request;
      const pr = S.PRS.getRequirementsForRequest(r.id)[0], sup = S.Sup.getSuppliers(PUR)[0];
      const po = S.POS.createDraft(PUR, { supplierId: sup.id, lines: [{ productVariantId: pr.productVariantId, unit: pr.unit, unitPrice: 1, demand: [{ purchaseRequirementId: pr.id, quantity: qty }] }] }, { operationKey: key }).purchaseOrder;
      S.POS.sendPurchaseOrder(PUR, po.id);
      return { r, pr, po, vid };
    };
    const issueNotes = (po) => S.Ntf.notificationsForUser('demo-pur1').filter((n) => n.type === 'PURCHASE_RECEIPT_ISSUE' && n.entityId === po.id);
    // TEST: 20 ordered, 15 good + 5 damaged
    const a = mkPo(VV[0], 20, 'dmg-a'), itA = a.po.items[0], locA = S.Rcv.defaultReceivingLocation(a.po, itA);
    const mv0 = db.MATERIAL_MOVEMENTS.length;
    const ra = S.Rcv.receivePurchaseOrder(WM, a.po.id, { lines: [{ purchaseOrderItemId: itA.id, quantityGood: 15, quantityDamaged: 5, locationId: locA }] }, { operationKey: 'rc-dmg-a' });
    const recA = ra.receipt, riA = recA && recA.items[0];
    check('7 SINGLE DAMAGED ISSUE: 15 good + 5 damaged -> good 15, damaged 5, exactly ONE issue { DAMAGED, 5 }', ra.ok && riA.quantityReceivedGood === 15 && riA.quantityReceivedDamaged === 5 &&
      recA.issues.length === 1 && recA.issues[0].type === 'DAMAGED' && recA.issues[0].quantity === 5);
    const movA = db.MATERIAL_MOVEMENTS.slice(mv0).filter((m) => m.movementType === 'PURCHASE_RECEIPT');
    check('4 ledger unchanged: one PURCHASE_RECEIPT 15 -> AVAILABLE and one 5 -> DAMAGED; DAMAGED stock 5; 15 reserved for the request', movA.length === 2 &&
      movA.some((m) => m.quantity === 15 && m.toInventoryState === 'AVAILABLE') && movA.some((m) => m.quantity === 5 && m.toInventoryState === 'DAMAGED') &&
      q(a.vid, 'DAMAGED') === 5 && S.RP.getAllocatedQuantity(a.r.items[0]) === 15);
    const na = issueNotes(a.po);
    check('5 one issue notification, naming the damage once ("5 EA damaged")', na.length === 1 && (na[0].message.match(/damaged/g) || []).length === 1 && na[0].message.indexOf('5 EA damaged') !== -1 &&
      db.AUDIT_EVENTS.filter((e) => e.action === 'PURCHASE_RECEIPT_ISSUE_REPORTED' && e.entityId === recA.id).length === 1 &&
      JSON.stringify(db.AUDIT_EVENTS.find((e) => e.action === 'PURCHASE_RECEIPT_ISSUE_REPORTED' && e.entityId === recA.id).after.issues) === '["DAMAGED"]');
    const again = S.Rcv.receivePurchaseOrder(WM, a.po.id, { lines: [{ purchaseOrderItemId: itA.id, quantityGood: 15, quantityDamaged: 5, locationId: locA }] }, { operationKey: 'rc-dmg-a' });
    check('9 receipt idempotency intact: the retry returns the same receipt, still one issue, no second notification', again.duplicate && again.receipt.id === recA.id &&
      again.receipt.issues.length === 1 && issueNotes(a.po).length === 1);
    // TEST: damaged only, 10 ordered, 0 good + 10 damaged
    const b = mkPo(VV[1], 10, 'dmg-b'), itB = b.po.items[0];
    const rb = S.Rcv.receivePurchaseOrder(WM, b.po.id, { lines: [{ purchaseOrderItemId: itB.id, quantityGood: 0, quantityDamaged: 10, locationId: S.Rcv.defaultReceivingLocation(b.po, itB) }] }, { operationKey: 'rc-dmg-b' });
    check('8 DAMAGED ONLY: 0 good + 10 damaged -> exactly ONE issue { DAMAGED, 10 }, DAMAGED stock 10, nothing reserved, requirement reopens 10',
      rb.ok && rb.receipt.issues.length === 1 && rb.receipt.issues[0].type === 'DAMAGED' && rb.receipt.issues[0].quantity === 10 && q(b.vid, 'DAMAGED') === 10 &&
      S.RP.getAllocatedQuantity(b.r.items[0]) === 0 && S.PRS.getRequirementProgress(b.pr).toSource === 10 && issueNotes(b.po).length === 1);
    // the real duplication path: damage reported BOTH as a damaged quantity and as a DAMAGED issue
    const c = mkPo(VV[2], 10, 'dmg-c'), itC = c.po.items[0], locC = S.Rcv.defaultReceivingLocation(c.po, itC);
    const mvC = db.MATERIAL_MOVEMENTS.length;
    const both = S.Rcv.receivePurchaseOrder(WM, c.po.id, { lines: [{ purchaseOrderItemId: itC.id, quantityGood: 7, quantityDamaged: 3, locationId: locC }],
      issues: [{ purchaseOrderItemId: itC.id, type: 'DAMAGED', quantity: 3 }] }, { operationKey: 'rc-dmg-c' });
    check('2 damage reported both as a quantity and as an issue never stores DAMAGED twice (refused, nothing posted)', both.error === 'damaged_is_a_quantity' &&
      db.MATERIAL_MOVEMENTS.length === mvC && !db.PURCHASE_RECEIPTS.some((x) => x.purchaseOrderId === c.po.id));
    const claim = S.Rcv.receivePurchaseOrder(WM, c.po.id, { lines: [], issues: [{ purchaseOrderItemId: itC.id, type: 'DAMAGED', quantity: 3 }] }, { operationKey: 'rc-dmg-c2' });
    check('2 a DAMAGED issue with no damaged quantity is refused too (no damage record without DAMAGED stock)', claim.error === 'damaged_is_a_quantity' && q(c.vid, 'DAMAGED') === 0);
    const ok = S.Rcv.receivePurchaseOrder(WM, c.po.id, { lines: [{ purchaseOrderItemId: itC.id, quantityGood: 7, quantityDamaged: 3, locationId: locC }] }, { operationKey: 'rc-dmg-c3' });
    check('7 the same delivery entered once: one DAMAGED issue for 3', ok.ok && ok.receipt.issues.length === 1 && ok.receipt.issues[0].quantity === 3);
    const wr = S.Rcv.receivePurchaseOrder(WM, b.po.id, { lines: [], issues: [{ purchaseOrderItemId: itB.id, type: 'WRONG_MATERIAL', notes: 'wrong size' }] }, { operationKey: 'rc-dmg-w' });
    check('9 wrong material issues still work (one WRONG_MATERIAL issue, no inventory)', wr.error === 'not_receivable' || (wr.ok && wr.receipt.issues.length === 1 && wr.receipt.issues[0].type === 'WRONG_MATERIAL'));
    check('micro correction leaves 0 integrity problems and no negative stock', S.Integrity.checkIntegrity(db).length === 0 && db.INVENTORY_BALANCES.every((x) => x.quantity >= 0));
  }

  console.log('TEST Phase 4: migrations to v6 (135 / 155)');
  {
    const raw5 = fs.readFileSync(path.join(__dirname, 'fixtures', 'v5-react-saved.json'), 'utf8'), src5 = JSON.parse(raw5);
    W = boot(raw5); await wait(80); ({ A, ui, db, C, S } = W.__ANT);
    const outLines = src5.materialRequests.filter((r) => r.allocationMode === 'V5' && ['APPROVED', 'PROCESSING', 'PARTIALLY_FULFILLED'].indexOf(r.status) !== -1)
      .reduce((acc, r) => acc.concat(r.items.filter((it) => it.quantity > (src5.allocations || []).filter((a) => a.requestItemId === it.id && a.status !== 'RELEASED' && a.status !== 'CANCELLED').reduce((n, a) => n + a.quantity, 0)).map((it) => it.id)), []);
    check('135 v5 -> v6: one migration-generated requirement per unsourced line (ORD-1004), none for cancelled / fully sourced', S.loadReport.migratedFrom === 5 && db.SCHEMA_VERSION === 6 &&
      outLines.length > 0 && db.PURCHASE_REQUIREMENTS.length === outLines.length && db.PURCHASE_REQUIREMENTS.every((x) => x.metadata.migrationGenerated && x.metadata.sourceSchema === 5 && outLines.indexOf(x.requestItemId) !== -1));
    check('135 no fake PO, supplier, supplier allocation or receipt; ledger unchanged; backup kept', !db.PURCHASE_ORDERS.length && !db.SUPPLIERS.length && !db.PURCHASE_RECEIPTS.length &&
      !db.ALLOCATIONS.some((a) => a.sourceType === 'SUPPLIER') && db.MATERIAL_MOVEMENTS.length === src5.materialMovements.length && W.localStorage.getItem(S.backupKeyFor(5)) === raw5 &&
      S.Integrity.checkIntegrity(db).length === 0);
    const n6 = db.PURCHASE_REQUIREMENTS.length;
    W = boot(W.localStorage.getItem(S.STORAGE_KEY)); await wait(80); ({ A, ui, db, C, S } = W.__ANT);
    check('135 second load: no duplicate requirement (and a live sync adds none either)', db.PURCHASE_REQUIREMENTS.length === n6 &&
      (() => { db.REQUESTS.filter((r) => r.allocationMode === 'V5').forEach((r) => S.PRS.syncForRequest(r, S.MLS.systemActor(r.companyId, 'TEST', null))); return db.PURCHASE_REQUIREMENTS.length === n6; })());
    for (const [tag, file, from] of [['v4', 'v4-react-saved.json', 4], ['v3', 'v3-react-saved.json', 3], ['v2', 'v2-react-saved.json', 2], ['v1', 'v1-react-saved.json', 1]]) {
      W = boot(fs.readFileSync(path.join(__dirname, 'fixtures', file), 'utf8')); await wait(80); ({ A, ui, db, C, S } = W.__ANT);
      check('155 ' + tag + ' -> v6 (' + db.MIGRATIONS.map((m) => m.from + '>' + m.to).join() + '): no requirement, PO or receipt invented for legacy history, 0 problems',
        db.SCHEMA_VERSION === 6 && S.loadReport.migratedFrom === from && /5>6$/.test(db.MIGRATIONS.map((m) => m.from + '>' + m.to).join()) && !db.PURCHASE_REQUIREMENTS.length &&
        !db.PURCHASE_ORDERS.length && !db.PURCHASE_RECEIPTS.length && S.Integrity.checkIntegrity(db).length === 0);
    }
  }

  console.log('TEST N: responsive layout (375 / 390 / 430 / tablet / desktop) runs in real Chromium: npm run test:visual');

  check('No runtime errors', errors.length === 0);
  if (errors.length) console.log(errors.slice(0, 5));
  check('No console errors (broken references, missing modules, React errors)', consoleErrors.length === 0);
  if (consoleErrors.length) console.log(consoleErrors.slice(0, 5));
  console.log('\n' + pass + ' passed, ' + fail + ' failed');
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('TEST ERROR', e.stack); process.exit(1); });
