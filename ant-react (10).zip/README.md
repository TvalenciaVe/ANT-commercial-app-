# ANT: Move materials. Keep work moving.

A mobile-first material-request app for electrical construction. Field crews
(Foreman, Journeyman, Apprentice) request materials for a job site; the
warehouse (Manager, Worker) picks, packs, and ships them.

This is the React version of the original single-file ANT prototype.

## What's included

Everything from the original single-file prototype, rebuilt in React:

- **Field (Foreman, Journeyman, Apprentice):** login and new profile, Home with search, 32-area catalog with 352 configurable product families and variant-level inventory, Material Request, request details and submit, My Orders, Quick Reorder, Save as Job Kit, Job Kits and Create Job Kit, Projects with Overview / Materials / Orders / Deliveries / Team, team permissions, delivery confirmation, Profile with English/Español and Large Text.
- **Requests, allocation and approvals (Phase 3):** a request is the field's demand; ANT reserves what the project's warehouse has and keeps the rest visible as outstanding demand. Possible-duplicate warning before sending, Project Manager approval for Emergency requests (demo policy), request details in plain words (Requested / Warehouse / On order / Needs sourcing), cancel before picking, and a manager screen to review or change allocations.
- **Purchasing (Phase 4):** approved demand the warehouse can't cover automatically becomes a **Purchase Requirement** (PR-1001) linked to its request. Purchasing Managers keep company **Suppliers**, enter **quotes** by hand, and create **Purchase Orders** (PO-1001): drafts first, then "Mark as sent", confirm, backorder, release a backorder, or cancel what's left. One PO line can buy for several projects and still remembers how much belongs to each, and extra "for stock" is always separate. The field sees "On order" and the supplier's expected date, never prices. ANT never picks a supplier or orders by itself.
- **Warehouse (Manager, Worker):** Home, Orders with filters, order checklist with shortages (pre-v5 orders), Packing Mode picking each line's own reservation, dispatch in strict order (Packed → Ready to Ship → Shipped → Completed), Inventory with restock, inventory detail with activity history and adjustments (Manager), **Incoming purchases and receiving** (Manager: good, damaged or wrong material, into a chosen bin; received material goes straight back to the request it was bought for as a new warehouse batch), an illustrative supplier lookup (clearly labeled, not company records), History, Profile.

## Demo logins

| Person | Role | PIN |
|---|---|---|
| Carlos | Foreman | 4827 |
| Sofia Reyes | Project Manager (approves Emergency requests on her projects; signs in with the Field Team) | 7272 |
| John Martinez | Journeyman (Can Request Materials on 7 Fairfield Rd) | 2211 |
| Daniel Perez | Apprentice (View Only on 7 Fairfield Rd) | 3322 |
| Ana | Warehouse Manager | 0000 |
| Marcus Lee | Purchasing Manager (signs in with the Purchasing Team; fictional demo user) | 5151 |
| Michael Torres | Warehouse Worker | 8899 |

Data is saved in the browser (localStorage). "Reset demo data" on the first
screen restores the original demo projects, orders, and inventory.

## Architecture (Phase 1 foundation, hardened)

ANT is built to grow into a full material operating system (inventory, ledger,
purchasing, logistics, returns, costs). Phase 1 puts the foundation in place
without changing how the app looks or works.

- **Company** owns everything. Every record carries a `companyId`, and the services refuse to read or write across companies (see "Things that are prototype-only" for what this does and doesn't mean for security).
- **Feature flags vs settings.** `company.features` says which modules a company *has* (`src/config/features.js`). `company.settings` says how it *runs* them, e.g. `approvalsEnabled` (`src/config/companySettings.js`). A module shows only when it is both built and switched on.
- **Users** live in one table. `primaryRole` decides the person's home screen; `companyRoles` lists every company responsibility they hold (always including `primaryRole`), so one person can be Owner, Company Admin and Purchasing Manager without duplicate accounts. Names are stored as `firstName`, `lastName` and `fullName`, written together through one function; `user.name` is a read-only alias that is never saved.
- **Project memberships** are the only source of project access. A membership's `projectRole` is independent of the person's `primaryRole`: a Journeyman can be Journeyman / Can Edit on one project and Foreman / Full Control on another. Journeymen and Apprentices can never get Full Control, and making someone a project lead needs lead-assignment rights (Owner, Company Admin, Project Manager). A project creator gets a lead membership only in a lead role they really hold; Owners and Admins get none.
- **Capabilities**: every permission question is `canUser(user, capability, { projectId })`, answered from one table in `src/config/capabilities.js`. Project capabilities have their own names (`VIEW_PROJECT_DELIVERIES`, `CONFIRM_PROJECT_RECEIPT`...) so they can't be confused with company modules (`VIEW_SHIPMENTS`, `MANAGE_INVENTORY`...). Company capabilities are the union of the person's company roles; project capabilities come only from their membership on that project (Owners and Company Admins oversee every project of their own company).
- **Locations**: each company has its own warehouse (the demo company keeps `loc-wh-main`; others get ids like `loc-wh-company2-main`) with zones and bins, plus one jobsite per project. A location belongs to exactly one company; a project and a company default always use a warehouse of their own company.
- **Stock is transactional (Phase 2).** Every change is one immutable `MaterialMovement` in the Material Ledger: which exact variant, how much, which unit, from and to which location, from and to which state (Available, Picking, Packed), why, who, when, and which request and project. `InventoryBalance` rows (company + variant + location + state) are a materialized total that can always be rebuilt from the ledger. Only `services/materialLedgerService.js` writes movements or balances; it validates the whole batch against current balances, commits all or nothing, and never lets stock go negative. Idempotency is per company: the same company + operation key + payload returns the original result, the same key with a different payload is refused (`IDEMPOTENCY_CONFLICT`), and another company's operations are never looked at. Location and state are separate: picking 25 EA moves them from Available to Picking in the same bin.
- **Warehouse flow on the ledger:** collecting a line is a PICK; un-checking it is an UNPICK (and UNPACK if needed) linked to the original; marking short picks what is available and records a shortage (demand, never negative stock); when an order becomes Packed its picked material moves to PACKED. Ready to Ship, Shipped and Completed post no movement yet (Logistics phase). Manager adjustments need a reason and are movements too, never an overwritten number. They correct ONE location: the bin is preselected only when the material is in one place; otherwise the Manager chooses it (`LOCATION_REQUIRED`), and a removal never reaches into another bin.
- **Requests, allocation, reservation and fulfillment are separate (Phase 3).** A `MaterialRequest` is demand only. After approval (or when none is needed), `services/allocationService.js` allocates `min(outstanding, AVAILABLE)` from the project's *assigned* warehouse only: primary bin first, one `MaterialAllocation` per bin, each backed by a RESERVE movement (Available → Reserved, same bin). What can't be covered stays **outstanding** (`requested − active allocated`) for future Purchasing; it never disappears and never becomes negative stock. The warehouse works on a `Fulfillment` with only the allocated quantity, and picks each line's **own** reservation (Reserved → Picking). The ledger refuses any movement that touches reserved stock without naming its allocation, so one project can't consume another's reservation. Automatic allocation is posted by ANT itself as a marked system actor (who triggered it is recorded); there is no fake "ANT System" user. `services/requestWorkflowService.js` orchestrates submit → duplicate check → approval → allocation → reservation → fulfillment inside one rollback boundary (`src/lib/transaction.js`).
- **Approvals** are a company policy (`ApprovalPolicy` with ordered rules: priority, category, variant, project, quantity, value). Matched rules become sequential steps (e.g. Project Manager → Purchasing Manager): one step is active at a time, only its approvers are notified, and allocation runs once, after the last step. Each step's role decides its scope (`APPROVER_ROLE_SCOPES` in `src/config/requests.js`): a **project** step needs that role *on the request's project* (`RESOLVE_PROJECT_APPROVAL`); a **company** step (Purchasing Manager, Owner, Company Admin) needs that company role (`RESOLVE_COMPANY_APPROVAL`) and no project membership. Owners and Company Admins may override where configured. Never the requester, never another company.
- **Outstanding demand stays actionable.** Warehouse Manager Home previews the five most urgent **Outstanding requests** (approved demand not yet covered, including requests with nothing allocated and no fulfillment, or when automatic allocation is switched off) and **View all N outstanding requests** opens the full list, from the same selector in the same order, so no request is ever out of reach. A manager whose profile names a warehouse sees only that warehouse's projects. Each opens a request allocation detail (requested / warehouse / available now / outstanding) with **Allocate available stock**. More stock for the same request never needs a new request: it becomes a new warehouse **batch** (a second `Fulfillment` for the same request) unless the current batch hasn't been started yet. Workers see the request number with "Batch 2 of 2"; the field sees one request with its batches.
- **Submitting is safe to retry.** A submission is keyed by company + requester + key and checked by a payload fingerprint (item order doesn't matter): the same retry returns the same request; the same key with different details is refused (`IDEMPOTENCY_CONFLICT`); another person's or company's key is independent. A value rule never treats unknown cost as $0: the catalog has no trusted prices, so it routes to manual review (`COST_UNKNOWN_REVIEW_REQUIRED`). The demo policy: Emergency → Project Manager.
- **Material requests** reference their project and requester by id and keep their `ORD-XXXX` numbers. Each line is canonical: `productVariantId`, `quantity`, `unit`, plus `productNameSnapshot`, `variantSnapshot` and `brandSnapshot`, so an old order stays readable even if the catalog changes. The person who confirmed a delivery is stored as `fieldConfirmedByUserId` (their name only as a snapshot).
- **Warehouse work** (pick, un-pick, mark short, stock adjustments) happens in `services/warehouseService.js` and `services/inventoryService.js`, which re-check permission and company on every call. The screen actions only pass along what the person tapped.
- **Statuses**: a v5 request stores its own `status` (derived from demand: a request is never FULFILLED while demand is outstanding); its fulfillment has `FulfillmentStatus`. Screens ask one mapping layer (`stageOf`, `fieldRequestView`, `warehouseOrderView`) so they keep the familiar order stages. Pre-v5 requests keep the combined `workflowStatus`. Scrap and Damage are return *dispositions*, not return steps.
- **Audit events** (with ids and before / after) and **notifications** are recorded for key actions, including picks, shortages and stock adjustments. A notification only reaches an active user of the same company. Ledger actions are audited once per meaningful action (MATERIAL_PICKED, MATERIAL_UNPICKED, MATERIAL_PACKED, INVENTORY_ADJUSTED...) with the ids of the movements they posted.

### Saved data and upgrades

Saved data carries a schema version (currently **6**). Opening ANT with older
saved data upgrades it automatically, one step at a time (v1 → v2 → v3 → v4 → v5 → v6,
v2 → …, v3 → …, v4 → …, or v5 → v6), and first keeps an untouched copy under
`ant_prototype_data_v1__backup_schema1` … `..._backup_schema5`.

The v5 → v6 step starts purchasing. Today's unsourced, approved demand becomes
Purchase Requirements marked `migrationGenerated` (current work, not invented
history), with the same key the live sync uses, so a reload or sync can never
add a second one. No purchase orders, receipts, supplier commitments or
movements are invented, and saved data gets no invented suppliers. The demo
company gets one fictional demo Purchasing Manager (Marcus Lee); brand-new demo
data also gets three fictional demo supplier records (no prices, no live data).

The v4 → v5 step starts requests + allocation. Every existing request is kept
as **LEGACY**: its progress, its held Picking / Packed stock and its Phase 2
flow stay exactly as they were, with a compatibility `Fulfillment` record
(`legacyMigrated: true`). No approvals, allocations or reservations are
invented for history. The dormant `requestApprovalRequired` setting becomes
`approvalsEnabled`; the demo company gets the Emergency → Project Manager
policy and one fictional demo Project Manager (Sofia Reyes). Balances and the
ledger are untouched.

The v3 → v4 step starts the ledger. The quantity stored in v3 is the current
available stock, so it becomes one system OPENING_BALANCE per stock record;
old picks are not replayed against it (that would deduct them twice).
Material that open orders had already picked becomes an opening balance in
Picking or Packed, linked to its request line. Orders dispatched before the
ledger keep their progress as labeled legacy history. Each company records
`inventoryLedgerStartedAt`, and no movement is invented before it. Nothing is
dropped: users, projects, memberships, requests, kits, stock, audit events and
notifications all carry over, and the integrity checker runs after every
upgrade. Data saved by the original single-file HTML prototype upgrades the
same way. Fresh demo data also goes through the full chain, so it ends at v6.

### Signing in with more than one company

With one company (the demo), sign-in is exactly as before. If ANT ever holds
more than one company, the person picks their company first, and only that
company's profiles are listed. Creating a profile only joins a company ANT
already knows, by its exact name; an unknown name shows "That company is not
available in ANT. Ask your company administrator for access." and creates
nothing.

### Developer tools (development builds only)

While running `npm run dev`, the browser console has:

```js
__ANT_DEV__.whoami()      // current user, company, project, role, permission, schema version
__ANT_DEV__.integrity()   // relationship problems (should be [])
__ANT_DEV__.audit(20)     // latest audit events
```

These never appear in the published app.

## Run it on a computer

Requires Node.js 18 or newer.

```bash
npm ci        # installs exactly the versions in package-lock.json
npm run dev
```

Then open the address it prints (usually http://localhost:5173).

## Publish it on GitHub with a live link

1. Create a repository on github.com and upload every file and folder from this project, including the `.github` folder.
2. In the repository, open **Settings → Pages** and set **Source** to **GitHub Actions**.
3. Wait about a minute. The app is published at `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

Every later change pushed to `main` republishes the app automatically. The
workflow installs with `npm ci`, runs `npm test`, and only builds and publishes
if every test passes.

## Tests

```bash
npm test
```

The real app is loaded in a simulated browser (jsdom) and driven through every
role by tapping the same buttons a user would: login, search, configuring
products, submitting, reordering, Job Kits, projects and permissions, packing
with shortages, dispatch order, delivery confirmation, language, and reloading
the page. It also checks the foundation: permissions per project and per
company, company roles, project roles independent of primary roles, project
creators, feature flags vs settings, the warehouse and inventory services and
their audit events, notifications, data integrity, and upgrades of real saved
data from every earlier version (`test/fixtures/`: the original HTML
prototype, the first React version, a Phase 1 schema v2 save, a v3 save, and a
Phase 2 schema v4 save with an order mid-pick). Phase 3 adds full / partial /
zero allocation, competing requests, multi-bin reservations, reservation
ownership, release and manager changes, approval / double approval /
rejection / unknown cost, duplicate warnings, Quick Reorder, cancellation,
cross-company isolation, the rollback boundary and the new integrity rules. The Phase 3
correction pass adds Project Manager → Purchasing Manager approval chains, the
warehouse Outstanding requests path, several warehouse batches for one request,
and per-user submission retries with conflict detection. Phase 4 adds the purchasing story end to end, in the services and
through the screens: requirement creation without duplicates, drafts that protect their quantity
and never show as "On order", sending once, partial and final receipts that continue the
original request as new warehouse batches, stock overage, two projects on one PO line, cancel,
partial cancel, backorder and release, damaged and wrong material, demand covered from stock
before the supplier delivers, company isolation, same-named suppliers in two companies, receipt
double taps and over-receipts, the v5 → v6 upgrade, and new integrity rules (including "warehouse
+ supplier coverage never exceeds the request").

Company isolation is tested with a second, test-only company ("Test Mechanical",
`test/fixtures/multi-company.cjs`) that is never part of the visible demo.
The suite also fails on any runtime or console error.

Last run (September 29, 2026, after `npm ci`): **876 passed, 0 failed**. The
runner prints the current count at the end of every run.

```bash
npm run test:visual
```

Opens the app in a real Chromium browser at 375, 390 and 430 px (phones), 768 px
(tablet) and 1280 px (desktop), plus Spanish with Large Text (including the Phase 3
approval, request detail and Packing Mode screens, and the Phase 4 purchasing, receiving and
field "On order" screens), and checks that no
screen scrolls sideways and that nothing logs a runtime or console error.
Screenshots are saved to `test/.visual/`. The first time on a machine, run
`npx playwright-core install chromium`.

Last run (same day): **249 of 249 screen checks passed**.

## Project structure

```
src/
  config/      roles, capabilities, statuses, priorities, company settings, feature flags, locations, ledger types
  services/    the only way screens read or change data (users, projects, requests, warehouse, inventory, locations, audit, session...)
  types/       the data model, documented (entities.js)
  data/        seed data, the 352-family catalog, strings (EN/ES), icons
  lib/         db (saving + upgrades), schema migrations, request-line and user models, integrity checks, store, auth, permissions, catalog engine, cart, actions
  dev/         developer tools (development builds only)
  components/  shared UI pieces and the overlay sheets
  screens/     one file per area of the app
  styles.css   ANT visual identity (unchanged from the original)
```

## Things that are prototype-only

- **Login** is a 4-digit PIN checked in the browser (`src/lib/auth.js`). It is not real security, and it is isolated so real sign-in can replace it without touching permissions.
- **Company isolation** is enforced in ANT's own services and tested with two companies, but everything runs in one browser with localStorage. That is architecture, not tenant security: anyone with the browser's developer tools can read or change the saved data. Real multi-company security needs server-side sign-in and server-enforced (row-level) authorization.
- **Creating a profile** joins a company by typing its exact name. A real product needs invitations or admin approval instead.
- **Saving** uses the browser's localStorage (`src/lib/db.js`). A real backend would replace that one file; screens only talk to `src/services/`.
- **Inventory**: stock is tracked per company, per exact variant, location, state and unit. A variant the warehouse has never stocked shows 0 and "Not stocked"; a Manager adjustment starts stocking it (at the warehouse until it gets a bin).
- **The request workflow's rollback** (`src/lib/transaction.js`) protects one browser tab from half-finished state; it is not database ACID. A production backend must run approval resolution, allocation, reservation, balance updates and fulfillment creation inside one server-side database transaction.
- **Purchasing is manual by design**: "Mark as sent" records that a PO was sent; ANT does not email suppliers. Quotes, prices and expected dates are typed in by people; ANT has no live supplier prices, stock, catalogs or APIs. PO totals are procurement figures, not accounting (no invoices, payables, costing or valuation yet). Supplier returns and credits for damaged material are recorded as issues only, for a later phase.
- **Purchase receiving** runs as one domain operation in the browser (receipt, ledger movements, the handoff to warehouse allocation, reservation and fulfillment). A production backend must do it in one server-side database transaction.
- **Dispatch** (Ready to Ship → Shipped → Completed) is still recorded on the fulfillment as a transitional `dispatchStatus` until the Logistics phase adds Shipment records.
- **Prices**: ANT has no trusted material prices yet, so "Estimated material value" shows "Value unavailable" and value-based approval rules always go to manual review.
- **Ledger transactions** are domain transactions inside one browser tab. A production backend must enforce the same rules in database transactions with row locks; localStorage offers no multi-user concurrency. The ledger is never trimmed, so very long use can reach browser storage limits.
- **Packed material on shipped orders** stays in Packed at the warehouse until the Logistics phase adds shipment movements, so the physical warehouse total includes it; the inventory detail says so.
- **Feature flags**: the Material Ledger is infrastructure and always on. The `inventory` flag (on for every company) only shows or hides the inventory and order activity history; turning it off never stops stock tracking, picking, packing or adjustments.
- **Developer tools** (`npm run dev`): `__ANT_DEV__.validateInventory()` lists balance vs ledger variances and `__ANT_DEV__.rebuildInventory()` rebuilds balances from the ledger.
- **Manufacturer data**: part numbers and UPCs are intentionally empty. Breaker availability rules are conservative placeholders to confirm against manufacturer catalogs.
- **Development server advisories**: `npm audit` reports two advisories in Vite 5 and its esbuild (they affect `npm run dev`, not the published app or the tests). Fixing them needs a Vite major-version upgrade, left for a separate, tested change.
