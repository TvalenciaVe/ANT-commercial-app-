/* =========================================================================
   DEVELOPER UTILITIES — development builds only (never in production UI).
   In the browser console during `npm run dev`:
     __ANT_DEV__.whoami()      current user, company, project, role, permission, schema
     __ANT_DEV__.integrity()   relationship problems (should be [])
     __ANT_DEV__.audit(20)     latest audit events
     __ANT_DEV__.loadReport    what the last load migrated or repaired
     __ANT_DEV__.validateInventory()   stored balances vs the ledger (variances, never hidden)
     __ANT_DEV__.rebuildInventory()    repair path: rebuild balances from the ledger and save
                                       (history is never changed)
     __ANT_DEV__.movements(variantId)  that variant's ledger, in order
   ========================================================================= */
import { ui } from '../lib/store.js';
import { db, loadReport, ANT_SCHEMA_VERSION } from '../lib/db.js';
import { checkIntegrity } from '../lib/integrity.js';
import { getCompany, getProject, getMembership } from '../services/repo.js';
import { effectivePermissionLevel } from '../lib/permissions.js';
import { recentAudit } from '../services/auditService.js';
import { validateInventoryAgainstLedger, rebuildInventoryBalancesFromLedger } from '../services/inventoryService.js';
import { getMovementsForVariant } from '../services/materialLedgerService.js';
import { saveAppData } from '../lib/db.js';

export function whoami() {
  const u = ui.currentUser;
  const p = getProject(ui.session.currentProjectId);
  const c = getCompany(ui.session.currentCompanyId);
  const m = u && p ? getMembership(u.id, p.id) : null;
  return {
    user: u ? { id: u.id, name: u.fullName, primaryRole: u.primaryRole, companyRoles: u.companyRoles, workerType: u.workerType } : null,
    company: c ? { id: c.id, name: c.name } : null,
    project: p ? { id: p.id, name: p.name } : null,
    projectRole: m ? m.projectRole : null,
    projectPermission: m ? effectivePermissionLevel(m, c) : null,
    schemaVersion: ANT_SCHEMA_VERSION,
  };
}
export function installDevTools(target) {
  const w = target || (typeof window !== 'undefined' ? window : null);
  if (!w) return null;
  w.__ANT_DEV__ = { whoami, integrity: () => checkIntegrity(db), audit: (n) => recentAudit(n || 20), loadReport, schemaVersion: ANT_SCHEMA_VERSION,
    validateInventory: (companyId) => validateInventoryAgainstLedger(companyId || (ui.session && ui.session.currentCompanyId) || 'company1'),
    rebuildInventory: (companyId) => { const out = rebuildInventoryBalancesFromLedger(companyId || (ui.session && ui.session.currentCompanyId) || 'company1', { apply: true }); saveAppData(); return out.length + ' balance(s) rebuilt from the ledger'; },
    movements: (variantId, companyId) => getMovementsForVariant(companyId || (ui.session && ui.session.currentCompanyId) || 'company1', variantId) };
  return w.__ANT_DEV__;
}
