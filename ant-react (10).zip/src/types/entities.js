/* =========================================================================
   ANT DATA MODEL — schema v3 (Phase 1, hardened).

   Rule for every "who did this" field, today and in later phases: store the
   user's ID (fieldConfirmedByUserId, and future approvedByUserId,
   pickedByUserId, verifiedByUserId, packedByUserId, receivedByUserId,
   inspectedByUserId). A name may be kept alongside only as a *NameSnapshot
   for history; it is never the reference.
   JSDoc types: editors show these shapes on hover/autocomplete. The stored
   JSON uses exactly these fields. Enum values live in src/config/.
   Relationships are always by id, never by display name.
   ========================================================================= */

/**
 * @typedef {Object} Company
 * @property {string} id
 * @property {string} name
 * @property {string} legalName
 * @property {string} companyType        one of COMPANY_TYPES (config/companySettings.js)
 * @property {string} phone
 * @property {string} email
 * @property {string} address
 * @property {string|null} logoUrl
 * @property {string} timezone
 * @property {'ACTIVE'|'SUSPENDED'|'CLOSED'} status
 * @property {CompanySettings} settings            how the company runs the modules it has
 * @property {Object<string, boolean>} features    which modules it has (feature flags, config/features.js)
 * @property {number} createdAt
 * @property {number} updatedAt
 */

/**
 * Operating choices only. Module availability is company.features, never here.
 * @typedef {Object} CompanySettings
 * @property {boolean} projectPermissionsEnabled   false = every member gets their role's default level
 * @property {boolean} allowJourneymanRequests
 * @property {boolean} allowApprenticeRequests
 * @property {string}  defaultPriority             EMERGENCY | HIGH | NORMAL | LOW
 * @property {string}  defaultWarehouseId          a WAREHOUSE Location OF THIS COMPANY
 * @property {boolean} approvalsEnabled            this company requires approvals (v5; the module flag is features.approvals)
 * @property {boolean} duplicateDetectionEnabled   warn before sending a possible duplicate request
 * @property {number}  duplicateWindowHours        how far back to look (demo 24; 0 = off)
 * @property {boolean} autoAllocateWarehouseStock  allocate + reserve automatically once approved
 * @property {boolean} allowManualAllocationAdjustment  warehouse managers may change allocations
 * @property {string}  currency
 * @property {string}  timezone
 */

/**
 * @typedef {Object} User
 * @property {string} id
 * @property {string} companyId
 * @property {string} firstName
 * @property {string} lastName
 * @property {string} fullName      written together with first/last by userService.setUserName (`name` is a read-only, unsaved alias)
 * @property {string} email
 * @property {string} phone
 * @property {string} pin           PROTOTYPE ONLY (mock sign-in); never used for authorization
 * @property {'FIELD'|'WAREHOUSE'|'MANAGEMENT'|'PURCHASING'|'ADMIN'} workerType
 * @property {string} primaryRole   one of ROLES: decides the person's home screen
 * @property {string[]} companyRoles every company responsibility they hold (always includes primaryRole)
 * @property {'ACTIVE'|'INVITED'|'INACTIVE'} status
 * @property {string|null} avatarUrl
 * @property {string|null} [lastProjectId]  field users: project to reopen at next sign-in (a preference, re-validated; not a permission)
 * @property {string|null} [warehouseId]    warehouse users: the one warehouse they work for (a WAREHOUSE of their company); none = every warehouse of the company
 * @property {string[]} [recentlyUsed]      field users: productVariantIds
 * @property {string[]} [mostUsed]          field users: productVariantIds
 * @property {Object<string, number>} [brandPrefs]
 * @property {Object<string, number>} [lastQty]
 * @property {number} createdAt
 * @property {number} updatedAt
 */

/**
 * @typedef {Object} Project
 * @property {string} id
 * @property {string} companyId
 * @property {string} name
 * @property {string} projectNumber
 * @property {string} address        street line
 * @property {string} city
 * @property {string} state
 * @property {string} zipCode
 * @property {string} description
 * @property {'PLANNING'|'ACTIVE'|'ON_HOLD'|'CLOSING'|'COMPLETED'|'ARCHIVED'} status
 * @property {number|null} startDate
 * @property {number|null} expectedCompletionDate
 * @property {string} assignedWarehouseId   a WAREHOUSE Location id
 * @property {number|null} materialBudget
 * @property {string|null} createdBy
 * @property {number} createdAt
 * @property {number} updatedAt
 */

/**
 * The ONLY source of truth for project access. One ACTIVE record per user + project.
 * @typedef {Object} ProjectMembership
 * @property {string} id
 * @property {string} companyId
 * @property {string} projectId
 * @property {string} userId
 * @property {'PROJECT_MANAGER'|'SUPERINTENDENT'|'FOREMAN'|'JOURNEYMAN'|'APPRENTICE'} projectRole
 * @property {'VIEWER'|'CAN_EDIT'|'FULL_CONTROL'} permissionLevel
 * @property {'ACTIVE'|'REMOVED'} status
 * @property {number} assignedAt
 * @property {string|null} assignedBy
 */

/**
 * A location belongs to exactly ONE company; ids are never shared.
 * Stock is held in InventoryBalance rows that point to a location by id (schema v4).
 * @typedef {Object} Location
 * @property {string} id
 * @property {string} companyId
 * @property {string} name
 * @property {'WAREHOUSE'|'WAREHOUSE_ZONE'|'WAREHOUSE_BIN'|'JOBSITE'|'VEHICLE'|'TRANSIT'|'RETURN_INSPECTION'|'DAMAGED'|'SCRAP'|'OTHER'} type
 * @property {string|null} parentLocationId
 * @property {string|null} projectId     set for JOBSITE locations
 * @property {string} address
 * @property {'ACTIVE'|'INACTIVE'} status
 * @property {Object} metadata
 * @property {number} createdAt
 * @property {number} updatedAt
 */

/**
 * What the field needs (DEMAND). Stored in db.REQUESTS (payload key `materialRequests`).
 *
 * Since v5 a request carries no warehouse state of its own: the warehouse
 * work is a Fulfillment, the sourcing is MaterialAllocation, the held stock
 * is RESERVED movements, and outstanding demand = requested - active allocated.
 * Screens read it through fulfillmentService.fieldRequestView / stageOf.
 * Pre-v5 requests are allocationMode LEGACY and keep their combined
 * workflowStatus and Phase 2 flow (nothing was invented for them).
 *
 * @typedef {Object} MaterialRequest
 * @property {string} id                    e.g. "ORD-1004" (shown to users as the order number)
 * @property {string} requestNumber         same as id today (kept separate for a future numbering scheme)
 * @property {'DRAFT'|'SUBMITTED'|'PENDING_APPROVAL'|'APPROVED'|'PROCESSING'|'PARTIALLY_FULFILLED'|'FULFILLED'|'CANCELLED'} status  derived from demand (services/requestProgress.js)
 * @property {'NOT_REQUIRED'|'PENDING'|'APPROVED'|'REJECTED'|'CANCELLED'|'LEGACY'|null} approvalStatus  a rejection keeps status CANCELLED + approvalStatus REJECTED
 * @property {'NOT_STARTED'|'UNALLOCATED'|'PARTIALLY_ALLOCATED'|'ALLOCATED'|'RELEASED'|'LEGACY'} allocationStatus
 * @property {'V5'|'LEGACY'} allocationMode
 * @property {string|null} submissionKey    one per review: a retry by the same person with the same payload returns the same request
 * @property {string|null} [submissionFingerprint]  normalized payload (project, requester, priority, needed by, notes, sorted lines)
 * @property {string|null} [approvalRequestId]
 * @property {string} [legacyStatus]        LEGACY only: the combined status at migration
 * @property {number} [cancelledAt]
 * @property {string} [cancelledByUserId]
 * @property {string} [cancelReason]
 * @property {string} companyId
 * @property {string} projectId
 * @property {string} requestedByUserId
 * @property {'EMERGENCY'|'HIGH'|'NORMAL'|'LOW'} priority
 * @property {number} neededBy
 * @property {string} notes
 * @property {'PENDING'|'IN_PROGRESS'|'PARTIALLY_PACKED'|'PACKED'|'READY_TO_SHIP'|'SHIPPED'|'COMPLETED'} [workflowStatus]  LEGACY requests only
 * @property {number} createdAt
 * @property {number} submittedAt
 * @property {number} updatedAt
 * @property {number|null} [packedAt]        LEGACY only (v5: Fulfillment.packedAt)
 * @property {number|null} [shippedAt]       LEGACY only (v5: Fulfillment.shippedAt)
 * @property {number|null} [completedAt]     LEGACY only (v5: Fulfillment.deliveredAt)
 * @property {boolean} fieldConfirmed        (→ Receipt)
 * @property {string|null} fieldConfirmedByUserId        (→ Receipt) who confirmed, by user id
 * @property {string|null} fieldConfirmedByNameSnapshot  (→ Receipt) their name at the time, display only
 * @property {number|null} fieldConfirmedAt  (→ Receipt)
 * @property {DeliveryIssue[]|null} deliveryIssues (→ Receipt)
 * @property {MaterialRequestItem[]} items
 * @property {string} [legacyProjectName]    only if migration could not resolve the project
 * @property {string} [legacyRequesterName]  only if migration could not resolve the requester
 */

/**
 * One requested line. v5 lines are DEMAND ONLY (lib/requestModel.demandItem): no
 * warehouse progress is stored on them; requested / allocated / reserved / picked /
 * packed / outstanding come from services/requestProgress.js. LEGACY lines keep the
 * Phase 2 progress cache (lib/requestModel.canonicalItem) marked below.
 * @typedef {Object} MaterialRequestItem
 * @property {string} id                     e.g. "ORD-1004-L1"
 * @property {string} requestId
 * @property {string} productVariantId       exact master catalog variant
 * @property {number} quantity
 * @property {string} unit
 * @property {string} productNameSnapshot    readable name at request time
 * @property {{familyId:string, familyName:string, attributes:Object, unit:string, displayName:string}|null} variantSnapshot
 * @property {{selection:'SPECIFIC'|'ANY'|'NOT_APPLICABLE', manufacturerId:string|null, manufacturerName:string, manufacturerPartNumber:string|null}} brandSnapshot
 * @property {string|null} legacyProductId   the pre-catalog flat id, when migrated
 * @property {boolean} [collected]           LEGACY only
 * @property {number} [packedQuantity]       LEGACY only
 * @property {number} [shortQuantity]        LEGACY only (never used for v5 outstanding demand)
 */

/**
 * @typedef {Object} DeliveryIssue
 * @property {string|null} requestItemId
 * @property {string} productVariantId
 * @property {string} productNameSnapshot
 * @property {string} unit
 * @property {number} expectedQuantity
 * @property {number} receivedQuantity
 * @property {number} missingQuantity
 */

/**
 * Where ANT sources (part of) one request line. Phase 3 creates WAREHOUSE
 * allocations only, one per bin of the project's assigned warehouse, each
 * backed by RESERVE movements that carry its id (reservation ownership).
 * Invariant: quantity = reserved + picking + packed for this allocation (ledger).
 * @typedef {Object} MaterialAllocation
 * @property {string} id                    ALC-1001
 * @property {string} companyId
 * @property {string} projectId
 * @property {string} requestId
 * @property {string} requestItemId
 * @property {string} productVariantId      the exact stocked variant
 * @property {'WAREHOUSE'|'SUPPLIER'|'JOBSITE_TRANSFER'|'DIRECT_PURCHASE'|'SPECIAL_ORDER'} sourceType  only WAREHOUSE is active
 * @property {string|null} sourceLocationId the bin
 * @property {string} warehouseId           the project's assigned warehouse
 * @property {number} quantity              currently allocated (changes only with RESERVE / UNRESERVE movements)
 * @property {number} releasedQuantity      released so far
 * @property {string} unit
 * @property {'PROPOSED'|'ALLOCATED'|'RESERVED'|'PARTIALLY_FULFILLED'|'FULFILLED'|'RELEASED'|'CANCELLED'} status
 * @property {string|null} createdByUserId  null when ANT allocated automatically
 * @property {'USER'|'SYSTEM'} actorType
 * @property {number} createdAt
 * @property {number} updatedAt
 * @property {string|null} fulfillmentId
 * @property {{source:string, round:number, actorType:string, triggeredByUserId?:string}} metadata
 */

/**
 * The warehouse WORK for a request: only what was allocated to the warehouse.
 * ONE request -> MANY fulfillments, linked only by Fulfillment.requestId. Each
 * warehouse fulfillment is a "batch" (Batch 1, Batch 2...): stock allocated later
 * for outstanding demand joins a batch nobody has started, otherwise it gets a
 * new batch; a started, packed, ready or dispatched batch is never enlarged. LEGACY
 * fulfillments are compatibility records for pre-v5 requests (legacyMigrated,
 * status read from the request, no allocations).
 * @typedef {Object} Fulfillment
 * @property {string} id                    FUL-1001
 * @property {string} companyId
 * @property {string} projectId             always the request's project
 * @property {string} requestId
 * @property {'WAREHOUSE'} sourceType
 * @property {string|null} sourceLocationId the warehouse
 * @property {'PENDING'|'ALLOCATED'|'PICKING'|'PARTIALLY_PICKED'|'PICKED'|'VERIFIED'|'PACKED'|'READY'|'CANCELLED'|null} status  null for LEGACY (read from the request)
 * @property {'SHIPPED'|'DELIVERED'|null} dispatchStatus  TRANSITIONAL until the Logistics phase adds Shipment records
 * @property {string} priority
 * @property {number} neededBy
 * @property {'V5'|'LEGACY'} allocationMode
 * @property {boolean} legacyMigrated
 * @property {string|null} createdByUserId
 * @property {'USER'|'SYSTEM'} actorType
 * @property {number|null} packedAt
 * @property {number|null} readyAt
 * @property {number|null} shippedAt
 * @property {number|null} deliveredAt
 * @property {FulfillmentItem[]} items
 * @property {number} createdAt
 * @property {number} updatedAt
 */

/**
 * @typedef {Object} FulfillmentItem
 * @property {string} id                    FUL-1001-L1
 * @property {string} fulfillmentId
 * @property {string} requestItemId
 * @property {string[]} allocationIds
 * @property {string} productVariantId
 * @property {number|null} allocatedQuantity  sum of its active allocations (null for LEGACY)
 * @property {string} unit
 * @property {number} pickedQuantity        cache written from the ledger (fulfillmentService.refreshFulfillment)
 * @property {number} packedQuantity        cache written from the ledger
 * @property {boolean} collected
 * @property {number} [legacyRequestedQuantity]  LEGACY only
 */

/**
 * @typedef {Object} ApprovalPolicy
 * @property {string} id
 * @property {string} companyId
 * @property {string} name
 * @property {boolean} active
 * @property {ApprovalRule[]} rules
 * @property {'AUTO_APPROVE'|'REQUIRE_APPROVAL'} defaultBehavior   when no rule matches
 * @property {string|null} defaultApproverRole
 * @property {number} createdAt
 * @property {number} updatedAt
 */

/**
 * @typedef {Object} ApprovalRule
 * @property {string} id
 * @property {'PRIORITY'|'MATERIAL_CATEGORY'|'PRODUCT_VARIANT'|'PROJECT'|'QUANTITY'|'REQUEST_VALUE'} type  REQUEST_VALUE: unknown cost routes to manual review, never $0
 * @property {'EQUALS'|'IN'|'GREATER_THAN'} operator
 * @property {*} value
 * @property {string} approverRole          e.g. PROJECT_MANAGER
 * @property {number} priority              order of the approval steps
 * @property {boolean} active
 * @property {string} [label]
 */

/**
 * One approval decision for one request, resolved step by step.
 * @typedef {Object} ApprovalRequest
 * @property {string} id                    APR-1001
 * @property {string} companyId
 * @property {string} projectId
 * @property {string} requestId
 * @property {'PENDING'|'APPROVED'|'REJECTED'|'CANCELLED'} status  terminal states can't be resolved again
 * @property {string} requiredApproverRole  the first step's role
 * @property {string|null} ruleIdOptional
 * @property {string} policyId
 * @property {number} requestedAt
 * @property {number|null} resolvedAt
 * @property {string|null} resolvedByUserId
 * @property {string|null} decisionNotes
 * @property {{sequence:number, requiredRole:string, status:'WAITING'|'PENDING'|'APPROVED'|'REJECTED'|'CANCELLED', ruleIds:string[], activatedAt:number|null, resolvedByUserId:string|null, resolvedAt:number|null, notes:string|null}[]} steps
 *           sequential: exactly one PENDING (active) step while the approval is PENDING; later steps WAITING. A step's
 *           requiredRole decides its scope (config/requests.js APPROVER_ROLE_SCOPES): PROJECT (Project Manager on that
 *           project) or COMPANY (Purchasing Manager / Owner / Company Admin via companyRoles, no project membership)
 * @property {{ruleId:string|null, type:string, role:string, code:string, message:string}[]} reasons  code: RULE_MATCHED | COST_UNKNOWN_REVIEW_REQUIRED | POLICY_DEFAULT
 * @property {{estimatedValue:{known:boolean, value:number|null, label:string}}} metadata
 */

/**
 * Material Ledger (schema v4). One immutable record per change in where
 * material is or what state it is in. Posted only by
 * services/materialLedgerService.js; frozen in memory; never edited or
 * deleted. Mistakes are corrected with a new movement (UNPICK, UNPACK,
 * REVERSAL, adjustment) that points at the original.
 * Ids are mov_000001, mov_000002... with no gaps (a gap means a deletion).
 * @typedef {Object} MaterialMovement
 * @property {string} id                     mov_000001
 * @property {string} companyId
 * @property {string} productVariantId       the exact stocked variant (never a family)
 * @property {number} quantity               always > 0
 * @property {string} unit                   the variant's unit (no conversions)
 * @property {string|null} fromLocationId    null = material entered tracked inventory
 * @property {string|null} toLocationId      null = material left tracked inventory
 * @property {string|null} fromInventoryState  INVENTORY_STATES (config/ledger.js)
 * @property {string|null} toInventoryState
 * @property {string} movementType           MOVEMENT_TYPES (config/ledger.js)
 * @property {string|null} projectId
 * @property {string|null} requestId
 * @property {string|null} requestItemId
 * @property {string|null} allocationId      v5: the allocation that owns RESERVED stock (required whenever RESERVED is touched)
 * @property {string|null} fulfillmentId     v5 warehouse picks / packs
 * @property {string|null} shipmentId
 * @property {string|null} returnId
 * @property {string|null} purchaseOrderId
 * @property {string|null} reasonCode        ADJUSTMENT_REASONS, or LEDGER_OPENING_BALANCE
 * @property {string} notes
 * @property {string|null} performedByUserId null only for ANT itself: opening balances and automatic RESERVE / UNRESERVE (metadata.source, metadata.triggeredByUserId)
 * @property {'USER'|'SYSTEM'} actorType
 * @property {number} timestamp
 * @property {string|null} reversalOfMovementId
 * @property {string|null} operationKey      idempotency key (see IdempotencyRecord)
 * @property {Object|null} metadata
 */

/**
 * One per company + operationKey (never global). A retry with the same key
 * and the same payload fingerprint replays resultMovementIds; the same key
 * with a different payload is IDEMPOTENCY_CONFLICT. Lookups filter by the
 * actor's company first, so another company's record is never found.
 * @typedef {Object} IdempotencyRecord
 * @property {string} companyId
 * @property {string} operationKey
 * @property {string} operationType          PICK_MATERIAL, PACK_MATERIAL, INVENTORY_ADJUSTMENT, POST_MOVEMENTS... and SUBMIT_MATERIAL_REQUEST
 * @property {string} actorUserId
 * @property {'USER'|'SYSTEM'} [actorType]
 * @property {string|null} entityType
 * @property {string|null} entityId
 * @property {string} payloadFingerprint     business payload only (no timestamps or generated ids)
 * @property {string[]} resultMovementIds    empty for SUBMIT_MATERIAL_REQUEST
 * @property {string} [resultEntityType]     SUBMIT_MATERIAL_REQUEST: 'MaterialRequest'
 * @property {string} [resultEntityId]       SUBMIT_MATERIAL_REQUEST: the request it created. Key = "submit:<userId>:<submissionKey>",
 *                                           so a submission is scoped by company + requester + key and checked by fingerprint
 * @property {number} createdAt
 */

/**
 * Materialized total for one key: company + variant + location + state.
 * Written only together with its movement; always rebuildable by replaying
 * the ledger (inventoryService.rebuildInventoryBalancesFromLedger).
 * Production database:
 *   inventory_balances UNIQUE (company_id, product_variant_id, location_id, inventory_state)
 * @typedef {Object} InventoryBalance
 * @property {string} id                     bal:<company>:<location>:<state>:<variant>
 * @property {string} companyId
 * @property {string} productVariantId
 * @property {string} locationId             the most precise known location (bin, or the warehouse if no bin yet)
 * @property {string} inventoryState
 * @property {number} quantity               never negative
 * @property {string} unit
 * @property {number} updatedAt
 */

/**
 * Inventory metadata per company + variant. Holds NO quantity.
 * @typedef {Object} InventoryItem
 * @property {string} id                     inv:<company>:<variant>
 * @property {string} companyId
 * @property {string} productVariantId
 * @property {string} primaryLocationId      picked from first
 * @property {number|null} minimumStock
 * @property {number|null} reorderPoint      low stock = AVAILABLE <= reorderPoint
 * @property {number|null} targetStock
 * @property {boolean} active
 */

/**
 * Request line progress (schema v4). pickedQuantity / packedQuantity /
 * shortQuantity / collected are a cache written only by inventoryService
 * from the ledger; integrity checks they match. Equations:
 *   requested = picked + outstanding;  packed <= picked;  short <= outstanding
 * A shortage is demand, never negative stock:
 * @typedef {Object} Shortage
 * @property {string} requestId
 * @property {string} requestItemId
 * @property {string} productVariantId
 * @property {number} requestedQuantity
 * @property {number} pickedQuantity
 * @property {number} shortQuantity
 * @property {string|null} reportedByUserId  null only when a pre-v4 shortage has no audit record
 * @property {number|null} reportedAt
 * @property {string|null} reason
 * @property {boolean} legacy                recorded before the ledger started
 * legacyProgress { pickedQuantity, packedQuantity, recordedBefore } exists only
 * on lines dispatched before the ledger started (history, not stock).
 */

/**
 * @typedef {Object} AuditEvent
 * @property {string} id
 * @property {string|null} companyId
 * @property {string|null} userId
 * @property {string|null} userRole
 * @property {string} action           one of AUDIT_ACTIONS (services/auditService.js)
 * @property {string|null} entityType
 * @property {string|null} entityId
 * @property {string|null} projectId
 * @property {string|null} locationId
 * @property {Object|null} before
 * @property {Object|null} after
 * @property {number} timestamp
 */

/**
 * @typedef {Object} Notification
 * @property {string} id
 * @property {string} companyId
 * @property {string} userId
 * @property {string} type             one of NOTIFICATION_TYPES (services/notificationService.js)
 * @property {string} title
 * @property {string} message
 * @property {string|null} entityType
 * @property {string|null} entityId
 * @property {string|null} projectId
 * @property {boolean} read
 * @property {number} createdAt
 */

export {};
