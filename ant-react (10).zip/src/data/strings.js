// EN/ES interface text. Product names, brands, part numbers, project names and notes are never translated.
export const STRINGS = {
 "home": {
  "en": "Home",
  "es": "Inicio"
 },
 "good_morning": {
  "en": "Good morning",
  "es": "Buenos días"
 },
 "good_afternoon": {
  "en": "Good afternoon",
  "es": "Buenas tardes"
 },
 "good_evening": {
  "en": "Good evening",
  "es": "Buenas noches"
 },
 "projects": {
  "en": "Projects",
  "es": "Proyectos"
 },
 "orders": {
  "en": "Orders",
  "es": "Órdenes"
 },
 "profile": {
  "en": "Profile",
  "es": "Perfil"
 },
 "inventory": {
  "en": "Inventory",
  "es": "Inventario"
 },
 "packing": {
  "en": "Packing",
  "es": "Empaque"
 },
 "search_materials": {
  "en": "Search materials, size or part #",
  "es": "Buscar material, tamaño o número de parte"
 },
 "change": {
  "en": "Change",
  "es": "Cambiar"
 },
 "see_all": {
  "en": "See all",
  "es": "Ver todos"
 },
 "added": {
  "en": "Added",
  "es": "Agregado"
 },
 "add": {
  "en": "Add",
  "es": "Agregar"
 },
 "what_materials": {
  "en": "What materials do you need?",
  "es": "¿Qué materiales necesitas?"
 },
 "request_materials": {
  "en": "Request materials",
  "es": "Solicitar materiales"
 },
 "current_project": {
  "en": "Current project",
  "es": "Proyecto actual"
 },
 "change_project": {
  "en": "Change project",
  "es": "Cambiar proyecto"
 },
 "start_packing": {
  "en": "Start packing",
  "es": "Empezar a empacar"
 },
 "view_full_list": {
  "en": "View full list",
  "es": "Ver lista completa"
 },
 "skip_for_now": {
  "en": "Skip for now",
  "es": "Saltar por ahora"
 },
 "mark_short": {
  "en": "Mark short",
  "es": "Marcar faltante"
 },
 "pack": {
  "en": "Pack",
  "es": "Empacar"
 },
 "need": {
  "en": "Need",
  "es": "Necesita"
 },
 "available": {
  "en": "Available",
  "es": "Disponible"
 },
 "location": {
  "en": "Location",
  "es": "Ubicación"
 },
 "packing_complete": {
  "en": "Packing complete",
  "es": "Empaque completo"
 },
 "done": {
  "en": "Done",
  "es": "Listo"
 },
 "view_only": {
  "en": "View Only",
  "es": "Solo ver"
 },
 "can_request_materials": {
  "en": "Can Request Materials",
  "es": "Puede solicitar materiales"
 },
 "full_control": {
  "en": "Full Control",
  "es": "Control total"
 },
 "requested": {
  "en": "Requested",
  "es": "Solicitado"
 },
 "packing_stage": {
  "en": "Packing",
  "es": "Empacando"
 },
 "ready_to_ship": {
  "en": "Ready to Ship",
  "es": "Listo para enviar"
 },
 "on_the_way": {
  "en": "On the Way",
  "es": "En camino"
 },
 "delivered": {
  "en": "Delivered",
  "es": "Entregado"
 },
 "warehouse_inventory": {
  "en": "Warehouse Inventory",
  "es": "Inventario del almacén"
 },
 "did_everything_arrive": {
  "en": "Did everything arrive?",
  "es": "¿Llegó todo?"
 },
 "yes_everything_arrived": {
  "en": "Yes, everything arrived",
  "es": "Sí, todo llegó"
 },
 "something_missing": {
  "en": "Something is missing",
  "es": "Falta algo"
 },
 "submit": {
  "en": "Submit",
  "es": "Enviar"
 },
 "categories": {
  "en": "Categories",
  "es": "Categorías"
 },
 "job_kits": {
  "en": "Job Kits",
  "es": "Kits de trabajo"
 },
 "recently_used": {
  "en": "Recently used",
  "es": "Usados recientemente"
 },
 "most_used_by_you": {
  "en": "Most used by you",
  "es": "Más usados por ti"
 },
 "add_to_material_request": {
  "en": "Add to material request",
  "es": "Agregar a la solicitud"
 },
 "continue_label": {
  "en": "Continue",
  "es": "Continuar"
 },
 "cancel": {
  "en": "Cancel",
  "es": "Cancelar"
 },
 "language": {
  "en": "Language",
  "es": "Idioma"
 },
 "text_size": {
  "en": "Text size",
  "es": "Tamaño de texto"
 },
 "standard": {
  "en": "Standard",
  "es": "Estándar"
 },
 "large": {
  "en": "Large",
  "es": "Grande"
 },
 "preferences": {
  "en": "Preferences",
  "es": "Preferencias"
 },
 "view_only_access_project": {
  "en": "You have view-only access on",
  "es": "Tienes acceso de solo lectura en"
 },
 "view_only_access_requests": {
  "en": "You have view-only access to material requests on this project.",
  "es": "Tienes acceso de solo lectura a las solicitudes de materiales en este proyecto."
 },
 "no_permission_submit": {
  "en": "You don't have permission to submit material requests for this project.",
  "es": "No tienes permiso para enviar solicitudes de materiales en este proyecto."
 },
 "err_name_required": {
  "en": "Enter your name to continue.",
  "es": "Ingresa tu nombre para continuar."
 },
 "err_email_invalid": {
  "en": "Enter a valid email address, like name@company.com.",
  "es": "Ingresa un correo válido, como nombre@empresa.com."
 },
 "err_phone_invalid": {
  "en": "Enter a valid 10-digit phone number.",
  "es": "Ingresa un número de teléfono válido de 10 dígitos."
 },
 "err_pin_invalid": {
  "en": "PIN must be exactly 4 digits.",
  "es": "El PIN debe tener exactamente 4 dígitos."
 },
 "err_company_required": {
  "en": "Enter your company name to continue.",
  "es": "Ingresa el nombre de tu empresa para continuar."
 },
 "available_label": { "en": "Available", "es": "Disponible" },
 "picking_state": { "en": "Picking", "es": "En recolección" },
 "packed_state": { "en": "Packed", "es": "Empacado" },
 "physical_in_warehouse": { "en": "Physical in warehouse", "es": "Físico en almacén" },
 "inventory_adjustment": { "en": "Inventory Adjustment", "es": "Ajuste de inventario" },
 "adjust_inventory": { "en": "Adjust inventory", "es": "Ajustar inventario" },
 "recent_activity": { "en": "Recent Activity", "es": "Actividad reciente" },
 "current_quantity": { "en": "Current quantity", "es": "Cantidad actual" },
 "add_stock": { "en": "Add", "es": "Agregar" },
 "remove_stock": { "en": "Remove", "es": "Quitar" },
 "adjust_quantity_label": { "en": "Quantity", "es": "Cantidad" },
 "new_quantity": { "en": "New quantity", "es": "Nueva cantidad" },
 "reason": { "en": "Reason", "es": "Motivo" },
 "choose_reason": { "en": "Choose a reason", "es": "Elige un motivo" },
 "notes_optional": { "en": "Notes (optional)", "es": "Notas (opcional)" },
 "save_adjustment": { "en": "Save adjustment", "es": "Guardar ajuste" },
 "inventory_adjusted": { "en": "Inventory adjusted.", "es": "Inventario ajustado." },
 "err_reason_required": { "en": "Choose a reason for this adjustment.", "es": "Elige un motivo para este ajuste." },
 "err_adjust_quantity": { "en": "Enter a whole quantity greater than 0.", "es": "Ingresa una cantidad entera mayor que 0." },
 "err_adjust_insufficient": { "en": "You can't remove more than is available.", "es": "No puedes quitar más de lo disponible." },
 "primary_location": { "en": "Primary location", "es": "Ubicación principal" },
 "other_locations": { "en": "Other locations", "es": "Otras ubicaciones" },
 "reorder_point": { "en": "Reorder point", "es": "Punto de reorden" },
 "low_stock": { "en": "Low stock", "es": "Existencia baja" },
 "no_activity_yet": { "en": "No activity yet.", "es": "Aún no hay actividad." },
 "inventory_activity": { "en": "Inventory activity", "es": "Actividad de inventario" },
 "pick_verb": { "en": "Pick", "es": "Recolectar" },
 "pick_from_bins": { "en": "Pick from", "es": "Recolectar de" },
 "system_actor": { "en": "System", "es": "Sistema" },
 "packed_on_shipped_note": { "en": "{qty} of the packed quantity belongs to orders already marked shipped; it leaves the warehouse count when the Logistics phase adds shipments.", "es": "{qty} de lo empacado pertenece a órdenes ya marcadas como enviadas; saldrá del conteo del almacén cuando la fase de Logística agregue envíos." },
 "mv_pick": { "en": "{qty} picked for {order}", "es": "{qty} recolectados para {order}" },
 "mv_unpick": { "en": "{qty} returned to stock from {order}", "es": "{qty} devueltos al inventario de {order}" },
 "mv_pack": { "en": "{qty} packed for {order}", "es": "{qty} empacados para {order}" },
 "mv_unpack": { "en": "{qty} unpacked for {order}", "es": "{qty} desempacados de {order}" },
 "mv_adjust_in": { "en": "Inventory adjusted +{qty} at {location}", "es": "Inventario ajustado +{qty} en {location}" },
 "mv_adjust_out": { "en": "Inventory adjusted -{qty} at {location}", "es": "Inventario ajustado -{qty} en {location}" },
 "mv_opening": { "en": "Opening balance +{qty}", "es": "Saldo inicial +{qty}" },
 "mv_opening_held": { "en": "Opening balance: {qty} already picked for {order}", "es": "Saldo inicial: {qty} ya recolectados para {order}" },
 "mv_transfer": { "en": "{qty} moved from {from} to {to}", "es": "{qty} movidos de {from} a {to}" },
 "mv_reversal": { "en": "Correction: {qty} reversed", "es": "Corrección: {qty} revertidos" },
 "ledger_started": { "en": "Inventory ledger started", "es": "Inicio del registro de inventario" },
 "total_available": { "en": "Total available", "es": "Total disponible" },
 "choose_location": { "en": "Choose the location you counted", "es": "Elige la ubicación que contaste" },
 "available_at": { "en": "Available at {location}", "es": "Disponible en {location}" },
 "new_quantity_at": { "en": "New quantity at {location}", "es": "Nueva cantidad en {location}" },
 "total_after": { "en": "Total after adjustment", "es": "Total después del ajuste" },
 "other_warehouse_locations": { "en": "Other warehouse locations", "es": "Otras ubicaciones del almacén" },
 "err_location_required": { "en": "This material is in more than one location. Choose the location you are correcting.", "es": "Este material está en más de una ubicación. Elige la ubicación que estás corrigiendo." },
 "err_location_invalid": { "en": "That location can't be adjusted here.", "es": "Esa ubicación no se puede ajustar aquí." },
 "err_company_unknown": {
  "en": "That company is not available in ANT. Ask your company administrator for access.",
  "es": "Esa empresa no está disponible en ANT. Pide acceso al administrador de tu empresa."
 },
 "err_company_mismatch": {
  "en": "That company doesn't match the one you selected.",
  "es": "Esa empresa no coincide con la que seleccionaste."
 },
 "err_no_permission_create_project": {
  "en": "You don't have permission to create a project.",
  "es": "No tienes permiso para crear un proyecto."
 },
 "select_company": {
  "en": "Select your company",
  "es": "Selecciona tu empresa"
 },
 "change_company": {
  "en": "Change company",
  "es": "Cambiar empresa"
 },
 "err_role_required": {
  "en": "Choose your role to continue.",
  "es": "Elige tu rol para continuar."
 },
 "err_email_taken": {
  "en": "An account with this email already exists. Try logging in instead.",
  "es": "Ya existe una cuenta con este correo. Intenta iniciar sesión."
 },
 "err_phone_taken": {
  "en": "An account with this phone number already exists. Try logging in instead.",
  "es": "Ya existe una cuenta con este número. Intenta iniciar sesión."
 },
 "err_cart_empty": {
  "en": "Add at least one material to continue.",
  "es": "Agrega al menos un material para continuar."
 },
 "err_needed_date": {
  "en": "Choose when these materials are needed.",
  "es": "Elige cuándo se necesitan estos materiales."
 },
 "err_priority": {
  "en": "Choose a priority to continue.",
  "es": "Elige una prioridad para continuar."
 },
 "err_no_project": {
  "en": "Select a project before submitting a request.",
  "es": "Selecciona un proyecto antes de enviar una solicitud."
 },
 "possible_duplicate": { "en": "Possible duplicate request", "es": "Posible solicitud duplicada" },
 "duplicate_intro": { "en": "This project already has an active request with the same material. That can be on purpose. Just checking before you send.", "es": "Este proyecto ya tiene una solicitud activa con el mismo material. Puede ser a propósito. Solo lo verificamos antes de enviar." },
 "duplicate_requested_ago": { "en": "Requested {when} · {id}", "es": "Solicitado {when} · {id}" },
 "view_request": { "en": "View request", "es": "Ver solicitud" },
 "continue_anyway": { "en": "Continue anyway", "es": "Continuar de todos modos" },
 "go_back": { "en": "Go back", "es": "Regresar" },
 "approvals_waiting": { "en": "{n} requests are waiting for your approval", "es": "{n} solicitudes esperan tu aprobación" },
 "approvals_tap": { "en": "Tap to review", "es": "Toca para revisar" },
 "requested_by": { "en": "Requested by", "es": "Solicitado por" },
 "priority": { "en": "Priority", "es": "Prioridad" },
 "needed_label": { "en": "Needed", "es": "Se necesita" },
 "estimated_value": { "en": "Estimated material value", "es": "Valor estimado del material" },
 "value_unavailable": { "en": "Value unavailable", "es": "Valor no disponible" },
 "approval_reason": { "en": "Reason for approval", "es": "Motivo de aprobación" },
 "cost_unknown_review": { "en": "Material value unknown, needs review", "es": "Valor del material desconocido, requiere revisión" },
 "approver": { "en": "Approver", "es": "Aprobador" },
 "materials_n": { "en": "Materials ({n})", "es": "Materiales ({n})" },
 "decision_notes": { "en": "Comment (optional)", "es": "Comentario (opcional)" },
 "reject": { "en": "Reject", "es": "Rechazar" },
 "approve": { "en": "Approve", "es": "Aprobar" },
 "request_approval": { "en": "Request approval", "es": "Aprobación de solicitud" },
 "no_approvals": { "en": "Nothing waiting for approval", "es": "Nada esperando aprobación" },
 "approval_already_resolved": { "en": "This request was already decided.", "es": "Esta solicitud ya fue decidida." },
 "toast_approved": { "en": "Request approved.", "es": "Solicitud aprobada." },
 "toast_rejected": { "en": "Request rejected. The requester was told why.", "es": "Solicitud rechazada. Se le avisó al solicitante." },
 "toast_sent_needs_approval": { "en": "Request sent. It needs approval before the warehouse prepares it.", "es": "Solicitud enviada. Necesita aprobación antes de que el almacén la prepare." },
 "toast_sent_outstanding": { "en": "Request sent. Some materials aren't in the warehouse yet; they stay on your request as outstanding.", "es": "Solicitud enviada. Algunos materiales aún no están en el almacén; quedan pendientes en tu solicitud." },
 "toast_request_cancelled": { "en": "Request cancelled.", "es": "Solicitud cancelada." },
 "available_status": { "en": "Available", "es": "Disponible" },
 "partially_available": { "en": "Partially available", "es": "Parcialmente disponible" },
 "not_available_yet": { "en": "Not available yet", "es": "Aún no disponible" },
 "materials_label": { "en": "Materials", "es": "Materiales" },
 "requested_label": { "en": "Requested", "es": "Solicitado" },
 "warehouse_label": { "en": "Warehouse", "es": "Almacén" },
 "outstanding_label": { "en": "Outstanding", "es": "Pendiente" },
 "approval_history": { "en": "Approval", "es": "Aprobación" },
 "approval_required_because": { "en": "Approval needed because: {reason}", "es": "Requiere aprobación porque: {reason}" },
 "waiting": { "en": "waiting", "es": "en espera" },
 "approved_by": { "en": "Approved by", "es": "Aprobado por" },
 "rejected_by": { "en": "Rejected by", "es": "Rechazado por" },
 "cancel_request": { "en": "Cancel request", "es": "Cancelar solicitud" },
 "view_details": { "en": "View details", "es": "Ver detalles" },
 "lines_outstanding": { "en": "{n} lines still outstanding", "es": "{n} líneas aún pendientes" },
 "allocated_label": { "en": "Allocated", "es": "Asignado" },
 "reserved_label": { "en": "Reserved", "es": "Reservado" },
 "reserved_word": { "en": "reserved", "es": "reservado" },
 "requested_outstanding": { "en": "Requested {requested} · {outstanding} {unit} outstanding", "es": "Solicitado {requested} · {outstanding} {unit} pendientes" },
 "outstanding_qty": { "en": "Outstanding {qty} {unit}", "es": "Pendiente {qty} {unit}" },
 "not_yet_sourced": { "en": "not yet sourced", "es": "sin fuente aún" },
 "warehouse_prepares_reserved": { "en": "Warehouse prepares only what is reserved. The rest stays outstanding on the request.", "es": "El almacén prepara solo lo reservado. El resto queda pendiente en la solicitud." },
 "review_allocation": { "en": "Review allocation", "es": "Revisar asignación" },
 "warehouse_allocation": { "en": "Warehouse allocation", "es": "Asignación del almacén" },
 "allocation_line_summary": { "en": "Requested {requested} · Warehouse {allocated} · Outstanding {outstanding} {unit}", "es": "Solicitado {requested} · Almacén {allocated} · Pendiente {outstanding} {unit}" },
 "release": { "en": "Release", "es": "Liberar" },
 "allocate_available": { "en": "Allocate available stock", "es": "Asignar stock disponible" },
 "allocation_note": { "en": "Changes reserve or release stock in the ledger. An allocation can't exceed the request or the stock in that bin.", "es": "Los cambios reservan o liberan stock en el registro. Una asignación no puede exceder la solicitud ni el stock de ese lugar." },
 "toast_allocation_updated": { "en": "Allocation updated.", "es": "Asignación actualizada." },
 "toast_allocation_released": { "en": "Allocation released. The stock is available again.", "es": "Asignación liberada. El stock vuelve a estar disponible." },
 "nothing_available_to_allocate": { "en": "Nothing is available in this project's warehouse right now.", "es": "No hay nada disponible en el almacén de este proyecto ahora." },
 "save": { "en": "Save", "es": "Guardar" },
 "approvals_waiting_one": { "en": "1 request is waiting for your approval", "es": "1 solicitud espera tu aprobación" },
 "lines_outstanding_one": { "en": "1 line still outstanding", "es": "1 línea aún pendiente" },
 "batch_n_of_m": { "en": "Batch {n} of {m}", "es": "Lote {n} de {m}" },
 "batch_n": { "en": "Batch {n}", "es": "Lote {n}" },
 "warehouse_batch_n": { "en": "Warehouse batch {n}", "es": "Lote de almacén {n}" },
 "request_allocation": { "en": "Request allocation", "es": "Asignación de la solicitud" },
 "available_now": { "en": "Available now", "es": "Disponible ahora" },
 "nothing_allocated_yet": { "en": "Nothing allocated yet \u00b7 awaiting stock", "es": "Nada asignado aún · esperando stock" },
 "partially_allocated_note": { "en": "Partly allocated \u00b7 the rest is still outstanding", "es": "Asignado en parte · el resto sigue pendiente" },
 "fully_allocated_note": { "en": "Everything requested is allocated", "es": "Todo lo solicitado está asignado" },
 "awaiting_stock_note": { "en": "No stock available in this project's warehouse right now.", "es": "No hay stock disponible en el almacén de este proyecto ahora." },
 "needs_attention": { "en": "Outstanding requests", "es": "Solicitudes pendientes" },
 "needs_attention_sub": { "en": "Approved demand the warehouse still has to source.", "es": "Demanda aprobada que el almacén aún debe cubrir." },
 "needs_attention_none": { "en": "Nothing allocated yet \u00b7 {n} lines outstanding", "es": "Nada asignado aún · {n} líneas pendientes" },
 "needs_attention_partial": { "en": "Partly allocated \u00b7 {n} lines outstanding", "es": "Asignado en parte · {n} líneas pendientes" },
 "err_submission_conflict": { "en": "This request was already sent with different details. Review it and send again.", "es": "Esta solicitud ya se envió con otros detalles. Revísala y envíala de nuevo." },
 "err_batch_started": { "en": "Work already started on this batch. Use Allocate available stock to prepare more in a new batch.", "es": "Ya se empezó a trabajar en este lote. Usa Asignar stock disponible para preparar más en un lote nuevo." },
 "company_approver_home": { "en": "Approval requests that need you appear above.", "es": "Las solicitudes que necesitan tu aprobación aparecen arriba." },
 "needs_attention_none_one": { "en": "Nothing allocated yet \u00b7 1 line outstanding", "es": "Nada asignado aún · 1 línea pendiente" },
 "needs_attention_partial_one": { "en": "Partly allocated \u00b7 1 line outstanding", "es": "Asignado en parte · 1 línea pendiente" },
 "view_all_outstanding": { "en": "View all {n} outstanding requests", "es": "Ver las {n} solicitudes pendientes" },
 "qty_outstanding": { "en": "{qty} {unit} outstanding", "es": "{qty} {unit} pendientes" },
 "materials_need_sourcing": { "en": "{n} materials need sourcing", "es": "{n} materiales necesitan abastecimiento" },
 "nothing_allocated_short": { "en": "nothing allocated yet", "es": "nada asignado aún" },
 "partly_allocated_short": { "en": "partly allocated", "es": "asignado en parte" },
 "n_requests": { "en": "{n} requests", "es": "{n} solicitudes" },
 "n_requests_one": { "en": "1 request", "es": "1 solicitud" },
 "all_demand_allocated": { "en": "All warehouse demand is currently allocated.", "es": "Toda la demanda del almacén está asignada." },
 "all_demand_allocated_sub": { "en": "New outstanding requests will appear here.", "es": "Las nuevas solicitudes pendientes aparecerán aquí." },
 "back": { "en": "Back", "es": "Atrás" },
 "account_number": { "en": "Account number", "es": "Número de cuenta" },
 "account_short": { "en": "Acct.", "es": "Cta." },
 "add_quote": { "en": "Add quote", "es": "Agregar cotización" },
 "add_supplier": { "en": "Add supplier", "es": "Agregar proveedor" },
 "add_supplier_first": { "en": "Add a supplier under Suppliers first.", "es": "Primero agrega un proveedor en Proveedores." },
 "address_label": { "en": "Address", "es": "Dirección" },
 "available_quantity_quote": { "en": "Available quantity (optional)", "es": "Cantidad disponible (opcional)" },
 "backorder_qty": { "en": "Backordered", "es": "Pendiente" },
 "buyer": { "en": "Buyer", "es": "Comprador" },
 "cancel_draft": { "en": "Cancel draft", "es": "Cancelar borrador" },
 "cancel_remaining": { "en": "Cancel remaining", "es": "Cancelar lo pendiente" },
 "choose_supplier": { "en": "Supplier", "es": "Proveedor" },
 "combine_requirements": { "en": "Also buy on this line", "es": "Comprar también en esta línea" },
 "commitment_warning": { "en": "{qty} {unit} on {po} may no longer be required for {req}.", "es": "{qty} {unit} de {po} tal vez ya no se necesiten para {req}." },
 "company_label": { "en": "Company", "es": "Empresa" },
 "confirmed_expected_date": { "en": "Expected delivery (from supplier)", "es": "Entrega esperada (del proveedor)" },
 "confirmed_label": { "en": "Confirmed", "es": "Confirmada" },
 "contact_name": { "en": "Contact name", "es": "Nombre de contacto" },
 "create_draft_po": { "en": "Create draft PO", "es": "Crear borrador de OC" },
 "create_po": { "en": "Create purchase order", "es": "Crear orden de compra" },
 "created_label": { "en": "Created", "es": "Creada" },
 "deactivate_supplier": { "en": "Deactivate supplier", "es": "Desactivar proveedor" },
 "default_lead_time": { "en": "Default lead time (days)", "es": "Tiempo de entrega habitual (días)" },
 "draft_not_on_order_note": { "en": "A draft is internal. The field sees On Order only after you mark the PO as sent.", "es": "Un borrador es interno. El campo ve En pedido solo cuando marcas la OC como enviada." },
 "email_label": { "en": "Email", "es": "Correo" },
 "expected_delivery": { "en": "Expected delivery", "es": "Entrega esperada" },
 "expected_from_supplier": { "en": "Expected from supplier: {d} (to the warehouse, not the jobsite)", "es": "Esperado del proveedor: {d} (al almacén, no a la obra)" },
 "expected_on": { "en": "Expected {d}", "es": "Esperada {d}" },
 "for_stock": { "en": "For stock (not for a request)", "es": "Para inventario (no para una solicitud)" },
 "inactive": { "en": "Inactive", "es": "Inactivo" },
 "incoming_purchases": { "en": "Incoming purchases", "es": "Compras por recibir" },
 "lead_days": { "en": "{n} day lead time", "es": "Entrega en {n} días" },
 "lead_time_days": { "en": "Lead time (days)", "es": "Tiempo de entrega (días)" },
 "line_total_label": { "en": "Line total", "es": "Total de la línea" },
 "lines_label": { "en": "Lines", "es": "Líneas" },
 "log_out": { "en": "Log out", "es": "Cerrar sesión" },
 "mark_as_sent": { "en": "Mark as sent", "es": "Marcar como enviada" },
 "mark_backordered": { "en": "Save backorder", "es": "Guardar pendiente" },
 "mark_confirmed": { "en": "Mark as confirmed", "es": "Marcar como confirmada" },
 "mark_sent_note": { "en": "ANT does not email the supplier. Send the PO your usual way, then mark it sent here.", "es": "ANT no envía correos al proveedor. Envía la OC como siempre y márcala aquí como enviada." },
 "marked_sent": { "en": "Marked sent", "es": "Marcada enviada" },
 "n_to_receive": { "en": "{n} to receive", "es": "{n} por recibir" },
 "needs_sourcing_label": { "en": "Needs sourcing", "es": "Necesita abastecimiento" },
 "new_expected_date": { "en": "New expected date", "es": "Nueva fecha esperada" },
 "new_po_title": { "en": "New purchase order", "es": "Nueva orden de compra" },
 "no_contact_yet": { "en": "No contact details yet", "es": "Sin datos de contacto" },
 "no_external_sourcing": { "en": "No material currently needs external sourcing.", "es": "Ningún material necesita compra externa por ahora." },
 "no_matching_pos": { "en": "No purchase orders match this filter.", "es": "Ninguna orden de compra coincide con este filtro." },
 "no_matching_requirements": { "en": "No requirements match.", "es": "Ningún requerimiento coincide." },
 "no_matching_suppliers": { "en": "No suppliers match your search.", "es": "Ningún proveedor coincide con tu búsqueda." },
 "no_pos_yet": { "en": "No purchase orders yet.", "es": "Aún no hay órdenes de compra." },
 "no_quote_for_supplier": { "en": "No quote entered", "es": "Sin cotización" },
 "no_quotes_yet": { "en": "No supplier quotes entered yet.", "es": "Aún no hay cotizaciones de proveedores." },
 "no_suppliers_yet": { "en": "No suppliers added yet.", "es": "Aún no hay proveedores." },
 "notes_label": { "en": "Notes", "es": "Notas" },
 "on_order_label": { "en": "On order", "es": "En pedido" },
 "p_cancelled": { "en": "Cancelled", "es": "Cancelado" },
 "p_from_warehouse": { "en": "From the warehouse", "es": "Del almacén" },
 "p_in_draft": { "en": "In a draft PO", "es": "En un borrador de OC" },
 "p_linked_pos": { "en": "Purchase orders", "es": "Órdenes de compra" },
 "p_nav_pos": { "en": "POs", "es": "OC" },
 "p_nav_requirements": { "en": "Requirements", "es": "Requerim." },
 "p_nav_suppliers": { "en": "Suppliers", "es": "Proveedores" },
 "p_ordered": { "en": "Ordered", "es": "Pedido" },
 "p_received": { "en": "Received", "es": "Recibido" },
 "p_released": { "en": "No longer needed", "es": "Ya no se necesita" },
 "p_remaining": { "en": "Still expected", "es": "Aún por llegar" },
 "p_requested_on_request": { "en": "Requested", "es": "Solicitado" },
 "p_required_externally": { "en": "Needs buying", "es": "Por comprar" },
 "p_search_placeholder": { "en": "Search PR, ORD, project, material or PO", "es": "Buscar PR, ORD, proyecto, material u OC" },
 "p_ship_to": { "en": "Ship to", "es": "Enviar a" },
 "p_to_source": { "en": "Still to order", "es": "Falta pedir" },
 "packing_slip_no": { "en": "Packing slip # (optional)", "es": "N.º de remisión (opcional)" },
 "payment_terms": { "en": "Payment terms", "es": "Condiciones de pago" },
 "pf_all": { "en": "All", "es": "Todas" },
 "pf_in_draft": { "en": "In draft", "es": "En borrador" },
 "pf_on_order": { "en": "On order", "es": "En pedido" },
 "pf_to_source": { "en": "Needs sourcing", "es": "Por abastecer" },
 "phone_label": { "en": "Phone", "es": "Teléfono" },
 "po_qty_for": { "en": "Quantity for {req} ({unit})", "es": "Cantidad para {req} ({unit})" },
 "pos_backordered": { "en": "Backordered", "es": "Pedido pendiente" },
 "pos_cancelled": { "en": "Cancelled", "es": "Cancelada" },
 "pos_closed": { "en": "Closed", "es": "Cerrada" },
 "pos_confirmed": { "en": "Confirmed", "es": "Confirmada" },
 "pos_draft": { "en": "Draft", "es": "Borrador" },
 "pos_late": { "en": "Late", "es": "Atrasada" },
 "pos_partially_received": { "en": "Partially received", "es": "Recibido parcialmente" },
 "pos_received": { "en": "Received", "es": "Recibida" },
 "pos_sent": { "en": "Sent", "es": "Enviada" },
 "preferred": { "en": "Preferred", "es": "Preferido" },
 "preferred_note": { "en": "Preferred suppliers are listed first. ANT never orders from them automatically.", "es": "Los proveedores preferidos aparecen primero. ANT nunca les pide automáticamente." },
 "preferred_supplier": { "en": "Preferred supplier", "es": "Proveedor preferido" },
 "procurement_not_accounting": { "en": "Purchase amounts for procurement only (no accounting or project cost yet).", "es": "Montos de compra solo para abastecimiento (aún sin contabilidad ni costo del proyecto)." },
 "prs_cancelled": { "en": "No longer needed", "es": "Ya no se necesita" },
 "prs_closed": { "en": "Closed", "es": "Cerrado" },
 "prs_in_draft": { "en": "In draft", "es": "En borrador" },
 "prs_open": { "en": "Open", "es": "Abierto" },
 "prs_ordered": { "en": "Ordered", "es": "Pedido" },
 "prs_partially_ordered": { "en": "Partly ordered", "es": "Pedido en parte" },
 "prs_partially_received": { "en": "Partially received", "es": "Recibido parcialmente" },
 "prs_received": { "en": "Received", "es": "Recibido" },
 "prs_sourcing": { "en": "Sourcing", "es": "Cotizando" },
 "pt_awaiting_confirmation": { "en": "Awaiting confirmation", "es": "Esperan confirmación" },
 "pt_backorders": { "en": "Backorders", "es": "Pendientes del proveedor" },
 "pt_emergency": { "en": "Emergency", "es": "Emergencia" },
 "pt_needs_sourcing": { "en": "Need sourcing", "es": "Por abastecer" },
 "pt_overdue": { "en": "Overdue POs", "es": "OC atrasadas" },
 "pt_unsent_drafts": { "en": "Unsent drafts", "es": "Borradores sin enviar" },
 "purchase_orders": { "en": "Purchase Orders", "es": "Órdenes de compra" },
 "purchase_requirements": { "en": "Purchase Requirements", "es": "Requerimientos de compra" },
 "purchasing_area": { "en": "Purchasing", "es": "Compras" },
 "put_away_location": { "en": "Put away at", "es": "Guardar en" },
 "qty_available_quote": { "en": "{qty} available", "es": "{qty} disponibles" },
 "qty_backordered": { "en": "{qty} backordered", "es": "{qty} pendientes" },
 "qty_damaged": { "en": "{qty} damaged", "es": "{qty} dañados" },
 "qty_needs_sourcing": { "en": "{qty} {unit} needed", "es": "{qty} {unit} por abastecer" },
 "qty_on_order": { "en": "{qty} {unit} on order", "es": "{qty} {unit} en pedido" },
 "quote_label": { "en": "Quote", "es": "Cotización" },
 "quote_number": { "en": "Quote # (optional)", "es": "N.º de cotización (opcional)" },
 "quotes_manual_note": { "en": "Quotes are entered by hand. ANT has no live supplier prices or stock.", "es": "Las cotizaciones se ingresan a mano. ANT no tiene precios ni existencias en vivo de proveedores." },
 "reactivate_supplier": { "en": "Reactivate supplier", "es": "Reactivar proveedor" },
 "receipts_label": { "en": "Receipts", "es": "Recepciones" },
 "receive_materials": { "en": "Receive materials", "es": "Recibir materiales" },
 "receive_note": { "en": "Good material goes into stock and to the request it was bought for. Damaged material is recorded separately.", "es": "El material en buen estado entra al inventario y a la solicitud para la que se compró. El dañado se registra aparte." },
 "receive_po_title": { "en": "Receive {po}", "es": "Recibir {po}" },
 "received_damaged": { "en": "Damaged", "es": "Dañado" },
 "received_good": { "en": "Received good", "es": "Recibido bien" },
 "receiving_issue_banner": { "en": "{po} has a receiving issue to review.", "es": "{po} tiene un problema de recepción por revisar." },
 "recent_pos": { "en": "Recent purchase orders", "es": "Órdenes de compra recientes" },
 "release_backorder": { "en": "Release for another supplier", "es": "Liberar para otro proveedor" },
 "rest_on_order": { "en": "Rest is on order", "es": "El resto está en pedido" },
 "save_draft": { "en": "Save draft", "es": "Guardar borrador" },
 "save_quote": { "en": "Save quote", "es": "Guardar cotización" },
 "save_supplier": { "en": "Save supplier", "es": "Guardar proveedor" },
 "shipping": { "en": "Shipping", "es": "Envío" },
 "still_expected": { "en": "{qty} {unit} still expected", "es": "Aún se esperan {qty} {unit}" },
 "stock_overage_label": { "en": "Extra for stock (optional)", "es": "Extra para inventario (opcional)" },
 "stock_overage_note": { "en": "Extra units go to warehouse stock, never to a project.", "es": "Las unidades extra van al inventario, nunca a un proyecto." },
 "subtotal": { "en": "Subtotal", "es": "Subtotal" },
 "supplier_confirmation_no": { "en": "Supplier confirmation # (optional)", "es": "N.º de confirmación del proveedor (opcional)" },
 "supplier_name": { "en": "Supplier name", "es": "Nombre del proveedor" },
 "supplier_options": { "en": "Supplier options", "es": "Opciones de proveedores" },
 "supplier_search_placeholder": { "en": "Search name, contact, account, phone or email", "es": "Buscar nombre, contacto, cuenta, teléfono o correo" },
 "suppliers_sub": { "en": "Your company's supplier records", "es": "Los proveedores de tu empresa" },
 "suppliers_title": { "en": "Suppliers", "es": "Proveedores" },
 "tax": { "en": "Tax", "es": "Impuesto" },
 "toast_backorder_released": { "en": "Backorder released. The requirement is open again.", "es": "Pendiente liberado. El requerimiento está abierto otra vez." },
 "toast_backorder_saved": { "en": "Backorder saved.", "es": "Pendiente guardado." },
 "toast_covered_from_stock": { "en": "Covered from warehouse stock. Purchasing will review the order.", "es": "Cubierto con inventario del almacén. Compras revisará el pedido." },
 "toast_draft_saved": { "en": "Draft saved.", "es": "Borrador guardado." },
 "toast_issue_reported": { "en": "Receiving issue reported.", "es": "Problema de recepción reportado." },
 "toast_po_cancelled": { "en": "Purchase order updated.", "es": "Orden de compra actualizada." },
 "toast_po_confirmed": { "en": "Marked as confirmed.", "es": "Marcada como confirmada." },
 "toast_po_draft_created": { "en": "Draft purchase order created.", "es": "Borrador de orden de compra creado." },
 "toast_po_sent": { "en": "Marked as sent. The material is now on order.", "es": "Marcada como enviada. El material ya está en pedido." },
 "toast_quote_added": { "en": "Quote added.", "es": "Cotización agregada." },
 "toast_received": { "en": "Received. Material is in stock and linked to its request.", "es": "Recibido. El material está en inventario y ligado a su solicitud." },
 "toast_supplier_added": { "en": "Supplier added.", "es": "Proveedor agregado." },
 "toast_supplier_deactivated": { "en": "Supplier deactivated.", "es": "Proveedor desactivado." },
 "toast_supplier_reactivated": { "en": "Supplier reactivated.", "es": "Proveedor reactivado." },
 "toast_supplier_saved": { "en": "Supplier saved.", "es": "Proveedor guardado." },
 "total": { "en": "Total", "es": "Total" },
 "unit_price_per": { "en": "Unit price (per {unit})", "es": "Precio unitario (por {unit})" },
 "use_stock_instead": { "en": "Use warehouse stock instead", "es": "Usar inventario del almacén" },
 "use_stock_instead_note": { "en": "The supplier order stays as it is. Purchasing is asked to review it; what arrives goes to stock.", "es": "El pedido al proveedor no cambia. Compras lo revisará; lo que llegue irá al inventario." },
 "valid_until": { "en": "valid until {d}", "es": "válida hasta {d}" },
 "valid_until_label": { "en": "Valid until (optional)", "es": "Válida hasta (opcional)" },
 "website": { "en": "Website", "es": "Sitio web" },
 "what_arrived_instead": { "en": "What arrived instead?", "es": "¿Qué llegó en su lugar?" },
 "work_area": { "en": "Work area", "es": "Área de trabajo" },
 "wrong_material": { "en": "wrong material", "es": "material equivocado" },
 "wrong_material_arrived": { "en": "Wrong material arrived", "es": "Llegó material equivocado" },
 "n_lines": { "en": "{n} lines", "es": "{n} líneas" },
 "n_lines_one": { "en": "1 line", "es": "1 línea" },
 "n_pos": { "en": "{n} purchase orders", "es": "{n} órdenes de compra" },
 "n_pos_one": { "en": "1 purchase order", "es": "1 orden de compra" },
 "p_needs_attention": { "en": "Needs attention", "es": "Requiere atención" }
};
