import { createRoot } from 'react-dom/client';
import './styles.css';
import App from './App.jsx';
import { loadAppData } from './lib/db.js';

loadAppData();  // restore saved data (migrating older versions), or seed the demo data on first run
createRoot(document.getElementById('root')).render(<App />);

// Developer utilities (whoami, integrity, audit) exist only in development builds.
if (import.meta.env && import.meta.env.DEV) import('./dev/devtools.js').then((m) => m.installDevTools());
