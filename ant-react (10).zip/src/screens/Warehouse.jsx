import { ui } from '../lib/store.js';
import { t, tf, greeting } from '../lib/i18n.js';
import { SUPPLIERS } from '../data/seed.js';
import { canPickMaterials, canDispatchOrder, canModifyInventory, canSourceMaterials, canUser } from '../lib/permissions.js';
import { CAP } from '../config/capabilities.js';
import * as Inv from '../services/inventoryService.js';
import { getLocation } from '../services/locationService.js';
import { getMovementsForVariant, getMovementsForRequest } from '../services/materialLedgerService.js';
import { describeMovement, movementContext } from '../lib/ledgerText.js';
import { ADJUSTMENT_REASONS } from '../config/ledger.js';
import { prefs, db } from '../lib/db.js';
import { requestsForCompany, requestProjectName, requesterName, requesterPhone, displayProductFor } from '../services/requestService.js';
import { getRequestFor } from '../services/selectors.js';
import { warehouseOrdersForCompany, warehouseTaskFor, requestIdForTask, stageOf, stageOfFulfillment, warehouseFulfillmentsFor, fulfillmentById } from '../services/fulfillmentService.js';
import { getUnresolvedRequestItems, outstandingRequestsFor, OUTSTANDING_PREVIEW_COUNT, getAllocatedQuantity, getSupplierOrderedQuantity, getOutstandingQuantity, activeAllocationsForItem, allocationState } from '../services/requestProgress.js';
import { availableForProject } from '../services/allocationService.js';
import { stockVariantFor } from '../services/inventoryService.js';
import { getProject } from '../services/repo.js';
import { isResolved } from '../services/warehouseService.js';
import { getCompany, isFeatureEnabled } from '../services/companyService.js';
import { userRoleLabel, homeScreenFor } from '../services/userService.js';
import { PRIORITY_ORDER, priorityLabel, priorityCss, byPriorityThenNewest } from '../config/priorities.js';
import { WORKFLOW, ORDER_STAGE_KEYS, inWorkflowGroup, workflowLabel, workflowPillClass, workflowStageIndex } from '../config/statuses.js';
import { getProduct, catLabel, familyById } from '../lib/catalog.js';
import { availableQty, isLowStock, lowStockProducts, shortageLines, splitLocation, stockedProductIds, pickPlanFor, stockKey } from '../lib/inventory.js';
import { orderProgress, fmtNeeded, relTime, money } from '../lib/orders.js';
import { initials } from '../lib/validation.js';
import { Icon, ProductImage, Sheet, Empty, Preferences } from '../components/common.jsx';
import * as PU from '../lib/actionsPurchasing.js';
import { getIncomingPurchaseOrders, isPurchaseOrderLate, poRemaining, poById, lineProgress } from '../services/purchaseOrderService.js';
import { receivingLocations } from '../services/purchaseReceivingService.js';
import * as A from '../lib/actions.js';
import * as W from '../lib/actionsWarehouse.js';

// A warehouse only ever sees its own company's requests.
// Orders = warehouse fulfillments (v5) + legacy orders, read through views (services/fulfillmentService.js).
const companyOrders = (u) => warehouseOrdersForCompany(u.companyId);
// A warehouse task by id: a batch (fulfillment id) or a request id (its default batch).
const orderView = (u, id) => { const r = getRequestFor(u, requestIdForTask(id)); return r ? warehouseTaskFor(r, id) : null; };
// Workers see the request number they know; a later batch is labeled, never a new request.
const taskTitle = (o) => o.requestNumber + (o.batchCount > 1 ? ' \u00b7 ' + tf('batch_n_of_m', { n: o.batchNumber, m: o.batchCount }) : '');
// What a line can be picked from: v5 = its OWN reservation (allocation bins); legacy = AVAILABLE stock.
const codeOf = (name) => String(name || '\u2014').split(' ').pop();
function linePick(o, it) {
  if (!o.legacy && it.allocations) {
    const parts = it.allocations.filter((a) => a.reserved > 0).map((a) => ({ locationId: a.locationId, name: a.name, quantity: a.reserved }));
    return { v5: true, avail: it.reservedQuantity || 0, plan: { parts }, code: parts[0] ? codeOf(parts[0].name) : '\u2014', bin: parts[0] ? parts[0].name : '' };
  }
  return { v5: false, avail: availableQty(it.productVariantId), plan: pickPlanFor(it), code: splitLocation(it.productVariantId).code };
}
function BinBlock({ name }) {
  if (!name) return null;
  const parts = name.split(' '), code = parts.pop();
  return <div className="loc-block"><div><div className="loc-label">{t('location')}</div><div className="loc-value">{code}</div></div>{parts.length ? <div className="loc-area">{parts.join(' ')}</div> : null}</div>;
}
function OutstandingNote({ it }) {
  if (!it.outstandingQuantity) return null;
  return <span className="tiny" style={{ display: 'block', color: 'var(--warning)', fontWeight: 700 }}>{tf('requested_outstanding', { requested: it.requestedQuantity, outstanding: it.outstandingQuantity, unit: it.unit })}</span>;
}
const ordersToPack = (u) => companyOrders(u).filter((o) => inWorkflowGroup('OPEN_FOR_PACKING', o.workflowStatus)).sort(byPriorityThenNewest);
const plural = (n, w) => n + ' ' + w + (n === 1 ? '' : 's');

export function WarehouseNav({ active }) {
  const u = ui.currentUser;
  const items = homeScreenFor(u) === 'whHome'
    ? [['home', t('home'), 'home', 'whHome'], ['packing', t('packing'), 'box', 'whPacking'], ['inventory', t('inventory'), 'store', 'mInventory'], ['profile', t('profile'), 'profile', 'mProfile']]
    : [['home', t('home'), 'home', 'mHome'], ['orders', t('orders'), 'orders', 'mOrders'], ['inventory', t('inventory'), 'store', 'mInventory'], ['profile', t('profile'), 'profile', 'mProfile']];
  return (
    <div className="bottomnav">
      {items.map(([k, label, icon, go]) => (
        <button key={k} className={'navitem' + (active === k ? ' active' : '')} onClick={() => W.mNavTo(k, go)}><Icon name={icon} /><span>{label}</span></button>
      ))}
    </div>
  );
}

// Always paired with the text label, never color alone.
export function OrderTimeline({ status }) {
  const current = workflowStageIndex(status);
  return (
    <div className="order-timeline">
      {ORDER_STAGE_KEYS.map((key, i) => (
        <div key={key} className={'ot-step ' + (i < current ? 'done' : i === current ? 'current' : '')}>
          <span className="ot-dot">{i < current ? <Icon name="check" /> : null}</span><span className="ot-label">{t(key)}</span>
        </div>
      ))}
    </div>
  );
}

function ShortNote({ prog, word }) {
  return (
    <span className={'tiny' + (prog.shorted > 0 ? '' : ' muted')} style={prog.shorted > 0 ? { color: 'var(--warning)', fontWeight: 700 } : undefined}>
      {prog.done}/{prog.total}{prog.shorted > 0 ? ' processed (' + prog.shorted + ' short)' : ' ' + (word || 'collected')}
    </span>
  );
}

export function ManagerOrderCard({ o }) {
  const prog = orderProgress(o);
  return (
    <button className="order-card" onClick={() => W.openOrder(o.id)}>
      <div className={'stripe stripe-' + priorityCss(o.priority)} />
      <div className="ocbody">
        <div className="ocrow1"><div className="ocneeded">Needed {fmtNeeded(o.neededBy)}</div><span className={'badge badge-' + priorityCss(o.priority)}>{priorityLabel(o.priority)}</span></div>
        <div className="ocproj">{requestProjectName(o)}</div>
        <div className="ocmeta2"><span>{requesterName(o)}</span><span>·</span><span>{plural(prog.total, 'material')}</span>{o.batchCount > 1 ? <><span>·</span><span>{o.requestNumber} {tf('batch_n_of_m', { n: o.batchNumber, m: o.batchCount })}</span></> : null}</div>
        <div className="ocfooter">
          <span className={'status-pill' + workflowPillClass(o.workflowStatus)}>{workflowLabel(o.workflowStatus)}</span>
          {(prog.done > 0 && prog.done < prog.total) || prog.shorted > 0 ? <ShortNote prog={prog} /> : null}
          <span className="octime">Created {relTime(o.createdAt)}</span>
        </div>
      </div>
    </button>
  );
}

function PackCard({ o }) {
  const prog = orderProgress(o);
  return (
    <div className="info-card" style={{ marginBottom: 12 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div><div style={{ fontWeight: 700, fontSize: 16, color: 'var(--ink)' }}>{requestProjectName(o)}</div><div className="tiny muted">{plural(o.items.length, 'material')}{o.batchCount > 1 ? ' \u00b7 ' + taskTitle(o) : ''}</div></div>
        <span className={'badge badge-' + priorityCss(o.priority)}>{priorityLabel(o.priority)}</span>
      </div>
      <div className={'tiny' + (prog.shorted > 0 ? '' : ' muted')} style={{ marginTop: 6, ...(prog.shorted > 0 ? { color: 'var(--warning)', fontWeight: 700 } : {}) }}>
        Needed {fmtNeeded(o.neededBy)} · {prog.done}/{prog.total}{prog.shorted > 0 ? ' processed (' + prog.shorted + ' short)' : ' packed'}
      </div>
      <button className="btn btn-primary btn-sm" style={{ width: '100%', marginTop: 10 }} onClick={() => W.startPackingMode(o.id)}>Start packing</button>
    </div>
  );
}

const Greeting = () => (
  <div className="app-header"><div><div className="brand-tag">ANT</div><div className="h1" style={{ marginBottom: 0 }}>{greeting()}, {ui.currentUser.name.split(' ')[0]}</div></div></div>
);
const StatLink = ({ value, label, onClick }) => (
  <button className="info-card" style={{ textAlign: 'center', padding: '16px 8px' }} onClick={onClick}>
    <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--ink)' }}>{value}</div><div className="tiny muted" style={{ marginTop: 2 }}>{label}</div>
  </button>
);

export function ManagerHome() {
  const active = companyOrders(ui.currentUser).filter((o) => o.workflowStatus !== WORKFLOW.COMPLETED);
  const emergency = active.filter((o) => o.priority === 'EMERGENCY');
  const high = active.filter((o) => o.priority === 'HIGH');
  const incoming = active.filter((o) => o.workflowStatus === WORKFLOW.PENDING).sort(byPriorityThenNewest);
  const inProgress = active.filter((o) => inWorkflowGroup('PACKING_IN_PROGRESS', o.workflowStatus));
  const ready = active.filter((o) => o.workflowStatus === WORKFLOW.READY_TO_SHIP);
  // legacy short lines + v5 outstanding demand: both still need a source
  const needSourcing = new Set(shortageLines().map((s) => s.item.productVariantId).concat(getUnresolvedRequestItems(ui.currentUser.companyId).map((x) => x.productVariantId))).size;
  return (
    <>
      <Greeting />
      <div className="content"><div className="section-pad">
        {emergency.length + high.length > 0 ? (
          <>
            <div className="h2" style={{ marginBottom: 10 }}>Needs attention</div>
            {emergency.length ? <div className="alert-banner" style={{ background: 'var(--emergency-bg)', color: 'var(--emergency)' }}><Icon name="alert" /><span>{plural(emergency.length, 'emergency request')}</span></div> : null}
            {high.length ? <div className="alert-banner" style={{ background: 'var(--high-bg)', color: 'var(--high)' }}><Icon name="alert" /><span>{plural(high.length, 'high priority request')}</span></div> : null}
          </>
        ) : null}
        <NeedsAttention />
        <IncomingPurchases />
        <div className="h2" style={{ margin: '18px 0 10px' }}>Incoming requests</div>
        {incoming.length ? incoming.slice(0, 4).map((o) => <ManagerOrderCard key={o.id} o={o} />) : <div className="empty" style={{ padding: '20px 0' }}><div className="etitle">Nothing incoming</div></div>}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 6 }}>
          <StatLink value={inProgress.length} label="Packing in progress" onClick={() => W.mNavTo('orders', 'mOrders')} />
          <StatLink value={ready.length} label="Ready to ship" onClick={() => W.mNavTo('orders', 'mOrders')} />
          <StatLink value={lowStockProducts().length} label="Low stock items" onClick={() => W.mNavTo('inventory', 'mInventory')} />
          <StatLink value={needSourcing} label="Need sourcing" onClick={() => W.mNavTo('inventory', 'mInventory')} />
        </div>
      </div></div>
      <WarehouseNav active="home" />
    </>
  );
}

export function WorkerHome() {
  const toPack = ordersToPack(ui.currentUser);
  return (
    <>
      <Greeting />
      <div className="content"><div className="section-pad">
        <div className="h2" style={{ marginBottom: 10 }}>Orders to pack</div>
        {toPack.length ? toPack.slice(0, 5).map((o) => <PackCard key={o.id} o={o} />) : (
          <div className="empty" style={{ padding: '24px 0' }}><div className="etitle">No orders to pack</div><div>New packing assignments will appear here.</div></div>
        )}
        <div className="divider" />
        <div className="h2" style={{ marginBottom: 10 }}>Warehouse inventory</div>
        <button className="btn btn-secondary" onClick={() => W.mNavTo('inventory', 'mInventory')}><Icon name="search" /> Search inventory</button>
      </div></div>
      <WarehouseNav active="home" />
    </>
  );
}

// Filter chip label -> which workflow statuses it shows.
const STATUS_FILTERS = {
  All: null, New: [WORKFLOW.PENDING], 'In Progress': [WORKFLOW.IN_PROGRESS, WORKFLOW.PARTIALLY_PACKED],
  Packed: [WORKFLOW.PACKED], 'Ready to Ship': [WORKFLOW.READY_TO_SHIP], Completed: [WORKFLOW.SHIPPED, WORKFLOW.COMPLETED],
};
const PRIORITY_FILTERS = ['All'].concat(PRIORITY_ORDER);
const priorityFilterLabel = (v) => (v === 'All' ? 'All' : priorityLabel(v));
function matchesStatus(o, f) { const set = STATUS_FILTERS[f]; return !set || set.indexOf(o.workflowStatus) !== -1; }
export function ManagerOrders() {
  const list = companyOrders(ui.currentUser)
    .filter((o) => matchesStatus(o, ui.mStatusFilter) && (ui.mPriorityFilter === 'All' || o.priority === ui.mPriorityFilter))
    .sort(byPriorityThenNewest);
  return (
    <>
      <div className="app-header"><div><div className="brand-tag">ANT</div><div className="htitle">Orders</div><div className="hsub">{plural(list.length, 'order')} shown</div></div></div>
      <div className="content">
        <div className="tab-row" style={{ marginTop: 14 }}>
          {Object.keys(STATUS_FILTERS).map((s) => <button key={s} className={'chip' + (ui.mStatusFilter === s ? ' on' : '')} onClick={() => W.setStatusFilter(s)}>{s}</button>)}
        </div>
        <div className="tab-row" style={{ marginTop: 8, marginBottom: 6 }}>
          {PRIORITY_FILTERS.map((s) => <button key={s} className={'chip' + (ui.mPriorityFilter === s ? ' on' : '')} onClick={() => W.setPriorityFilter(s)}>{priorityFilterLabel(s)}</button>)}
        </div>
        <div style={{ height: 12 }} />
        {list.length ? list.map((o) => <ManagerOrderCard key={o.id} o={o} />) : (
          <Empty icon="orders" title="No orders match these filters">
            <div>Try a different status or priority.</div>
            <button className="btn btn-secondary btn-sm" onClick={W.clearOrderFilters}>Clear filters</button>
          </Empty>
        )}
        <div style={{ height: 12 }} />
      </div>
      <WarehouseNav active="orders" />
    </>
  );
}

export function WarehousePacking() {
  const toPack = ordersToPack(ui.currentUser);
  return (
    <>
      <div className="app-header"><div className="htitle">Packing</div><div className="hsub">{plural(toPack.length, 'order')} to pack</div></div>
      <div className="content">
        <div style={{ height: 12 }} />
        {toPack.length ? toPack.map((o) => <PackCard key={o.id} o={o} />) : <Empty title="No orders to pack"><div>New packing assignments will appear here.</div></Empty>}
      </div>
      <WarehouseNav active="packing" />
    </>
  );
}

export function PackingMode() {
  const o = orderView(ui.currentUser, ui.packingOrderId);
  if (!o) return <WorkerHome />;
  const items = o.items;
  const doneCount = items.filter(isResolved).length;
  if (doneCount >= items.length) {
    return (
      <div className="content no-nav" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', padding: 40, textAlign: 'center' }}>
        <div className="checkbox on" style={{ width: 56, height: 56, borderRadius: '50%', marginBottom: 18 }}><Icon name="check" /></div>
        <div className="h1">{t('packing_complete')}</div>
        <div className="muted" style={{ marginBottom: 26 }}>{taskTitle(o)} · {items.length} of {items.length} materials packed</div>
        <button className="btn btn-primary" style={{ maxWidth: 280 }} onClick={W.exitPackingMode}>{t('done')}</button>
      </div>
    );
  }
  let idx = ui.packingIndex;
  if (idx < 0 || idx >= items.length || isResolved(items[idx])) { idx = W.firstUnresolvedIndex(o); ui.packingIndex = idx; }
  const it = items[idx];
  const p = displayProductFor(it);
  const lp = linePick(o, it);
  const avail = lp.avail;
  const need = it.quantity - (it.pickedQuantity || 0);
  const enough = avail >= need;
  const loc = { code: lp.code };
  const plan = lp.plan;
  const pct = Math.round((doneCount / items.length) * 100);
  return (
    <>
      <div className="app-header">
        <button className="icon-btn" onClick={W.exitPackingMode} aria-label="Exit packing"><Icon name="close" /></button>
        <div><div className="htitle" style={{ fontSize: 18 }}>{taskTitle(o)}</div><div className="hsub">{requestProjectName(o)} · Needed {fmtNeeded(o.neededBy)}</div></div>
      </div>
      <div className="content no-nav"><div className="section-pad">
        <div className="pm-progress"><span>{t('packing')}</span><span>{doneCount + 1} of {items.length}</span></div>
        <div className="progress-bar" style={{ marginBottom: 24 }}><div className={'progress-fill' + (pct === 100 ? ' complete' : '')} style={{ width: pct + '%' }} /></div>
        <div className="detail-photo" style={{ height: 210, marginLeft: 0, marginRight: 0 }}><ProductImage p={p} large key={p.id} /></div>
        <div className="h1" style={{ textAlign: 'center', marginTop: 16, marginBottom: 2 }}>{p.name}</div>
        {p.size ? <div className="pm-size">{p.size}</div> : null}
        <div className="pm-stats">
          <div className="pm-stat"><div className="pm-stat-label">{lp.v5 ? t('allocated_label') : t('need')}</div><div className="pm-stat-value">{need} {it.unit}</div></div>
          <div className="pm-stat"><div className="pm-stat-label">{t('location')}</div><div className="pm-stat-value">{loc.code}</div></div>
          <div className="pm-stat"><div className="pm-stat-label">{lp.v5 ? t('reserved_label') : t('available')}</div><div className="pm-stat-value" style={{ color: enough ? 'var(--good)' : 'var(--warning)' }}>{avail} {p.unit}</div></div>
        </div>
        {lp.v5 && it.outstandingQuantity > 0 ? <div className="tiny muted" style={{ textAlign: 'center', marginTop: 8 }}>{tf('requested_outstanding', { requested: it.requestedQuantity, outstanding: it.outstandingQuantity, unit: it.unit })}</div> : null}
        <PickBins plan={plan} unit={it.unit} />
        {enough
          ? <button className="btn btn-primary" style={{ marginTop: 22 }} onClick={W.packCurrentFull}><Icon name="check" /> {lp.v5 ? t('pick_verb') : t('pack')} {need} {it.unit}</button>
          : <>
              <div className="alert-banner" style={{ background: 'var(--warning-bg)', color: 'var(--warning)', marginTop: 22 }}><Icon name="alert" /><span>Only {avail} {it.unit} available — not enough to pack {need}.</span></div>
              <button className="btn btn-secondary" onClick={W.packCurrentShort}>{t('mark_short')}</button>
            </>}
        <div style={{ display: 'flex', justifyContent: 'center', gap: 18, marginTop: 16 }}>
          <button className="btn-ghost" onClick={W.packingSkip}>{t('skip_for_now')}</button>
          <button className="btn-ghost" onClick={W.viewFullListFromPacking}>{t('view_full_list')}</button>
        </div>
      </div></div>
    </>
  );
}

function LocationBlock({ productId }) {
  const loc = splitLocation(productId);
  return (
    <div className="loc-block">
      <div><div className="loc-label">Location</div><div className="loc-value">{loc.code}</div></div>
      {loc.area ? <div className="loc-area">{loc.area}</div> : null}
    </div>
  );
}

function InventoryRow({ p, canEdit }) {
  const qty = availableQty(p.id);
  const low = isLowStock(p.id);
  const open = canEdit ? () => W.openInventoryDetail(stockKey(p.id)) : undefined;
  return (
    <div className="info-card" style={{ marginBottom: 10, cursor: canEdit ? 'pointer' : 'default' }} onClick={open}
      role={canEdit ? 'button' : undefined} tabIndex={canEdit ? 0 : undefined} aria-label={canEdit ? p.name + ' ' + (p.size || '') : undefined}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
        <div className="thumb check-thumb" style={{ borderRadius: 8 }}><ProductImage p={p} key={p.id} /></div>
        <div style={{ flex: 1, minWidth: 0 }}><div style={{ fontWeight: 700, color: 'var(--ink)' }}>{p.name}</div><div className="tiny muted" style={{ marginTop: 2 }}>{p.size || ''}</div></div>
        <span className="badge" style={{ flexShrink: 0, ...(low ? { background: 'var(--warning-bg)', color: 'var(--warning)' } : { background: 'var(--good-bg)', color: 'var(--good)' }) }}>{qty} {p.unit}</span>
      </div>
      <LocationBlock productId={p.id} />
      {low ? <div className="tiny" style={{ color: 'var(--warning)', fontWeight: 700, marginTop: 8 }}><Icon name="alert" /> {t('low_stock')}</div> : null}
    </div>
  );
}

export function Inventory() {
  const canEdit = canModifyInventory(ui.currentUser);
  const q = ui.invSearch.trim().toLowerCase();
  // Pool = every stock record. Stock is variant-level, so legacy ids no longer appear separately.
  const pool = stockedProductIds().map(getProduct).filter(Boolean);
  // Word-by-word match that also uses the family's trade aliases ("EMT connector" finds "EMT Set-Screw Connector").
  const words = q.split(/\s+/).filter(Boolean);
  const list = q ? pool.filter((p) => {
    const fam = p.familyId ? familyById(p.familyId) : null;
    const text = (p.name + ' ' + (p.size || '') + ' ' + catLabel(p.cat) + ' ' + (p.displayName || '') + ' ' + (fam ? fam.aliases.join(' ') : '')).toLowerCase();
    return words.every((w) => text.indexOf(w) !== -1);
  }) : null;
  const shortages = shortageLines();
  const outstanding = getUnresolvedRequestItems(ui.currentUser.companyId);   // v5 demand with no source yet
  const lowStock = lowStockProducts();
  return (
    <>
      <div className="app-header" style={{ flexDirection: 'column', alignItems: 'stretch', gap: 14 }}>
        <div><div className="htitle">Inventory</div><div className="hsub">Warehouse stock on hand</div></div>
        <div className="searchbar"><Icon name="search" />
          <input type="text" id="inv-search-input" placeholder="Search inventory" value={ui.invSearch} onChange={(e) => W.invSearch(e.target.value)} aria-label="Search inventory" /></div>
      </div>
      <div className="content" id="inv-body"><div className="section-pad">
        {list ? (
          <>
            <div className="h2" style={{ marginBottom: 10 }}>{plural(list.length, 'result')}</div>
            {list.length ? list.map((p) => <InventoryRow key={p.id} p={p} canEdit={canEdit} />)
              : <Empty title="No inventory items found"><div>Try another name, size, or part number.</div></Empty>}
          </>
        ) : canEdit ? (
          <>
            <div className="h2" style={{ marginBottom: 10 }}>Restock</div>
            {shortages.map((s, i) => {
              const p = displayProductFor(s.item);
              return (
                <div className="info-card" style={{ marginBottom: 10 }} key={s.order.id + i}>
                  <div style={{ fontWeight: 700 }}>{p.name}</div>
                  <div className="tiny muted" style={{ marginTop: 2 }}><b style={{ color: 'var(--warning)' }}>Short {s.item.shortQuantity} {s.item.unit}</b> · {s.order.id} ({requestProjectName(s.order)})</div>
                </div>
              );
            })}
            {outstanding.map((x) => {
              const p = displayProductFor(x.item);
              return (
                <button className="info-card" style={{ marginBottom: 10, width: '100%', textAlign: 'left' }} key={x.item.id} onClick={() => W.openAllocation(x.request.id)}>
                  <div style={{ fontWeight: 700 }}>{p.name}</div>
                  <div className="tiny muted" style={{ marginTop: 2 }}><b style={{ color: 'var(--warning)' }}>{tf('outstanding_qty', { qty: x.outstanding, unit: x.item.unit })}</b> · {x.request.id} ({requestProjectName(x.request)}) · {t('not_yet_sourced')}</div>
                </button>
              );
            })}
            {lowStock.length ? <><div className="h2" style={{ margin: '18px 0 10px' }}>Low stock</div>{lowStock.map((p) => <InventoryRow key={p.id} p={p} canEdit />)}</> : null}
            {!shortages.length && !outstanding.length && !lowStock.length ? <div className="empty" style={{ padding: '20px 0' }}><div className="etitle">Nothing needs restocking</div></div> : null}
            <button className="btn btn-secondary" style={{ marginTop: 12 }} onClick={() => A.goto('mSuppliers')}><Icon name="store" /> Browse suppliers</button>
          </>
        ) : <div className="tiny muted">Search above to find where a material is and how much is available.</div>}
      </div></div>
      <WarehouseNav active="inventory" />
    </>
  );
}

const SupplierHead = ({ s }) => (
  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
    <div><div style={{ fontWeight: 800, fontSize: 15 }}>{s.name}</div><div className="tiny muted">{s.distance} miles · {s.address}</div></div>
    <Icon name="store" />
  </div>
);
export function Suppliers() {
  return (
    <>
      <div className="app-header">
        <button className="icon-btn" onClick={() => A.goto('mInventory')} aria-label="Back"><Icon name="back" /></button>
        <div><div className="htitle">Supplier lookup</div><div className="hsub">Illustrative only · not your supplier records</div></div>
      </div>
      <div className="content no-nav">
        <div style={{ height: 14 }} />
        {SUPPLIERS.map((s) => <div className="supplier-card" key={s.name}><SupplierHead s={s} /><div className="srow"><span>Phone</span><b>{s.phone}</b></div></div>)}
        <div className="section-pad"><div className="tiny muted">Open an order and tap "Find suppliers" to compare estimated availability and pricing for that order's materials.</div></div>
      </div>
    </>
  );
}

export function History() {
  const done = companyOrders(ui.currentUser).filter((o) => inWorkflowGroup('CLOSED_FOR_FIELD', o.workflowStatus)).sort((a, b) => b.createdAt - a.createdAt);
  return (
    <>
      <div className="app-header">
        <button className="icon-btn" onClick={() => A.goto('mOrders')} aria-label="Back"><Icon name="back" /></button>
        <div><div className="htitle">History</div><div className="hsub">{plural(done.length, 'completed order')}</div></div>
      </div>
      <div className="content no-nav">
        <div style={{ height: 12 }} />
        {done.length ? done.map((o) => <ManagerOrderCard key={o.id} o={o} />) : <Empty icon="history" title="No completed orders yet" />}
      </div>
    </>
  );
}

export function WarehouseProfile() {
  const u = ui.currentUser;
  const company = getCompany(u.companyId);
  return (
    <>
      <div className="app-header"><div className="htitle">Profile</div></div>
      <div className="content section-pad">
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 22 }}>
          <div className="avatar" style={{ width: 56, height: 56, fontSize: 18 }}>{initials(u.name)}</div>
          <div><div style={{ fontWeight: 800, fontSize: 17 }}>{u.name}</div><div className="muted small">{userRoleLabel(u)}</div></div>
        </div>
        <div className="info-card">
          <div className="spec-row"><span className="k">Work area</span><span className="v">Warehouse</span></div>
          <div className="spec-row"><span className="k">Role</span><span className="v">{userRoleLabel(u)}</span></div>
          <div className="spec-row"><span className="k">Company</span><span className="v">{company ? company.name : '\u2014'}</span></div>
          <div className="spec-row"><span className="k">Email</span><span className="v">{u.email}</span></div>
          <div className="spec-row"><span className="k">Phone</span><span className="v">{u.phone}</span></div>
          <div className="spec-row" style={{ borderBottom: 'none' }}><span className="k">PIN</span><span className="v">••••</span></div>
        </div>
        {!canModifyInventory(u) ? <div className="tiny muted" style={{ marginTop: 10 }}>Warehouse Worker access is limited to picking, packing, and viewing inventory.</div> : null}
        <Preferences />
        <div style={{ height: 24 }} />
        <button className="btn btn-danger" onClick={A.logout}><Icon name="logout" /> Log out</button>
      </div>
      <WarehouseNav active="profile" />
    </>
  );
}

/* ---------------- sheets ---------------- */
function ChecklistLine({ o, it, canPick }) {
  // The line's own snapshots keep it readable even if the catalog changes.
  const p = displayProductFor(it);
  const toggle = () => W.toggleItemCollected(o.id, it.id);
  if (it.collected) {
    return (
      <button className="check-item" onClick={canPick ? toggle : undefined} style={canPick ? undefined : { cursor: 'default' }}>
        <span className="checkbox on"><Icon name="check" /></span>
        <div className="thumb check-thumb"><ProductImage p={p} key={p.id} /></div>
        <span style={{ flex: 1 }}>
          <span className="ciname done" style={{ display: 'block' }}>{p.name}</span>
          <span className="ciqty" style={{ display: 'block' }}><b>{it.quantity} {it.unit}</b> · {p.size || ''} · {it.brandSnapshot.manufacturerName}<OutstandingNote it={it} /></span>
        </span>
      </button>
    );
  }
  if ((it.shortQuantity || 0) > 0) {
    return (
      <div className="check-item" style={{ cursor: 'default' }}>
        <span className="checkbox" style={{ background: 'var(--warning-bg)', borderColor: 'var(--warning)', color: 'var(--warning)' }}><Icon name="alert" /></span>
        <div className="thumb check-thumb"><ProductImage p={p} key={p.id} /></div>
        <span style={{ flex: 1 }}>
          <span className="ciname" style={{ display: 'block' }}>{p.name}</span>
          <span className="ciqty" style={{ display: 'block' }}><b style={{ color: 'var(--warning)' }}>Short {it.shortQuantity} {it.unit}</b> · {it.packedQuantity > 0 ? 'packed ' + it.packedQuantity : 'picked ' + (it.pickedQuantity || 0)} of {it.quantity} {it.unit}</span>
        </span>
      </div>
    );
  }
  const lp = linePick(o, it);
  const avail = lp.avail;
  const left = it.quantity - (it.pickedQuantity || 0);
  const need = <span className="ciqty" style={{ display: 'block' }}>Need <b>{left} {it.unit}</b> · {avail} {lp.v5 ? t('reserved_word') : 'available'} · {p.size || ''}<OutstandingNote it={it} /></span>;
  if (avail >= left && canPick) {
    return (
      <button className="check-item" style={{ flexWrap: 'wrap' }} onClick={toggle}>
        <span className="checkbox"><Icon name="check" /></span>
        <div className="thumb check-thumb"><ProductImage p={p} key={p.id} /></div>
        <span style={{ flex: 1, minWidth: 160 }}><span className="ciname" style={{ display: 'block' }}>{p.name}</span>{need}</span>
        <div style={{ width: '100%' }}>{lp.v5 ? (lp.plan.parts.length < 2 ? <BinBlock name={lp.bin} /> : null) : <LocationBlock productId={it.productVariantId} />}<PickBins plan={lp.plan} unit={it.unit} /></div>
      </button>
    );
  }
  return (
    <div className="check-item" style={{ cursor: 'default', flexWrap: 'wrap' }}>
      <span className="checkbox" style={{ opacity: 0.35 }}><Icon name="check" /></span>
      <div className="thumb check-thumb"><ProductImage p={p} key={p.id} /></div>
      <span style={{ flex: 1 }}><span className="ciname" style={{ display: 'block' }}>{p.name}</span>{need}</span>
      {canPick ? <button className="btn-sm btn-secondary" style={{ flexShrink: 0 }} onClick={() => W.markItemShort(o.id, it.id)}>Mark short</button> : null}
    </div>
  );
}

export function OrderDetailSheet() {
  const o = orderView(ui.currentUser, ui.openOrderId);
  if (!o) return null;
  const u = ui.currentUser;
  const prog = orderProgress(o);
  const canPick = canPickMaterials(u);
  let action = null;
  if (canDispatchOrder(u)) {
    if (o.workflowStatus === WORKFLOW.PACKED) action = <button className="btn btn-primary" onClick={() => W.markReadyToShip(o.id)}>Mark as ready to ship</button>;
    else if (o.workflowStatus === WORKFLOW.READY_TO_SHIP) action = <button className="btn btn-primary" onClick={() => W.markShipped(o.id)}><Icon name="truck" /> Mark as shipped</button>;
    else if (o.workflowStatus === WORKFLOW.SHIPPED) action = <button className="btn btn-primary" onClick={() => W.markCompleted(o.id)}>Mark as completed</button>;
  }
  const fill = prog.pct === 100 && prog.shorted === 0 ? ' complete' : prog.shorted > 0 ? ' warning' : '';
  return (
    <Sheet onClose={W.closeOrder} title={taskTitle(o)}>
      <div className="section-pad">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
          <div><div style={{ fontWeight: 700, fontSize: 18, color: 'var(--ink)' }}>{requesterName(o)}</div><div className="muted small">{requestProjectName(o)}</div></div>
          <span className={'badge badge-' + priorityCss(o.priority)}>{priorityLabel(o.priority)}</span>
        </div>
        <OrderTimeline status={o.workflowStatus} />
        <div className="spec-row" style={{ marginTop: 8 }}><span className="k">Phone</span><span className="v">{requesterPhone(o)}</span></div>
        <div className="spec-row"><span className="k">Needed by</span><span className="v">{fmtNeeded(o.neededBy)}</span></div>
        <div className="spec-row" style={{ borderBottom: 'none' }}><span className="k">Created</span><span className="v">{relTime(o.createdAt)}</span></div>
        {o.notes ? <div className="info-card" style={{ marginTop: 14 }}><div className="tiny muted" style={{ fontWeight: 700 }}>Notes</div><div className="small" style={{ marginTop: 4 }}>{o.notes}</div></div> : null}
      </div>
      <div className="progress-wrap">
        <div className="progress-top"><span>{prog.shorted > 0 ? 'Materials processed' : 'Materials collected'}</span><span>{prog.done} of {prog.total} · {prog.pct}%</span></div>
        <div className="progress-bar"><div className={'progress-fill' + fill} style={{ width: prog.pct + '%' }} /></div>
        {prog.shorted > 0 ? <div className="tiny" style={{ color: 'var(--warning)', fontWeight: 700, marginTop: 6 }}>{plural(prog.shorted, 'item')} short — not a complete pack</div> : null}
        {!o.legacy && o.outstandingTotal > 0 ? <div className="tiny" style={{ color: 'var(--warning)', fontWeight: 700, marginTop: 6 }}>{t('warehouse_prepares_reserved')}</div> : null}
      </div>
      {o.items.map((it) => <ChecklistLine key={it.id} o={o} it={it} canPick={canPick} />)}
      <RequestActivity o={o} />
      {(canSourceMaterials(u) && isFeatureEnabled(u.companyId, 'supplierLookup')) || action ? (
        <div className="section-pad" style={{ marginTop: 6 }}>
          {!o.legacy && canUser(u, 'MANAGE_ALLOCATIONS') && ['READY_TO_SHIP', 'SHIPPED', 'COMPLETED'].indexOf(o.workflowStatus) === -1
            ? <button className="btn btn-secondary" style={{ marginBottom: 10 }} onClick={() => W.openAllocation(o.id)}>{t('review_allocation')}</button> : null}
          {(canSourceMaterials(u) && isFeatureEnabled(u.companyId, 'supplierLookup')) ? <button className="btn btn-secondary" style={{ marginBottom: 10 }} onClick={() => W.findSuppliers(o.id)}><Icon name="store" /> Find suppliers</button> : null}
          {action}
        </div>
      ) : null}
    </Sheet>
  );
}

const seededRandom = (seed) => { const x = Math.sin(seed) * 10000; return x - Math.floor(x); };
export function SupplierSheet() {
  const o = orderView(ui.currentUser, ui.supplierOrderId);
  if (!o) return null;
  const total = o.items.length;
  const units = o.items.reduce((sum, it) => sum + it.quantity, 0);
  return (
    <Sheet onClose={W.closeSuppliers} title={'Supplier lookup for ' + o.requestNumber}>
      <div className="section-pad" style={{ paddingTop: 0, paddingBottom: 0 }}>
        <div className="tiny muted">Illustrative estimates only. These are not your company's supplier records, quotes or purchase orders; Purchasing keeps those.</div>
      </div>
      <div style={{ height: 14 }} />
      {SUPPLIERS.map((s, idx) => {
        const seed = (o.requestId.charCodeAt(o.requestId.length - 1) + 1) * (idx + 3) * 7.13;
        const avail = Math.max(1, Math.round(total * (0.75 + seededRandom(seed) * 0.25)));
        const est = Math.round((units * (18 + seededRandom(seed + 1) * 14)) / 8);
        return (
          <div className="supplier-card" key={s.name}>
            <SupplierHead s={s} />
            <div className="srow"><span>Estimated availability</span><b>{avail} / {total} items</b></div>
            <div className="srow"><span>Estimated total</span><b>{money(est)}</b></div>
            <div className="srow"><span>Phone</span><b>{s.phone}</b></div>
          </div>
        );
      })}
      <div style={{ height: 8 }} />
    </Sheet>
  );
}


/* ---------------- Phase 2: bins to pick from, inventory detail, adjustment, activity ---------------- */
// Only shown when a pick needs more than one bin ("1. C-2 — Pick 100 EA").
function PickBins({ plan, unit }) {
  if (!plan || plan.parts.length < 2) return null;
  return (
    <div className="info-card" style={{ marginTop: 10, padding: '10px 14px' }}>
      <div className="loc-label">{t('pick_from_bins')}</div>
      {plan.parts.map((part, i) => (
        <div key={part.locationId} className="small" style={{ fontWeight: 700, marginTop: 4 }}>{i + 1}. {part.name} — {t('pick_verb')} {part.quantity.toLocaleString()} {unit}</div>
      ))}
    </div>
  );
}

function ActivityList({ movements }) {
  if (!movements.length) return <div className="small muted" style={{ padding: '8px 0' }}>{t('no_activity_yet')}</div>;
  return movements.map((m) => (
    <div className="spec-row" key={m.id} style={{ alignItems: 'flex-start' }}>
      <span className="k" style={{ flex: 1, color: 'var(--ink)' }}>
        <span style={{ fontWeight: 700, display: 'block' }}>{describeMovement(m)}</span>
        <span className="tiny muted">{movementContext(m)}</span>
      </span>
      <span className="v tiny muted" style={{ fontWeight: 400, whiteSpace: 'nowrap' }}>{relTime(m.timestamp)}</span>
    </div>
  ));
}

// Order detail: what the ledger did for this request (manager only; hidden until something happened).
function RequestActivity({ o }) {
  if (!canUser(ui.currentUser, CAP.VIEW_INVENTORY_HISTORY) || !isFeatureEnabled(o.companyId, 'inventory')) return null;
  const list = getMovementsForRequest(o.requestId).slice().reverse();
  if (!list.length) return null;
  return (
    <div className="section-pad">
      <div className="spec-block-title">{t('inventory_activity')}</div>
      <ActivityList movements={list.slice(0, 12)} />
    </div>
  );
}

export function InventoryDetailSheet() {
  const u = ui.currentUser;
  const vid = ui.inventoryDetailId;
  const p = getProduct(vid);
  if (!u || !p) return null;
  const c = u.companyId;
  const q = Inv.getQuantityByState(c, vid);
  const item = Inv.inventoryItemFor(c, vid);
  const bins = Inv.getInventoryForVariant(c, vid).filter((b) => b.quantity > 0 && b.inventoryState === 'AVAILABLE');
  const others = bins.filter((b) => !item || b.locationId !== item.primaryLocationId);
  const locName = (id) => { const l = getLocation(id); return l ? (l.type === 'WAREHOUSE' ? l.name + ' (no bin)' : l.name) : '—'; };
  // The `inventory` feature flag only shows or hides these history views; stock tracking itself never switches off.
  const showHistory = canUser(u, CAP.VIEW_INVENTORY_HISTORY) && isFeatureEnabled(c, 'inventory');
  const history = showHistory ? getMovementsForVariant(c, vid).slice().reverse().slice(0, 10) : [];
  const shippedPacked = packedOnDispatched(c, vid);
  const stat = (label, value, color) => <div className="pm-stat"><div className="pm-stat-label">{label}</div><div className="pm-stat-value" style={color ? { color } : undefined}>{value.toLocaleString()} {p.unit}</div></div>;
  return (
    <Sheet onClose={W.closeInventoryDetail} title={t('inventory')}>
      <div className="detail-photo"><ProductImage p={p} large key={p.id} /></div>
      <div className="section-pad">
        <div className="h1">{p.name}</div>
        {p.size ? <div className="pm-size" style={{ textAlign: 'left' }}>{p.size}</div> : null}
        <div className="pm-stats" style={{ gridTemplateColumns: '1fr 1fr' }}>
          {stat(t('available_label'), q.AVAILABLE, Inv.isLowStock(c, vid) ? 'var(--warning)' : 'var(--good)')}
          {stat(t('reserved_label'), q.RESERVED || 0)}
          {stat(t('picking_state'), q.PICKING)}
          {stat(t('packed_state'), q.PACKED)}
        </div>
        <div className="spec-row" style={{ marginTop: 10 }}><span className="k">{t('physical_in_warehouse')}</span><span className="v">{Inv.getPhysicalOnHand(c, vid).toLocaleString()} {p.unit}</span></div>
        <div className="spec-row"><span className="k">{t('primary_location')}</span><span className="v">{item ? locName(item.primaryLocationId) : '—'}</span></div>
        {others.length ? <div className="spec-row"><span className="k">{t('other_locations')}</span><span className="v">{others.map((b) => locName(b.locationId) + ': ' + b.quantity.toLocaleString() + ' ' + p.unit).join(', ')}</span></div> : null}
        {item && item.reorderPoint != null ? <div className="spec-row"><span className="k">{t('reorder_point')}</span><span className="v">{item.reorderPoint.toLocaleString()} {p.unit}</span></div> : null}
        {shippedPacked > 0 ? <div className="tiny muted" style={{ marginTop: 8 }}>{tf('packed_on_shipped_note', { qty: shippedPacked.toLocaleString() + ' ' + p.unit })}</div> : null}
        {canModifyInventory(u) ? <button className="btn btn-primary" style={{ marginTop: 16 }} onClick={() => W.openAdjust(vid)}>{t('adjust_inventory')}</button> : null}
        {showHistory ? <><div className="spec-block-title">{t('recent_activity')}</div><ActivityList movements={history} /></> : null}
      </div>
    </Sheet>
  );
}

export function AdjustInventorySheet() {
  const d = ui.adjustDraft;
  const u = ui.currentUser;
  const p = d && getProduct(d.productVariantId);
  if (!d || !u || !p) return null;
  const total = Inv.getAvailableQuantity(u.companyId, d.productVariantId);
  const options = Inv.adjustableLocations(u.companyId, d.productVariantId);
  const chosen = options.find((o) => o.locationId === d.locationId) || null;
  const here = chosen ? chosen.available : null;               // the editable balance is ALWAYS the selected location's
  const n = parseInt(d.quantity, 10);
  const delta = n > 0 ? (d.direction === 'IN' ? n : -n) : null;
  const lang = prefs.language;
  const qty = (x) => x.toLocaleString() + ' ' + p.unit;
  return (
    <Sheet center onClose={W.closeAdjust}>
      <div className="section-pad" style={{ paddingTop: 22 }}>
        <div className="h1" style={{ marginBottom: 4 }}>{t('inventory_adjustment')}</div>
        <div className="small muted" style={{ marginBottom: 14 }}>{p.name}{p.size ? ' · ' + p.size : ''}</div>
        {d.error ? <div className="alert-banner"><Icon name="alert" /><span>{d.error}</span></div> : null}
        <div className="spec-row"><span className="k">{t('total_available')}</span><span className="v">{qty(total)}</span></div>
        <div className="field" style={{ marginTop: 12 }}><label htmlFor="adj-location">{t('location')}</label>
          <select id="adj-location" value={d.locationId || ''} onChange={(e) => W.setAdjustField('locationId', e.target.value)}>
            {!chosen ? <option value="">{t('choose_location')}</option> : null}
            {options.filter((o) => o.stocked).map((o) => <option key={o.locationId} value={o.locationId}>{o.name} · {qty(o.available)}</option>)}
            {options.some((o) => !o.stocked) ? <optgroup label={t('other_warehouse_locations')}>
              {options.filter((o) => !o.stocked).map((o) => <option key={o.locationId} value={o.locationId}>{o.name}</option>)}
            </optgroup> : null}
          </select></div>
        {chosen ? <div className="spec-row"><span className="k">{tf('available_at', { location: chosen.name })}</span><span className="v">{qty(here)}</span></div> : null}
        <div className="segment" style={{ margin: '14px 0' }}>
          <button className={d.direction === 'IN' ? 'on' : ''} onClick={() => W.setAdjustField('direction', 'IN')}>+ {t('add_stock')}</button>
          <button className={d.direction === 'OUT' ? 'on' : ''} onClick={() => W.setAdjustField('direction', 'OUT')}>− {t('remove_stock')}</button>
        </div>
        <div className="field"><label htmlFor="adj-qty">{t('adjust_quantity_label')} ({p.unit})</label>
          <input id="adj-qty" type="number" inputMode="numeric" min="1" value={d.quantity} onChange={(e) => W.setAdjustField('quantity', e.target.value)} /></div>
        {chosen && delta != null ? <>
          <div className="spec-row"><span className="k">{tf('new_quantity_at', { location: chosen.name })}</span><span className="v" style={here + delta < 0 ? { color: 'var(--emergency)' } : undefined}>{qty(here + delta)}</span></div>
          <div className="spec-row"><span className="k">{t('total_after')}</span><span className="v">{qty(total + delta)}</span></div>
        </> : null}
        <div className="field" style={{ marginTop: 12 }}><label htmlFor="adj-reason">{t('reason')}</label>
          <select id="adj-reason" value={d.reasonCode} onChange={(e) => W.setAdjustField('reasonCode', e.target.value)}>
            <option value="">{t('choose_reason')}</option>
            {Object.keys(ADJUSTMENT_REASONS).map((k) => <option key={k} value={k}>{ADJUSTMENT_REASONS[k][lang] || ADJUSTMENT_REASONS[k].en}</option>)}
          </select></div>
        <div className="field"><label htmlFor="adj-notes">{t('notes_optional')}</label>
          <textarea id="adj-notes" value={d.notes} onChange={(e) => W.setAdjustField('notes', e.target.value)} /></div>
        <button className="btn btn-primary" style={{ marginBottom: 10 }} onClick={W.saveAdjustment}>{t('save_adjustment')}</button>
        <button className="btn btn-secondary" onClick={W.closeAdjust}>{t('cancel')}</button>
      </div>
    </Sheet>
  );
}

// Packed quantity on requests already marked Shipped / Completed: still counted in the
// warehouse until the Logistics phase posts shipment movements (known transitional area).
function packedOnDispatched(companyId, vid) {
  const dispatched = new Set(requestsForCompany(companyId).filter((r) => stageOf(r) === WORKFLOW.SHIPPED || stageOf(r) === WORKFLOW.COMPLETED).map((r) => r.id));
  let n = 0;
  getMovementsForVariant(companyId, vid).forEach((m) => {
    if (!m.requestId || !dispatched.has(m.requestId)) return;
    if (m.toInventoryState === 'PACKED') n += m.quantity;
    if (m.fromInventoryState === 'PACKED') n -= m.quantity;
  });
  return Math.max(0, n);
}

/* Warehouse Manager: one request's allocation detail (spec 22 + correction #2).
   Reachable even when nothing is allocated yet (no fulfillment exists).
   Shows requested / warehouse (all batches) / available now / outstanding per
   material; each allocation with its batch. Changes are ledger movements
   (RESERVE / UNRESERVE); nothing exceeds the demand or the bin's AVAILABLE
   stock, and a batch that is already being worked on is never enlarged: new
   stock goes to a new batch. */
export function AllocationSheet() {
  const raw = getRequestFor(ui.currentUser, ui.allocationOrderId);
  if (!raw) return null;
  const project = getProject(raw.projectId);
  const batches = warehouseFulfillmentsFor(raw.id);
  const bNo = (fid) => batches.findIndex((f) => f.id === fid) + 1;
  const lines = raw.items.map((it) => {
    const vid = stockVariantFor(raw.companyId, it.productVariantId);
    const avail = project ? availableForProject(project, vid).reduce((s, b) => s + b.quantity, 0) : 0;
    return { it, allocated: getAllocatedQuantity(it), outstanding: getOutstandingQuantity(it, raw), avail, allocs: activeAllocationsForItem(it.id) };
  });
  const outstanding = lines.reduce((s, l) => s + l.outstanding, 0);
  const allocated = lines.reduce((s, l) => s + l.allocated, 0);
  const canAllocateMore = lines.some((l) => l.outstanding > 0 && l.avail > 0);
  return (
    <Sheet onClose={W.closeAllocation} title={t('request_allocation') + ' \u00b7 ' + raw.id}>
      <div className="section-pad" style={{ paddingTop: 0 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
          <div><div style={{ fontWeight: 800, fontSize: 16 }}>{requestProjectName(raw)}</div><div className="tiny muted">{t('needed_label')} {fmtNeeded(raw.neededBy)} · {requesterName(raw)}</div></div>
          <span className={'badge badge-' + priorityCss(raw.priority)}>{priorityLabel(raw.priority)}</span>
        </div>
        <div className="tiny" style={{ fontWeight: 700, color: outstanding > 0 ? 'var(--warning)' : 'var(--good)', marginBottom: 12 }}>
          {allocated === 0 ? t('nothing_allocated_yet') : outstanding > 0 ? t('partially_allocated_note') : t('fully_allocated_note')}</div>
        {lines.map(({ it, allocated: al, outstanding: out, avail, allocs }) => { const p = displayProductFor(it); return (
          <div className="info-card" style={{ marginBottom: 12 }} key={it.id}>
            <div style={{ fontWeight: 700 }}>{p.name}{p.size ? ' \u00b7 ' + p.size : ''}</div>
            <div className="spec-row"><span className="k">{t('requested_label')}</span><span className="v">{it.quantity} {it.unit}</span></div>
            <div className="spec-row"><span className="k">{t('warehouse_label')}</span><span className="v">{al} {it.unit}</span></div>
            <div className="spec-row"><span className="k">{t('available_now')}</span><span className="v">{avail} {it.unit}</span></div>
            {getSupplierOrderedQuantity(it) > 0 ? <div className="spec-row"><span className="k">{t('on_order_label')}</span><span className="v">{getSupplierOrderedQuantity(it)} {it.unit}</span></div> : null}
            <div className="spec-row" style={{ borderBottom: 'none' }}><span className="k">{t('outstanding_label')}</span><span className="v" style={out > 0 ? { color: 'var(--warning)' } : undefined}>{out} {it.unit}</span></div>
            {allocs.map((a) => {
              const draft = ui.allocationDraft[a.id], f = fulfillmentById(a.fulfillmentId);
              // editable only where something can change: unpicked reserved stock on a batch that hasn't left packing
              const editable = !(f && (f.status === 'READY' || f.dispatchStatus)) && allocationState(a.id).RESERVED > 0;
              const name = ((db.LOCATIONS.find((l) => l.id === a.sourceLocationId)) || {}).name || '';
              return (
                <div key={a.id} style={{ marginTop: 10 }}>
                  <div className="tiny muted">{tf('batch_n', { n: bNo(a.fulfillmentId) })}{f ? ' \u00b7 ' + workflowLabel(stageOfFulfillment(f)) : ''}{' \u00b7 '}<b style={{ color: 'var(--ink)' }}>{name}</b></div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4 }}>
                    {!editable ? <b>{a.quantity} {a.unit}</b> : <>
                      <input type="number" min="0" aria-label={name + ' quantity'} id={'alloc-' + a.id} style={{ width: 84, minHeight: 44, border: '1.5px solid var(--line)', borderRadius: 10, textAlign: 'center', fontWeight: 700 }}
                        value={draft == null ? a.quantity : draft} onChange={(e) => W.setAllocationDraft(a.id, e.target.value)} />
                      <button className="btn-sm btn-secondary" onClick={() => W.saveAllocation(a.id)}>{t('save')}</button>
                      <button className="btn-sm btn-secondary" onClick={() => W.releaseAllocationLine(a.id)}>{t('release')}</button>
                    </>}
                  </div>
                </div>
              );
            })}
          </div>
        ); })}
        {ui.allocationError ? <div className="alert-banner" style={{ margin: '0 0 12px' }}><Icon name="alert" /><span>{ui.allocationError}</span></div> : null}
        {outstanding > 0 ? <button className="btn btn-primary" disabled={!canAllocateMore} onClick={() => W.allocateAvailable(raw.id)}>{t('allocate_available')}</button> : null}
        {outstanding > 0 && !canAllocateMore ? <div className="tiny muted" style={{ marginTop: 8 }}>{t('awaiting_stock_note')}</div> : null}
        {outstanding === 0 && lines.some((l) => getSupplierOrderedQuantity(l.it) > 0 && l.avail > 0) ? <>
          <button className="btn btn-secondary" style={{ marginTop: 10 }} onClick={() => W.coverFromStock(raw.id)}>{t('use_stock_instead')}</button>
          <div className="tiny muted" style={{ marginTop: 6 }}>{t('use_stock_instead_note')}</div></> : null}
        <div className="tiny muted" style={{ marginTop: 10 }}>{t('allocation_note')}</div>
      </div>
    </Sheet>
  );
}

/* Incoming supplier purchase orders to this warehouse (Phase 4): "PO-1004
   arrived. Receive 40." No prices here; receiving is a physical act. */
export function IncomingPurchases() {
  const u = ui.currentUser;
  if (!canUser(u, CAP.RECEIVE_PURCHASE_ORDER)) return null;
  const list = getIncomingPurchaseOrders(u);
  if (!list.length) return null;
  const fmtD = (d) => new Date(d + 'T12:00:00').toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  return (
    <>
      <div className="h2" style={{ margin: '18px 0 10px' }}>{t('incoming_purchases')}</div>
      {list.map((po) => { const late = isPurchaseOrderLate(po); return (
        <div className="info-card" key={po.id} data-incoming={po.id} style={{ marginBottom: 10 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 }}>
            <div style={{ minWidth: 0 }}><div style={{ fontWeight: 800, fontSize: 16 }}>{po.purchaseOrderNumber}</div><div className="small" style={{ fontWeight: 600, color: 'var(--ink-soft)' }}>{po.supplierSnapshot.name}</div></div>
            {late ? <span className="status-pill status-warning" style={{ flexShrink: 0 }}>{t('pos_late')}</span> : null}
          </div>
          <div className="tiny muted" style={{ marginTop: 4 }}>{po.expectedDeliveryDate ? tf('expected_on', { d: fmtD(po.expectedDeliveryDate) }) + ' \u00b7 ' : ''}{tf(po.items.length === 1 ? 'n_lines_one' : 'n_lines', { n: po.items.length })}{' \u00b7 '}{tf('n_to_receive', { n: poRemaining(po) })}</div>
          <button className="btn btn-primary btn-sm" style={{ width: '100%', marginTop: 10 }} onClick={() => PU.openReceive(po.id)}>{t('receive_materials')}</button>
        </div>); })}
    </>
  );
}
export function ReceivePoSheet() {
  const u = ui.currentUser, po = poById(ui.receivePoId), d = ui.receiveDraft;
  if (!po || !d || po.companyId !== u.companyId) return null;
  const locs = receivingLocations(po);
  return (
    <Sheet onClose={PU.closeReceive} title={tf('receive_po_title', { po: po.purchaseOrderNumber })}>
      <div className="section-pad" style={{ paddingTop: 0 }}>
        <div className="small" style={{ fontWeight: 600, marginBottom: 10 }}>{po.supplierSnapshot.name} · {((db.LOCATIONS.find((l) => l.id === po.shipToWarehouseId)) || {}).name}</div>
        {po.items.map((it) => { const lp = lineProgress(po, it), l = d.lines[it.id]; if (!l || lp.remaining === 0) return null; return (
          <div className="info-card" key={it.id} style={{ marginBottom: 12 }}>
            <div style={{ fontWeight: 700 }}>{it.productNameSnapshot}</div>
            <div className="tiny muted" style={{ marginBottom: 8 }}>{tf('still_expected', { qty: lp.remaining, unit: it.unit })}</div>
            {!l.wrong ? <>
              <div style={{ display: 'flex', gap: 10 }}>
                <div className="field" style={{ flex: 1, marginBottom: 8 }}><label htmlFor={'rg-' + it.id}>{t('received_good')}</label>
                  <input type="text" inputMode="numeric" id={'rg-' + it.id} value={l.good} onChange={(e) => PU.setReceiveLine(it.id, 'good', e.target.value)} /></div>
                <div className="field" style={{ flex: 1, marginBottom: 8 }}><label htmlFor={'rd-' + it.id}>{t('received_damaged')}</label>
                  <input type="text" inputMode="numeric" id={'rd-' + it.id} value={l.damaged} onChange={(e) => PU.setReceiveLine(it.id, 'damaged', e.target.value)} /></div>
              </div>
              <div className="field" style={{ marginBottom: 8 }}><label htmlFor={'rl-' + it.id}>{t('put_away_location')}</label>
                <select id={'rl-' + it.id} value={l.locationId} onChange={(e) => PU.setReceiveLine(it.id, 'locationId', e.target.value)}>
                  <option value="">{t('choose_location')}</option>
                  {locs.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
                </select></div>
            </> : <div className="field" style={{ marginBottom: 8 }}><label htmlFor={'rn-' + it.id}>{t('what_arrived_instead')}</label>
              <input type="text" id={'rn-' + it.id} value={l.notes} onChange={(e) => PU.setReceiveLine(it.id, 'notes', e.target.value)} /></div>}
            <label className="checkline" style={{ padding: '4px 0' }}><input type="checkbox" checked={!!l.wrong} onChange={(e) => PU.setReceiveLine(it.id, 'wrong', e.target.checked)} /><span className="small">{t('wrong_material_arrived')}</span></label>
          </div>); })}
        <div className="field" style={{ marginBottom: 12 }}><label htmlFor="rc-slip">{t('packing_slip_no')}</label><input type="text" id="rc-slip" value={d.slip} onChange={(e) => PU.setReceiveField('slip', e.target.value)} /></div>
        {d.error ? <div className="alert-banner" style={{ margin: '0 0 12px' }}><Icon name="alert" /><span>{d.error}</span></div> : null}
        <button className="btn btn-primary" onClick={PU.submitReceive}>{t('receive_materials')}</button>
        <div className="tiny muted" style={{ marginTop: 8 }}>{t('receive_note')}</div>
      </div>
    </Sheet>
  );
}

/* One outstanding request, the same card on Home and in the full list: request
   number, project, priority, needed by, and what still needs sourcing (one
   line: its quantity; several lines: how many materials, since units differ). */
function OutstandingCard({ x, showWarehouse }) {
  const r = x.request;
  const wh = showWarehouse && x.warehouseId ? ((db.LOCATIONS.find((l) => l.id === x.warehouseId)) || {}).name : null;
  const what = x.single ? tf('qty_outstanding', { qty: x.single.quantity.toLocaleString(), unit: x.single.unit })
    : tf('materials_need_sourcing', { n: x.linesWithOutstanding });
  return (
    <button className="info-card" data-outstanding={r.id} style={{ width: '100%', textAlign: 'left', marginBottom: 10, display: 'flex', alignItems: 'center', gap: 10 }} onClick={() => W.openAllocation(r.id)}>
      <span style={{ flex: 1, minWidth: 0 }}>
        <span style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 }}>
          <span style={{ fontWeight: 800, fontSize: 16, color: 'var(--ink)' }}>{r.id}</span>
          <span className={'badge badge-' + priorityCss(r.priority)} style={{ flexShrink: 0 }}>{priorityLabel(r.priority)}</span>
        </span>
        <span className="small" style={{ display: 'block', fontWeight: 600, color: 'var(--ink-soft)', marginTop: 2 }}>{requestProjectName(r)}{wh ? ' \u00b7 ' + wh : ''}</span>
        <span className="tiny muted" style={{ display: 'block', marginTop: 2 }}>{t('needed_label')} {fmtNeeded(r.neededBy)}</span>
        <span className="tiny" style={{ display: 'block', color: 'var(--warning)', fontWeight: 700, marginTop: 6 }}>{what}{' \u00b7 '}{x.allocated === 0 ? t('nothing_allocated_short') : t('partly_allocated_short')}</span>
      </span>
      <span style={{ color: 'var(--mist)', flexShrink: 0 }}><Icon name="chev" className="ico-sm" /></span>
    </button>
  );
}
const multiWarehouse = (companyId) => db.LOCATIONS.filter((l) => l.companyId === companyId && l.type === 'WAREHOUSE' && l.status !== 'INACTIVE').length > 1;

/* Manager Home preview: the most urgent few, from the SAME list the full
   screen shows. "View all N" opens that screen; nothing is ever unreachable. */
export function NeedsAttention() {
  const u = ui.currentUser;
  if (!canUser(u, CAP.MANAGE_ALLOCATIONS)) return null;
  const list = outstandingRequestsFor(u);
  if (!list.length) return null;
  const many = multiWarehouse(u.companyId) && !u.warehouseId;
  return (
    <>
      <div className="h2" style={{ margin: '18px 0 4px' }}>{t('needs_attention')}</div>
      <div className="tiny muted" style={{ marginBottom: 10 }}>{t('needs_attention_sub')}</div>
      {list.slice(0, OUTSTANDING_PREVIEW_COUNT).map((x) => <OutstandingCard key={x.request.id} x={x} showWarehouse={many} />)}
      {list.length > OUTSTANDING_PREVIEW_COUNT
        ? <button className="btn btn-secondary" style={{ marginBottom: 10 }} onClick={W.openOutstandingRequests}>{tf('view_all_outstanding', { n: list.length })}</button> : null}
    </>
  );
}

/* Full list: every outstanding request (Home > Outstanding requests > View all).
   Same source, same order, same cards. Warehouse Managers only. */
export function OutstandingRequests() {
  const u = ui.currentUser;
  const allowed = canUser(u, CAP.MANAGE_ALLOCATIONS);
  const list = allowed ? outstandingRequestsFor(u) : [];
  const many = multiWarehouse(u.companyId) && !u.warehouseId;
  return (
    <>
      <div className="app-header">
        <button className="icon-btn" onClick={() => W.mNavTo('home', 'mHome')} aria-label={t('back')}><Icon name="back" /></button>
        <div><div className="htitle">{t('needs_attention')}</div><div className="hsub">{list.length ? tf(list.length === 1 ? 'n_requests_one' : 'n_requests', { n: list.length }) : t('needs_attention_sub')}</div></div>
      </div>
      <div className="content"><div className="section-pad">
        {list.length ? list.map((x) => <OutstandingCard key={x.request.id} x={x} showWarehouse={many} />)
          : <Empty icon="check" title={t('all_demand_allocated')}><div>{t('all_demand_allocated_sub')}</div></Empty>}
      </div></div>
      <WarehouseNav active="home" />
    </>
  );
}
