/* Purchasing (Phase 4): what needs to be bought, who from, how much, when it
   arrives, and whether it arrived. Stacked mobile cards, never a spreadsheet.
   Nothing here decides anything: services validate every action. */
import { ui } from '../lib/store.js';
import { t, tf, greeting } from '../lib/i18n.js';
import { db } from '../lib/db.js';
import { canUser, CAP } from '../lib/permissions.js';
import { Icon, Sheet, Empty, Preferences } from '../components/common.jsx';
import { ApprovalsCard } from '../components/RequestSheets.jsx';
import { priorityLabel, priorityCss } from '../config/priorities.js';
import { fmtNeeded } from '../lib/orders.js';
import { initials } from '../lib/validation.js';
import { getCompany } from '../services/repo.js';
import { userRoleLabel } from '../services/userService.js';
import { requestProjectName, requesterName } from '../services/requestService.js';
import { getRequirementById, getRequirementProgress, requirementsVisibleTo, isOpenRequirement } from '../services/purchaseRequirementService.js';
import { getSuppliers, getSupplier, getQuotesForRequirement } from '../services/supplierService.js';
import { getPurchaseOrders, getPurchaseOrder, lineProgress, isPurchaseOrderLate, commitmentWarnings, getPurchaseOrdersForRequirement,
  getPurchaseOrdersForSupplier, receiptsForPo, variantCompatible, poRemaining } from '../services/purchaseOrderService.js';
import { getAllocatedQuantity } from '../services/requestProgress.js';
import * as A from '../lib/actions.js';
import * as PU from '../lib/actionsPurchasing.js';

const money = (n) => '$' + (Number(n) || 0).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
const statusKey = (s) => 'prs_' + String(s || '').toLowerCase();
const poStatusKey = (s) => 'pos_' + String(s || '').toLowerCase();
const req = (id) => db.REQUESTS.find((r) => r.id === id) || null;
const locName = (id) => ((db.LOCATIONS.find((l) => l.id === id)) || {}).name || '';
const userName = (id) => { const u = db.USERS.find((x) => x.id === id); return u ? u.fullName : ''; };
const fmtDate = (d) => (d ? new Date(d.length === 10 ? d + 'T12:00:00' : d).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : '');
const pill = (s) => (['RECEIVED', 'ORDERED'].indexOf(s) !== -1 ? ' status-success' : ['OPEN', 'BACKORDERED', 'PARTIALLY_RECEIVED', 'PARTIALLY_ORDERED'].indexOf(s) !== -1 ? ' status-warning' : '');

export function PurchasingNav({ active }) {
  const items = [['home', t('p_nav_requirements'), 'orders', 'pHome'], ['pos', t('p_nav_pos'), 'truck', 'pOrders'], ['suppliers', t('p_nav_suppliers'), 'store', 'pSuppliers'], ['profile', t('profile'), 'profile', 'pProfile']];
  return (
    <div className="bottomnav">
      {items.map(([k, label, icon, go]) => (
        <button key={k} className={'navitem' + (active === k ? ' active' : '')} onClick={() => PU.pNavTo(k, go)}><Icon name={icon} /><span>{label}</span></button>
      ))}
    </div>
  );
}

/* ---------- Home = Requirements ---------- */
function RequirementCard({ pr }) {
  const p = getRequirementProgress(pr), r = req(pr.requestId);
  return (
    <button className="info-card" data-requirement={pr.id} style={{ width: '100%', textAlign: 'left', marginBottom: 10, display: 'block' }} onClick={() => PU.openRequirement(pr.id)}>
      <span style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 }}>
        <span style={{ fontWeight: 800, fontSize: 16, color: 'var(--ink)' }}>{pr.requirementNumber}</span>
        <span className={'badge badge-' + priorityCss(pr.priority)} style={{ flexShrink: 0 }}>{priorityLabel(pr.priority)}</span>
      </span>
      <span className="small" style={{ display: 'block', fontWeight: 600, color: 'var(--ink-soft)', marginTop: 2 }}>{r ? requestProjectName(r) : ''} · {pr.requestId}</span>
      <span className="small" style={{ display: 'block', color: 'var(--ink)', marginTop: 4 }}>{pr.productNameSnapshot}{pr.variantSnapshot && pr.variantSnapshot.attributes ? '' : ''}</span>
      <span className="tiny muted" style={{ display: 'block', marginTop: 2 }}>{t('needed_label')} {fmtNeeded(pr.neededBy)}</span>
      <span style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 8, gap: 8 }}>
        <span className="tiny" style={{ fontWeight: 700, color: p.toSource > 0 ? 'var(--warning)' : 'var(--ink-soft)' }}>
          {p.toSource > 0 ? tf('qty_needs_sourcing', { qty: p.toSource, unit: pr.unit }) : tf('qty_on_order', { qty: p.expected, unit: pr.unit })}</span>
        <span className={'status-pill' + pill(pr.status)}>{t(statusKey(pr.status))}</span>
      </span>
    </button>
  );
}
function Tile({ n, label, onClick, warn }) {
  return <button className="info-card" style={{ textAlign: 'center', padding: '14px 8px' }} onClick={onClick}>
    <div style={{ fontSize: 22, fontWeight: 800, color: warn && n ? 'var(--warning)' : 'var(--ink)' }}>{n}</div><div className="tiny muted" style={{ marginTop: 2 }}>{label}</div></button>;
}
const REQ_FILTERS = [['TO_SOURCE', 'pf_to_source'], ['IN_DRAFT', 'pf_in_draft'], ['ON_ORDER', 'pf_on_order'], ['ALL', 'pf_all']];
function matchesReq(pr, f) {
  const p = getRequirementProgress(pr);
  if (f === 'TO_SOURCE') return isOpenRequirement(pr) && p.toSource > 0;
  if (f === 'IN_DRAFT') return p.inDraft > 0;
  if (f === 'ON_ORDER') return p.expected > 0;
  return true;
}
function searchReq(pr, q) {
  if (!q) return true;
  const r = req(pr.requestId);
  const pos = getPurchaseOrdersForRequirement(ui.currentUser, pr.id);
  return [pr.requirementNumber, pr.requestId, r ? requestProjectName(r) : '', pr.productNameSnapshot, pr.variantSnapshot && pr.variantSnapshot.displayName]
    .concat(pos.map((p) => p.purchaseOrderNumber + ' ' + p.supplierSnapshot.name)).some((v) => String(v || '').toLowerCase().indexOf(q) !== -1);
}
export function PurchasingHome() {
  const u = ui.currentUser;
  const all = requirementsVisibleTo(u).slice().sort((a, b) => ((b.priority === 'EMERGENCY') - (a.priority === 'EMERGENCY')) || ((a.neededBy || 0) - (b.neededBy || 0)) || (a.createdAt - b.createdAt));
  const f = ui.pReqFilter || 'TO_SOURCE', q = String(ui.pReqSearch || '').trim().toLowerCase();
  const list = all.filter((pr) => matchesReq(pr, f) && searchReq(pr, q));
  const pos = getPurchaseOrders(u);
  const toSource = all.filter((pr) => matchesReq(pr, 'TO_SOURCE'));
  const warnings = commitmentWarnings(u);
  const issues = pos.filter((p) => receiptsForPo(p.id).some((rc) => (rc.issues || []).length) && poRemaining(p) > 0);
  return (
    <>
      <div className="app-header" style={{ flexDirection: 'column', alignItems: 'stretch', gap: 14 }}>
        <div><div className="brand-tag">ANT</div><div className="h1" style={{ marginBottom: 0 }}>{greeting()}, {u.name.split(' ')[0]}</div></div>
        <div className="searchbar"><Icon name="search" />
          <input type="text" id="req-search-input" value={ui.pReqSearch || ''} placeholder={t('p_search_placeholder')} aria-label={t('p_search_placeholder')} onChange={(e) => PU.setReqSearch(e.target.value)} /></div>
      </div>
      <div className="content"><div className="section-pad">
        <ApprovalsCard />
        <div className="h2" style={{ margin: '4px 0 10px' }}>{t('p_needs_attention')}</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
          <Tile n={toSource.length} label={t('pt_needs_sourcing')} warn onClick={() => PU.setReqFilter('TO_SOURCE')} />
          <Tile n={toSource.filter((pr) => pr.priority === 'EMERGENCY').length} label={t('pt_emergency')} warn onClick={() => PU.setReqFilter('TO_SOURCE')} />
          <Tile n={pos.filter((p) => p.status === 'DRAFT').length} label={t('pt_unsent_drafts')} onClick={() => { PU.setPoFilter('DRAFT'); PU.pNavTo('pos', 'pOrders'); }} />
          <Tile n={pos.filter((p) => p.status === 'SENT').length} label={t('pt_awaiting_confirmation')} onClick={() => { PU.setPoFilter('SENT'); PU.pNavTo('pos', 'pOrders'); }} />
          <Tile n={pos.filter((p) => isPurchaseOrderLate(p)).length} label={t('pt_overdue')} warn onClick={() => { PU.setPoFilter('LATE'); PU.pNavTo('pos', 'pOrders'); }} />
          <Tile n={pos.filter((p) => p.status === 'BACKORDERED').length} label={t('pt_backorders')} warn onClick={() => { PU.setPoFilter('BACKORDERED'); PU.pNavTo('pos', 'pOrders'); }} />
        </div>
        {warnings.map((w) => (
          <button key={w.link.supplierAllocationId} className="alert-banner" style={{ background: 'var(--warning-bg)', color: 'var(--warning)', margin: '0 0 10px', width: '100%', textAlign: 'left', border: 'none' }} onClick={() => PU.openPo(w.purchaseOrder.id)}>
            <Icon name="alert" className="ico-md" /><span>{tf('commitment_warning', { qty: w.quantity, unit: w.item.unit, po: w.purchaseOrder.purchaseOrderNumber, req: w.requestId })}</span></button>
        ))}
        {issues.map((p) => (
          <button key={p.id} className="alert-banner" style={{ margin: '0 0 10px', width: '100%', textAlign: 'left', border: 'none' }} onClick={() => PU.openPo(p.id)}>
            <Icon name="alert" className="ico-md" /><span>{tf('receiving_issue_banner', { po: p.purchaseOrderNumber })}</span></button>
        ))}
        <div className="h2" style={{ margin: '8px 0 10px' }}>{t('purchase_requirements')}</div>
        <div className="tab-row" style={{ padding: 0, marginBottom: 12 }}>
          {REQ_FILTERS.map(([k, key]) => <button key={k} className={'chip' + (f === k ? ' on' : '')} style={{ whiteSpace: 'nowrap', flexShrink: 0 }} onClick={() => PU.setReqFilter(k)}>{t(key)}</button>)}
        </div>
        {list.length ? list.map((pr) => <RequirementCard key={pr.id} pr={pr} />)
          : <Empty icon="check" title={f === 'TO_SOURCE' && !q ? t('no_external_sourcing') : t('no_matching_requirements')} />}
      </div></div>
      <PurchasingNav active="home" />
    </>
  );
}

/* ---------- requirement detail ---------- */
export function RequirementSheet() {
  const u = ui.currentUser, pr = getRequirementById(ui.requirementId);
  if (!pr || pr.companyId !== u.companyId) return null;
  const p = getRequirementProgress(pr), r = req(pr.requestId), item = r && r.items.find((i) => i.id === pr.requestItemId);
  const quotes = getQuotesForRequirement(u, pr.id), pos = getPurchaseOrdersForRequirement(u, pr.id);
  const supName = (id) => ((db.SUPPLIERS.find((s) => s.id === id)) || {}).name || '';
  const canBuy = canUser(u, CAP.CREATE_PURCHASE_ORDER), canQuote = canUser(u, CAP.MANAGE_SUPPLIERS);
  return (
    <Sheet onClose={PU.closeRequirement} title={pr.requirementNumber}>
      <div className="section-pad" style={{ paddingTop: 0 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 }}>
          <div style={{ minWidth: 0 }}><div style={{ fontWeight: 800, fontSize: 17 }}>{pr.productNameSnapshot}</div>
            <div className="tiny muted">{pr.requestId} · {r ? requestProjectName(r) : ''} · {r ? requesterName(r) : ''}</div></div>
          <span className={'badge badge-' + priorityCss(pr.priority)} style={{ flexShrink: 0 }}>{priorityLabel(pr.priority)}</span>
        </div>
        <div className="spec-row"><span className="k">{t('needed_label')}</span><span className="v">{fmtNeeded(pr.neededBy)}</span></div>
        <div className="spec-row"><span className="k">{t('p_requested_on_request')}</span><span className="v">{item ? item.quantity : '—'} {pr.unit}</span></div>
        <div className="spec-row"><span className="k">{t('p_from_warehouse')}</span><span className="v">{item ? getAllocatedQuantity(item) : 0} {pr.unit}</span></div>
        <div className="spec-row"><span className="k">{t('p_required_externally')}</span><span className="v">{p.required} {pr.unit}</span></div>
        {p.released ? <div className="spec-row"><span className="k">{t('p_released')}</span><span className="v">{p.released} {pr.unit}</span></div> : null}
        {p.inDraft ? <div className="spec-row"><span className="k">{t('p_in_draft')}</span><span className="v">{p.inDraft} {pr.unit}</span></div> : null}
        <div className="spec-row"><span className="k">{t('p_ordered')}</span><span className="v">{p.ordered} {pr.unit}</span></div>
        <div className="spec-row"><span className="k">{t('p_received')}</span><span className="v">{p.received} {pr.unit}</span></div>
        <div className="spec-row" style={{ borderBottom: 'none' }}><span className="k">{t('p_to_source')}</span><span className="v" style={p.toSource ? { color: 'var(--warning)' } : undefined}>{p.toSource} {pr.unit}</span></div>
        <div className="tiny muted">{t('p_ship_to')} {locName(pr.destinationWarehouseId)} · <span className={'status-pill' + pill(pr.status)}>{t(statusKey(pr.status))}</span></div>
        <div className="spec-block-title">{t('supplier_options')}</div>
        {quotes.length ? quotes.map((qt) => (
          <div className="info-card" key={qt.id} style={{ marginBottom: 8, padding: '10px 14px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10 }}><b>{supName(qt.supplierId)}</b><b>{money(qt.unitPrice)} {qt.unit}</b></div>
            <div className="tiny muted">{[qt.leadTimeDays != null ? tf('lead_days', { n: qt.leadTimeDays }) : null, qt.availableQuantity != null ? tf('qty_available_quote', { qty: qt.availableQuantity }) : null,
              qt.quoteNumber ? t('quote_label') + ' ' + qt.quoteNumber : null, qt.validUntil ? tf('valid_until', { d: fmtDate(qt.validUntil) }) : null].filter(Boolean).join(' · ')}</div>
          </div>)) : <div className="tiny muted" style={{ marginBottom: 8 }}>{t('no_quotes_yet')}</div>}
        <div className="tiny muted" style={{ marginBottom: 10 }}>{t('quotes_manual_note')}</div>
        {canQuote ? <button className="btn btn-secondary" style={{ marginBottom: 10 }} onClick={() => PU.startQuote(pr.id)}>{t('add_quote')}</button> : null}
        {pos.length ? <><div className="spec-block-title">{t('p_linked_pos')}</div>
          {pos.map((po) => (
            <button key={po.id} className="profile-pick" onClick={() => PU.openPo(po.id)}>
              <div style={{ flex: 1, minWidth: 0 }}><div className="pname">{po.purchaseOrderNumber} · {po.supplierSnapshot.name}</div>
                <div className="pmeta">{t(poStatusKey(po.status))}{po.expectedDeliveryDate ? ' · ' + tf('expected_on', { d: fmtDate(po.expectedDeliveryDate) }) : ''}</div></div>
              <div className="chev"><Icon name="chev" /></div>
            </button>))}</> : null}
        {ui.purchasingError ? <div className="alert-banner" style={{ margin: '8px 0' }}><Icon name="alert" /><span>{ui.purchasingError}</span></div> : null}
        {canBuy && p.toSource > 0 ? <button className="btn btn-primary" style={{ marginTop: 8 }} onClick={() => PU.startPo(pr.id)}>{t('create_po')}</button> : null}
      </div>
    </Sheet>
  );
}

/* ---------- create a draft PO ---------- */
export function CreatePoSheet() {
  const u = ui.currentUser, d = ui.poDraft, pr = d && getRequirementById(d.requirementId);
  if (!pr) return null;
  const sups = getSuppliers(u), quotes = getQuotesForRequirement(u, pr.id);
  const qOf = (sid) => quotes.find((x) => x.supplierId === sid);
  // compatible requirements that could share this line: same material, unit and destination warehouse
  const others = requirementsVisibleTo(u).filter((x) => x.id !== pr.id && isOpenRequirement(x) && x.unit === pr.unit && x.destinationWarehouseId === pr.destinationWarehouseId &&
    variantCompatible(x.productVariantId, pr.productVariantId) && getRequirementProgress(x).toSource > 0);
  const total = (parseInt(d.quantity, 10) || 0) + Object.keys(d.extra).reduce((s, k) => s + (parseInt(d.extra[k], 10) || 0), 0) + (parseInt(d.overage, 10) || 0);
  const input = (id, key, value, mode, label) => (
    <div className="field" style={{ marginBottom: 12 }}><label htmlFor={id}>{label}</label>
      <input type={mode === 'date' ? 'date' : 'text'} inputMode={mode === 'num' ? 'decimal' : undefined} id={id} value={value} onChange={(e) => PU.setPoDraft(key, e.target.value)} /></div>);
  return (
    <Sheet onClose={PU.closePoDraft} title={t('new_po_title')}>
      <div className="section-pad" style={{ paddingTop: 0 }}>
        <div style={{ fontWeight: 700 }}>{pr.productNameSnapshot}</div>
        <div className="tiny muted" style={{ marginBottom: 12 }}>{pr.requirementNumber} · {pr.requestId} · {tf('qty_needs_sourcing', { qty: getRequirementProgress(pr).toSource, unit: pr.unit })}</div>
        <div className="spec-block-title" style={{ marginTop: 0 }}>{t('choose_supplier')}</div>
        {sups.length ? sups.map((s) => (
          <button key={s.id} className="profile-pick" style={s.id === d.supplierId ? { borderColor: 'var(--ant-blue)', background: 'var(--ant-blue-tint)' } : undefined} onClick={() => PU.selectPoSupplier(s.id)}>
            <div style={{ flex: 1, minWidth: 0 }}><div className="pname">{s.name}{s.preferred ? ' · ' + t('preferred') : ''}</div>
              <div className="pmeta">{qOf(s.id) ? money(qOf(s.id).unitPrice) + ' ' + pr.unit + (qOf(s.id).leadTimeDays != null ? ' · ' + tf('lead_days', { n: qOf(s.id).leadTimeDays }) : '') : t('no_quote_for_supplier')}</div></div>
            {s.id === d.supplierId ? <Icon name="check" className="ico-sm" /> : null}
          </button>)) : <Empty icon="store" title={t('no_suppliers_yet')}><div>{t('add_supplier_first')}</div></Empty>}
        {input('po-qty', 'quantity', d.quantity, 'num', tf('po_qty_for', { req: pr.requirementNumber, unit: pr.unit }))}
        {others.length ? <><div className="spec-block-title">{t('combine_requirements')}</div>
          {others.map((x) => { const on = d.extra[x.id] != null, rx = req(x.requestId); return (
            <label key={x.id} className="checkline" style={{ padding: '6px 0' }}>
              <input type="checkbox" checked={on} onChange={() => PU.toggleExtraRequirement(x.id)} />
              <span className="small">{x.requirementNumber} · {rx ? requestProjectName(rx) : ''} · {tf('qty_needs_sourcing', { qty: getRequirementProgress(x).toSource, unit: x.unit })}</span>
            </label>); })}</> : null}
        {input('po-price', 'unitPrice', d.unitPrice, 'num', tf('unit_price_per', { unit: pr.unit }))}
        {input('po-overage', 'overage', d.overage, 'num', t('stock_overage_label'))}
        <div className="tiny muted" style={{ marginTop: -6, marginBottom: 12 }}>{t('stock_overage_note')}</div>
        {input('po-expected', 'expected', d.expected, 'date', t('expected_delivery'))}
        <div className="spec-row" style={{ borderBottom: 'none' }}><span className="k">{t('line_total_label')}</span><span className="v">{total} {pr.unit}{d.unitPrice !== '' ? ' · ' + money(total * Number(d.unitPrice)) : ''}</span></div>
        {d.error ? <div className="alert-banner" style={{ margin: '0 0 12px' }}><Icon name="alert" /><span>{d.error}</span></div> : null}
        <button className="btn btn-primary" disabled={!d.supplierId} onClick={PU.createPoFromDraft}>{t('create_draft_po')}</button>
        <div className="tiny muted" style={{ marginTop: 8 }}>{t('draft_not_on_order_note')}</div>
      </div>
    </Sheet>
  );
}

/* ---------- purchase orders ---------- */
const PO_FILTERS = [['ALL', 'pf_all'], ['DRAFT', 'pos_draft'], ['SENT', 'pos_sent'], ['CONFIRMED', 'pos_confirmed'], ['PARTIAL', 'pos_partially_received'], ['BACKORDERED', 'pos_backordered'], ['LATE', 'pos_late'], ['RECEIVED', 'pos_received']];
function PoCard({ po }) {
  const late = isPurchaseOrderLate(po);
  return (
    <button className="info-card" data-po={po.id} style={{ width: '100%', textAlign: 'left', marginBottom: 10, display: 'block' }} onClick={() => PU.openPo(po.id)}>
      <span style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 }}>
        <span style={{ fontWeight: 800, fontSize: 16, color: 'var(--ink)' }}>{po.purchaseOrderNumber}</span>
        <span style={{ fontWeight: 800, color: 'var(--ink)' }}>{canUser(ui.currentUser, CAP.VIEW_PURCHASE_PRICES) ? money(po.total) : ''}</span>
      </span>
      <span className="small" style={{ display: 'block', fontWeight: 600, color: 'var(--ink-soft)', marginTop: 2 }}>{po.supplierSnapshot.name}</span>
      <span className="tiny muted" style={{ display: 'block', marginTop: 2 }}>{tf(po.items.length === 1 ? 'n_lines_one' : 'n_lines', { n: po.items.length })}{po.expectedDeliveryDate ? ' · ' + tf('expected_on', { d: fmtDate(po.expectedDeliveryDate) }) : ''}</span>
      <span style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
        <span className={'status-pill' + pill(po.status)}>{t(poStatusKey(po.status))}</span>
        {late ? <span className="status-pill status-warning">{t('pos_late')}</span> : null}
      </span>
    </button>
  );
}
export function PurchaseOrders() {
  const f = ui.pPoFilter || 'ALL';
  const all = getPurchaseOrders(ui.currentUser);
  const list = f === 'LATE' ? all.filter((p) => isPurchaseOrderLate(p)) : getPurchaseOrders(ui.currentUser, { status: f });
  return (
    <>
      <div className="app-header"><div><div className="htitle">{t('purchase_orders')}</div><div className="hsub">{tf(all.length === 1 ? 'n_pos_one' : 'n_pos', { n: all.length })}</div></div></div>
      <div className="content">
        <div className="tab-row" style={{ marginTop: 14, marginBottom: 12 }}>
          {PO_FILTERS.map(([k, key]) => <button key={k} className={'chip' + (f === k ? ' on' : '')} style={{ whiteSpace: 'nowrap', flexShrink: 0 }} onClick={() => PU.setPoFilter(k)}>{t(key)}</button>)}
        </div>
        <div className="section-pad" style={{ paddingTop: 0 }}>
          {list.length ? list.map((po) => <PoCard key={po.id} po={po} />) : <Empty icon="orders" title={all.length ? t('no_matching_pos') : t('no_pos_yet')} />}
        </div>
      </div>
      <PurchasingNav active="pos" />
    </>
  );
}
export function PoSheet() {
  const u = ui.currentUser, po = getPurchaseOrder(u, ui.poId);
  if (!po) return null;
  const e = ui.poEdit || {}, draft = po.status === 'DRAFT', active = ['SENT', 'CONFIRMED', 'PARTIALLY_RECEIVED', 'BACKORDERED'].indexOf(po.status) !== -1;
  const prices = canUser(u, CAP.VIEW_PURCHASE_PRICES), warnings = commitmentWarnings(u).filter((w) => w.purchaseOrder.id === po.id);
  const numIn = (id, key, value, label, type) => (
    <div className="field" style={{ marginBottom: 10 }}><label htmlFor={id}>{label}</label>
      <input type={type || 'text'} inputMode={type ? undefined : 'decimal'} id={id} value={value == null ? '' : value} onChange={(ev) => PU.setPoEdit(key, ev.target.value)} /></div>);
  return (
    <Sheet onClose={PU.closePo} title={po.purchaseOrderNumber}>
      <div className="section-pad" style={{ paddingTop: 0 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, marginBottom: 6 }}>
          <div style={{ fontWeight: 800, fontSize: 17 }}>{po.supplierSnapshot.name}</div>
          <span style={{ display: 'flex', gap: 6 }}><span className={'status-pill' + pill(po.status)}>{t(poStatusKey(po.status))}</span>{isPurchaseOrderLate(po) ? <span className="status-pill status-warning">{t('pos_late')}</span> : null}</span>
        </div>
        <div className="spec-row"><span className="k">{t('p_ship_to')}</span><span className="v">{locName(po.shipToWarehouseId)}</span></div>
        <div className="spec-row"><span className="k">{t('buyer')}</span><span className="v">{userName(po.buyerUserId)}</span></div>
        <div className="spec-row"><span className="k">{t('created_label')}</span><span className="v">{fmtDate(new Date(po.createdAt).toISOString())}</span></div>
        {po.sentAt ? <div className="spec-row"><span className="k">{t('marked_sent')}</span><span className="v">{fmtDate(new Date(po.sentAt).toISOString())}</span></div> : null}
        {po.confirmedAt ? <div className="spec-row"><span className="k">{t('confirmed_label')}</span><span className="v">{fmtDate(new Date(po.confirmedAt).toISOString())}{po.supplierConfirmationNumber ? ' · ' + po.supplierConfirmationNumber : ''}</span></div> : null}
        <div className="spec-row" style={{ borderBottom: 'none' }}><span className="k">{t('expected_delivery')}</span><span className="v">{po.expectedDeliveryDate ? fmtDate(po.expectedDeliveryDate) : '—'}</span></div>
        {warnings.map((w) => <div key={w.link.supplierAllocationId} className="alert-banner" style={{ background: 'var(--warning-bg)', color: 'var(--warning)', margin: '6px 0' }}><Icon name="alert" className="ico-md" />
          <span>{tf('commitment_warning', { qty: w.quantity, unit: w.item.unit, po: po.purchaseOrderNumber, req: w.requestId })}</span></div>)}
        <div className="spec-block-title">{t('lines_label')}</div>
        {po.items.map((it) => { const lp = lineProgress(po, it); return (
          <div className="info-card" key={it.id} style={{ marginBottom: 10 }}>
            <div style={{ fontWeight: 700 }}>{it.productNameSnapshot}</div>
            <div className="spec-row"><span className="k">{t('p_ordered')}</span><span className="v">{it.quantityOrdered} {it.unit}{prices ? ' × ' + money(it.unitPrice) + ' = ' + money(it.lineSubtotal) : ''}</span></div>
            {!draft ? <><div className="spec-row"><span className="k">{t('p_received')}</span><span className="v">{lp.good} {it.unit}{lp.damaged ? ' · ' + tf('qty_damaged', { qty: lp.damaged }) : ''}</span></div>
              <div className="spec-row"><span className="k">{t('p_remaining')}</span><span className="v">{lp.remaining} {it.unit}{lp.backordered ? ' · ' + tf('qty_backordered', { qty: lp.backordered }) : ''}</span></div>
              {lp.cancelled ? <div className="spec-row"><span className="k">{t('p_cancelled')}</span><span className="v">{lp.cancelled} {it.unit}</span></div> : null}</> : null}
            {it.demandLinks.map((l) => { const rx = req(l.requestId); return (
              <div key={l.supplierAllocationId} className="tiny" style={{ marginTop: 6, display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                <span className="muted">{l.requestId} · {rx ? requestProjectName(rx) : ''}</span>
                {draft ? <input type="text" inputMode="numeric" aria-label={l.requestId + ' quantity'} id={'dl-' + l.supplierAllocationId} style={{ width: 70, minHeight: 36, border: '1.5px solid var(--line)', borderRadius: 8, textAlign: 'center' }}
                  value={e['qty:' + l.supplierAllocationId] != null ? e['qty:' + l.supplierAllocationId] : l.quantity} onChange={(ev) => PU.setPoEdit('qty:' + l.supplierAllocationId, ev.target.value)} />
                  : <b>{l.quantity} {it.unit}</b>}
              </div>); })}
            {it.stockOverageQuantity ? <div className="tiny" style={{ marginTop: 6, display: 'flex', justifyContent: 'space-between' }}><span className="muted">{t('for_stock')}</span><b>{it.stockOverageQuantity} {it.unit}</b></div> : null}
            {draft && prices ? numIn('price-' + it.id, 'price:' + it.id, e['price:' + it.id] != null ? e['price:' + it.id] : it.unitPrice, tf('unit_price_per', { unit: it.unit })) : null}
            {active && lp.remaining > 0 && canUser(u, CAP.MANAGE_BACKORDERS) ? <div style={{ marginTop: 10 }}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
                <div style={{ flex: 1 }}>{numIn('bo-' + it.id, 'bo:' + it.id, e['bo:' + it.id] != null ? e['bo:' + it.id] : lp.backordered || '', t('backorder_qty'))}</div>
                <div style={{ flex: 1 }}>{numIn('bod-' + it.id, 'boDate:' + it.id, e['boDate:' + it.id] != null ? e['boDate:' + it.id] : it.backorderExpectedDate || '', t('new_expected_date'), 'date')}</div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-secondary btn-sm" style={{ flex: 1 }} onClick={() => PU.backorderLine(po.id, it.id)}>{t('mark_backordered')}</button>
                {lp.backordered ? <button className="btn btn-secondary btn-sm" style={{ flex: 1 }} onClick={() => PU.releaseBackorder(po.id, it.id)}>{t('release_backorder')}</button> : null}
              </div>
            </div> : null}
          </div>); })}
        {prices ? <div className="info-card" style={{ marginBottom: 10 }}>
          <div className="spec-row"><span className="k">{t('subtotal')}</span><span className="v">{money(po.subtotal)}</span></div>
          {draft ? <>{numIn('po-shipping', 'shipping', e.shipping != null ? e.shipping : po.shipping, t('shipping'))}{numIn('po-tax', 'tax', e.tax != null ? e.tax : po.tax, t('tax'))}</>
            : <><div className="spec-row"><span className="k">{t('shipping')}</span><span className="v">{money(po.shipping)}</span></div><div className="spec-row"><span className="k">{t('tax')}</span><span className="v">{money(po.tax)}</span></div></>}
          <div className="spec-row" style={{ borderBottom: 'none' }}><span className="k"><b>{t('total')}</b></span><span className="v">{money(po.total)}</span></div>
          <div className="tiny muted">{t('procurement_not_accounting')}</div>
        </div> : null}
        {receiptsForPo(po.id).length ? <><div className="spec-block-title">{t('receipts_label')}</div>
          {receiptsForPo(po.id).map((rc) => <div key={rc.id} className="spec-row"><span className="k">{rc.receiptNumber} · {fmtDate(new Date(rc.receivedAt).toISOString())}</span>
            <span className="v">{rc.items.reduce((s, x) => s + x.quantityReceivedGood, 0)}{rc.items.some((x) => x.quantityReceivedDamaged) ? ' · ' + tf('qty_damaged', { qty: rc.items.reduce((s, x) => s + (x.quantityReceivedDamaged || 0), 0) }) : ''}{(rc.issues || []).some((x) => x.type === 'WRONG_MATERIAL') ? ' · ' + t('wrong_material') : ''}</span></div>)}</> : null}
        {ui.purchasingError ? <div className="alert-banner" style={{ margin: '8px 0' }}><Icon name="alert" /><span>{ui.purchasingError}</span></div> : null}
        {draft ? <>
          {numIn('po-exp', 'expected', e.expected != null ? e.expected : po.expectedDeliveryDate || '', t('expected_delivery'), 'date')}
          {canUser(u, CAP.EDIT_DRAFT_PURCHASE_ORDER) ? <button className="btn btn-secondary" style={{ marginBottom: 10 }} onClick={() => PU.saveDraft(po.id)}>{t('save_draft')}</button> : null}
          {canUser(u, CAP.SEND_PURCHASE_ORDER) ? <button className="btn btn-primary" style={{ marginBottom: 6 }} onClick={() => PU.sendPo(po.id)}>{t('mark_as_sent')}</button> : null}
          <div className="tiny muted" style={{ marginBottom: 10 }}>{t('mark_sent_note')}</div>
        </> : null}
        {active && !po.confirmedAt && canUser(u, CAP.CONFIRM_PURCHASE_ORDER) ? <div className="info-card" style={{ marginBottom: 10 }}>
          {numIn('conf-no', 'confNo', e.confNo || '', t('supplier_confirmation_no'))}
          {numIn('conf-exp', 'confExpected', e.confExpected || '', t('confirmed_expected_date'), 'date')}
          <button className="btn btn-primary" onClick={() => PU.confirmPo(po.id)}>{t('mark_confirmed')}</button>
        </div> : null}
        {(draft || active) && canUser(u, CAP.CANCEL_PURCHASE_ORDER) ? <button className="btn btn-danger" onClick={() => PU.cancelPo(po.id)}>{draft ? t('cancel_draft') : t('cancel_remaining')}</button> : null}
      </div>
    </Sheet>
  );
}

/* ---------- suppliers ---------- */
export function Suppliers() {
  const u = ui.currentUser, list = getSuppliers(u, { search: ui.supplierSearch, includeInactive: true });
  return (
    <>
      <div className="app-header" style={{ flexDirection: 'column', alignItems: 'stretch', gap: 14 }}>
        <div><div className="htitle">{t('suppliers_title')}</div><div className="hsub">{t('suppliers_sub')}</div></div>
        <div className="searchbar"><Icon name="search" /><input type="text" id="supplier-search-input" value={ui.supplierSearch || ''} placeholder={t('supplier_search_placeholder')} aria-label={t('supplier_search_placeholder')} onChange={(e) => PU.setSupplierSearch(e.target.value)} /></div>
      </div>
      <div className="content"><div className="section-pad">
        {canUser(u, CAP.MANAGE_SUPPLIERS) ? <button className="btn btn-primary" style={{ marginBottom: 14 }} onClick={() => PU.openSupplier('new')}><Icon name="plus" /> {t('add_supplier')}</button> : null}
        {list.length ? list.map((s) => (
          <button key={s.id} className="info-card" data-supplier={s.id} style={{ width: '100%', textAlign: 'left', marginBottom: 10, display: 'block' }} onClick={() => PU.openSupplier(s.id)}>
            <span style={{ display: 'flex', justifyContent: 'space-between', gap: 10 }}><span style={{ fontWeight: 800, fontSize: 16, color: 'var(--ink)' }}>{s.name}</span>
              <span>{s.preferred ? <span className="badge badge-current">{t('preferred')}</span> : null}{s.status !== 'ACTIVE' ? <span className="status-pill">{t('inactive')}</span> : null}</span></span>
            <span className="tiny muted" style={{ display: 'block', marginTop: 4 }}>{[s.contactName, s.phone, s.email, s.accountNumber ? t('account_short') + ' ' + s.accountNumber : null].filter(Boolean).join(' · ') || t('no_contact_yet')}</span>
          </button>)) : <Empty icon="store" title={ui.supplierSearch ? t('no_matching_suppliers') : t('no_suppliers_yet')} />}
      </div></div>
      <PurchasingNav active="suppliers" />
    </>
  );
}
export function SupplierSheet() {
  const u = ui.currentUser, e = ui.supplierEdit; if (!e) return null;
  const s = e.id ? getSupplier(u, e.id) : null, can = canUser(u, CAP.MANAGE_SUPPLIERS);
  const f = (key, label, type) => (
    <div className="field" style={{ marginBottom: 10 }} key={key}><label htmlFor={'sup-' + key}>{label}</label>
      {type === 'area' ? <textarea id={'sup-' + key} value={e.form[key]} disabled={!can} onChange={(ev) => PU.setSupplierField(key, ev.target.value)} />
        : <input type={type || 'text'} id={'sup-' + key} value={e.form[key]} disabled={!can} onChange={(ev) => PU.setSupplierField(key, ev.target.value)} />}</div>);
  const recent = s ? getPurchaseOrdersForSupplier(u, s.id).slice(0, 5) : [];
  return (
    <Sheet onClose={PU.closeSupplier} title={s ? s.name : t('add_supplier')}>
      <div className="section-pad" style={{ paddingTop: 0 }}>
        {f('name', t('supplier_name'))}{f('contactName', t('contact_name'))}{f('phone', t('phone_label'), 'tel')}{f('email', t('email_label'), 'email')}
        {f('accountNumber', t('account_number'))}{f('paymentTerms', t('payment_terms'))}{f('defaultLeadTimeDays', t('default_lead_time'))}
        {f('website', t('website'))}{f('address', t('address_label'))}{f('notes', t('notes_label'), 'area')}
        <label className="checkline"><input type="checkbox" checked={!!e.form.preferred} disabled={!can} onChange={(ev) => PU.setSupplierField('preferred', ev.target.checked)} /><span>{t('preferred_supplier')}</span></label>
        <div className="tiny muted" style={{ marginBottom: 12 }}>{t('preferred_note')}</div>
        {e.error ? <div className="alert-banner" style={{ margin: '0 0 12px' }}><Icon name="alert" /><span>{e.error}</span></div> : null}
        {can ? <button className="btn btn-primary" style={{ marginBottom: 10 }} onClick={PU.saveSupplier}>{s ? t('save_supplier') : t('add_supplier')}</button> : null}
        {s && can ? <button className="btn btn-secondary" onClick={() => PU.setSupplierActive(s.id, s.status !== 'ACTIVE')}>{s.status === 'ACTIVE' ? t('deactivate_supplier') : t('reactivate_supplier')}</button> : null}
        {recent.length ? <><div className="spec-block-title">{t('recent_pos')}</div>
          {recent.map((po) => <div key={po.id} className="spec-row"><span className="k">{po.purchaseOrderNumber}</span><span className="v">{t(poStatusKey(po.status))}</span></div>)}</> : null}
      </div>
    </Sheet>
  );
}
export function QuoteSheet() {
  const u = ui.currentUser, d = ui.quoteDraft; if (!d) return null;
  const pr = getRequirementById(d.requirementId), sups = getSuppliers(u);
  const f = (key, label, type) => (
    <div className="field" style={{ marginBottom: 10 }} key={key}><label htmlFor={'q-' + key}>{label}</label>
      <input type={type || 'text'} inputMode={type ? undefined : 'decimal'} id={'q-' + key} value={d[key]} onChange={(ev) => PU.setQuoteField(key, ev.target.value)} /></div>);
  return (
    <Sheet onClose={PU.closeQuote} title={t('add_quote')}>
      <div className="section-pad" style={{ paddingTop: 0 }}>
        <div className="tiny muted" style={{ marginBottom: 10 }}>{pr ? pr.requirementNumber + ' · ' + pr.productNameSnapshot : ''}</div>
        <div className="spec-block-title" style={{ marginTop: 0 }}>{t('choose_supplier')}</div>
        <div className="chiprow" style={{ marginBottom: 12 }}>{sups.map((s) => <button key={s.id} className={'chip' + (d.supplierId === s.id ? ' on' : '')} onClick={() => PU.setQuoteField('supplierId', s.id)}>{s.name}</button>)}</div>
        {f('unitPrice', tf('unit_price_per', { unit: pr ? pr.unit : '' }))}{f('leadTimeDays', t('lead_time_days'))}{f('availableQuantity', t('available_quantity_quote'))}
        <div className="field" style={{ marginBottom: 10 }}><label htmlFor="q-quoteNumber">{t('quote_number')}</label><input type="text" id="q-quoteNumber" value={d.quoteNumber} onChange={(ev) => PU.setQuoteField('quoteNumber', ev.target.value)} /></div>
        {f('validUntil', t('valid_until_label'), 'date')}
        <div className="tiny muted" style={{ marginBottom: 12 }}>{t('quotes_manual_note')}</div>
        {d.error ? <div className="alert-banner" style={{ margin: '0 0 12px' }}><Icon name="alert" /><span>{d.error}</span></div> : null}
        <button className="btn btn-primary" disabled={!d.supplierId} onClick={PU.saveQuote}>{t('save_quote')}</button>
      </div>
    </Sheet>
  );
}
export function PurchasingProfile() {
  const u = ui.currentUser, company = getCompany(u.companyId);
  return (
    <>
      <div className="app-header"><div className="htitle">{t('profile')}</div></div>
      <div className="content section-pad">
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 22 }}>
          <div className="avatar" style={{ width: 56, height: 56, fontSize: 18 }}>{initials(u.name)}</div>
          <div><div style={{ fontWeight: 800, fontSize: 17 }}>{u.name}</div><div className="muted small">{userRoleLabel(u)}</div></div>
        </div>
        <div className="info-card">
          <div className="spec-row"><span className="k">{t('work_area')}</span><span className="v">{t('purchasing_area')}</span></div>
          <div className="spec-row"><span className="k">{t('company_label')}</span><span className="v">{company ? company.name : '—'}</span></div>
          <div className="spec-row"><span className="k">{t('email_label')}</span><span className="v">{u.email}</span></div>
          <div className="spec-row" style={{ borderBottom: 'none' }}><span className="k">{t('phone_label')}</span><span className="v">{u.phone}</span></div>
        </div>
        <Preferences />
        <div style={{ height: 24 }} />
        <button className="btn btn-danger" onClick={A.logout}><Icon name="logout" /> {t('log_out')}</button>
      </div>
      <PurchasingNav active="profile" />
    </>
  );
}
