/* =========================================================================
   AUDIT EVENTS — a structured record of meaningful actions, for the future
   Audit Trail. Recorded today: sign-in, sign-out, project switch, project
   created, request submitted, request status changed, team member added,
   permission changed, delivery confirmed / issue reported, inventory
   adjusted, request line picked / un-picked / marked short. Events carry
   ids (who, which company, project and record) plus before / after.

   Deliberately NOT recorded: every tap, keystroke or stepper press.
   (The human-readable project timeline users see is the separate `activity`
   feed; this is the machine-readable record behind it.)
   ========================================================================= */
import { db, uid, now } from '../lib/db.js';
import { ui } from '../lib/store.js';

export const AUDIT_ACTIONS = {
  LOGIN: 'LOGIN', LOGOUT: 'LOGOUT', PROJECT_SWITCHED: 'PROJECT_SWITCHED', PROJECT_CREATED: 'PROJECT_CREATED',
  MATERIAL_REQUEST_SUBMITTED: 'MATERIAL_REQUEST_SUBMITTED', REQUEST_STATUS_CHANGED: 'REQUEST_STATUS_CHANGED',
  TEAM_MEMBER_ADDED: 'TEAM_MEMBER_ADDED', PERMISSION_CHANGED: 'PERMISSION_CHANGED',
  DELIVERY_CONFIRMED: 'DELIVERY_CONFIRMED', DELIVERY_ISSUE_REPORTED: 'DELIVERY_ISSUE_REPORTED',
  INVENTORY_ADJUSTED: 'INVENTORY_ADJUSTED', REQUEST_ITEM_PICKED: 'REQUEST_ITEM_PICKED',
  REQUEST_ITEM_UNPICKED: 'REQUEST_ITEM_UNPICKED', REQUEST_ITEM_MARKED_SHORT: 'REQUEST_ITEM_MARKED_SHORT',
  // Phase 2 Material Ledger (one event per meaningful action; ids of the movements it posted)
  MATERIAL_MOVEMENT_CREATED: 'MATERIAL_MOVEMENT_CREATED', MATERIAL_PICKED: 'MATERIAL_PICKED', MATERIAL_UNPICKED: 'MATERIAL_UNPICKED',
  MATERIAL_PACKED: 'MATERIAL_PACKED', MATERIAL_UNPACKED: 'MATERIAL_UNPACKED', INVENTORY_LEDGER_STARTED: 'INVENTORY_LEDGER_STARTED',
  // Phase 3: requests, approvals, allocation
  DUPLICATE_WARNING_SHOWN: 'DUPLICATE_WARNING_SHOWN', DUPLICATE_WARNING_OVERRIDDEN: 'DUPLICATE_WARNING_OVERRIDDEN',
  APPROVAL_REQUEST_CREATED: 'APPROVAL_REQUEST_CREATED', MATERIAL_REQUEST_APPROVED: 'MATERIAL_REQUEST_APPROVED', MATERIAL_REQUEST_REJECTED: 'MATERIAL_REQUEST_REJECTED',
  MATERIAL_REQUEST_CANCELLED: 'MATERIAL_REQUEST_CANCELLED', ALLOCATION_CREATED: 'ALLOCATION_CREATED', ALLOCATION_MODIFIED: 'ALLOCATION_MODIFIED',
  ALLOCATION_RELEASED: 'ALLOCATION_RELEASED', MATERIAL_RESERVED: 'MATERIAL_RESERVED', MATERIAL_UNRESERVED: 'MATERIAL_UNRESERVED',
  FULFILLMENT_CREATED: 'FULFILLMENT_CREATED', FULFILLMENT_STATUS_CHANGED: 'FULFILLMENT_STATUS_CHANGED', REQUEST_ALLOCATION_STARTED: 'REQUEST_ALLOCATION_STARTED',
  // Phase 3 correction pass
  APPROVAL_STEP_COMPLETED: 'APPROVAL_STEP_COMPLETED', APPROVAL_STEP_ACTIVATED: 'APPROVAL_STEP_ACTIVATED', WAREHOUSE_ALLOCATION_REOPENED: 'WAREHOUSE_ALLOCATION_REOPENED',
  FULFILLMENT_CREATED_FOR_OUTSTANDING_DEMAND: 'FULFILLMENT_CREATED_FOR_OUTSTANDING_DEMAND', REQUEST_SUBMISSION_IDEMPOTENCY_CONFLICT: 'REQUEST_SUBMISSION_IDEMPOTENCY_CONFLICT',
  // Phase 4 purchasing
  PURCHASE_REQUIREMENT_CREATED: 'PURCHASE_REQUIREMENT_CREATED', PURCHASE_REQUIREMENT_RELEASED: 'PURCHASE_REQUIREMENT_RELEASED',
  SUPPLIER_CREATED: 'SUPPLIER_CREATED', SUPPLIER_UPDATED: 'SUPPLIER_UPDATED', SUPPLIER_QUOTE_ADDED: 'SUPPLIER_QUOTE_ADDED',
  PURCHASE_ORDER_CREATED: 'PURCHASE_ORDER_CREATED', PURCHASE_ORDER_DRAFT_UPDATED: 'PURCHASE_ORDER_DRAFT_UPDATED', PURCHASE_ORDER_SENT: 'PURCHASE_ORDER_SENT',
  PURCHASE_ORDER_CONFIRMED: 'PURCHASE_ORDER_CONFIRMED', PURCHASE_ORDER_BACKORDERED: 'PURCHASE_ORDER_BACKORDERED', PURCHASE_ORDER_BACKORDER_RELEASED: 'PURCHASE_ORDER_BACKORDER_RELEASED',
  PURCHASE_ORDER_CANCELLED: 'PURCHASE_ORDER_CANCELLED', PURCHASE_RECEIPT_POSTED: 'PURCHASE_RECEIPT_POSTED', PURCHASE_RECEIPT_ISSUE_REPORTED: 'PURCHASE_RECEIPT_ISSUE_REPORTED',
  SUPPLIER_ALLOCATION_CREATED: 'SUPPLIER_ALLOCATION_CREATED', SUPPLIER_ALLOCATION_RELEASED: 'SUPPLIER_ALLOCATION_RELEASED',
  PURCHASED_MATERIAL_CONVERTED_TO_WAREHOUSE_ALLOCATION: 'PURCHASED_MATERIAL_CONVERTED_TO_WAREHOUSE_ALLOCATION', PURCHASING_STARTED: 'PURCHASING_STARTED',
};

// `actor` defaults to whoever is signed in. opts.coalesceWithinMs folds a
// burst of the same edit (same person, same action, same record) into one
// event whose `after` is the final value, so typing "42" is one event, not two.
export function recordAudit(e, actor, opts) {
  const u = actor || ui.currentUser;
  const last = db.AUDIT_EVENTS[0];
  if (opts && opts.coalesceWithinMs && last && u && last.userId === u.id && last.action === e.action &&
      last.entityType === (e.entityType || null) && last.entityId === (e.entityId || null) && now() - last.timestamp <= opts.coalesceWithinMs) {
    last.after = e.after === undefined ? null : e.after;
    last.timestamp = now();
    return last;
  }
  const ev = {
    id: uid('aud'), companyId: e.companyId || (u && u.companyId) || null,
    userId: u ? u.id : null, userRole: u ? u.primaryRole || null : null,
    actorType: u && u.system ? 'SYSTEM' : u ? 'USER' : null,   // SYSTEM = ANT itself (e.g. automatic allocation)
    action: e.action, entityType: e.entityType || null, entityId: e.entityId || null,
    projectId: e.projectId || null, locationId: e.locationId || null,
    before: e.before === undefined ? null : e.before, after: e.after === undefined ? null : e.after,
    timestamp: now(),
  };
  db.AUDIT_EVENTS.unshift(ev);   // newest first; storage keeps the latest 1,000
  return ev;
}
export const auditForEntity = (entityType, entityId) => db.AUDIT_EVENTS.filter((e) => e.entityType === entityType && e.entityId === entityId);
export const auditForProject = (projectId) => db.AUDIT_EVENTS.filter((e) => e.projectId === projectId);
export const recentAudit = (n) => db.AUDIT_EVENTS.slice(0, n || 50);
