/* =========================================================================
   SESSION — who is signed in, for which company, on which project.
   Stores ids only. Logging out clears the session and nothing else: company,
   project and request data stay exactly as they were.
   ========================================================================= */
import { ui } from '../lib/store.js';
import { getUser, getCompany, getProject } from './repo.js';
import { canViewProject, canUser, CAP } from '../lib/permissions.js';
import { projectsForUser } from './projectService.js';
import { saveAppData } from '../lib/db.js';

export const currentUser = () => (ui.session.currentUserId ? getUser(ui.session.currentUserId) : null);
export const currentCompany = () => getCompany(ui.session.currentCompanyId);
// The current project, but only if this user can still see it.
export function currentProject() {
  const u = currentUser();
  const p = getProject(ui.session.currentProjectId);
  return u && p && canViewProject(u, p.id) ? p : null;
}
export const currentProjectId = () => { const p = currentProject(); return p ? p.id : null; };
// Can the signed-in person request materials on the current project right now?
export const canRequestNow = () => { const p = currentProject(); return !!p && canUser(currentUser(), CAP.REQUEST_MATERIALS, { projectId: p.id }); };

// A valid project for this user: the remembered one if still allowed, else their first.
export function pickValidProject(user) {
  const remembered = getProject(user.lastProjectId);
  if (remembered && canViewProject(user, remembered.id)) return remembered;
  return projectsForUser(user.id)[0] || null;
}

// Anyone with project memberships gets a project context (field workers
// today; Project Managers and Superintendents too, once their screens exist).
export function startSession(user) {
  ui.session = { currentUserId: user.id, currentCompanyId: user.companyId, currentProjectId: null };
  const p = pickValidProject(user);
  if (p) setCurrentProject(p.id);
}
export function endSession() {
  ui.session = { currentUserId: null, currentCompanyId: null, currentProjectId: null };
}

// The ONE place the active project changes. Validates access, and remembers
// it on the user record (a preference for next sign-in, not a permission).
export function setCurrentProject(projectId) {
  const u = currentUser();
  const p = getProject(projectId);
  if (!u || !p || !canViewProject(u, p.id)) return false;
  ui.session = { ...ui.session, currentProjectId: p.id };
  u.lastProjectId = p.id;
  saveAppData();
  return true;
}
