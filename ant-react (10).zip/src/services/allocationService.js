/* =========================================================================
   ALLOCATION SERVICE (Phase 3) — decides where requested demand is sourced.

   Phase 3 sources from ONE place: the project's assigned warehouse (no other
   warehouses, no other projects, no suppliers). For each line it allocates
   min(outstanding, AVAILABLE), primary bin first, then the other bins by
   name, one MaterialAllocation per bin, each backed by its own RESERVE
   movement (AVAILABLE -> RESERVED, same bin). Whatever can't be covered stays
   OUTSTANDING: never negative stock, never silently dropped.
   Changes are ledger movements too: more = RESERVE, less / release = UNRESERVE.
   ========================================================================= */
import { db, now } from '../lib/db.js';
import { canUser, CAP } from '../lib/permissions.js';
import { getProduct } from '../lib/catalog.js';
import { getProject, getCompany } from './repo.js';
import { postMovements, findOperation, reservedForAllocation } from './materialLedgerService.js';
import { stockVariantFor, inventoryItemFor } from './inventoryService.js';
import { recordAudit, AUDIT_ACTIONS } from './auditService.js';
import { activeAllocationsForItem, getOutstandingQuantity, refreshAllocationStatus, isActiveAllocation, allocationState, isWarehouseAllocation,
  supplierAllocationsForItem, isSupplierCommitted, supplierRemaining, getDemandCoverage } from './requestProgress.js';

const fail = (error, message, extra) => Object.assign({ error, message }, extra || {});
const loc = (id) => db.LOCATIONS.find((l) => l.id === id) || null;
function withinWarehouse(locationId, warehouseId) { let cur = loc(locationId), g = 0; while (cur && g++ < 20) { if (cur.id === warehouseId) return true; cur = loc(cur.parentLocationId); } return false; }
function nextAllocationId() { db.ALLOCATION_SEQ = (db.ALLOCATION_SEQ || 1000) + 1; return 'ALC-' + db.ALLOCATION_SEQ; }
export const newAllocationId = nextAllocationId;   // shared with purchasing (supplier allocations use the same id space)
/* Warehouse stock now covers demand a supplier PO had committed to (only after an
   explicit manager choice): that supplier coverage is SUPERSEDED, newest first, so
   warehouse + supplier never exceed the request. The PO is not changed; the units
   arrive as plain stock and Purchasing is warned they may no longer be needed. */
export function supersedeSupplierCoverage(item) {
  let excess = getDemandCoverage(item) - item.quantity;
  const out = [];
  supplierAllocationsForItem(item.id).filter(isSupplierCommitted).sort((a, b) => b.createdAt - a.createdAt).forEach((a) => {
    if (excess <= 0) return;
    const take = Math.min(excess, supplierRemaining(a));
    if (take <= 0) return;
    a.supersededQuantity = (a.supersededQuantity || 0) + take; a.updatedAt = now(); excess -= take;
    out.push({ allocation: a, quantity: take });
  });
  return out;
}
// WAREHOUSE allocations only (supplier sourcing lives in purchaseOrderService / requestProgress)
export const getAllocationsForRequest = (requestId) => (db.ALLOCATIONS || []).filter((a) => a.requestId === requestId && isWarehouseAllocation(a));
export const getAllocationsForRequestItem = (requestItemId) => (db.ALLOCATIONS || []).filter((a) => a.requestItemId === requestItemId && isWarehouseAllocation(a));
export const getOutstandingDemand = getOutstandingQuantity;
export const allocationById = (id) => (db.ALLOCATIONS || []).find((a) => a.id === id) || null;

// AVAILABLE stock this project may draw from: its assigned warehouse only.
export function availableForProject(project, vid) {
  const primary = (inventoryItemFor(project.companyId, vid) || {}).primaryLocationId;
  const name = (id) => (loc(id) || {}).name || '';
  return db.INVENTORY_BALANCES.filter((b) => b.companyId === project.companyId && b.productVariantId === vid && b.inventoryState === 'AVAILABLE' && b.quantity > 0 &&
    withinWarehouse(b.locationId, project.assignedWarehouseId))
    .sort((a, b) => (a.locationId === primary ? -1 : b.locationId === primary ? 1 : name(a.locationId).localeCompare(name(b.locationId))))
    .map((b) => ({ locationId: b.locationId, quantity: b.quantity }));
}
export function planAllocation(project, vid, want) {
  const parts = []; let left = want;
  availableForProject(project, vid).forEach((b) => { if (left <= 0) return; const q = Math.min(left, b.quantity); parts.push({ locationId: b.locationId, quantity: q }); left -= q; });
  return parts;
}
const actorInfo = (actor) => ({ createdByUserId: actor.system ? null : actor.id, actorType: actor.system ? 'SYSTEM' : 'USER' });
function canManage(actor, companyId) {
  if (actor.system) return actor.companyId === companyId;
  const c = getCompany(companyId);
  return actor.companyId === companyId && canUser(actor, CAP.MANAGE_ALLOCATIONS) && !!c && c.settings.allowManualAllocationAdjustment !== false;
}
function reserveDraft(a, qty, type) {
  const into = type === 'RESERVE';
  return { movementType: type, companyId: a.companyId, productVariantId: a.productVariantId, quantity: qty, unit: a.unit,
    fromLocationId: a.sourceLocationId, toLocationId: a.sourceLocationId, fromInventoryState: into ? 'AVAILABLE' : 'RESERVED', toInventoryState: into ? 'RESERVED' : 'AVAILABLE',
    projectId: a.projectId, requestId: a.requestId, requestItemId: a.requestItemId, allocationId: a.id, fulfillmentId: a.fulfillmentId || null };
}
const describeActor = (actor) => (actor.system ? { actorType: 'SYSTEM', source: actor.source, triggeredByUserId: actor.triggeredByUserId } : { actorType: 'USER' });

// One line: allocate what the warehouse can cover. Idempotent per company +
// "allocate:<request>:<line>[:round]": a retry never reserves twice.
export function allocateRequestItem(actor, r, item, opts) {
  const o = opts || {};
  const key = 'allocate:' + r.id + ':' + item.id + (o.round > 1 ? ':' + o.round : '');
  // permission BEFORE replay: a replay must never hand another company's results back
  if (!canManage(actor, r.companyId)) return fail('forbidden', 'Not allowed to allocate for this company');
  if (findOperation(r.companyId, key)) return { ok: true, duplicate: true, allocations: activeAllocationsForItem(item.id), allocated: 0 };
  const project = getProject(r.projectId);
  if (!project || project.companyId !== r.companyId) return fail('project_company', 'The project belongs to another company');
  // coverOnOrder (explicit manager choice): warehouse stock may also cover quantity a supplier
  // PO already committed; that commitment then shows as excess for Purchasing to decide on.
  const need = o.coverOnOrder ? Math.max(0, item.quantity - activeAllocationsForItem(item.id).reduce((n, x) => n + x.quantity, 0)) : getOutstandingQuantity(item, r);
  if (need <= 0) return { ok: true, allocations: [], allocated: 0 };
  const vid = stockVariantFor(r.companyId, item.productVariantId);
  const p = getProduct(vid);
  const parts = planAllocation(project, vid, Math.min(need, o.maxQuantity == null ? need : o.maxQuantity));
  if (!parts.length) return { ok: true, allocations: [], allocated: 0 };
  const t = now();
  const allocs = parts.map((part) => Object.assign({ id: nextAllocationId(), companyId: r.companyId, projectId: r.projectId, requestId: r.id, requestItemId: item.id,
    productVariantId: vid, sourceType: 'WAREHOUSE', sourceLocationId: part.locationId, warehouseId: project.assignedWarehouseId,
    quantity: part.quantity, releasedQuantity: 0, unit: p.unit, status: 'ALLOCATED', createdAt: t, updatedAt: t, fulfillmentId: null,
    metadata: Object.assign({ source: o.source || 'AUTO_ALLOCATION', round: o.round || 1 }, describeActor(actor)) }, actorInfo(actor)));
  db.ALLOCATIONS.push.apply(db.ALLOCATIONS, allocs);
  const res = postMovements(actor, allocs.map((a) => reserveDraft(a, a.quantity, 'RESERVE')),
    { operationKey: key, operationType: 'ALLOCATE_REQUEST_ITEM', entityType: 'MaterialRequestItem', entityId: item.id });
  if (res.error) { db.ALLOCATIONS = db.ALLOCATIONS.filter((a) => allocs.indexOf(a) === -1); return res; }
  allocs.forEach((a) => { a.status = 'RESERVED'; });
  const superseded = o.coverOnOrder ? supersedeSupplierCoverage(item) : [];
  const total = allocs.reduce((s, a) => s + a.quantity, 0);
  const base = { companyId: r.companyId, projectId: r.projectId };
  recordAudit(Object.assign({ action: AUDIT_ACTIONS.ALLOCATION_CREATED, entityType: 'MaterialAllocation', entityId: allocs[0].id, before: null,
    after: Object.assign({ allocationIds: allocs.map((a) => a.id), requestId: r.id, requestItemId: item.id, productVariantId: vid, quantity: total, requested: item.quantity,
      outstanding: getOutstandingQuantity(item, r) }, describeActor(actor)) }, base), actor);
  recordAudit(Object.assign({ action: AUDIT_ACTIONS.MATERIAL_RESERVED, entityType: 'MaterialMovement', entityId: res.movements[0].id, before: null,
    after: Object.assign({ movementIds: res.movements.map((m) => m.id), allocationIds: allocs.map((a) => a.id), requestId: r.id, requestItemId: item.id, productVariantId: vid,
      quantity: total, locationIds: allocs.map((a) => a.sourceLocationId) }, describeActor(actor)) }, base), actor);
  if (superseded.length) recordAudit(Object.assign({ action: AUDIT_ACTIONS.SUPPLIER_ALLOCATION_RELEASED, entityType: 'MaterialAllocation', entityId: superseded[0].allocation.id, before: null,
    after: { reason: 'SUPERSEDED_BY_WAREHOUSE_STOCK', allocationIds: superseded.map((x) => x.allocation.id), quantities: superseded.map((x) => x.quantity), requestId: r.id, requestItemId: item.id,
      purchaseOrderIds: superseded.map((x) => x.allocation.purchaseOrderId), poUnchanged: true } }, base), actor);
  return { ok: true, allocations: allocs, allocated: total, movements: res.movements, superseded };
}

export function allocateRequest(actor, r, opts) {
  const byItem = {}; let allocations = [];
  for (const it of r.items) {
    const res = allocateRequestItem(actor, r, it, opts);
    if (res.error) return res;
    byItem[it.id] = res; allocations = allocations.concat(res.duplicate ? [] : res.allocations);
  }
  refreshRequestAllocationStatus(r);
  return { ok: true, allocations, byItem };
}
export function refreshRequestAllocationStatus(r) {
  const allocated = r.items.reduce((s, it) => s + activeAllocationsForItem(it.id).reduce((a, x) => a + x.quantity, 0), 0);
  const outstanding = r.items.reduce((s, it) => s + getOutstandingQuantity(it, r), 0);
  const any = getAllocationsForRequest(r.id).length > 0;
  r.allocationStatus = allocated === 0 ? (any ? 'RELEASED' : 'UNALLOCATED') : outstanding > 0 ? 'PARTIALLY_ALLOCATED' : 'ALLOCATED';
  return r.allocationStatus;
}

// Release (part of) what an allocation still has RESERVED. Picked stock can't be released this way.
export function releaseAllocation(actor, allocationId, opts) {
  const o = opts || {};
  const a = allocationById(allocationId);
  if (!a || !isActiveAllocation(a)) return fail('not_found', 'No active allocation');
  if (!canManage(actor, a.companyId)) return fail('forbidden', 'Not allowed to change this allocation');
  const reserved = reservedForAllocation(a.id);
  const qty = o.quantity == null ? reserved : Number(o.quantity);
  if (!(qty > 0)) return fail('invalid_quantity', 'Nothing reserved to release');
  if (qty > reserved) return fail('cannot_release_picked', 'Only ' + reserved + ' ' + a.unit + ' are still reserved; picked material needs a warehouse correction');
  const res = postMovements(actor, [Object.assign(reserveDraft(a, qty, 'UNRESERVE'), { reasonCode: o.reasonCode || null })], { operationKey: o.operationKey, operationType: 'RELEASE_ALLOCATION', entityType: 'MaterialAllocation', entityId: a.id });
  if (res.error || res.duplicate) return res;
  const before = a.quantity;
  a.quantity -= qty; a.releasedQuantity = (a.releasedQuantity || 0) + qty; a.updatedAt = now();
  refreshAllocationStatus(a);
  const base = { companyId: a.companyId, projectId: a.projectId };
  recordAudit(Object.assign({ action: AUDIT_ACTIONS.ALLOCATION_RELEASED, entityType: 'MaterialAllocation', entityId: a.id, before: { quantity: before },
    after: Object.assign({ quantity: a.quantity, released: qty, requestId: a.requestId, requestItemId: a.requestItemId, movementIds: res.movements.map((m) => m.id), reason: o.reason || null }, describeActor(actor)) }, base), actor);
  recordAudit(Object.assign({ action: AUDIT_ACTIONS.MATERIAL_UNRESERVED, entityType: 'MaterialMovement', entityId: res.movements[0].id, before: null,
    after: Object.assign({ movementIds: res.movements.map((m) => m.id), allocationIds: [a.id], requestId: a.requestId, quantity: qty, locationIds: [a.sourceLocationId] }, describeActor(actor)) }, base), actor);
  return Object.assign(res, { allocation: a });
}

// Manager override: set an allocation to a new quantity (RESERVE / UNRESERVE the difference).
export function modifyAllocation(actor, allocationId, newQuantity, opts) {
  const a = allocationById(allocationId);
  if (!a || !isActiveAllocation(a)) return fail('not_found', 'No active allocation');
  if (!canManage(actor, a.companyId) || actor.system) return fail('forbidden', 'Only a warehouse manager can change an allocation');
  const q = Number(newQuantity);
  if (!isFinite(q) || q < 0 || Math.floor(q) !== q) return fail('invalid_quantity', 'Enter a whole quantity');
  const s = allocationState(a.id), consumed = s.PICKING + s.PACKED;
  if (q < consumed) return fail('below_picked', consumed + ' ' + a.unit + ' are already picked from this allocation');
  const delta = q - a.quantity;
  if (delta === 0) return { ok: true, allocation: a, movements: [] };
  if (delta < 0) return releaseAllocation(actor, a.id, Object.assign({}, opts, { quantity: -delta }));
  const r = db.REQUESTS.find((x) => x.id === a.requestId), item = r && r.items.find((i) => i.id === a.requestItemId);
  if (!item) return fail('not_found', 'Request line missing');
  if (delta > getOutstandingQuantity(item, r)) return fail('exceeds_demand', 'That would allocate more than was requested');
  const res = postMovements(actor, [reserveDraft(a, delta, 'RESERVE')], { operationKey: opts && opts.operationKey, operationType: 'MODIFY_ALLOCATION', entityType: 'MaterialAllocation', entityId: a.id });
  if (res.error || res.duplicate) return res;
  const before = a.quantity; a.quantity = q; a.updatedAt = now(); refreshAllocationStatus(a);
  const base = { companyId: a.companyId, projectId: a.projectId };
  recordAudit(Object.assign({ action: AUDIT_ACTIONS.ALLOCATION_MODIFIED, entityType: 'MaterialAllocation', entityId: a.id, before: { quantity: before },
    after: { quantity: q, requestId: a.requestId, requestItemId: a.requestItemId, movementIds: res.movements.map((m) => m.id) } }, base), actor);
  recordAudit(Object.assign({ action: AUDIT_ACTIONS.MATERIAL_RESERVED, entityType: 'MaterialMovement', entityId: res.movements[0].id, before: null,
    after: { movementIds: res.movements.map((m) => m.id), allocationIds: [a.id], requestId: a.requestId, quantity: delta, locationIds: [a.sourceLocationId] } }, base), actor);
  return Object.assign(res, { allocation: a });
}

// Manager: allocate from a specific bin of the project's warehouse (e.g. move part of an allocation to D-4).
// Call it through requestWorkflowService.managerAllocateFromLocation, which attaches the allocation to a batch.
export function allocateFromLocation(actor, r, item, locationId, quantity) {
  if (actor.system || !canManage(actor, r.companyId)) return fail('forbidden', 'Only a warehouse manager can allocate by hand');
  const project = getProject(r.projectId);
  if (!project || !withinWarehouse(locationId, project.assignedWarehouseId)) return fail('location_not_assigned_warehouse', 'Pick a bin in this project\'s warehouse');
  const q = Number(quantity);
  if (!(q > 0) || Math.floor(q) !== q) return fail('invalid_quantity', 'Enter a whole quantity');
  if (q > getOutstandingQuantity(item, r)) return fail('exceeds_demand', 'That would allocate more than was requested');
  const vid = stockVariantFor(r.companyId, item.productVariantId), p = getProduct(vid), t = now();
  const a = Object.assign({ id: nextAllocationId(), companyId: r.companyId, projectId: r.projectId, requestId: r.id, requestItemId: item.id, productVariantId: vid,
    sourceType: 'WAREHOUSE', sourceLocationId: locationId, warehouseId: project.assignedWarehouseId, quantity: q, releasedQuantity: 0, unit: p.unit, status: 'ALLOCATED',
    createdAt: t, updatedAt: t, fulfillmentId: null, metadata: { source: 'MANUAL_ALLOCATION', actorType: 'USER' } }, actorInfo(actor));
  db.ALLOCATIONS.push(a);
  const res = postMovements(actor, [reserveDraft(a, q, 'RESERVE')], { operationType: 'MANUAL_ALLOCATION', entityType: 'MaterialAllocation', entityId: a.id });
  if (res.error) { db.ALLOCATIONS = db.ALLOCATIONS.filter((x) => x !== a); return res; }
  a.status = 'RESERVED';
  const base = { companyId: a.companyId, projectId: a.projectId };
  recordAudit(Object.assign({ action: AUDIT_ACTIONS.ALLOCATION_CREATED, entityType: 'MaterialAllocation', entityId: a.id, before: null,
    after: { allocationIds: [a.id], requestId: r.id, requestItemId: item.id, productVariantId: vid, quantity: q, source: 'MANUAL_ALLOCATION' } }, base), actor);
  recordAudit(Object.assign({ action: AUDIT_ACTIONS.MATERIAL_RESERVED, entityType: 'MaterialMovement', entityId: res.movements[0].id, before: null,
    after: { movementIds: res.movements.map((m) => m.id), allocationIds: [a.id], requestId: r.id, quantity: q, locationIds: [locationId] } }, base), actor);
  refreshRequestAllocationStatus(r);
  return Object.assign(res, { allocation: a });
}

/* Phase 4: purchased material that just arrived at `locationId` becomes a
   warehouse allocation for the demand it was bought for (RESERVE at that very
   bin). Never more than the line still needs: the caller re-checks demand. */
export function allocateReceivedStock(actor, r, item, locationId, quantity, meta) {
  const q = Number(quantity);
  if (!(q > 0)) return { ok: true, allocation: null };
  const project = getProject(r.projectId);
  if (!project || !withinWarehouse(locationId, project.assignedWarehouseId)) return fail('location_not_assigned_warehouse', 'Received material is not in this project\'s warehouse');
  const vid = meta.productVariantId, p = getProduct(vid), t = now();
  const a = Object.assign({ id: nextAllocationId(), companyId: r.companyId, projectId: r.projectId, requestId: r.id, requestItemId: item.id, productVariantId: vid,
    sourceType: 'WAREHOUSE', sourceLocationId: locationId, warehouseId: project.assignedWarehouseId, quantity: q, releasedQuantity: 0, unit: p.unit, status: 'ALLOCATED',
    createdAt: t, updatedAt: t, fulfillmentId: null,
    metadata: Object.assign({ source: 'PURCHASE_RECEIPT' }, describeActor(actor), meta.links || {}) }, actorInfo(actor));
  db.ALLOCATIONS.push(a);
  const res = postMovements(actor, [reserveDraft(a, q, 'RESERVE')], { operationType: 'RESERVE_PURCHASED_STOCK', entityType: 'MaterialAllocation', entityId: a.id });
  if (res.error) { db.ALLOCATIONS = db.ALLOCATIONS.filter((x) => x !== a); return res; }
  a.status = 'RESERVED';
  recordAudit({ action: AUDIT_ACTIONS.ALLOCATION_CREATED, entityType: 'MaterialAllocation', entityId: a.id, companyId: a.companyId, projectId: a.projectId, before: null,
    after: Object.assign({ allocationIds: [a.id], requestId: r.id, requestItemId: item.id, productVariantId: vid, quantity: q, source: 'PURCHASE_RECEIPT' }, describeActor(actor)) }, actor);
  refreshRequestAllocationStatus(r);
  return Object.assign(res, { allocation: a });
}
