/* =========================================================================
   NOTIFICATIONS — in-app records for a future notification center.
   Nothing here is shown yet (feature flag `notificationsCenter` is off) and
   nothing is pushed to a phone. Toast messages work exactly as before.
   Created today: request submitted (to the company's warehouse managers),
   request shipped (to the requester), delivery issue (to warehouse managers).
   ========================================================================= */
import { db, uid, now } from '../lib/db.js';

export const NOTIFICATION_TYPES = { REQUEST_SUBMITTED: 'REQUEST_SUBMITTED', REQUEST_SHIPPED: 'REQUEST_SHIPPED', DELIVERY_ISSUE: 'DELIVERY_ISSUE',
  APPROVAL_REQUIRED: 'APPROVAL_REQUIRED', REQUEST_AWAITING_APPROVAL: 'REQUEST_AWAITING_APPROVAL', REQUEST_APPROVED: 'REQUEST_APPROVED',
  REQUEST_REJECTED: 'REQUEST_REJECTED', ALLOCATION_SUMMARY: 'ALLOCATION_SUMMARY', FULFILLMENT_CREATED: 'FULFILLMENT_CREATED',
  OUTSTANDING_DEMAND: 'OUTSTANDING_DEMAND', ADDITIONAL_ALLOCATION: 'ADDITIONAL_ALLOCATION',
  PURCHASE_REQUIREMENT_CREATED: 'PURCHASE_REQUIREMENT_CREATED', ON_ORDER: 'ON_ORDER', PURCHASE_ORDER_INCOMING: 'PURCHASE_ORDER_INCOMING',
  PURCHASE_ORDER_RECEIVED: 'PURCHASE_ORDER_RECEIVED', PURCHASE_RECEIPT_ISSUE: 'PURCHASE_RECEIPT_ISSUE', PURCHASED_MATERIAL_ARRIVED: 'PURCHASED_MATERIAL_ARRIVED' };

// Only ACTIVE users of the notification's own company can receive it. Any
// other id (unknown, inactive, another company) is skipped, never delivered.
export function notify(userIds, n) {
  const ok = (userId) => { const u = db.USERS.find((x) => x.id === userId); return !!u && u.status === 'ACTIVE' && !!n.companyId && u.companyId === n.companyId; };
  return (userIds || []).filter(Boolean).filter(ok).map((userId) => {
    const rec = { id: uid('ntf'), companyId: n.companyId, userId, type: n.type, title: n.title, message: n.message,
      entityType: n.entityType || null, entityId: n.entityId || null, projectId: n.projectId || null, read: false, createdAt: now() };
    db.NOTIFICATIONS.unshift(rec);
    return rec;
  });
}
export const notificationsForUser = (userId) => db.NOTIFICATIONS.filter((n) => n.userId === userId);
export const unreadCount = (userId) => db.NOTIFICATIONS.filter((n) => n.userId === userId && !n.read).length;
export function markRead(notificationId, userId) {
  const n = db.NOTIFICATIONS.find((x) => x.id === notificationId && x.userId === userId);
  if (n) n.read = true;
  return !!n;
}
