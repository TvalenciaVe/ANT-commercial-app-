/* =========================================================================
   PURCHASE ORDERS (Phase 4) — commercial orders to a supplier.

   DRAFT  internal and editable. Each demand link claims its requirement with a
          PROPOSED supplier allocation, so two drafts can't buy the same
          quantity. Not "on order" for the field, no inventory.
   SENT   ("Mark as Sent": ANT does not email anyone) the links become supplier
          COMMITMENTS (ORDERED). Refused if request coverage would exceed demand.
   after  quantities, prices and supplier are locked. Changes are explicit:
          confirm, backorder, release a backorder, cancel remaining. Released
          commitment reopens the requirement; the field never re-requests.
   A line = demand links (why it was bought: requirement / request / line /
   project / quantity) + an explicit stock overage (extra for stock, never
   linked to a request). Prices and supplier details are snapshots.
   ========================================================================= */
import { db, now } from '../lib/db.js';
import { canUser, CAP } from '../lib/permissions.js';
import { getProduct } from '../lib/catalog.js';
import { variantSnapshotFor } from '../lib/requestModel.js';
import { matchStockVariant } from '../lib/stockMatch.js';
import { transaction } from '../lib/transaction.js';
import { recordAudit, AUDIT_ACTIONS } from './auditService.js';
import { notify, NOTIFICATION_TYPES } from './notificationService.js';
import { getProject } from './repo.js';
import { getRequirementById, getRequirementProgress, refreshRequirementStatus, syncForRequest, isOpenRequirement } from './purchaseRequirementService.js';
import { supplierRemaining, getAllocatedQuantity, isSupplierCommitted, refreshRequestStatus, warehouseScopeFor, WAREHOUSE_SCOPE_DENIED, supplierAllocationsForItem } from './requestProgress.js';
import { newAllocationId, refreshRequestAllocationStatus } from './allocationService.js';
import { priorOperation, recordOperation, fingerprintOf } from './operationRecords.js';
import { RECEIVABLE_PO_STATUSES, PACKAGE_CONVERSIONS } from '../config/purchasing.js';
import { priorityWeight } from '../config/priorities.js';
import { systemActor } from './materialLedgerService.js';

const fail = (error, message, extra) => Object.assign({ error, message }, extra || {});
const round2 = (n) => Math.round(n * 100) / 100;
const int = (v) => (v === '' || v == null ? 0 : Number(v));
const isInt = (v) => Number.isInteger(v) && v >= 0;
function nextPo() { db.PO_SEQ = (db.PO_SEQ || 1000) + 1; return { id: 'po_' + db.PO_SEQ, number: 'PO-' + db.PO_SEQ }; }
export const poById = (id) => (db.PURCHASE_ORDERS || []).find((p) => p.id === id) || null;
export const getPurchaseOrder = (user, id) => { const po = poById(id); return po && user && po.companyId === user.companyId && canUser(user, CAP.VIEW_PURCHASE_ORDERS) ? po : null; };
export const receiptsForPo = (poId) => (db.PURCHASE_RECEIPTS || []).filter((r) => r.purchaseOrderId === poId);
export const allocOf = (link) => (db.ALLOCATIONS || []).find((a) => a.id === link.supplierAllocationId) || null;
const requestOf = (id) => db.REQUESTS.find((r) => r.id === id) || null;
const loc = (id) => db.LOCATIONS.find((l) => l.id === id) || null;
const isAnyVariant = (vid) => { const sel = String(vid || '').split('::')[1]; return !!sel && sel.split('~')[0].split('|').indexOf('Any') !== -1; };
// A PO line buys a CONCRETE variant; an "Any" requirement accepts any matching concrete one.
export const variantCompatible = (prVid, lineVid) => !isAnyVariant(lineVid) && (prVid === lineVid || (isAnyVariant(prVid) && matchStockVariant(prVid, [lineVid], () => 1) === lineVid));

/* ---------- reconciliation (derived, never counters) ---------- */
export function lineProgress(po, item) {
  let good = 0, damaged = 0, overGood = 0, overDamaged = 0;
  receiptsForPo(po.id).forEach((rc) => rc.items.forEach((ri) => { if (ri.purchaseOrderItemId !== item.id) return;
    good += ri.quantityReceivedGood; damaged += ri.quantityReceivedDamaged || 0; overGood += ri.toOverage || 0; overDamaged += ri.damagedOnOverage || 0; }));
  const cancelled = item.cancelledQuantity || 0;
  const remaining = Math.max(0, item.quantityOrdered - cancelled - good - damaged);
  const overage = item.stockOverageQuantity || 0;
  return { ordered: item.quantityOrdered, good, damaged, cancelled, remaining, backordered: Math.min(item.backorderedQuantity || 0, remaining),
    demandLinked: item.demandLinks.reduce((s, l) => s + l.quantity, 0), overage,
    overageRemaining: Math.max(0, overage - overGood - overDamaged - (item.overageCancelledQuantity || 0)) };
}
export const poRemaining = (po) => po.items.reduce((s, it) => s + lineProgress(po, it).remaining, 0);
export function derivePoStatus(po) {
  if (po.status === 'DRAFT' || po.status === 'CLOSED') return po.status;
  const lines = po.items.map((it) => lineProgress(po, it));
  const received = lines.reduce((s, l) => s + l.good + l.damaged, 0), remaining = lines.reduce((s, l) => s + l.remaining, 0);
  if (remaining === 0) return received > 0 ? 'RECEIVED' : 'CANCELLED';
  if (lines.some((l) => l.backordered > 0)) return 'BACKORDERED';
  if (received > 0) return 'PARTIALLY_RECEIVED';
  return po.confirmedAt ? 'CONFIRMED' : 'SENT';
}
export function refreshPoStatus(po) { const s = derivePoStatus(po); if (po.status !== s) { po.status = s; po.updatedAt = now(); } return s; }
function retotal(po) {
  po.items.forEach((it) => { it.lineSubtotal = round2(it.quantityOrdered * it.unitPrice); });
  po.subtotal = round2(po.items.reduce((s, it) => s + it.lineSubtotal, 0));
  po.total = round2(po.subtotal + (Number(po.shipping) || 0) + (Number(po.tax) || 0));
}
const todayStr = (t) => { const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
// Derived: expected date passed, something still to receive, PO still active (no fake LATE status).
export const isPurchaseOrderLate = (po, at) => !!po.expectedDeliveryDate && RECEIVABLE_PO_STATUSES.indexOf(po.status) !== -1 && poRemaining(po) > 0 && po.expectedDeliveryDate < todayStr(at || now());

/* ---------- deterministic distribution across a line's demand links ---------- */
export function sortedLinks(item) {
  return item.demandLinks.map((l, i) => ({ l, i, r: requestOf(l.requestId) })).sort((a, b) =>
    (((b.r && b.r.priority) === 'EMERGENCY') - ((a.r && a.r.priority) === 'EMERGENCY')) || (((a.r && a.r.neededBy) || 0) - ((b.r && b.r.neededBy) || 0)) ||
    (priorityWeight(b.r && b.r.priority) - priorityWeight(a.r && a.r.priority)) || (a.i - b.i)).map((x) => x.l);
}

/* ---------- queries ---------- */
export function getPurchaseOrders(user, opts) {
  if (!user || !canUser(user, CAP.VIEW_PURCHASE_ORDERS)) return [];
  const f = (opts && opts.status) || 'ALL';
  const match = { ALL: () => true, DRAFT: (p) => p.status === 'DRAFT', SENT: (p) => p.status === 'SENT', CONFIRMED: (p) => p.status === 'CONFIRMED',
    PARTIAL: (p) => p.status === 'PARTIALLY_RECEIVED', BACKORDERED: (p) => p.status === 'BACKORDERED', RECEIVED: (p) => p.status === 'RECEIVED', CANCELLED: (p) => p.status === 'CANCELLED' }[f] || (() => true);
  return (db.PURCHASE_ORDERS || []).filter((p) => p.companyId === user.companyId && match(p)).sort((a, b) => b.createdAt - a.createdAt);
}
export const getPurchaseOrdersForSupplier = (user, supplierId) => getPurchaseOrders(user).filter((p) => p.supplierId === supplierId);
export const getPurchaseOrdersForRequirement = (user, prId) => getPurchaseOrders(user).filter((p) => p.items.some((it) => it.demandLinks.some((l) => l.purchaseRequirementId === prId)));
// What the warehouse should expect: receivable POs to ITS warehouse (invalid scope -> nothing).
export function getIncomingPurchaseOrders(user) {
  if (!user || !canUser(user, CAP.RECEIVE_PURCHASE_ORDER)) return [];
  const scope = warehouseScopeFor(user);
  if (scope === WAREHOUSE_SCOPE_DENIED) return [];
  return (db.PURCHASE_ORDERS || []).filter((p) => p.companyId === user.companyId && RECEIVABLE_PO_STATUSES.indexOf(p.status) !== -1 && poRemaining(p) > 0 && (!scope || p.shipToWarehouseId === scope))
    .sort((a, b) => (isPurchaseOrderLate(b) - isPurchaseOrderLate(a)) || String(a.expectedDeliveryDate || '9999').localeCompare(String(b.expectedDeliveryDate || '9999')));
}
// Purchasing warnings: commitments the demand may no longer need; drafts that no longer fit.
export function commitmentWarnings(user) {
  const out = [];
  getPurchaseOrders(user).filter((p) => RECEIVABLE_PO_STATUSES.indexOf(p.status) !== -1).forEach((po) => po.items.forEach((it) => it.demandLinks.forEach((l) => {
    const r = requestOf(l.requestId), a = allocOf(l);
    if (!r || !a) return;
    // superseded by warehouse stock (or demand closed) while the PO still owes it
    const excess = Math.min(a.supersededQuantity || 0, lineProgress(po, it).remaining);
    if (excess > 0) out.push({ purchaseOrder: po, item: it, link: l, quantity: excess, requestId: r.id });
  })));
  return out;
}
export function draftCoverageIssues(po) {
  const out = [];
  po.items.forEach((it) => it.demandLinks.forEach((l) => {
    const r = requestOf(l.requestId), ri = r && r.items.find((x) => x.id === l.requestItemId), pr = getRequirementById(l.purchaseRequirementId);
    if (!ri || !pr) { out.push({ link: l, allowed: 0 }); return; }
    const others = supplierAllocationsForItem(ri.id).filter((a) => isSupplierCommitted(a) && a.id !== l.supplierAllocationId).reduce((s, a) => s + supplierRemaining(a), 0);
    const allowed = ['APPROVED', 'PROCESSING', 'PARTIALLY_FULFILLED'].indexOf(r.status) === -1 || !isOpenRequirement(pr) ? 0 : Math.max(0, ri.quantity - getAllocatedQuantity(ri) - others);
    if (l.quantity > allowed) out.push({ link: l, allowed, requirement: pr, requestId: r.id });
  }));
  return out;
}

/* ---------- drafts ---------- */
function snapshotOf(s) { return { name: s.name, accountNumber: s.accountNumber || null, contactName: s.contactName || null, email: s.email || null, phone: s.phone || null }; }
function activeSupplier(actor, id) { const s = (db.SUPPLIERS || []).find((x) => x.id === id); return s && s.companyId === actor.companyId && s.status === 'ACTIVE' ? s : null; }
function companyWarehouse(companyId, id) { const l = loc(id); return !!l && l.companyId === companyId && l.type === 'WAREHOUSE' && l.status !== 'INACTIVE'; }
// Build one line (validated) + its PROPOSED supplier allocations. `own` = quantity this draft already holds per requirement (edits).
function buildLine(actor, poId, index, input, supplier, shipTo, own) {
  const vid = input.productVariantId, p = getProduct(vid);
  if (!p) return fail('unknown_variant', 'Unknown material');
  if (isAnyVariant(vid)) return fail('variant_not_specific', 'Choose the exact variant to buy');
  const unit = input.unit || p.unit;
  if (unit !== p.unit && !(PACKAGE_CONVERSIONS[vid] && PACKAGE_CONVERSIONS[vid][unit])) return fail('unit_mismatch', 'Order in ' + p.unit + ' (no trusted package conversion for ' + unit + ')');
  const price = Number(input.unitPrice);
  if (!isFinite(price) || price < 0) return fail('invalid_price', 'Enter a unit price of 0 or more');
  const overage = int(input.stockOverageQuantity);
  if (!isInt(overage)) return fail('invalid_overage', 'Stock overage must be a whole number');
  const itemId = poId + '-L' + (index + 1), links = [], allocs = [];
  for (const d of input.demand || []) {
    const pr = getRequirementById(d.purchaseRequirementId), q = int(d.quantity);
    if (!pr || pr.companyId !== actor.companyId) return fail('requirement_company', 'Unknown requirement');
    if (!isOpenRequirement(pr)) return fail('requirement_closed', pr.requirementNumber + ' is no longer open');
    if (!variantCompatible(pr.productVariantId, vid) || pr.unit !== unit) return fail('incompatible_material', pr.requirementNumber + ' needs a different material or unit');
    if (pr.destinationWarehouseId !== shipTo) return fail('warehouse_mismatch', pr.requirementNumber + ' goes to another warehouse');
    if (!Number.isInteger(q) || q <= 0) return fail('invalid_quantity', 'Enter a whole quantity for ' + pr.requirementNumber);
    const free = getRequirementProgress(pr).toSource + ((own && own[pr.id]) || 0);
    if (q > free) return fail('exceeds_requirement', pr.requirementNumber + ' has only ' + free + ' ' + pr.unit + ' left to source', { available: free });
    const t = now();
    const a = { id: newAllocationId(), companyId: actor.companyId, projectId: pr.projectId, requestId: pr.requestId, requestItemId: pr.requestItemId, productVariantId: vid,
      sourceType: 'SUPPLIER', sourceLocationId: null, warehouseId: shipTo, supplierId: supplier.id, purchaseRequirementId: pr.id, purchaseOrderId: poId, purchaseOrderItemId: itemId,
      quantity: q, convertedQuantity: 0, stockedQuantity: 0, cancelledQuantity: 0, unit, status: 'PROPOSED', releasedQuantity: 0, fulfillmentId: null,
      createdByUserId: actor.id, actorType: 'USER', createdAt: t, updatedAt: t, metadata: { source: 'PURCHASE_ORDER' } };
    allocs.push(a);
    links.push({ purchaseRequirementId: pr.id, requestId: pr.requestId, requestItemId: pr.requestItemId, projectId: pr.projectId, quantity: q, supplierAllocationId: a.id });
  }
  const qty = links.reduce((s, l) => s + l.quantity, 0) + overage;
  if (!(qty > 0)) return fail('empty_line', 'A line needs a demand quantity or an explicit stock overage');
  const vs = variantSnapshotFor(vid);
  const item = { id: itemId, purchaseOrderId: poId, productVariantId: vid, productNameSnapshot: (vs && vs.displayName) || p.displayName || p.name, variantSnapshot: vs || null,
    quantityOrdered: qty, unit, unitPrice: round2(price), lineSubtotal: round2(qty * price), expectedDeliveryDate: input.expectedDeliveryDate || null,
    supplierPartNumber: input.supplierPartNumber ? String(input.supplierPartNumber).trim() : null, demandLinks: links, stockOverageQuantity: overage,
    backorderedQuantity: 0, backorderExpectedDate: null, cancelledQuantity: 0, overageCancelledQuantity: 0, notes: input.notes || null,
    purchaseType: links.length ? 'DEMAND' : 'STOCK_PURCHASE' };
  return { item, allocs };
}
const draftFingerprint = (input) => fingerprintOf({ supplierId: input.supplierId, shipTo: input.shipToWarehouseId || null, expected: input.expectedDeliveryDate || null,
  lines: (input.lines || []).map((l) => ({ v: l.productVariantId, u: l.unit || null, p: Number(l.unitPrice), o: int(l.stockOverageQuantity),
    d: (l.demand || []).map((d) => d.purchaseRequirementId + ':' + int(d.quantity)).sort() })).sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b))) });
const touchedRequests = (allocs) => allocs.map((a) => a.requestId).filter((x, i, l) => l.indexOf(x) === i).map(requestOf).filter(Boolean);
function resync(requests, actor) {
  const sys = systemActor(actor.companyId, 'PURCHASING_SYNC', actor.id);
  requests.forEach((r) => { syncForRequest(r, sys); refreshRequestAllocationStatus(r); refreshRequestStatus(r); });
}
export function createDraft(actor, input, opts) {
  const o = opts || {};
  if (!actor || !canUser(actor, CAP.CREATE_PURCHASE_ORDER)) return fail('forbidden', 'Not allowed to create purchase orders');
  const supplier = activeSupplier(actor, input.supplierId);
  if (!supplier) return fail('supplier_invalid', 'Pick an active supplier of your company');
  const firstPr = ((input.lines || [])[0] && (input.lines[0].demand || [])[0]) ? getRequirementById(input.lines[0].demand[0].purchaseRequirementId) : null;
  const co = db.COMPANIES.find((c) => c.id === actor.companyId);
  const shipTo = input.shipToWarehouseId || (firstPr && firstPr.companyId === actor.companyId ? firstPr.destinationWarehouseId : null) || (co && co.settings.defaultWarehouseId);
  if (!companyWarehouse(actor.companyId, shipTo)) return fail('warehouse_invalid', 'Ship to one of your company\'s warehouses');
  const fp = draftFingerprint(Object.assign({}, input, { shipToWarehouseId: shipTo }));
  const prior = priorOperation(actor, 'po-create', o.operationKey, fp, 'PURCHASE_ORDERS');
  if (prior) return prior.error ? prior : { ok: true, purchaseOrder: prior.replay, duplicate: true };
  if (!(input.lines || []).length) return fail('no_lines', 'Add at least one line');
  const seen = {};
  for (const l of input.lines) for (const d of l.demand || []) { if (seen[d.purchaseRequirementId]) return fail('duplicate_requirement', 'A requirement can appear only once on a PO'); seen[d.purchaseRequirementId] = true; }
  return transaction(() => {
    const ids = nextPo(), t = now(), items = [], allocs = [];
    for (let i = 0; i < input.lines.length; i++) { const b = buildLine(actor, ids.id, i, input.lines[i], supplier, shipTo); if (b.error) return b; items.push(b.item); allocs.push.apply(allocs, b.allocs); }
    const po = { id: ids.id, purchaseOrderNumber: ids.number, companyId: actor.companyId, supplierId: supplier.id, supplierSnapshot: snapshotOf(supplier), shipToWarehouseId: shipTo,
      status: 'DRAFT', orderDate: null, sentAt: null, sentByUserId: null, confirmedAt: null, confirmedByUserId: null, supplierConfirmationNumber: null,
      expectedDeliveryDate: input.expectedDeliveryDate || null, paymentTermsSnapshot: supplier.paymentTerms || null, supplierQuoteNumber: input.supplierQuoteNumber || null,
      buyerUserId: actor.id, notes: input.notes || null, shipping: round2(Number(input.shipping) || 0), tax: round2(Number(input.tax) || 0), subtotal: 0, total: 0,
      items, createdAt: t, updatedAt: t, cancelledAt: null };
    retotal(po);
    db.PURCHASE_ORDERS.push(po);
    db.ALLOCATIONS.push.apply(db.ALLOCATIONS, allocs);
    recordOperation(actor, 'po-create', o.operationKey, fp, 'CREATE_PURCHASE_ORDER', 'PurchaseOrder', po.id);
    recordAudit({ action: AUDIT_ACTIONS.PURCHASE_ORDER_CREATED, entityType: 'PurchaseOrder', entityId: po.id, before: null,
      after: { purchaseOrderNumber: po.purchaseOrderNumber, supplierId: supplier.id, lines: items.length, total: po.total } }, actor);
    if (allocs.length) recordAudit({ action: AUDIT_ACTIONS.SUPPLIER_ALLOCATION_CREATED, entityType: 'PurchaseOrder', entityId: po.id, before: null,
      after: { allocationIds: allocs.map((a) => a.id), status: 'PROPOSED', requirementIds: allocs.map((a) => a.purchaseRequirementId) } }, actor);
    allocs.forEach((a) => refreshRequirementStatus(getRequirementById(a.purchaseRequirementId)));
    return { ok: true, purchaseOrder: po };
  });
}
function ownDraftQuantities(po) { const own = {}; po.items.forEach((it) => it.demandLinks.forEach((l) => { own[l.purchaseRequirementId] = (own[l.purchaseRequirementId] || 0) + l.quantity; })); return own; }
/* Edit a DRAFT: header fields and whole lines (lines are rebuilt from input and
   their PROPOSED allocations replaced). Nothing here touches a sent PO. */
export function updateDraft(actor, poId, patch) {
  const po = poById(poId);
  if (!po || !actor || po.companyId !== actor.companyId || !canUser(actor, CAP.EDIT_DRAFT_PURCHASE_ORDER)) return fail('forbidden', 'Not your company\'s purchase order');
  if (po.status !== 'DRAFT') return fail('not_draft', 'Only a draft can be edited; after sending, cancel remaining and create another PO');
  return transaction(() => {
    const supplier = patch.supplierId ? activeSupplier(actor, patch.supplierId) : (db.SUPPLIERS || []).find((s) => s.id === po.supplierId);
    if (!supplier || supplier.companyId !== actor.companyId) return fail('supplier_invalid', 'Pick an active supplier of your company');
    ['expectedDeliveryDate', 'notes', 'supplierQuoteNumber'].forEach((k) => { if (patch[k] !== undefined) po[k] = patch[k] || null; });
    ['shipping', 'tax'].forEach((k) => { if (patch[k] !== undefined) po[k] = round2(Number(patch[k]) || 0); });
    if (patch.supplierId) { po.supplierId = supplier.id; po.supplierSnapshot = snapshotOf(supplier); po.paymentTermsSnapshot = supplier.paymentTerms || null; }
    const old = (db.ALLOCATIONS || []).filter((a) => a.purchaseOrderId === po.id && a.status === 'PROPOSED');
    if (patch.lines) {
      const own = ownDraftQuantities(po), items = [], allocs = [], seen = {};
      for (const l of patch.lines) for (const d of l.demand || []) { if (seen[d.purchaseRequirementId]) return fail('duplicate_requirement', 'A requirement can appear only once on a PO'); seen[d.purchaseRequirementId] = true; }
      old.forEach((a) => { a.status = 'CANCELLED'; a.updatedAt = now(); });   // replaced below (still inside the transaction)
      for (let i = 0; i < patch.lines.length; i++) { const b = buildLine(actor, po.id, i, patch.lines[i], supplier, po.shipToWarehouseId, own); if (b.error) return b; items.push(b.item); allocs.push.apply(allocs, b.allocs); }
      if (!items.length) return fail('no_lines', 'A draft needs at least one line (or cancel it)');
      po.items = items; db.ALLOCATIONS.push.apply(db.ALLOCATIONS, allocs);
    } else if (patch.supplierId) old.forEach((a) => { a.supplierId = supplier.id; });
    retotal(po); po.updatedAt = now();
    recordAudit({ action: AUDIT_ACTIONS.PURCHASE_ORDER_DRAFT_UPDATED, entityType: 'PurchaseOrder', entityId: po.id, before: null, after: { lines: po.items.length, total: po.total } }, actor);
    const prs = (db.PURCHASE_REQUIREMENTS || []).filter((pr) => old.some((a) => a.purchaseRequirementId === pr.id) || po.items.some((it) => it.demandLinks.some((l) => l.purchaseRequirementId === pr.id)));
    prs.forEach(refreshRequirementStatus);
    resync(prs.map((pr) => requestOf(pr.requestId)).filter((r, i, l) => r && l.indexOf(r) === i), actor);
    return { ok: true, purchaseOrder: po };
  });
}
// Draft line helpers for the UI: add / remove one requirement on a draft.
const lineInputs = (po) => po.items.map((it) => ({ productVariantId: it.productVariantId, unit: it.unit, unitPrice: it.unitPrice, stockOverageQuantity: it.stockOverageQuantity,
  supplierPartNumber: it.supplierPartNumber, expectedDeliveryDate: it.expectedDeliveryDate, notes: it.notes, demand: it.demandLinks.map((l) => ({ purchaseRequirementId: l.purchaseRequirementId, quantity: l.quantity })) }));
export function addRequirementToDraft(actor, poId, prId, quantity, unitPrice) {
  const po = poById(poId), pr = getRequirementById(prId);
  if (!po || !pr) return fail('not_found', 'Unknown purchase order or requirement');
  const lines = lineInputs(po);
  const line = lines.find((l) => l.unit === pr.unit && variantCompatible(pr.productVariantId, l.productVariantId));
  if (line) line.demand.push({ purchaseRequirementId: prId, quantity });
  else lines.push({ productVariantId: pr.productVariantId, unit: pr.unit, unitPrice: unitPrice == null ? 0 : unitPrice, demand: [{ purchaseRequirementId: prId, quantity }] });
  return updateDraft(actor, poId, { lines });
}
export function removeRequirementFromDraft(actor, poId, prId) {
  const po = poById(poId);
  if (!po) return fail('not_found', 'Unknown purchase order');
  const lines = lineInputs(po).map((l) => Object.assign(l, { demand: l.demand.filter((d) => d.purchaseRequirementId !== prId) })).filter((l) => l.demand.length || int(l.stockOverageQuantity) > 0);
  return updateDraft(actor, poId, { lines });
}

/* ---------- send / confirm ---------- */
export function sendPurchaseOrder(actor, poId) {
  const po = poById(poId);
  if (!po || !actor || po.companyId !== actor.companyId || !canUser(actor, CAP.SEND_PURCHASE_ORDER)) return fail('forbidden', 'Not your company\'s purchase order');
  if (po.status !== 'DRAFT') return po.status === 'CANCELLED' ? fail('cancelled', 'This purchase order was cancelled') : { ok: true, purchaseOrder: po, duplicate: true };   // double tap: once
  if (!activeSupplier(actor, po.supplierId)) return fail('supplier_invalid', 'The supplier is no longer active');
  if (!po.items.length) return fail('no_lines', 'Add at least one line');
  const issues = draftCoverageIssues(po);
  if (issues.length) { const x = issues[0]; return fail('demand_exceeded', (x.requirement ? x.requirement.requirementNumber : 'A requirement') + ' now needs only ' + x.allowed + ' ' + ((x.requirement && x.requirement.unit) || '') + '. Edit the draft before sending.', { issues }); }
  return transaction(() => {
    const t = now(), allocs = (db.ALLOCATIONS || []).filter((a) => a.purchaseOrderId === po.id && a.status === 'PROPOSED');
    allocs.forEach((a) => { a.status = 'ORDERED'; a.updatedAt = t; a.orderedAt = t; });
    Object.assign(po, { status: 'SENT', orderDate: t, sentAt: t, sentByUserId: actor.id, updatedAt: t });
    recordAudit({ action: AUDIT_ACTIONS.PURCHASE_ORDER_SENT, entityType: 'PurchaseOrder', entityId: po.id, before: { status: 'DRAFT' },
      after: { purchaseOrderNumber: po.purchaseOrderNumber, committedAllocationIds: allocs.map((a) => a.id), total: po.total, markedSentOnly: true } }, actor);
    const reqs = touchedRequests(allocs);
    resync(reqs, actor);
    allocs.forEach((a) => refreshRequirementStatus(getRequirementById(a.purchaseRequirementId)));
    // field: "now on order" (no prices); warehouse: what to expect
    reqs.forEach((r) => {
      const mine = allocs.filter((a) => a.requestId === r.id), what = mine.map((a) => { const it = r.items.find((x) => x.id === a.requestItemId); return a.quantity + ' ' + a.unit + ' ' + ((it && it.productNameSnapshot) || ''); });
      notify([r.requestedByUserId], { companyId: r.companyId, type: NOTIFICATION_TYPES.ON_ORDER, title: r.id + ' \u00b7 remaining material is on order',
        message: what.join(', ') + (po.expectedDeliveryDate ? ' \u00b7 expected from supplier ' + po.expectedDeliveryDate : ''), entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId });
    });
    const wm = db.USERS.filter((u) => u.companyId === po.companyId && u.status === 'ACTIVE' && canUser(u, CAP.RECEIVE_PURCHASE_ORDER)).map((u) => u.id);
    notify(wm, { companyId: po.companyId, type: NOTIFICATION_TYPES.PURCHASE_ORDER_INCOMING, title: po.purchaseOrderNumber + ' from ' + po.supplierSnapshot.name,
      message: po.items.length + ' line' + (po.items.length === 1 ? '' : 's') + (po.expectedDeliveryDate ? ' \u00b7 expected ' + po.expectedDeliveryDate : ''), entityType: 'PurchaseOrder', entityId: po.id });
    return { ok: true, purchaseOrder: po };
  });
}
export function confirmPurchaseOrder(actor, poId, opts) {
  const po = poById(poId), o = opts || {};
  if (!po || !actor || po.companyId !== actor.companyId || !canUser(actor, CAP.CONFIRM_PURCHASE_ORDER)) return fail('forbidden', 'Not your company\'s purchase order');
  if (po.confirmedAt) return { ok: true, purchaseOrder: po, duplicate: true };
  if (RECEIVABLE_PO_STATUSES.indexOf(po.status) === -1) return fail('not_sent', 'Only a sent purchase order can be confirmed');
  const t = now();
  Object.assign(po, { confirmedAt: t, confirmedByUserId: actor.id, supplierConfirmationNumber: o.supplierConfirmationNumber || null, updatedAt: t });
  if (o.expectedDeliveryDate) po.expectedDeliveryDate = o.expectedDeliveryDate;
  refreshPoStatus(po);
  recordAudit({ action: AUDIT_ACTIONS.PURCHASE_ORDER_CONFIRMED, entityType: 'PurchaseOrder', entityId: po.id, before: { status: 'SENT' },
    after: { supplierConfirmationNumber: po.supplierConfirmationNumber, expectedDeliveryDate: po.expectedDeliveryDate } }, actor);
  return { ok: true, purchaseOrder: po };
}

/* ---------- backorders, releases, cancellation (commitment changes are explicit) ---------- */
export function markBackordered(actor, poId, itemId, quantity, expectedDate) {
  const po = poById(poId);
  if (!po || !actor || po.companyId !== actor.companyId || !canUser(actor, CAP.MANAGE_BACKORDERS)) return fail('forbidden', 'Not your company\'s purchase order');
  if (RECEIVABLE_PO_STATUSES.indexOf(po.status) === -1) return fail('not_active', 'Only an active purchase order can have backorders');
  const it = po.items.find((x) => x.id === itemId);
  if (!it) return fail('not_found', 'Unknown line');
  const q = int(quantity), lp = lineProgress(po, it);
  if (!isInt(q) || q > lp.remaining) return fail('invalid_quantity', 'At most ' + lp.remaining + ' ' + it.unit + ' can be backordered');
  it.backorderedQuantity = q; it.backorderExpectedDate = expectedDate || null; po.updatedAt = now();
  refreshPoStatus(po);   // commitment unchanged: a backorder is still owed by the supplier
  recordAudit({ action: AUDIT_ACTIONS.PURCHASE_ORDER_BACKORDERED, entityType: 'PurchaseOrder', entityId: po.id, before: null,
    after: { purchaseOrderItemId: it.id, backordered: q, expectedDate: expectedDate || null } }, actor);
  return { ok: true, purchaseOrder: po };
}
// Cancel `qty` of a line's REMAINING quantity: overage first, then demand links (lowest urgency first).
function releaseLine(po, it, qty) {
  const lp = lineProgress(po, it);
  let left = Math.min(qty, lp.remaining);
  const released = [];
  const fromOverage = Math.min(left, lp.overageRemaining);
  it.overageCancelledQuantity = (it.overageCancelledQuantity || 0) + fromOverage; left -= fromOverage;
  sortedLinks(it).slice().reverse().forEach((l) => {
    if (left <= 0) return;
    const a = allocOf(l), take = Math.min(left, a ? supplierRemaining(a) : 0);
    if (take <= 0) return;
    a.cancelledQuantity = (a.cancelledQuantity || 0) + take; a.updatedAt = now(); left -= take;
    if (supplierRemaining(a) === 0 && !(a.convertedQuantity || a.stockedQuantity)) a.status = 'RELEASED';
    else if (supplierRemaining(a) === 0) a.status = 'RECEIVED';
    released.push({ allocation: a, quantity: take });
  });
  const done = Math.min(qty, lp.remaining) - left;
  it.cancelledQuantity = (it.cancelledQuantity || 0) + done;
  it.backorderedQuantity = Math.max(0, (it.backorderedQuantity || 0) - done);
  return { quantity: done, released };
}
function afterRelease(actor, po, results, auditAction, reason) {
  const allocs = [].concat.apply([], results.map((x) => x.released.map((r) => r.allocation)));
  refreshPoStatus(po); po.updatedAt = now();
  recordAudit({ action: auditAction, entityType: 'PurchaseOrder', entityId: po.id, before: null,
    after: { purchaseOrderNumber: po.purchaseOrderNumber, quantity: results.reduce((s, x) => s + x.quantity, 0), reason, status: po.status } }, actor);
  if (allocs.length) recordAudit({ action: AUDIT_ACTIONS.SUPPLIER_ALLOCATION_RELEASED, entityType: 'PurchaseOrder', entityId: po.id, before: null,
    after: { allocationIds: allocs.map((a) => a.id), quantities: [].concat.apply([], results.map((x) => x.released.map((r) => r.quantity))), reason } }, actor);
  resync(touchedRequests(allocs), actor);
  allocs.forEach((a) => refreshRequirementStatus(getRequirementById(a.purchaseRequirementId)));
}
// "Release Backordered Quantity": the supplier won't deliver it; Purchasing may source it elsewhere.
export function releaseBackorderedQuantity(actor, poId, itemId, quantity) {
  const po = poById(poId);
  if (!po || !actor || po.companyId !== actor.companyId || !canUser(actor, CAP.MANAGE_BACKORDERS)) return fail('forbidden', 'Not your company\'s purchase order');
  const it = po.items.find((x) => x.id === itemId);
  if (!it) return fail('not_found', 'Unknown line');
  const q = int(quantity), bo = lineProgress(po, it).backordered;
  if (!(q > 0) || q > bo) return fail('invalid_quantity', 'At most ' + bo + ' ' + it.unit + ' are backordered');
  return transaction(() => { const res = releaseLine(po, it, q); afterRelease(actor, po, [res], AUDIT_ACTIONS.PURCHASE_ORDER_BACKORDER_RELEASED, 'BACKORDER_RELEASED'); return { ok: true, purchaseOrder: po, released: res.quantity }; });
}
// Cancel everything not yet received (whole PO, or chosen lines). A draft is simply cancelled.
export function cancelRemaining(actor, poId, opts) {
  const po = poById(poId), o = opts || {};
  if (!po || !actor || po.companyId !== actor.companyId || !canUser(actor, CAP.CANCEL_PURCHASE_ORDER)) return fail('forbidden', 'Not your company\'s purchase order');
  if (po.status === 'CANCELLED' || po.status === 'CLOSED' || po.status === 'RECEIVED') return fail('not_active', 'Nothing left to cancel on this purchase order');
  return transaction(() => {
    if (po.status === 'DRAFT') {
      const allocs = (db.ALLOCATIONS || []).filter((a) => a.purchaseOrderId === po.id && a.status === 'PROPOSED');
      allocs.forEach((a) => { a.status = 'CANCELLED'; a.updatedAt = now(); });
      Object.assign(po, { status: 'CANCELLED', cancelledAt: now(), updatedAt: now() });
      recordAudit({ action: AUDIT_ACTIONS.PURCHASE_ORDER_CANCELLED, entityType: 'PurchaseOrder', entityId: po.id, before: { status: 'DRAFT' }, after: { purchaseOrderNumber: po.purchaseOrderNumber, draft: true } }, actor);
      allocs.forEach((a) => refreshRequirementStatus(getRequirementById(a.purchaseRequirementId)));
      resync(touchedRequests(allocs), actor);
      return { ok: true, purchaseOrder: po };
    }
    const lines = po.items.filter((it) => !o.itemIds || o.itemIds.indexOf(it.id) !== -1);
    const results = lines.map((it) => releaseLine(po, it, lineProgress(po, it).remaining));
    if (poRemaining(po) === 0 && !receiptsForPo(po.id).length) { po.status = 'CANCELLED'; po.cancelledAt = now(); }
    afterRelease(actor, po, results, AUDIT_ACTIONS.PURCHASE_ORDER_CANCELLED, 'CANCEL_REMAINING');
    return { ok: true, purchaseOrder: po, released: results.reduce((s, x) => s + x.quantity, 0) };
  });
}
// Internal (request cancellation): remove a request's PROPOSED claims from draft POs. Sent POs are never touched here.
export function dropRequestFromDrafts(requestId) {
  const drafts = (db.ALLOCATIONS || []).filter((a) => a.requestId === requestId && a.sourceType === 'SUPPLIER' && a.status === 'PROPOSED');
  drafts.forEach((a) => {
    a.status = 'CANCELLED'; a.updatedAt = now();
    const po = poById(a.purchaseOrderId); if (!po || po.status !== 'DRAFT') return;
    po.items.forEach((it) => { it.demandLinks = it.demandLinks.filter((l) => l.supplierAllocationId !== a.id);
      it.quantityOrdered = it.demandLinks.reduce((n, l) => n + l.quantity, 0) + (it.stockOverageQuantity || 0); });
    po.items = po.items.filter((it) => it.quantityOrdered > 0);
    retotal(po); po.updatedAt = now();
  });
  return drafts.length;
}
export { requestOf as _requestOf };
