/* =========================================================================
   SUPPLIERS + QUOTES (Phase 4) — company-scoped records a Purchasing Manager
   keeps. Two companies can both buy from "Graybar": each has its own record
   (account number, contact, terms, notes); nothing is shared across tenants.
   A supplier referenced by a PO is never deleted: it becomes INACTIVE.
   Quotes are MANUALLY ENTERED facts (price, availability, lead time). ANT has
   no live supplier inventory, prices or APIs, and never picks a supplier.
   ========================================================================= */
import { db, now } from '../lib/db.js';
import { canUser, CAP } from '../lib/permissions.js';
import { getProduct } from '../lib/catalog.js';
import { recordAudit, AUDIT_ACTIONS } from './auditService.js';
import { getRequirementById, refreshRequirementStatus } from './purchaseRequirementService.js';

const fail = (error, message) => ({ error, message });
const nextId = (seq, prefix) => { db[seq] = (db[seq] || 1000) + 1; return prefix + db[seq]; };
const FIELDS = ['name', 'accountNumber', 'contactName', 'email', 'phone', 'website', 'address', 'paymentTerms', 'notes', 'preferred', 'defaultLeadTimeDays'];
const clean = (v) => (typeof v === 'string' ? v.trim() : v);
export const getSupplier = (user, id) => (db.SUPPLIERS || []).find((s) => s.id === id && user && s.companyId === user.companyId && canUser(user, CAP.VIEW_SUPPLIERS)) || null;
export function getSuppliers(user, opts) {
  if (!user || !canUser(user, CAP.VIEW_SUPPLIERS)) return [];
  const o = opts || {}, q = String(o.search || '').trim().toLowerCase();
  return (db.SUPPLIERS || []).filter((s) => s.companyId === user.companyId && (o.includeInactive || s.status === 'ACTIVE') &&
    (!q || [s.name, s.contactName, s.accountNumber, s.phone, s.email].some((v) => String(v || '').toLowerCase().indexOf(q) !== -1)))
    .sort((a, b) => (b.preferred - a.preferred) || a.name.localeCompare(b.name));   // preferred first, then A-Z (never auto-chosen)
}
export const getPreferredSuppliers = (user) => getSuppliers(user).filter((s) => s.preferred);
function validate(p) {
  if (p.name != null && !String(p.name).trim()) return fail('name_required', 'Enter the supplier name');
  if (p.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(p.email).trim())) return fail('invalid_email', 'Enter a valid email');
  if (p.defaultLeadTimeDays != null && p.defaultLeadTimeDays !== '' && !(Number(p.defaultLeadTimeDays) >= 0)) return fail('invalid_lead_time', 'Lead time is a number of days');
  return null;
}
export function createSupplier(actor, input) {
  if (!actor || !canUser(actor, CAP.MANAGE_SUPPLIERS)) return fail('forbidden', 'Not allowed to manage suppliers');
  if (!input || !String(input.name || '').trim()) return fail('name_required', 'Enter the supplier name');
  const bad = validate(input); if (bad) return bad;
  const t = now(), s = { id: nextId('SUPPLIER_SEQ', 'sup_'), companyId: actor.companyId, status: 'ACTIVE', preferred: false, createdAt: t, updatedAt: t };
  FIELDS.forEach((k) => { if (input[k] !== undefined) s[k] = k === 'preferred' ? !!input[k] : k === 'defaultLeadTimeDays' ? (input[k] === '' || input[k] == null ? null : Number(input[k])) : clean(input[k]) || null; });
  s.name = String(input.name).trim();
  db.SUPPLIERS.push(s);
  recordAudit({ action: AUDIT_ACTIONS.SUPPLIER_CREATED, entityType: 'Supplier', entityId: s.id, before: null, after: { name: s.name } }, actor);
  return { ok: true, supplier: s };
}
export function updateSupplier(actor, id, patch) {
  const s = (db.SUPPLIERS || []).find((x) => x.id === id);
  if (!s || !actor || s.companyId !== actor.companyId || !canUser(actor, CAP.MANAGE_SUPPLIERS)) return fail('forbidden', 'Not your company\'s supplier');
  const bad = validate(patch || {}); if (bad) return bad;
  const before = {};
  FIELDS.forEach((k) => { if (patch[k] !== undefined) { before[k] = s[k]; s[k] = k === 'preferred' ? !!patch[k] : k === 'defaultLeadTimeDays' ? (patch[k] === '' || patch[k] == null ? null : Number(patch[k])) : clean(patch[k]) || (k === 'name' ? s.name : null); } });
  s.updatedAt = now();
  recordAudit({ action: AUDIT_ACTIONS.SUPPLIER_UPDATED, entityType: 'Supplier', entityId: s.id, before, after: FIELDS.reduce((o, k) => (patch[k] !== undefined ? Object.assign(o, { [k]: s[k] }) : o), {}) }, actor);
  return { ok: true, supplier: s };
}
export function deactivateSupplier(actor, id) {
  const s = (db.SUPPLIERS || []).find((x) => x.id === id);
  if (!s || !actor || s.companyId !== actor.companyId || !canUser(actor, CAP.MANAGE_SUPPLIERS)) return fail('forbidden', 'Not your company\'s supplier');
  s.status = 'INACTIVE'; s.preferred = false; s.updatedAt = now();
  recordAudit({ action: AUDIT_ACTIONS.SUPPLIER_UPDATED, entityType: 'Supplier', entityId: s.id, before: { status: 'ACTIVE' }, after: { status: 'INACTIVE' } }, actor);
  return { ok: true, supplier: s };
}
export function reactivateSupplier(actor, id) {
  const s = (db.SUPPLIERS || []).find((x) => x.id === id);
  if (!s || !actor || s.companyId !== actor.companyId || !canUser(actor, CAP.MANAGE_SUPPLIERS)) return fail('forbidden', 'Not your company\'s supplier');
  s.status = 'ACTIVE'; s.updatedAt = now();
  recordAudit({ action: AUDIT_ACTIONS.SUPPLIER_UPDATED, entityType: 'Supplier', entityId: s.id, before: { status: 'INACTIVE' }, after: { status: 'ACTIVE' } }, actor);
  return { ok: true, supplier: s };
}
/* ---------- quotes (manual) ---------- */
export const getQuotesForRequirement = (user, prId) => (db.SUPPLIER_QUOTES || []).filter((q) => q.purchaseRequirementId === prId && user && q.companyId === user.companyId && canUser(user, CAP.VIEW_PURCHASE_PRICES))
  .sort((a, b) => a.unitPrice - b.unitPrice);
export function addSupplierQuote(actor, input) {
  if (!actor || !canUser(actor, CAP.MANAGE_SUPPLIERS)) return fail('forbidden', 'Not allowed to enter quotes');
  const s = (db.SUPPLIERS || []).find((x) => x.id === input.supplierId);
  if (!s || s.companyId !== actor.companyId) return fail('supplier_company', 'Pick one of your company\'s suppliers');
  const pr = input.purchaseRequirementId ? getRequirementById(input.purchaseRequirementId) : null;
  if (input.purchaseRequirementId && (!pr || pr.companyId !== actor.companyId)) return fail('requirement_company', 'Unknown requirement');
  const vid = input.productVariantId || (pr && pr.productVariantId), p = getProduct(vid);
  if (!p) return fail('unknown_variant', 'Unknown material');
  const price = Number(input.unitPrice);
  if (!isFinite(price) || price < 0) return fail('invalid_price', 'Enter a price of 0 or more');
  const unit = input.unit || p.unit;
  if (unit !== p.unit) return fail('unit_mismatch', 'Quote in ' + p.unit + ' (no trusted package conversion is configured)');
  const t = now(), q = { id: nextId('QUOTE_SEQ', 'quo_'), companyId: actor.companyId, supplierId: s.id, purchaseRequirementId: pr ? pr.id : null, productVariantId: vid, unit,
    unitPrice: Math.round(price * 10000) / 10000, availableQuantity: input.availableQuantity === '' || input.availableQuantity == null ? null : Number(input.availableQuantity),
    leadTimeDays: input.leadTimeDays === '' || input.leadTimeDays == null ? null : Number(input.leadTimeDays), expectedDeliveryDate: input.expectedDeliveryDate || null,
    quoteNumber: clean(input.quoteNumber) || null, validUntil: input.validUntil || null, notes: clean(input.notes) || null, source: 'MANUAL',
    enteredByUserId: actor.id, createdAt: t, updatedAt: t };
  db.SUPPLIER_QUOTES.push(q);
  if (pr) refreshRequirementStatus(pr);
  recordAudit({ action: AUDIT_ACTIONS.SUPPLIER_QUOTE_ADDED, entityType: 'SupplierQuote', entityId: q.id, projectId: pr ? pr.projectId : null, before: null,
    after: { supplierId: s.id, purchaseRequirementId: q.purchaseRequirementId, unitPrice: q.unitPrice, unit } }, actor);
  return { ok: true, quote: q };
}
