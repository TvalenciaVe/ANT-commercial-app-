/* =========================================================================
   APPROVALS (Phase 3) — configurable per company, evaluated per request.

   Two separate switches: the `approvals` FEATURE FLAG (module available) and
   the company SETTING approvalsEnabled (this company requires approvals).
   A company's ApprovalPolicy holds ordered rules. Each matched rule adds a
   step for its approver role; steps are resolved in order (PM -> Purchasing
   -> Owner...). No matching rule -> the policy's defaultBehavior.

   COST: ANT has no trusted prices yet, so a REQUEST_VALUE rule can never be
   evaluated; unknown cost is NEVER treated as $0. It routes to the rule's
   approver for manual review (reason COST_UNKNOWN_REVIEW_REQUIRED).
   Who can approve a step: a Project Manager ON that project (project role),
   or an Owner / Company Admin (company-wide). Never the requester, never
   another company.
   ========================================================================= */
import { db, now } from '../lib/db.js';
import { canUser, CAP } from '../lib/permissions.js';
import { getProduct } from '../lib/catalog.js';
import { companyRolesOf } from '../lib/userModel.js';
import { getCompany, getMembership, getProject } from './repo.js';
import { isFeatureEnabled } from './companyService.js';
import { recordAudit, AUDIT_ACTIONS } from './auditService.js';
import { notify, NOTIFICATION_TYPES } from './notificationService.js';
import { APPROVAL_RULE_TYPES, APPROVAL_REASON_CODES, APPROVER_ROLE_SCOPES } from '../config/requests.js';

const fail = (error, message) => ({ error, message });
function nextApprovalId() { db.APPROVAL_SEQ = (db.APPROVAL_SEQ || 1000) + 1; return 'APR-' + db.APPROVAL_SEQ; }
export const policyFor = (companyId) => (db.APPROVAL_POLICIES || []).find((p) => p.companyId === companyId && p.active) || null;
export const approvalById = (id) => (db.APPROVAL_REQUESTS || []).find((a) => a.id === id) || null;
export const approvalsForRequest = (requestId) => (db.APPROVAL_REQUESTS || []).filter((a) => a.requestId === requestId);

// Estimated Material Value: only when EVERY line has a trusted unit cost.
// The catalog has none today, so this is "Value unavailable" (never $0).
export function estimatedMaterialValue(r) {
  const missing = []; let value = 0;
  r.items.forEach((it) => { const p = getProduct(it.productVariantId); const c = p && p.unitCost != null && p.unitCostTrusted === true ? Number(p.unitCost) : null;
    if (c == null || !isFinite(c)) missing.push(it.id); else value += c * it.quantity; });
  return missing.length ? { known: false, value: null, missingItemIds: missing, label: 'Value unavailable' } : { known: true, value, missingItemIds: [], label: 'Estimated Material Value' };
}
function ruleMatches(rule, r) {
  const list = Array.isArray(rule.value) ? rule.value : [rule.value];
  switch (rule.type) {
    case 'PRIORITY': return list.indexOf(r.priority) !== -1;
    case 'PROJECT': return list.indexOf(r.projectId) !== -1;
    case 'PRODUCT_VARIANT': return r.items.some((it) => list.indexOf(it.productVariantId) !== -1);
    case 'MATERIAL_CATEGORY': return r.items.some((it) => { const p = getProduct(it.productVariantId); return !!p && list.indexOf(p.cat) !== -1; });
    case 'QUANTITY': return r.items.some((it) => it.quantity > Number(rule.value));
    default: return false;
  }
}
export function evaluateApproval(r) {
  const company = getCompany(r.companyId);
  if (!company || !isFeatureEnabled(company.id, 'approvals') || company.settings.approvalsEnabled !== true) return { required: false, steps: [], reasons: [{ code: 'APPROVALS_OFF' }] };
  const policy = policyFor(company.id);
  if (!policy) return { required: false, steps: [], reasons: [{ code: 'NO_POLICY' }] };
  const reasons = [];
  (policy.rules || []).filter((x) => x.active !== false && APPROVAL_RULE_TYPES[x.type]).sort((a, b) => (a.priority || 0) - (b.priority || 0)).forEach((rule) => {
    if (rule.type === 'REQUEST_VALUE') {
      const est = estimatedMaterialValue(r);
      if (!est.known) reasons.push({ ruleId: rule.id, type: rule.type, role: rule.approverRole, code: APPROVAL_REASON_CODES.COST_UNKNOWN_REVIEW_REQUIRED, message: 'Material value unknown: manual review' });
      else if (est.value > Number(rule.value)) reasons.push({ ruleId: rule.id, type: rule.type, role: rule.approverRole, code: APPROVAL_REASON_CODES.RULE_MATCHED, message: 'Estimated value above ' + rule.value });
    } else if (ruleMatches(rule, r)) reasons.push({ ruleId: rule.id, type: rule.type, role: rule.approverRole, code: APPROVAL_REASON_CODES.RULE_MATCHED, message: rule.label || (rule.type + ' rule') });
  });
  if (!reasons.length && policy.defaultBehavior === 'REQUIRE_APPROVAL' && policy.defaultApproverRole) reasons.push({ ruleId: null, type: 'DEFAULT', role: policy.defaultApproverRole, code: 'POLICY_DEFAULT', message: 'Company policy' });
  const roles = []; reasons.forEach((x) => { if (roles.indexOf(x.role) === -1) roles.push(x.role); });
  // sequential: only the first step is active; the others wait their turn
  const steps = roles.map((role, i) => ({ sequence: i + 1, requiredRole: role, status: i === 0 ? 'PENDING' : 'WAITING', ruleIds: reasons.filter((x) => x.role === role).map((x) => x.ruleId).filter(Boolean),
    activatedAt: null, resolvedByUserId: null, resolvedAt: null, notes: null }));
  return { required: steps.length > 0, steps, reasons, policyId: policy.id };
}
export const currentStep = (ap) => (ap && ap.steps ? ap.steps.find((s) => s.status === 'PENDING') || null : null);
/* Can this user resolve this step? Authority comes from the step's scope
   (config/requests.js APPROVER_ROLE_SCOPES):
   - PROJECT scope (Project Manager): that role ON the request's project, via
     ProjectMembership + RESOLVE_PROJECT_APPROVAL. A PM of another project can't.
   - COMPANY scope (Purchasing Manager, Owner, Company Admin): that role in the
     person's companyRoles + RESOLVE_COMPANY_APPROVAL. No project membership.
   - Owner / Company Admin may override steps whose config allows it.
   Always: same company, active user, never the requester, only the active step. */
export function canResolveStep(user, ap, step) {
  if (!user || !ap || !step || user.status !== 'ACTIVE' || user.companyId !== ap.companyId) return false;
  if (ap.status !== 'PENDING' || step.status !== 'PENDING') return false;
  const r = db.REQUESTS.find((x) => x.id === ap.requestId);
  if (!r || r.companyId !== ap.companyId || r.requestedByUserId === user.id) return false;   // never approve your own request
  const cfg = APPROVER_ROLE_SCOPES[step.requiredRole];
  if (!cfg) return false;
  const roles = companyRolesOf(user);
  const companyAuthority = canUser(user, CAP.RESOLVE_COMPANY_APPROVAL, { companyId: ap.companyId });
  if (cfg.ownerAdminOverride && companyAuthority && (roles.indexOf('OWNER') !== -1 || roles.indexOf('COMPANY_ADMIN') !== -1)) return true;
  if (cfg.scope === 'COMPANY') return companyAuthority && roles.indexOf(step.requiredRole) !== -1;
  const m = getMembership(user.id, ap.projectId);
  return !!m && m.projectRole === step.requiredRole && canUser(user, CAP.RESOLVE_PROJECT_APPROVAL, { projectId: ap.projectId });
}
export const stepScope = (role) => (APPROVER_ROLE_SCOPES[role] ? APPROVER_ROLE_SCOPES[role].scope : null);
export function eligibleApprovers(ap) {
  const step = currentStep(ap);
  return db.USERS.filter((u) => canResolveStep(u, ap, step)).map((u) => u.id);
}
// Project approvals for projects the person manages; company approvals company-wide.
export function approvalsVisibleTo(user) {
  if (!user) return [];
  const company = canUser(user, CAP.VIEW_COMPANY_APPROVALS, { companyId: user.companyId });
  return (db.APPROVAL_REQUESTS || []).filter((a) => a.companyId === user.companyId && (company || canUser(user, CAP.VIEW_PROJECT_APPROVALS, { projectId: a.projectId })));
}
// The request behind an approval, for someone allowed to see that approval.
// A company approver (e.g. a Purchasing Manager) has no project membership,
// so project visibility alone would hide the very request they must decide.
export function requestForApproval(user, approvalOrId) {
  const ap = typeof approvalOrId === 'string' ? approvalById(approvalOrId) : approvalOrId;
  if (!ap || approvalsVisibleTo(user).indexOf(ap) === -1) return null;
  const r = db.REQUESTS.find((x) => x.id === ap.requestId);
  return r && r.companyId === user.companyId ? r : null;
}
export const pendingApprovalsFor = (user) => approvalsVisibleTo(user).filter((a) => a.status === 'PENDING' && canResolveStep(user, a, currentStep(a)));

export function createApprovalRequest(r, ev, actor) {
  const t = now();
  const ap = { id: nextApprovalId(), companyId: r.companyId, projectId: r.projectId, requestId: r.id, status: 'PENDING',
    requiredApproverRole: ev.steps[0].requiredRole, ruleIdOptional: ev.reasons[0] ? ev.reasons[0].ruleId : null, policyId: ev.policyId,
    requestedAt: t, resolvedAt: null, resolvedByUserId: null, decisionNotes: null, steps: ev.steps, reasons: ev.reasons,
    metadata: { estimatedValue: estimatedMaterialValue(r) } };
  db.APPROVAL_REQUESTS.push(ap);
  recordAudit({ action: AUDIT_ACTIONS.APPROVAL_REQUEST_CREATED, entityType: 'ApprovalRequest', entityId: ap.id, companyId: r.companyId, projectId: r.projectId, before: null,
    after: { requestId: r.id, steps: ap.steps.map((s) => s.requiredRole), reasons: ap.reasons.map((x) => x.code), actorType: 'SYSTEM' } }, actor);
  const p = getProject(r.projectId);
  ap.steps[0].activatedAt = t;
  notifyStepApprovers(ap, r);   // only the ACTIVE step; later approvers are told when their turn comes
  notify([r.requestedByUserId], { companyId: r.companyId, type: NOTIFICATION_TYPES.REQUEST_AWAITING_APPROVAL, title: 'Request submitted \u00b7 awaiting approval',
    message: r.id + ' \u00b7 ' + (p ? p.name : ''), entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId });
  return ap;
}
const roleLabel = (k) => ({ PROJECT_MANAGER: 'Project Manager', PURCHASING_MANAGER: 'Purchasing', OWNER: 'Owner', COMPANY_ADMIN: 'Company Admin', SUPERINTENDENT: 'Superintendent' }[k] || k);
function notifyStepApprovers(ap, r) {
  const step = currentStep(ap), p = getProject(r.projectId);
  if (!step) return [];
  return notify(eligibleApprovers(ap), { companyId: r.companyId, type: NOTIFICATION_TYPES.APPROVAL_REQUIRED,
    title: step.sequence === 1 ? 'Material request requires approval' : 'Material request ' + r.id + ' requires ' + roleLabel(step.requiredRole) + ' approval',
    message: r.id + ' \u00b7 ' + (p ? p.name : '') + (ap.steps.length > 1 ? ' \u00b7 step ' + step.sequence + ' of ' + ap.steps.length : ''),
    entityType: 'ApprovalRequest', entityId: ap.id, projectId: r.projectId });
}
/* Resolves the ACTIVE step only. A resolved step can't be resolved again and a
   terminal approval can't change (double tap safe). Approve: the step is done
   and the next WAITING step becomes active (its approvers are notified); the
   approval is APPROVED only after the last step. Reject: the approval ends,
   later steps are cancelled, never activated. */
export function resolveStep(actor, approvalId, decision, notes) {
  const ap = approvalById(approvalId);
  if (!ap || !actor || actor.companyId !== ap.companyId) return fail('forbidden', 'Not your company\'s approval');
  if (ap.status !== 'PENDING') return fail('already_resolved', 'This approval was already ' + ap.status.toLowerCase());
  const step = currentStep(ap);
  if (!canResolveStep(actor, ap, step)) return fail('forbidden', 'You can\'t resolve this approval step');
  const t = now();
  const r = db.REQUESTS.find((x) => x.id === ap.requestId);
  Object.assign(step, { status: decision === 'APPROVE' ? 'APPROVED' : 'REJECTED', resolvedByUserId: actor.id, resolvedAt: t, notes: notes || null });
  recordAudit({ action: AUDIT_ACTIONS.APPROVAL_STEP_COMPLETED, entityType: 'ApprovalRequest', entityId: ap.id, companyId: ap.companyId, projectId: ap.projectId, before: { step: step.sequence, status: 'PENDING' },
    after: { step: step.sequence, requiredRole: step.requiredRole, status: step.status, resolvedByUserId: actor.id, requestId: ap.requestId } }, actor);
  if (decision === 'REJECT') {
    ap.steps.forEach((x) => { if (x.status === 'WAITING' || x.status === 'PENDING') x.status = 'CANCELLED'; });
    Object.assign(ap, { status: 'REJECTED', resolvedAt: t, resolvedByUserId: actor.id, decisionNotes: notes || null });
    return { ok: true, approval: ap, done: true, decision };
  }
  const next = ap.steps.find((x) => x.status === 'WAITING');
  if (next) {
    Object.assign(next, { status: 'PENDING', activatedAt: t });
    recordAudit({ action: AUDIT_ACTIONS.APPROVAL_STEP_ACTIVATED, entityType: 'ApprovalRequest', entityId: ap.id, companyId: ap.companyId, projectId: ap.projectId, before: null,
      after: { step: next.sequence, requiredRole: next.requiredRole, scope: stepScope(next.requiredRole), requestId: ap.requestId } }, actor);
    notifyStepApprovers(ap, r);
    return { ok: true, approval: ap, done: false, decision, nextStep: next };
  }
  Object.assign(ap, { status: 'APPROVED', resolvedAt: t, resolvedByUserId: actor.id, decisionNotes: notes || null });
  return { ok: true, approval: ap, done: true, decision };
}
