/* =========================================================================
   INVENTORY SERVICE (Phase 2) — balances, availability and every
   stock-changing operation, all through the Material Ledger.

   Source of truth: the MaterialMovement ledger. InventoryBalance rows are a
   materialized total per company + variant + location + state, updated only
   by materialLedgerService in the same step as the movement, and always
   rebuildable from the ledger (rebuildInventoryBalancesFromLedger).

   Request lines keep pickedQuantity / packedQuantity / shortQuantity /
   collected for the screens, but those are a CACHE written only here from
   the ledger (refreshLineProgress); integrity verifies they match.
   ========================================================================= */
import { db, now } from '../lib/db.js';
import { canUser, CAP } from '../lib/permissions.js';
import { INVENTORY_STATES, ON_HAND_STATES, ADJUSTMENT_REASONS } from '../config/ledger.js';
import { replayMovements } from '../lib/ledger.js';
import { matchStockVariant } from '../lib/stockMatch.js';
import { getProduct } from '../lib/catalog.js';
import { LEGACY_TO_VARIANT } from '../data/catalog.js';
import { mainWarehouseIdFor } from '../lib/locationModel.js';
import { LOCATION_TYPES } from '../config/locations.js';
import { postMovements, checkOperation, fingerprintOf, getMovementsForRequestItem, getMovementById, reversibleQuantity, reversalDraftFor, reverseMovement, getMovementsForCompany } from './materialLedgerService.js';
import { recordAudit, AUDIT_ACTIONS } from './auditService.js';

const fail = (error, message, extra) => Object.assign({ error, message }, extra || {});
const loc = (id) => db.LOCATIONS.find((l) => l.id === id) || null;
const locName = (id) => { const l = loc(id); return l ? l.name : ''; };

/* ---------- balances and availability ---------- */
export const getInventoryForCompany = (companyId) => db.INVENTORY_BALANCES.filter((b) => b.companyId === companyId);
export const getInventoryForVariant = (companyId, vid) => db.INVENTORY_BALANCES.filter((b) => b.companyId === companyId && b.productVariantId === vid);
export const getInventoryAtLocation = (companyId, locationId) => db.INVENTORY_BALANCES.filter((b) => b.companyId === companyId && b.locationId === locationId);
export function getInventoryBalance(companyId, vid, locationId, state) {
  const b = db.INVENTORY_BALANCES.find((x) => x.companyId === companyId && x.productVariantId === vid && x.locationId === locationId && x.inventoryState === state);
  return b ? b.quantity : 0;
}
export function getQuantityByState(companyId, vid) {
  const out = {}; Object.keys(INVENTORY_STATES).forEach((s) => { out[s] = 0; });
  getInventoryForVariant(companyId, vid).forEach((b) => { out[b.inventoryState] += b.quantity; });
  return out;
}
// AVAILABLE means exactly the AVAILABLE state (never picking, packed, damaged...).
export const getAvailableQuantity = (companyId, vid) => getQuantityByState(companyId, vid).AVAILABLE;
// Physically in the warehouse: AVAILABLE + RESERVED + PICKING + PACKED.
export function getPhysicalOnHand(companyId, vid) { const q = getQuantityByState(companyId, vid); return ON_HAND_STATES.reduce((a, s) => a + q[s], 0); }
function withinWarehouse(locationId, warehouseId) {
  let cur = loc(locationId), guard = 0;
  while (cur && guard++ < 20) { if (cur.id === warehouseId) return true; cur = loc(cur.parentLocationId); }
  return false;
}
export const getWarehouseInventory = (companyId, warehouseId) => getInventoryForCompany(companyId).filter((b) => withinWarehouse(b.locationId, warehouseId || mainWarehouseIdFor(db, companyId)));

/* ---------- inventory item metadata (no quantity here) ---------- */
export const inventoryItemFor = (companyId, vid) => db.INVENTORY_ITEMS.find((x) => x.companyId === companyId && x.productVariantId === vid) || null;
export const stockedVariantIds = (companyId) => db.INVENTORY_ITEMS.filter((x) => x.companyId === companyId && x.active !== false).map((x) => x.productVariantId);
function ensureInventoryItem(companyId, vid, locationId) {
  let it = inventoryItemFor(companyId, vid);
  if (!it) {
    it = { id: 'inv:' + companyId + ':' + vid, companyId, productVariantId: vid, primaryLocationId: locationId || mainWarehouseIdFor(db, companyId),
      minimumStock: null, reorderPoint: null, targetStock: null, active: true, createdAt: now(), updatedAt: now() };
    db.INVENTORY_ITEMS.push(it);
  }
  return it;
}
// The stocked variant a request line draws from (itself, its migrated id, or the "Any" match).
export const stockVariantFor = (companyId, vid) => matchStockVariant(LEGACY_TO_VARIANT[vid] || vid, stockedVariantIds(companyId), (k) => getAvailableQuantity(companyId, k));
// Low stock: AVAILABLE at or below the reorder point (or minimum stock).
export function isLowStock(companyId, vid) {
  const it = inventoryItemFor(companyId, vid);
  const limit = it ? (it.reorderPoint != null ? it.reorderPoint : it.minimumStock) : null;
  return limit != null && getAvailableQuantity(companyId, vid) <= limit;
}
export const lowStockVariantIds = (companyId) => stockedVariantIds(companyId).filter((vid) => isLowStock(companyId, vid));

/* ---------- where to pick: primary location first, then the others by name ---------- */
export function locationsHolding(companyId, vid, state) {
  const primary = (inventoryItemFor(companyId, vid) || {}).primaryLocationId;
  return getInventoryForVariant(companyId, vid).filter((b) => b.inventoryState === (state || 'AVAILABLE') && b.quantity > 0)
    .sort((a, b) => (a.locationId === primary ? -1 : b.locationId === primary ? 1 : locName(a.locationId).localeCompare(locName(b.locationId))));
}
export function planPick(companyId, vid, quantity) {
  const plan = []; let left = quantity;
  locationsHolding(companyId, vid, 'AVAILABLE').forEach((b) => { if (left <= 0) return; const q = Math.min(left, b.quantity); plan.push({ locationId: b.locationId, quantity: q }); left -= q; });
  return { stockVariantId: vid, parts: plan, total: quantity - Math.max(0, left) };
}

/* ---------- request line progress, derived from the ledger ---------- */
// Net quantity of this line held per variant + location + state.
function heldForLine(item) {
  const held = {};
  getMovementsForRequestItem(item.id).forEach((m) => {
    const bump = (l, s, d) => { if (!l) return; const k = m.productVariantId + '@' + l + '@' + s; held[k] = (held[k] || 0) + d; };
    bump(m.fromLocationId, m.fromInventoryState, -m.quantity);
    bump(m.toLocationId, m.toInventoryState, m.quantity);
  });
  return Object.keys(held).filter((k) => held[k] > 0).map((k) => { const [vid, locationId, state] = k.split('@'); return { productVariantId: vid, locationId, state, quantity: held[k] }; });
}
const heldIn = (item, state) => heldForLine(item).filter((h) => h.state === state);
const sum = (list) => list.reduce((a, h) => a + h.quantity, 0);
export function getPickedQuantityForRequestItem(item) { const lp = item.legacyProgress || {}; return (lp.pickedQuantity || 0) + sum(heldIn(item, 'PICKING')) + sum(heldIn(item, 'PACKED')); }
export function getPackedQuantityForRequestItem(item) { const lp = item.legacyProgress || {}; return (lp.packedQuantity || 0) + sum(heldIn(item, 'PACKED')); }
export const getOutstandingQuantityForRequestItem = (item) => Math.max(0, item.quantity - getPickedQuantityForRequestItem(item));
// A shortage is information about demand, never negative stock. It stays
// part of outstanding demand (Purchasing may fill it later).
export const getShortQuantityForRequestItem = (item) => (item.shortage ? Math.min(item.shortage.shortQuantity, getOutstandingQuantityForRequestItem(item)) : 0);
// requested = picked + outstanding;  short <= outstanding;  packed <= picked
export function requestItemProgress(item) {
  return { requested: item.quantity, picked: getPickedQuantityForRequestItem(item), packed: getPackedQuantityForRequestItem(item),
    short: getShortQuantityForRequestItem(item), outstanding: getOutstandingQuantityForRequestItem(item) };
}
export function refreshLineProgress(item) {
  const p = requestItemProgress(item);
  item.pickedQuantity = p.picked; item.packedQuantity = p.packed; item.collected = p.picked >= item.quantity;
  item.shortQuantity = item.shortage ? item.shortage.shortQuantity : 0;
  return p;
}

/* ---------- operations ---------- */
// Permission, then the request's company, THEN idempotency (company-scoped),
// so a replay is only ever returned for this company's own request line.
function lineContext(actor, cap, o, operationType) {
  if (!canUser(actor, CAP[cap])) return fail('forbidden', 'Not allowed');
  const r = db.REQUESTS.find((x) => x.id === o.requestId);
  if (!r || r.companyId !== actor.companyId) return fail('forbidden', 'Not your company\'s request');
  // v5 requests are picked from their own reservation through the fulfillment, never from AVAILABLE.
  if (r.allocationMode === 'V5') return fail('use_fulfillment', 'This request is picked from its reservation');
  const item = r.items.find((i) => i.id === o.requestItemId);
  if (!item) return fail('not_found', 'Unknown line');
  const idem = o.operationKey ? { operationKey: o.operationKey, operationType, entityType: 'MaterialRequestItem', entityId: item.id,
    fingerprint: fingerprintOf({ op: operationType, requestId: r.id, requestItemId: item.id, quantity: o.quantity == null ? null : Number(o.quantity) }) } : {};
  const prior = checkOperation(actor, o.operationKey, operationType, idem.fingerprint);
  if (prior) return prior.error ? prior : Object.assign(prior, { isDuplicate: true });
  return { r, item, idem };
}
const audit = (action, actor, r, item, movements, extra) => recordAudit({ action, entityType: 'MaterialMovement', entityId: movements[0] ? movements[0].id : null,
  companyId: actor.companyId, projectId: r ? r.projectId : null, before: null,
  after: Object.assign({ movementIds: movements.map((m) => m.id), productVariantId: movements[0] ? movements[0].productVariantId : null,
    requestId: r ? r.id : null, requestItemId: item ? item.id : null, quantity: movements.reduce((a, m) => a + m.quantity, 0) }, extra || {}) }, actor);
const lineFields = (r, item) => ({ projectId: r.projectId, requestId: r.id, requestItemId: item.id });

// PICK: AVAILABLE -> PICKING in the same bin(s). Refuses more than is available.
export function pickMaterial(actor, o) {
  const x = lineContext(actor, 'PICK_MATERIALS', o, 'PICK_MATERIAL'); if (x.error) return x; if (x.isDuplicate) return x;
  const { r, item } = x;
  const want = o.quantity == null ? getOutstandingQuantityForRequestItem(item) : Number(o.quantity);
  if (!(want > 0)) return fail('invalid_quantity', 'Nothing left to pick');
  if (want > getOutstandingQuantityForRequestItem(item)) return fail('over_request', 'More than the line still needs');
  const vid = stockVariantFor(r.companyId, item.productVariantId);
  const p = getProduct(vid);
  const plan = planPick(r.companyId, vid, want);
  if (plan.total < want) return fail('insufficient_stock', 'Only ' + plan.total + ' ' + item.unit + ' available', { available: plan.total });
  const res = postMovements(actor, plan.parts.map((part) => Object.assign({ movementType: 'PICK', companyId: r.companyId, productVariantId: vid, quantity: part.quantity,
    unit: p.unit, fromLocationId: part.locationId, toLocationId: part.locationId, fromInventoryState: 'AVAILABLE', toInventoryState: 'PICKING' }, lineFields(r, item))),
    x.idem);
  if (res.error || res.duplicate) return res;
  refreshLineProgress(item);
  if (o.audit !== false) audit(AUDIT_ACTIONS.MATERIAL_PICKED, actor, r, item, res.movements);
  return res;
}

// Moves this line's material from one state back / forward, linking each
// counter-movement to the original it undoes where one exists.
function moveHeld(actor, cap, o, fromState, toState, type, undoes) {
  const x = lineContext(actor, cap, o, type + '_MATERIAL'); if (x.error) return x; if (x.isDuplicate) return x;
  const { r, item } = x;
  const held = heldIn(item, fromState);
  const total = sum(held);
  const want = o.quantity == null ? total : Number(o.quantity);
  if (!(want > 0)) return fail('invalid_quantity', 'Nothing to move');
  if (want > total) return fail('insufficient_stock', 'Only ' + total + ' ' + item.unit + ' ' + fromState.toLowerCase() + ' for this line', { available: total });
  const drafts = []; let left = want;
  held.forEach((h) => {
    if (left <= 0) return;
    let q = Math.min(left, h.quantity); left -= q;
    // link to the newest originals first (the most recent pick is undone first)
    getMovementsForRequestItem(item.id).filter((m) => m.movementType === undoes && m.toLocationId === h.locationId && m.productVariantId === h.productVariantId).reverse().forEach((m) => {
      const can = Math.min(q, reversibleQuantity(m) - drafts.filter((d) => d.reversalOfMovementId === m.id).reduce((a, d) => a + d.quantity, 0));
      if (can > 0) { drafts.push(reversalDraftFor(m, can)); q -= can; }
    });
    // what's left came from before the ledger (a legacy opening balance) or a
    // forward move: an unlinked movement of the right type
    if (q > 0) drafts.push(Object.assign({ movementType: type, companyId: r.companyId, productVariantId: h.productVariantId, quantity: q, unit: item.unit,
      fromLocationId: h.locationId, toLocationId: h.locationId, fromInventoryState: fromState, toInventoryState: toState }, lineFields(r, item)));
  });
  const res = postMovements(actor, drafts, x.idem);
  if (res.error || res.duplicate) return res;
  refreshLineProgress(item);
  return Object.assign(res, { r, item });
}
export function unpickMaterial(actor, o) {
  const res = moveHeld(actor, 'PICK_MATERIALS', o, 'PICKING', 'AVAILABLE', 'UNPICK', 'PICK');
  if (res.ok && !res.duplicate && o.audit !== false) audit(AUDIT_ACTIONS.MATERIAL_UNPICKED, actor, res.r, res.item, res.movements);
  return res;
}
// PACK: PICKING -> PACKED. Partial quantities are supported.
export function packMaterial(actor, o) {
  const x = lineContext(actor, 'PACK_MATERIALS', o, 'PACK_MATERIAL'); if (x.error) return x; if (x.isDuplicate) return x;
  const { r, item } = x;
  const held = heldIn(item, 'PICKING'); const total = sum(held);
  const want = o.quantity == null ? total : Number(o.quantity);
  if (!(want > 0)) return fail('invalid_quantity', 'Nothing picked to pack');
  if (want > total) return fail('insufficient_stock', 'Only ' + total + ' ' + item.unit + ' picked for this line', { available: total });
  const drafts = []; let left = want;
  held.forEach((h) => { if (left <= 0) return; const q = Math.min(left, h.quantity); left -= q;
    drafts.push(Object.assign({ movementType: 'PACK', companyId: r.companyId, productVariantId: h.productVariantId, quantity: q, unit: item.unit,
      fromLocationId: h.locationId, toLocationId: h.locationId, fromInventoryState: 'PICKING', toInventoryState: 'PACKED' }, lineFields(r, item))); });
  const res = postMovements(actor, drafts, x.idem);
  if (res.error || res.duplicate) return res;
  refreshLineProgress(item);
  if (o.audit !== false) audit(AUDIT_ACTIONS.MATERIAL_PACKED, actor, r, item, res.movements);
  return res;
}
export function unpackMaterial(actor, o) {
  const res = moveHeld(actor, 'PACK_MATERIALS', o, 'PACKED', 'PICKING', 'UNPACK', 'PACK');
  if (res.ok && !res.duplicate && o.audit !== false) audit(AUDIT_ACTIONS.MATERIAL_UNPACKED, actor, res.r, res.item, res.movements);
  return res;
}

/* ---------- manual adjustments are LOCATION-SPECIFIC ----------
   A manual adjustment is a physical correction at ONE place: company +
   variant + location + AVAILABLE. ANT never spreads one adjustment over
   several bins and never guesses the bin when there is more than one. */
function insideAnyWarehouse(l) { let cur = l, guard = 0; while (cur && guard++ < 20) { if (cur.type === LOCATION_TYPES.WAREHOUSE) return true; cur = loc(cur.parentLocationId); } return false; }
// Bins in this company's own warehouses (never a jobsite, transit, or another company).
const warehouseBins = (companyId) => db.LOCATIONS.filter((l) => l.companyId === companyId && l.status !== 'INACTIVE' && l.type === LOCATION_TYPES.WAREHOUSE_BIN && insideAnyWarehouse(l))
  .sort((a, b) => a.name.localeCompare(b.name));
// Where this material could be being corrected: every location holding it as
// AVAILABLE, plus its primary location. A never-stocked variant: the warehouse itself.
export function adjustmentCandidates(companyId, vid) {
  const ids = locationsHolding(companyId, vid, 'AVAILABLE').map((b) => b.locationId);
  const it = inventoryItemFor(companyId, vid);
  if (it && ids.indexOf(it.primaryLocationId) === -1) ids.unshift(it.primaryLocationId);
  if (!ids.length) ids.push(mainWarehouseIdFor(db, companyId));
  return ids;
}
// Exactly one eligible location -> use it (no extra tap). Otherwise null: the manager chooses.
export function defaultAdjustmentLocation(companyId, vid) { const c = adjustmentCandidates(companyId, vid); return c.length === 1 ? c[0] : null; }
// For the adjustment screen: this material's locations first (with what is AVAILABLE
// there), then the company's other warehouse bins, which accept found stock.
export function adjustableLocations(companyId, vid) {
  const cand = adjustmentCandidates(companyId, vid);
  const row = (id, stocked) => ({ locationId: id, name: locName(id), available: getInventoryBalance(companyId, vid, id, 'AVAILABLE'), stocked });
  return cand.map((id) => row(id, true)).concat(warehouseBins(companyId).filter((l) => cand.indexOf(l.id) === -1).map((l) => row(l.id, false)));
}

// Manual adjustment: a reason is required; the change is ONE ledger movement
// at ONE location, never an overwritten number. Accepts a signed
// quantityDelta, or direction IN / OUT + quantity.
export function adjustInventory(actor, o) {
  if (!canUser(actor, CAP.MANAGE_INVENTORY)) return fail('forbidden', 'Only a warehouse manager can adjust inventory');
  const state = o.inventoryState || 'AVAILABLE';
  let direction = o.direction, q = Number(o.quantity);
  if (o.quantityDelta != null) { const dq = Number(o.quantityDelta); direction = dq > 0 ? 'IN' : dq < 0 ? 'OUT' : null; q = Math.abs(dq); }
  const idem = o.operationKey ? { operationKey: o.operationKey, operationType: 'INVENTORY_ADJUSTMENT', entityType: 'InventoryItem', entityId: o.productVariantId,
    fingerprint: fingerprintOf({ op: 'INVENTORY_ADJUSTMENT', productVariantId: o.productVariantId, locationId: o.locationId || null, inventoryState: state,
      direction: direction || null, quantity: q, reasonCode: o.reasonCode || null }) } : {};
  const prior = checkOperation(actor, o.operationKey, 'INVENTORY_ADJUSTMENT', idem.fingerprint);
  if (prior) return prior;
  const p = getProduct(o.productVariantId);
  if (!p) return fail('unknown_variant', 'Unknown product variant');
  if (state !== 'AVAILABLE') return fail('invalid_state', 'Manual adjustments correct AVAILABLE stock');
  if (!o.reasonCode || !ADJUSTMENT_REASONS[o.reasonCode]) return fail('reason_required', 'Choose a reason for this adjustment');
  if (!isFinite(q) || q <= 0 || Math.floor(q) !== q) return fail('invalid_quantity', 'Enter a whole quantity greater than 0');
  if (direction !== 'IN' && direction !== 'OUT') return fail('invalid_direction', 'Add or remove?');
  const c = actor.companyId, vid = o.productVariantId;
  let locationId = o.locationId || null;
  if (!locationId) {
    locationId = defaultAdjustmentLocation(c, vid);
    if (!locationId) return fail('LOCATION_REQUIRED', 'This material is in more than one location: choose the one you are correcting', { locations: adjustmentCandidates(c, vid) });
  }
  const beforeAt = getInventoryBalance(c, vid, locationId, 'AVAILABLE'), totalBefore = getAvailableQuantity(c, vid);
  const draft = { movementType: direction === 'IN' ? 'INVENTORY_ADJUSTMENT_IN' : 'INVENTORY_ADJUSTMENT_OUT', companyId: c, productVariantId: vid,
    quantity: q, unit: p.unit, reasonCode: o.reasonCode, notes: (o.notes || '').trim() };
  if (direction === 'IN') Object.assign(draft, { toLocationId: locationId, toInventoryState: 'AVAILABLE' });
  else Object.assign(draft, { fromLocationId: locationId, fromInventoryState: 'AVAILABLE' });
  // The ledger checks the location (exists, this company, inside a warehouse)
  // and that THIS location has enough; it never takes the rest from another bin.
  const res = postMovements(actor, [draft], idem);
  if (res.error || res.duplicate) return res;
  ensureInventoryItem(c, vid, locationId);
  const afterAt = getInventoryBalance(c, vid, locationId, 'AVAILABLE'), totalAfter = getAvailableQuantity(c, vid);
  const delta = direction === 'IN' ? q : -q, m = res.movements[0];
  recordAudit({ action: AUDIT_ACTIONS.INVENTORY_ADJUSTED, entityType: 'MaterialMovement', entityId: m.id, companyId: c,
    before: { available: totalBefore, atLocation: beforeAt },
    after: { companyId: c, productVariantId: vid, locationId, inventoryState: 'AVAILABLE', quantityBeforeAtLocation: beforeAt, quantityDelta: delta,
      quantityAfterAtLocation: afterAt, totalAvailableBefore: totalBefore, totalAvailableAfter: totalAfter, reasonCode: o.reasonCode,
      performedByUserId: actor.id, movementId: m.id, movementIds: [m.id], timestamp: m.timestamp, quantity: delta, available: totalAfter } }, actor);
  return Object.assign(res, { available: totalAfter, availableAtLocation: afterAt, locationId });
}
// Manager correction of any movement through a mirror-image reversal.
export function correctMovement(actor, movementId, o) {
  const res = reverseMovement(actor, movementId, o || {});
  if (res.ok && !res.duplicate) {
    const orig = getMovementById(movementId);
    const r = orig.requestId ? db.REQUESTS.find((x) => x.id === orig.requestId) : null;
    if (r) { const it = r.items.find((i) => i.id === orig.requestItemId); if (it) refreshLineProgress(it); }
    recordAudit({ action: AUDIT_ACTIONS.MATERIAL_MOVEMENT_CREATED, entityType: 'MaterialMovement', entityId: res.movements[0].id, companyId: actor.companyId,
      projectId: orig.projectId, before: null, after: { movementIds: [res.movements[0].id], reversalOfMovementId: movementId, quantity: res.movements[0].quantity,
        productVariantId: orig.productVariantId } }, actor);
  }
  return res;
}

/* ---------- reconciliation ---------- */
// Start from zero and replay the company's movements in order. With
// { apply: true } the stored balances are replaced by the rebuilt ones
// (a development / admin repair path; history is never changed).
export function rebuildInventoryBalancesFromLedger(companyId, opts) {
  const map = replayMovements(getMovementsForCompany(companyId));
  const rebuilt = Object.keys(map).map((k) => map[k]);
  if (opts && opts.apply) db.INVENTORY_BALANCES = db.INVENTORY_BALANCES.filter((b) => b.companyId !== companyId).concat(rebuilt);
  return rebuilt;
}
// Stored balance vs what the ledger says it should be. Never hides a variance.
export function validateInventoryAgainstLedger(companyId) {
  const expected = {}; rebuildInventoryBalancesFromLedger(companyId).forEach((b) => { expected[b.id] = b; });
  const stored = {}; getInventoryForCompany(companyId).forEach((b) => { stored[b.id] = b; });
  const out = [];
  Object.keys(Object.assign({}, expected, stored)).forEach((k) => {
    const s = stored[k] ? stored[k].quantity : 0, e = expected[k] ? expected[k].quantity : 0;
    if (s !== e) { const b = stored[k] || expected[k];
      out.push({ productVariantId: b.productVariantId, locationId: b.locationId, inventoryState: b.inventoryState, stored: s, ledger: e, variance: s - e }); }
  });
  return out;
}
export { LOCATION_TYPES };
