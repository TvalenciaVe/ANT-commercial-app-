/* =========================================================================
   REPOSITORY — plain lookups over the stored collections.
   The lowest service layer: no permissions, no side effects. Everything
   above it (permissions, services, screens) reads data through here, so a
   future backend only needs to reimplement these functions.
   ========================================================================= */
import { db } from '../lib/db.js';

const byId = (list, id) => (id ? list.find((x) => x.id === id) || null : null);

export const getCompany = (id) => byId(db.COMPANIES, id);
export const getUser = (id) => byId(db.USERS, id);
export const getProject = (id) => byId(db.PROJECTS, id);
export const getLocation = (id) => byId(db.LOCATIONS, id);
export const getRequest = (id) => byId(db.REQUESTS, id);
export const getKit = (id) => byId(db.JOB_KITS, id);

export const allCompanies = () => db.COMPANIES;
export const usersInCompany = (companyId) => db.USERS.filter((u) => u.companyId === companyId);
export const projectsInCompany = (companyId) => db.PROJECTS.filter((p) => p.companyId === companyId);
export const locationsInCompany = (companyId) => db.LOCATIONS.filter((l) => l.companyId === companyId);
export const requestsInCompany = (companyId) => db.REQUESTS.filter((r) => r.companyId === companyId);

// One active membership per user + project (enforced on write and by integrity checks).
export const getMembership = (userId, projectId) =>
  db.MEMBERSHIPS.find((m) => m.userId === userId && m.projectId === projectId && m.status === 'ACTIVE') || null;
export const activeMembershipsForUser = (userId) => db.MEMBERSHIPS.filter((m) => m.userId === userId && m.status === 'ACTIVE');
export const activeMembershipsForProject = (projectId) => db.MEMBERSHIPS.filter((m) => m.projectId === projectId && m.status === 'ACTIVE');
