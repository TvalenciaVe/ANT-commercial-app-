/* =========================================================================
   REQUEST WORKFLOW (Phase 3) — the orchestration a submitted request goes
   through. Screens call ONE function; they never know about allocation.

     validate -> duplicate check -> save -> approval needed?
       yes -> PENDING_APPROVAL (nothing reserved until approved)
       no  -> APPROVED -> allocate (assigned warehouse) -> RESERVE -> fulfillment
     outstanding demand stays on the request for future Purchasing.

   Every multi-step change runs inside transaction(): if any step fails,
   nothing is left half done (see lib/transaction.js for the prototype limit).
   ========================================================================= */
import { db, now } from '../lib/db.js';
import { canUser, CAP } from '../lib/permissions.js';
import { transaction } from '../lib/transaction.js';
import { getCompany, getProject } from './repo.js';
import { createRequest } from './requestService.js';
import { recordAudit, AUDIT_ACTIONS } from './auditService.js';
import { notify, NOTIFICATION_TYPES } from './notificationService.js';
import { systemActor, fingerprintOf } from './materialLedgerService.js';
import { allocateRequest, releaseAllocation, refreshRequestAllocationStatus, getAllocationsForRequest, modifyAllocation, allocationById, allocateFromLocation } from './allocationService.js';
import { createOrExtendWarehouseFulfillment, fulfillmentsForRequest, refreshFulfillment, fulfillmentById } from './fulfillmentService.js';
import { evaluateApproval, createApprovalRequest, resolveStep, approvalsForRequest } from './approvalService.js';
import { refreshRequestStatus, getRequestAllocationSummary, isV5, allocationState, isActiveAllocation } from './requestProgress.js';
import { OPEN_REQUEST_STATUSES, FULFILLMENT_EXTENDABLE_STATUSES } from '../config/requests.js';
import { syncForRequest } from './purchaseRequirementService.js';
import { dropRequestFromDrafts } from './purchaseOrderService.js';
import { supplierAllocationsForRequest, isSupplierCommitted, supplierRemaining } from './requestProgress.js';
import { normalizePriority } from '../config/priorities.js';
import { demandItem } from '../lib/requestModel.js';
import { deepFreeze } from '../lib/ledger.js';
import { stageOf } from './fulfillmentService.js';

const fail = (error, message, extra) => Object.assign({ error, message }, extra || {});
const OPEN_LEGACY_STAGES = ['PENDING', 'IN_PROGRESS', 'PARTIALLY_PACKED', 'PACKED', 'READY_TO_SHIP', 'SHIPPED'];

/* ---------- duplicate detection (a warning, never a block) ---------- */
export function findPossibleDuplicates(actor, projectId, lines) {
  const project = getProject(projectId);
  if (!actor || !project || project.companyId !== actor.companyId) return [];
  const c = getCompany(project.companyId);
  if (!c || c.settings.duplicateDetectionEnabled === false) return [];
  const hours = c.settings.duplicateWindowHours == null ? 24 : Math.max(0, Number(c.settings.duplicateWindowHours) || 0);   // 0 is a real choice
  if (hours === 0) return [];
  const since = now() - hours * 3600 * 1000;
  const wanted = (lines || []).map((l) => l.productId);
  const out = [];
  db.REQUESTS.forEach((r) => {
    if (r.companyId !== project.companyId || r.projectId !== projectId || (r.submittedAt || r.createdAt) < since) return;
    const open = isV5(r) ? OPEN_REQUEST_STATUSES.indexOf(r.status) !== -1 : OPEN_LEGACY_STAGES.indexOf(r.workflowStatus) !== -1 && r.status !== 'CANCELLED';
    if (!open) return;
    r.items.forEach((it) => { if (wanted.indexOf(it.productVariantId) !== -1) out.push({ requestId: r.id, requestItemId: it.id, productVariantId: it.productVariantId,
      quantity: it.quantity, unit: it.unit, productNameSnapshot: it.productNameSnapshot, variantSnapshot: it.variantSnapshot, submittedAt: r.submittedAt || r.createdAt }); });
  });
  return out;
}
export function recordDuplicateWarningShown(actor, projectId, matches) {
  return recordAudit({ action: AUDIT_ACTIONS.DUPLICATE_WARNING_SHOWN, entityType: 'Project', entityId: projectId, projectId, before: null,
    after: { matchingRequestIds: uniq(matches.map((m) => m.requestId)), productVariantIds: uniq(matches.map((m) => m.productVariantId)) } }, actor);
}
const uniq = (l) => l.filter((x, i) => l.indexOf(x) === i);

/* ---------- submit ---------- */
// opts: { submissionKey, duplicateOverride: matches[] }
// Returns { request } | { duplicates } (not saved: show the warning) | { error }.
/* ---------- submission idempotency ----------
   Scope: company + the requesting user + submissionKey, validated by a
   payload fingerprint. Same user, key and payload -> the same request comes
   back (a double tap creates one request, one allocation, one reservation).
   Same user and key with a different payload -> IDEMPOTENCY_CONFLICT (never
   silently the old request). Another user or another company with the same
   key -> an independent submission. The record lives in the company-scoped
   idempotency records (Phase 2 pattern) and points at the request it created. */
const brandKey = (b) => (b ? (b.selection || '') + ':' + (b.manufacturerId || b.manufacturerName || '') : '');
const sortItems = (items) => items.sort((a, b) => (a.v + '|' + a.u + '|' + a.b + '|' + a.q + '|' + a.n).localeCompare(b.v + '|' + b.u + '|' + b.b + '|' + b.q + '|' + b.n));
const fpPayload = (projectId, userId, priority, neededBy, notes, items) => fingerprintOf({ projectId, requestedByUserId: userId, priority: normalizePriority(priority),
  neededBy: Number(neededBy) || null, notes: String(notes || '').trim(), items: sortItems(items) });
// From the submission (cart lines resolved exactly as createRequest resolves them; item order doesn't matter).
export function submissionFingerprint(userId, input) {
  const items = (input.lines || []).filter((l) => l && l.qty > 0).map((l, i) => {
    const it = demandItem({ productId: l.productId, qty: l.qty, brandIdx: l.brandIdx || 0, configured: l.configured }, 'fp', i);
    return { v: it.productVariantId, q: it.quantity, u: it.unit, b: brandKey(it.brandSnapshot), n: String(l.notes || '').trim() };
  });
  return fpPayload(input.projectId, userId, input.priority, input.neededBy, input.notes, items);
}
// From a saved request (for records written before the fingerprint was stored).
export const requestFingerprint = (r) => fpPayload(r.projectId, r.requestedByUserId, r.priority, r.neededBy, r.notes,
  r.items.map((it) => ({ v: it.productVariantId, q: it.quantity, u: it.unit, b: brandKey(it.brandSnapshot), n: String(it.notes || '').trim() })));
const submitKey = (userId, key) => 'submit:' + userId + ':' + key;
function priorSubmission(actor, key, fp) {
  const rec = (db.IDEMPOTENCY_RECORDS || []).find((x) => x.companyId === actor.companyId && x.operationKey === submitKey(actor.id, key));
  let prior, priorFp;
  if (rec) {
    prior = db.REQUESTS.find((r) => r.id === rec.resultEntityId);
    // never hand back a request that isn't this person's, in this company
    if (!prior || prior.companyId !== actor.companyId || prior.requestedByUserId !== actor.id || rec.actorUserId !== actor.id)
      return fail('IDEMPOTENCY_INTEGRITY', 'This submission record is not valid for you');
    priorFp = rec.payloadFingerprint;
  } else {
    // v5 data saved before submission records existed: the request itself carries the key
    prior = db.REQUESTS.find((r) => r.companyId === actor.companyId && r.requestedByUserId === actor.id && r.submissionKey === key) || null;
    priorFp = prior ? prior.submissionFingerprint || requestFingerprint(prior) : null;
  }
  if (!prior) return null;
  if (priorFp !== fp) {
    recordAudit({ action: AUDIT_ACTIONS.REQUEST_SUBMISSION_IDEMPOTENCY_CONFLICT, entityType: 'MaterialRequest', entityId: prior.id, projectId: prior.projectId, before: null,
      after: { submissionKey: key, requesterUserId: actor.id } }, actor);
    return fail('IDEMPOTENCY_CONFLICT', 'This submission was already sent with different details');
  }
  return { request: prior, duplicateSubmission: true };
}

export function submitRequest(actor, input, opts) {
  const o = opts || {};
  const fp = actor ? submissionFingerprint(actor.id, input) : null;
  if (o.submissionKey && actor) {
    const prior = priorSubmission(actor, o.submissionKey, fp);
    if (prior) return prior;   // the same request again, a conflict, or an integrity refusal
  }
  if (!o.duplicateOverride) {
    const dups = findPossibleDuplicates(actor, input.projectId, input.lines);
    if (dups.length) return { duplicates: dups };
  }
  return transaction(() => {
    const res = createRequest(actor, input);
    if (res.error) return res;
    const r = res.request;
    r.submissionKey = o.submissionKey || null;
    r.submissionFingerprint = fp;
    if (o.submissionKey) db.IDEMPOTENCY_RECORDS.push(deepFreeze({ companyId: actor.companyId, operationKey: submitKey(actor.id, o.submissionKey),
      operationType: 'SUBMIT_MATERIAL_REQUEST', actorUserId: actor.id, actorType: 'USER', entityType: 'MaterialRequest', entityId: r.id,
      payloadFingerprint: fp, resultMovementIds: [], resultEntityType: 'MaterialRequest', resultEntityId: r.id, createdAt: now() }));
    if (o.duplicateOverride && o.duplicateOverride.length) recordAudit({ action: AUDIT_ACTIONS.DUPLICATE_WARNING_OVERRIDDEN, entityType: 'MaterialRequest', entityId: r.id,
      projectId: r.projectId, before: null, after: { requesterUserId: actor.id, projectId: r.projectId, matchingRequestIds: uniq(o.duplicateOverride.map((m) => m.requestId)),
        productVariantIds: uniq(o.duplicateOverride.map((m) => m.productVariantId)) } }, actor);
    const ev = evaluateApproval(r);
    if (ev.required) {
      r.approvalStatus = 'PENDING';
      const ap = createApprovalRequest(r, ev, actor);
      r.approvalRequestId = ap.id;
      refreshRequestStatus(r);
      return { request: r, approval: ap };
    }
    r.approvalStatus = 'NOT_REQUIRED';
    const cont = continueApprovedRequest(r, actor.id);
    if (cont.error) return cont;
    return { request: r, allocation: cont };
  });
}

// Approved (or approval not needed): allocate, reserve, create the warehouse fulfillment.
export function continueApprovedRequest(r, triggeredByUserId) {
  refreshRequestStatus(r);   // APPROVED
  const c = getCompany(r.companyId);
  if (c && c.settings.autoAllocateWarehouseStock === false) { notifyOutstanding(r, 'manual'); return { ok: true, waitingForManualAllocation: true }; }
  const sys = systemActor(r.companyId, 'AUTO_ALLOCATION', triggeredByUserId);
  const res = allocateRequest(sys, r);
  if (res.error) return res;
  const f = createOrExtendWarehouseFulfillment(sys, r, res.allocations);
  refreshRequestAllocationStatus(r);
  refreshRequestStatus(r);
  notifyAllocation(r);
  if (getRequestAllocationSummary(r).outstanding > 0) notifyOutstanding(r, 'stock');
  syncForRequest(r, systemActor(r.companyId, 'PURCHASE_REQUIREMENT_SYNC', triggeredByUserId));   // Phase 4: unsourced demand -> Purchase Requirement
  return { ok: true, allocations: res.allocations, fulfillment: f };
}
// The warehouse managers learn once when approved demand still needs sourcing.
function notifyOutstanding(r, why) {
  const managers = db.USERS.filter((u) => u.companyId === r.companyId && u.status === 'ACTIVE' && canUser(u, CAP.MANAGE_ALLOCATIONS)).map((u) => u.id);
  const s = getRequestAllocationSummary(r);
  notify(managers, { companyId: r.companyId, type: NOTIFICATION_TYPES.OUTSTANDING_DEMAND, title: r.id + ' \u00b7 outstanding demand',
    message: why === 'manual' ? 'Approved and waiting for manual allocation.' : s.linesWithOutstanding + ' line' + (s.linesWithOutstanding === 1 ? '' : 's') + ' not covered by warehouse stock yet.',
    entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId });
}
function notifyAllocation(r) {
  const s = getRequestAllocationSummary(r);
  const msg = s.outstanding === 0 ? 'Everything requested is available from the warehouse.'
    : s.allocated === 0 ? 'Nothing is available in the warehouse yet. ' + s.outstanding + ' remain outstanding.'
    : s.allocated + ' of ' + s.requested + ' are available from the warehouse. ' + s.outstanding + ' remain outstanding.';
  notify([r.requestedByUserId], { companyId: r.companyId, type: NOTIFICATION_TYPES.ALLOCATION_SUMMARY, title: r.id + ' \u00b7 warehouse availability',
    message: msg, entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId });
}

/* ---------- approve / reject ---------- */
export function approveRequest(actor, approvalId, notes) {
  return transaction(() => {
    const res = resolveStep(actor, approvalId, 'APPROVE', notes);
    if (res.error) return res;
    const r = db.REQUESTS.find((x) => x.id === res.approval.requestId);
    if (!res.done) return { ok: true, approval: res.approval, request: r, nextStep: true };   // multi-step: next approver
    r.approvalStatus = 'APPROVED';
    recordAudit({ action: AUDIT_ACTIONS.MATERIAL_REQUEST_APPROVED, entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId, before: { status: 'PENDING_APPROVAL' },
      after: { approvalId, approvedByUserId: actor.id, notes: notes || null } }, actor);
    notify([r.requestedByUserId], { companyId: r.companyId, type: NOTIFICATION_TYPES.REQUEST_APPROVED, title: 'Request approved', message: r.id,
      entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId });
    const cont = continueApprovedRequest(r, actor.id);
    if (cont.error) return cont;
    return { ok: true, approval: res.approval, request: r, allocation: cont };
  });
}
export function rejectRequest(actor, approvalId, notes) {
  return transaction(() => {
    const res = resolveStep(actor, approvalId, 'REJECT', notes);
    if (res.error) return res;
    const r = db.REQUESTS.find((x) => x.id === res.approval.requestId);
    r.approvalStatus = 'REJECTED';
    refreshRequestStatus(r);   // CANCELLED, rejection preserved in approvalStatus + the approval record
    recordAudit({ action: AUDIT_ACTIONS.MATERIAL_REQUEST_REJECTED, entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId, before: { status: 'PENDING_APPROVAL' },
      after: { approvalId, rejectedByUserId: actor.id, notes: notes || null } }, actor);
    notify([r.requestedByUserId], { companyId: r.companyId, type: NOTIFICATION_TYPES.REQUEST_REJECTED, title: 'Request rejected',
      message: r.id + (notes ? ' \u00b7 Reason: ' + notes : ''), entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId });
    return { ok: true, approval: res.approval, request: r };
  });
}

/* ---------- cancel ---------- */
// Before the warehouse physically starts: release reservations (UNRESERVE),
// cancel the fulfillment and any pending approval. After picking started:
// refused with a clear reason (a warehouse correction is needed first).
export function cancelRequest(actor, requestId, reason) {
  return transaction(() => {
    const r = db.REQUESTS.find((x) => x.id === requestId);
    if (!r || !actor || r.companyId !== actor.companyId) return fail('forbidden', 'Not your company\'s request');
    const mine = r.requestedByUserId === actor.id && canUser(actor, CAP.REQUEST_MATERIALS, { projectId: r.projectId });
    if (!mine && !canUser(actor, CAP.MANAGE_PROJECT, { projectId: r.projectId })) return fail('forbidden', 'Only the requester or the project lead can cancel');
    if (r.status === 'CANCELLED' || r.status === 'FULFILLED') return fail('not_cancellable', 'This request is already ' + r.status.toLowerCase());
    if (!isV5(r)) {
      if (r.workflowStatus !== 'PENDING' || r.items.some((i) => (i.pickedQuantity || 0) > 0)) return fail('processing_started', 'The warehouse has already started this order');
    } else {
      const started = getAllocationsForRequest(r.id).some((a) => { const s = allocationState(a.id); return s.PICKING + s.PACKED > 0; });
      if (started) return fail('processing_started', 'The warehouse has already picked material for this request. Ask the warehouse to return it first.');
      // Phase 4: material a supplier committed to can't just vanish; Purchasing releases it first
      if (supplierAllocationsForRequest(r.id).some((a) => isSupplierCommitted(a) && supplierRemaining(a) > 0))
        return fail('purchasing_committed', 'Material for this request is on order from a supplier. Ask Purchasing to cancel or release it first.');
      dropRequestFromDrafts(r.id);   // draft claims are internal: they simply go away
      const sys = systemActor(r.companyId, 'REQUEST_CANCELLED', actor.id);
      for (const a of getAllocationsForRequest(r.id).filter(isActiveAllocation)) {
        const rel = releaseAllocation(sys, a.id, { reason: 'Request cancelled' });
        if (rel.error) return rel;
        a.status = 'CANCELLED';
      }
      fulfillmentsForRequest(r.id).forEach((f) => { refreshFulfillment(f); f.status = 'CANCELLED'; f.updatedAt = now(); });
      approvalsForRequest(r.id).filter((ap) => ap.status === 'PENDING').forEach((ap) => {
        ap.status = 'CANCELLED'; ap.resolvedAt = now();
        ap.steps.forEach((x) => { if (x.status === 'PENDING' || x.status === 'WAITING') x.status = 'CANCELLED'; });
      });
      if (r.approvalStatus === 'PENDING') r.approvalStatus = 'CANCELLED';
      refreshRequestAllocationStatus(r);
    }
    Object.assign(r, { status: 'CANCELLED', cancelledAt: now(), cancelledByUserId: actor.id, cancelReason: reason || null, updatedAt: now() });
    syncForRequest(r, systemActor(r.companyId, 'REQUEST_CANCELLED', actor.id));   // open requirements for it are released
    recordAudit({ action: AUDIT_ACTIONS.MATERIAL_REQUEST_CANCELLED, entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId, before: null,
      after: { cancelledByUserId: actor.id, reason: reason || null } }, actor);
    return { ok: true, request: r };
  });
}
/* ---------- warehouse manager: review / change allocations ----------
   Changes go through the ledger (RESERVE / UNRESERVE the difference) and keep
   the fulfillment and the request's outstanding demand in step. Once an order
   has left packing (ready / dispatched) its allocation is locked. */
// The allocation's OWN batch decides: dispatched work is never changed; a batch
// the warehouse already started can shrink (unpicked reserve) but never grow.
const batchOf = (a) => (a.fulfillmentId ? fulfillmentById(a.fulfillmentId) : null);
const isLocked = (f) => !!f && (f.status === 'READY' || !!f.dispatchStatus);
const isStarted = (f) => !!f && FULFILLMENT_EXTENDABLE_STATUSES.indexOf(f.status) === -1;
function afterAllocationChange(r, actor) {
  fulfillmentsForRequest(r.id).forEach(refreshFulfillment);
  refreshRequestAllocationStatus(r);
  refreshRequestStatus(r);
  // Phase 4: warehouse coverage changed -> requirements grow or release UNCOMMITTED quantity (sent POs untouched)
  syncForRequest(r, systemActor(r.companyId, 'PURCHASE_REQUIREMENT_SYNC', actor ? actor.id : null));
}
export function managerSetAllocation(actor, allocationId, quantity) {
  return transaction(() => {
    const a = allocationById(allocationId);
    const r = a && db.REQUESTS.find((x) => x.id === a.requestId);
    if (!a || !r || r.companyId !== (actor && actor.companyId)) return fail('forbidden', 'Not your company\'s allocation');
    const f = batchOf(a);
    if (isLocked(f)) return fail('fulfillment_dispatched', 'This batch has left packing and can no longer change');
    if (Number(quantity) > a.quantity && isStarted(f)) return fail('batch_started', 'Work already started on this batch. Use Allocate available stock to prepare more in a new batch.');
    const res = modifyAllocation(actor, allocationId, quantity);
    if (res.error) return res;
    afterAllocationChange(r, actor);
    return Object.assign(res, { request: r });
  });
}
export const managerReleaseAllocation = (actor, allocationId) => managerSetAllocation(actor, allocationId, 0);
// Stock arrived after the request: allocate what is available now for its outstanding lines.
// opts.coverOnOrder: explicit manager choice to cover quantity already on a supplier PO from
// warehouse stock; the PO is not changed, Purchasing sees it as a commitment that may be unneeded.
export function managerAllocateAvailable(actor, requestId, opts) {
  return transaction(() => {
    const r = db.REQUESTS.find((x) => x.id === requestId);
    if (!r || !actor || r.companyId !== actor.companyId || !isV5(r)) return fail('forbidden', 'Not your company\'s request');
    if (['APPROVED', 'PROCESSING', 'PARTIALLY_FULFILLED'].indexOf(r.status) === -1) return fail('not_allocatable', 'This request is not open for allocation');
    // Existing outstanding demand is sourced ON THIS REQUEST (never "create a new request");
    // new stock joins an unstarted batch or gets a new batch (createOrExtendWarehouseFulfillment).
    const had = getAllocationsForRequest(r.id).length > 0;
    r.allocationRound = (r.allocationRound || 1) + 1;
    const res = allocateRequest(actor, r, { round: r.allocationRound, source: 'MANUAL_ALLOCATION', coverOnOrder: !!(opts && opts.coverOnOrder) });
    if (res.error) return res;
    let f = null;
    if (res.allocations.length) {
      f = createOrExtendWarehouseFulfillment(actor, r, res.allocations);
      const qty = res.allocations.reduce((n, a) => n + a.quantity, 0);
      if (had) recordAudit({ action: AUDIT_ACTIONS.WAREHOUSE_ALLOCATION_REOPENED, entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId, before: null,
        after: { allocationIds: res.allocations.map((a) => a.id), quantity: qty, fulfillmentId: f && f.id, round: r.allocationRound } }, actor);
      const lines = res.allocations.map((a) => { const it = r.items.find((x) => x.id === a.requestItemId); return a.quantity + ' ' + a.unit + ' ' + ((it && it.productNameSnapshot) || ''); });
      notify([r.requestedByUserId], { companyId: r.companyId, type: NOTIFICATION_TYPES.ADDITIONAL_ALLOCATION, title: r.id + ' \u00b7 more available from the warehouse',
        message: (had ? 'Now also allocated: ' : 'Now allocated: ') + lines.join(', ') + '.', entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId });
    }
    afterAllocationChange(r, actor);
    return { ok: true, allocations: res.allocations, fulfillment: f, request: r };
  });
}
// Manager: allocate from one specific bin. Same batch rule as Allocate available
// (joins an unstarted batch, otherwise a new batch), so no reservation is ever
// left without a warehouse task.
export function managerAllocateFromLocation(actor, requestId, requestItemId, locationId, quantity) {
  return transaction(() => {
    const r = db.REQUESTS.find((x) => x.id === requestId);
    if (!r || !actor || r.companyId !== actor.companyId || !isV5(r)) return fail('forbidden', 'Not your company\'s request');
    if (['APPROVED', 'PROCESSING', 'PARTIALLY_FULFILLED'].indexOf(r.status) === -1) return fail('not_allocatable', 'This request is not open for allocation');
    const item = r.items.find((i) => i.id === requestItemId);
    if (!item) return fail('not_found', 'Unknown line');
    const res = allocateFromLocation(actor, r, item, locationId, quantity);
    if (res.error) return res;
    const f = createOrExtendWarehouseFulfillment(actor, r, [res.allocation]);
    afterAllocationChange(r, actor);
    return Object.assign(res, { fulfillment: f, request: r });
  });
}
export { stageOf };
