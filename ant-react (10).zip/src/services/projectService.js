/* =========================================================================
   PROJECTS & MEMBERSHIPS

   ProjectMembership is the ONLY source of truth for who is on a project and
   what they may do there. Users never carry a project list; "my projects"
   is always derived from active memberships.
   ========================================================================= */
import { db, uid, now, nextProjectId } from '../lib/db.js';
import { getProject, getUser, getMembership, activeMembershipsForUser, activeMembershipsForProject, projectsInCompany } from './repo.js';
import { canUser, CAP, permLabel } from '../lib/permissions.js';
import { t } from '../lib/i18n.js';
import { DEFAULT_PROJECT_PERMISSION, permissionAllowedFor, isProjectLeadRole, normalizeProjectRole, normalizePermissionLevel, roleLabel, PROJECT_LEAD_ROLES } from '../config/roles.js';
import { companyRolesOf } from '../lib/userModel.js';
import { isOpenProjectStatus, projectStatusLabel, inWorkflowGroup } from '../config/statuses.js';
import { stageOf } from './fulfillmentService.js';
import { parseAddress, formatAddress } from '../lib/address.js';
import { ensureJobsite, mainWarehouseIdFor, ensureCompanyWarehouse } from '../lib/locationModel.js';
import { getCompany } from './repo.js';
import { recordAudit, AUDIT_ACTIONS } from './auditService.js';
export { getProject, getMembership };

/* ---------- reads ---------- */
export const projectsForUser = (userId) => activeMembershipsForUser(userId).map((m) => getProject(m.projectId)).filter(Boolean);
export const companyProjects = (companyId) => projectsInCompany(companyId);
export const projectAddress = (p) => formatAddress(p);
export const projectStatusText = (p) => (p ? projectStatusLabel(p.status) : '');
export const isOpenProject = (p) => !!p && isOpenProjectStatus(p.status);
export const projectRoleLabel = (m) => (m ? roleLabel(m.projectRole) : '');
export const isLeadMembership = (m) => !!m && isProjectLeadRole(m.projectRole);
// Home's context line: "Foreman" / "Journeyman · Can Request Materials" / "Apprentice · View Only".
export function projectContextLine(user, project) {
  const m = user && project ? getMembership(user.id, project.id) : null;
  if (!m) return t('current_project');
  return isLeadMembership(m) ? roleLabel(m.projectRole) : roleLabel(m.projectRole) + ' \u00b7 ' + permLabel(m.permissionLevel);
}

// Team, leads first, then alphabetical.
export function teamForProject(projectId) {
  return activeMembershipsForProject(projectId)
    .map((m) => ({ membership: m, user: getUser(m.userId) })).filter((x) => x.user)
    .sort((a, b) => (isLeadMembership(b.membership) - isLeadMembership(a.membership)) || a.user.name.localeCompare(b.user.name));
}
export function foremanForProject(projectId) {
  const f = activeMembershipsForProject(projectId).find((m) => m.projectRole === 'FOREMAN');
  return f ? getUser(f.userId) : null;
}
export function projectStats(projectId) {
  const requests = db.REQUESTS.filter((r) => r.projectId === projectId);
  return {
    teamCount: activeMembershipsForProject(projectId).length,
    openRequests: requests.filter((r) => ['PENDING_APPROVAL', 'AWAITING_STOCK'].indexOf(stageOf(r)) !== -1 || inWorkflowGroup('OPEN_FOR_PACKING', stageOf(r))).length,
    upcomingDeliveries: requests.filter((r) => inWorkflowGroup('UPCOMING_DELIVERY', stageOf(r))).length,
  };
}
export function findSimilarProject(companyId, name, address, number) {
  const n = (name || '').trim().toLowerCase(), a = (address || '').trim().toLowerCase(), num = (number || '').trim().toLowerCase();
  return projectsInCompany(companyId).find((p) =>
    (num && p.projectNumber && p.projectNumber.toLowerCase() === num) ||
    (n && p.name.trim().toLowerCase() === n) ||
    (a && formatAddress(p).toLowerCase() === a)) || null;
}

/* ---------- activity feed (human-readable project timeline) ---------- */
export function logActivity(projectId, text) {
  const p = getProject(projectId);
  db.ACTIVITY.unshift({ id: uid('act'), companyId: p ? p.companyId : null, projectId, text, at: now() });
}
export const activityForProject = (projectId) => db.ACTIVITY.filter((a) => a.projectId === projectId).slice(0, 20);

/* ---------- memberships: the only write path ---------- */
// One ACTIVE record per user + project: an existing one is updated in place.
// Refuses (null) anything invalid: unknown role, a level above the role's
// maximum, an inactive or warehouse person, or a user from another company.
export function addOrUpdateMembership(projectId, userId, projectRole, permissionLevel, assignedBy) {
  const project = getProject(projectId), user = getUser(userId);
  const role = normalizeProjectRole(projectRole);
  if (!project || !user || !role) return null;
  if (user.companyId !== project.companyId) return null;                 // never cross companies
  if (user.status !== 'ACTIVE' || (user.workerType !== 'FIELD' && user.workerType !== 'MANAGEMENT')) return null;
  const level = permissionLevel == null ? DEFAULT_PROJECT_PERMISSION[role] : normalizePermissionLevel(permissionLevel);
  if (!level || !permissionAllowedFor(role, level)) return null;
  const existing = getMembership(userId, projectId);
  if (existing) {
    Object.assign(existing, { projectRole: role, permissionLevel: level, assignedAt: now(), assignedBy });
    return existing;
  }
  const m = { id: uid('mem'), companyId: project.companyId, projectId, userId, projectRole: role, permissionLevel: level,
    status: 'ACTIVE', assignedAt: now(), assignedBy };
  db.MEMBERSHIPS.push(m);
  return m;
}

// A lead changes one person's permission on ONE project. Returns the
// updated membership, or null (refused). Other projects are untouched.
export function setProjectPermission(actor, projectId, userId, level) {
  if (!canUser(actor, CAP.MANAGE_PROJECT_TEAM, { projectId })) return null;
  const m = getMembership(userId, projectId);
  if (!m || userId === actor.id || isLeadMembership(m)) return null;   // leads manage others, not themselves or other leads
  if (!permissionAllowedFor(m.projectRole, level) || m.permissionLevel === level) return null;
  const before = m.permissionLevel;
  m.permissionLevel = level;
  recordAudit({ action: AUDIT_ACTIONS.PERMISSION_CHANGED, entityType: 'ProjectMembership', entityId: m.id, projectId,
    before: { permissionLevel: before }, after: { permissionLevel: level, userId } }, actor);
  return m;
}

// Adds people to a project. selections = { userId: permissionLevel } (the
// screen today: project role defaults to the person's primary role) or
// { userId: { projectRole, permissionLevel } } to set the project role
// explicitly. Project role and primary role are independent: a Journeyman
// can lead Project B. Making someone a lead (PM / Superintendent / Foreman)
// needs ASSIGN_PROJECT_LEADS; an existing lead's membership isn't changed here.
export function addTeamMembers(actor, projectId, selections) {
  if (!canUser(actor, CAP.MANAGE_PROJECT_TEAM, { projectId })) return [];
  const added = [];
  Object.keys(selections).forEach((userId) => {
    const worker = getUser(userId);
    const sel = selections[userId];
    const want = sel && typeof sel === 'object' ? sel : { permissionLevel: sel };
    if (!worker || worker.companyId !== actor.companyId) return;
    const role = want.projectRole ? normalizeProjectRole(want.projectRole) : normalizeProjectRole(worker.primaryRole);
    if (!role) return;
    const existing = getMembership(userId, projectId);
    if (isProjectLeadRole(role) && !canUser(actor, CAP.ASSIGN_PROJECT_LEADS)) return;
    if (existing && isLeadMembership(existing) && !canUser(actor, CAP.ASSIGN_PROJECT_LEADS)) return;
    const m = addOrUpdateMembership(projectId, userId, role, want.permissionLevel, actor.id);
    if (m) {
      added.push({ membership: m, user: worker });
      recordAudit({ action: AUDIT_ACTIONS.TEAM_MEMBER_ADDED, entityType: 'ProjectMembership', entityId: m.id, projectId,
        after: { userId, projectRole: m.projectRole, permissionLevel: m.permissionLevel } }, actor);
    }
  });
  return added;
}

/* ---------- projects ---------- */
// The lead role a creator really holds (primary first), or null. Owners and
// Company Admins already have company-wide authority: they get NO invented
// Foreman membership; the real PM / Superintendent / Foreman is assigned later.
export function creatorLeadRole(actor, requested) {
  const held = companyRolesOf(actor).filter((r) => PROJECT_LEAD_ROLES.indexOf(r) !== -1);
  if (requested) return held.indexOf(requested) !== -1 ? requested : null;
  return held[0] || null;
}
// Creates the project (on the company's OWN warehouse), its jobsite location,
// and a Full Control membership only in a lead role the creator actually holds.
export function createProject(actor, draft) {
  if (!canUser(actor, CAP.CREATE_PROJECT)) return null;
  const name = (draft.name || '').trim(), addressLine = (draft.address || '').trim();
  if (!name || !addressLine) return null;
  const company = getCompany(actor.companyId);
  if (!company) return null;
  const warehouseId = mainWarehouseIdFor(db, company.id) || ensureCompanyWarehouse(db, company);
  const addr = parseAddress(addressLine);
  const t = now();
  const proj = { id: nextProjectId(), companyId: actor.companyId, name, projectNumber: (draft.number || '').trim(),
    address: addr.address, city: addr.city, state: addr.state, zipCode: addr.zipCode, description: (draft.description || '').trim(),
    status: 'ACTIVE', startDate: null, expectedCompletionDate: null, assignedWarehouseId: warehouseId,
    materialBudget: null, createdAt: t, createdBy: actor.id, updatedAt: t };
  db.PROJECTS.push(proj);
  ensureJobsite(db, proj, formatAddress(proj));
  const leadRole = creatorLeadRole(actor, draft.creatorProjectRole);
  if (leadRole) addOrUpdateMembership(proj.id, actor.id, leadRole, 'FULL_CONTROL', actor.id);
  recordAudit({ action: AUDIT_ACTIONS.PROJECT_CREATED, entityType: 'Project', entityId: proj.id, projectId: proj.id, after: { name } }, actor);
  return proj;
}
