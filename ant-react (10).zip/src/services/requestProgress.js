/* =========================================================================
   REQUEST PROGRESS SELECTORS (Phase 3) — the one place request arithmetic lives.

   For a v5 request line:
     requested   = item.quantity                         (demand)
     allocated   = sum of ACTIVE allocations             (sourced)
     outstanding = requested - allocated                 (no source yet; stays visible)
     reserved / picked / packed come from the ledger, per allocation:
     allocation.quantity = reserved + picking + packed   (every allocated unit is explained)
   A legacy (pre-v5) line keeps its Phase 2 numbers: outstanding = requested - picked.
   The old shortQuantity field never decides outstanding demand.
   ========================================================================= */
import { db } from '../lib/db.js';
import { ACTIVE_ALLOCATION_STATUSES, OPEN_REQUEST_STATUSES } from '../config/requests.js';
import { byOutstandingUrgency } from '../config/priorities.js';

export const isV5 = (r) => !!r && r.allocationMode === 'V5';
/* Two kinds of MaterialAllocation, never summed together by accident:
   WAREHOUSE (Phase 3: reserved stock in a bin) and SUPPLIER (Phase 4: sourcing
   from a purchase order). Every Phase 3 helper below is WAREHOUSE-only. */
export const isWarehouseAllocation = (a) => !a.sourceType || a.sourceType === 'WAREHOUSE';
export const isSupplierAllocation = (a) => a.sourceType === 'SUPPLIER';
export const allocationsForRequest = (requestId) => (db.ALLOCATIONS || []).filter((a) => a.requestId === requestId && isWarehouseAllocation(a));
export const allocationsForItem = (requestItemId) => (db.ALLOCATIONS || []).filter((a) => a.requestItemId === requestItemId && isWarehouseAllocation(a));
export const isActiveAllocation = (a) => isWarehouseAllocation(a) && ACTIVE_ALLOCATION_STATUSES.indexOf(a.status) !== -1 && a.quantity > 0;
/* ---------- supplier sourcing (Phase 4) ----------
   A supplier allocation: quantity (on the PO for this demand) = converted
   (received -> warehouse allocation) + stocked (received, no longer needed by
   the demand -> plain stock) + cancelled (released / damaged) + superseded
   (warehouse stock covered it by an explicit manager choice; the PO itself is
   unchanged and those units arrive as plain stock) + remaining. */
export const supplierAllocationsForItem = (requestItemId) => (db.ALLOCATIONS || []).filter((a) => a.requestItemId === requestItemId && isSupplierAllocation(a));
export const supplierAllocationsForRequest = (requestId) => (db.ALLOCATIONS || []).filter((a) => a.requestId === requestId && isSupplierAllocation(a));
export const supplierRemaining = (a) => Math.max(0, a.quantity - (a.convertedQuantity || 0) - (a.stockedQuantity || 0) - (a.cancelledQuantity || 0) - (a.supersededQuantity || 0));
const COMMITTED = ['ORDERED', 'PARTIALLY_RECEIVED', 'RECEIVED'];
export const isSupplierCommitted = (a) => isSupplierAllocation(a) && COMMITTED.indexOf(a.status) !== -1;
// supplier commitment still expected (sent / confirmed POs; drafts never count)
export const getSupplierOrderedQuantity = (item) => sum(supplierAllocationsForItem(item.id).filter(isSupplierCommitted), supplierRemaining);
// on a DRAFT purchase order: internal, NOT "on order"
export const getSupplierDraftQuantity = (item) => sum(supplierAllocationsForItem(item.id).filter((a) => a.status === 'PROPOSED'), supplierRemaining);
export const getSupplierReceivedQuantity = (item) => sum(supplierAllocationsForItem(item.id), (a) => (a.convertedQuantity || 0) + (a.stockedQuantity || 0));
export const activeAllocationsForItem = (requestItemId) => allocationsForItem(requestItemId).filter(isActiveAllocation);
export const requestOf = (id) => db.REQUESTS.find((r) => r.id === id) || null;

// Ledger state per allocation, computed in one pass and cached until the ledger changes.
let cache = { key: null, map: {} };
export function allocationState(allocationId) {
  const mv = db.MATERIAL_MOVEMENTS;
  const key = mv.length + ':' + (mv.length ? mv[mv.length - 1].id : '');
  if (cache.key !== key) {
    const map = {};
    mv.forEach((m) => {
      if (!m.allocationId) return;
      const s = map[m.allocationId] = map[m.allocationId] || { RESERVED: 0, PICKING: 0, PACKED: 0 };
      if (s[m.fromInventoryState] != null) s[m.fromInventoryState] -= m.quantity;
      if (s[m.toInventoryState] != null) s[m.toInventoryState] += m.quantity;
    });
    cache = { key, map };
  }
  return cache.map[allocationId] || { RESERVED: 0, PICKING: 0, PACKED: 0 };
}
const sum = (list, f) => list.reduce((a, x) => a + f(x), 0);

export const getRequestedQuantity = (item) => item.quantity;
export const getAllocatedQuantity = (item) => sum(activeAllocationsForItem(item.id), (a) => a.quantity);
export const getReservedQuantity = (item) => sum(allocationsForItem(item.id), (a) => allocationState(a.id).RESERVED);
export function getPickedQuantity(item, r) {
  if (!isV5(r || requestOf(item.requestId))) return item.pickedQuantity || 0;
  return sum(allocationsForItem(item.id), (a) => { const s = allocationState(a.id); return s.PICKING + s.PACKED; });
}
export function getPackedQuantity(item, r) {
  if (!isV5(r || requestOf(item.requestId))) return item.packedQuantity || 0;
  return sum(allocationsForItem(item.id), (a) => allocationState(a.id).PACKED);
}
/* UNSOURCED (= outstanding) = requested - warehouse coverage - active supplier
   commitment. Drafts don't count (a draft is not a commitment). Received
   supplier quantity counts once: it becomes a warehouse allocation. */
export function getOutstandingQuantity(item, r) {
  const req = r || requestOf(item.requestId);
  if (req && req.status === 'CANCELLED') return 0;   // cancelled demand is no longer outstanding
  if (!isV5(req)) return Math.max(0, item.quantity - (item.pickedQuantity || 0));
  return Math.max(0, item.quantity - getAllocatedQuantity(item) - getSupplierOrderedQuantity(item));
}
export const getUnsourcedQuantity = getOutstandingQuantity;
// Earliest supplier expected date (YYYY-MM-DD) among this line's active commitments: the date the
// supplier gave for delivery TO THE WAREHOUSE, never a jobsite delivery promise.
export function getSupplierExpectedDate(item) {
  const dates = supplierAllocationsForItem(item.id).filter((a) => isSupplierCommitted(a) && supplierRemaining(a) > 0)
    .map((a) => { const po = (db.PURCHASE_ORDERS || []).find((p) => p.id === a.purchaseOrderId); return po && po.expectedDeliveryDate; }).filter(Boolean).sort();
  return dates[0] || null;
}
// Coverage never exceeds the request: warehouse + active supplier commitment <= requested (integrity REQUEST_OVER_COVERED).
export const getDemandCoverage = (item) => getAllocatedQuantity(item) + getSupplierOrderedQuantity(item);
// Supplier quantity this demand no longer needs (superseded by warehouse stock). The PO is kept; Purchasing decides.
export const getSupplierSupersededQuantity = (item) => sum(supplierAllocationsForItem(item.id).filter(isSupplierCommitted), (a) => a.supersededQuantity || 0);
export function getLineProgress(item, r) {
  const req = r || requestOf(item.requestId);
  const out = { requested: item.quantity, allocated: isV5(req) ? getAllocatedQuantity(item) : null, reserved: isV5(req) ? getReservedQuantity(item) : 0,
    picked: getPickedQuantity(item, req), packed: getPackedQuantity(item, req), outstanding: getOutstandingQuantity(item, req) };
  // Operational warehouse shortage: demand current warehouse stock could not cover.
  out.short = isV5(req) ? out.outstanding : (item.shortQuantity || 0);
  if (isV5(req)) { out.onOrder = getSupplierOrderedQuantity(item); out.inDraft = getSupplierDraftQuantity(item); out.supplierReceived = getSupplierReceivedQuantity(item); out.supplierExpected = getSupplierExpectedDate(item); }
  return out;
}
export function getRequestAllocationSummary(r) {
  const lines = r.items.map((it) => getLineProgress(it, r));
  return { requested: sum(lines, (l) => l.requested), allocated: sum(lines, (l) => l.allocated || 0), outstanding: sum(lines, (l) => l.outstanding),
    reserved: sum(lines, (l) => l.reserved), picked: sum(lines, (l) => l.picked), packed: sum(lines, (l) => l.packed),
    lines: lines.length, linesWithOutstanding: lines.filter((l) => l.outstanding > 0).length };
}
export const getRequestProgress = (r) => ({ lines: r.items.map((it) => Object.assign({ requestItemId: it.id }, getLineProgress(it, r))), summary: getRequestAllocationSummary(r) });

// Keeps an allocation's status in step with what the ledger says happened to it.
export function refreshAllocationStatus(a) {
  if (a.status === 'CANCELLED') return a;
  if (a.quantity <= 0) { a.status = 'RELEASED'; return a; }
  const s = allocationState(a.id), done = s.PICKING + s.PACKED;
  a.status = done === 0 ? 'RESERVED' : done < a.quantity ? 'PARTIALLY_FULFILLED' : 'FULFILLED';
  return a;
}

/* ---------- demand that still needs a source (for future Purchasing / Needs Attention) ---------- */
const openV5 = (companyId) => db.REQUESTS.filter((r) => r.companyId === companyId && isV5(r) && ['APPROVED', 'PROCESSING', 'PARTIALLY_FULFILLED'].indexOf(r.status) !== -1);
export function getUnresolvedRequestItems(companyId) {
  const out = [];
  openV5(companyId).forEach((r) => r.items.forEach((it) => { const n = getOutstandingQuantity(it, r); if (n > 0) out.push({ request: r, item: it, outstanding: n, productVariantId: it.productVariantId, projectId: r.projectId, neededBy: r.neededBy }); }));
  return out;
}
export const getRequestsWithOutstandingDemand = (companyId) => openV5(companyId).filter((r) => r.items.some((it) => getOutstandingQuantity(it, r) > 0));
/* Warehouse "Outstanding requests" (Needs attention): approved demand of this
   company (optionally one warehouse's projects) with anything still
   outstanding, INCLUDING requests with no allocation and no fulfillment
   (zero stock, or automatic allocation switched off). Legacy history,
   pending, rejected and cancelled requests never appear. */
export function getWarehouseOutstandingRequests(companyId, warehouseId) {
  return openV5(companyId).filter((r) => r.approvalStatus === 'APPROVED' || r.approvalStatus === 'NOT_REQUIRED')
    .filter((r) => { if (!warehouseId) return true; const p = db.PROJECTS.find((x) => x.id === r.projectId); return !!p && p.assignedWarehouseId === warehouseId; })
    .map((r) => {
      const lines = r.items.map((it) => ({ item: it, outstanding: getOutstandingQuantity(it, r), allocated: getAllocatedQuantity(it) }));
      const open = lines.filter((l) => l.outstanding > 0);
      const p = db.PROJECTS.find((x) => x.id === r.projectId);
      return { request: r, lines: lines.length, linesWithOutstanding: open.length, warehouseId: p ? p.assignedWarehouseId : null,
        outstanding: lines.reduce((s, l) => s + l.outstanding, 0), allocated: lines.reduce((s, l) => s + l.allocated, 0), items: lines,
        // one outstanding line: its quantity can be shown; several lines may mix units, so show the count instead
        single: open.length === 1 ? { quantity: open[0].outstanding, unit: open[0].item.unit } : null };
    })
    .filter((x) => x.outstanding > 0)
    .sort((a, b) => byOutstandingUrgency(a.request, b.request));
}
/* The warehouse a person works for: their profile's optional `warehouseId`
   (a WAREHOUSE of their own company). None set = every warehouse of their
   company (warehouse screens are company-wide today). */
// Safe deny: a warehouseId that is PRESENT but invalid (deleted, another
// company's, not a warehouse) never widens to the whole company.
export const WAREHOUSE_SCOPE_DENIED = '__no_valid_warehouse__';
export function warehouseScopeFor(user) {
  if (!user) return WAREHOUSE_SCOPE_DENIED;
  if (user.warehouseId == null || user.warehouseId === '') return null;   // intentionally company-wide
  const loc = (db.LOCATIONS || []).find((l) => l.id === user.warehouseId);
  return loc && loc.companyId === user.companyId && loc.type === 'WAREHOUSE' && loc.status !== 'INACTIVE' ? loc.id : WAREHOUSE_SCOPE_DENIED;
}
// What a Warehouse Manager sees: ONE list, used by the Home preview (first
// few) and by the full Outstanding requests screen (all of it).
export const outstandingRequestsFor = (user) => (user ? getWarehouseOutstandingRequests(user.companyId, warehouseScopeFor(user)) : []);
export const OUTSTANDING_PREVIEW_COUNT = 5;
// Approved, but the warehouse could not allocate anything at all.
export const getFailedAllocations = (companyId) => openV5(companyId).filter((r) => r.allocationStatus === 'UNALLOCATED');
export const getEmergencyRequests = (companyId) => db.REQUESTS.filter((r) => r.companyId === companyId && r.priority === 'EMERGENCY' && OPEN_REQUEST_STATUSES.indexOf(r.status) !== -1);
// Grouped the way Purchasing will want it (variant / project / needed by). Not used by any screen yet.
export function outstandingDemandByVariant(companyId) {
  const g = {};
  getUnresolvedRequestItems(companyId).forEach((x) => { const k = x.productVariantId; (g[k] = g[k] || { productVariantId: k, quantity: 0, lines: [] }); g[k].quantity += x.outstanding; g[k].lines.push(x); });
  return Object.keys(g).map((k) => g[k]);
}

/* ---------- request status: derived from demand, never copied from a fulfillment ---------- */
export function deriveRequestStatus(r) {
  if (r.status === 'CANCELLED' || r.approvalStatus === 'REJECTED') return 'CANCELLED';
  if (!isV5(r)) return legacyRequestStatus(r);
  if (r.approvalStatus === 'PENDING') return 'PENDING_APPROVAL';
  if (!r.approvalStatus) return 'SUBMITTED';
  if (r.allocationStatus === 'NOT_STARTED') return 'APPROVED';
  const outstanding = r.items.reduce((a, it) => a + getOutstandingQuantity(it, r), 0);
  const fs = (db.FULFILLMENTS || []).filter((f) => f.requestId === r.id && f.status !== 'CANCELLED');
  const delivered = fs.length > 0 && fs.every((f) => f.dispatchStatus === 'DELIVERED');
  const prepared = fs.some((f) => ['PACKED', 'READY'].indexOf(f.status) !== -1 || !!f.dispatchStatus);
  // the jobsite reported missing items: demand was not fully satisfied
  if (delivered && r.deliveryIssues && r.deliveryIssues.length) return 'PARTIALLY_FULFILLED';
  if (outstanding === 0 && delivered) return 'FULFILLED';
  if (prepared && outstanding > 0) return 'PARTIALLY_FULFILLED';   // warehouse part done, demand still open
  return 'PROCESSING';
}
export function legacyRequestStatus(r) {
  if (r.status === 'CANCELLED') return 'CANCELLED';
  if (r.workflowStatus !== 'COMPLETED') return 'PROCESSING';
  const short = r.items.some((i) => (i.shortQuantity || 0) > 0), issue = !!(r.deliveryIssues && r.deliveryIssues.length);
  return short || issue ? 'PARTIALLY_FULFILLED' : 'FULFILLED';
}
export function refreshRequestStatus(r) { const s = deriveRequestStatus(r); if (r.status !== s) { r.status = s; r.updatedAt = Date.now(); } return s; }
