/* =========================================================================
   SELECTORS — the named questions the rest of ANT asks, answered in one
   place (never by scanning UI state or duplicated arrays).
   ========================================================================= */
import { ui } from '../lib/store.js';
import { getUser, getProject, getMembership, usersInCompany, getRequest, getLocation } from './repo.js';
import { notificationsForUser } from './notificationService.js';
import { canUser, CAP, effectivePermissionLevel } from '../lib/permissions.js';
import { projectsForUser, teamForProject, foremanForProject } from './projectService.js';
import { requestsForProject, requestsForUser } from './requestService.js';
import { companyLocations, jobsiteForProject, warehousesFor, assignedWarehouseFor } from './locationService.js';
import { currentProject } from './sessionService.js';
import { getCompany } from './companyService.js';

export const getCurrentUser = () => ui.currentUser;
export const getCurrentCompany = () => getCompany(ui.session.currentCompanyId);
export const getCurrentProject = () => currentProject();
export const getProjectsForUser = (userId) => projectsForUser(userId);
export const getUsersForProject = (projectId) => teamForProject(projectId).map((x) => x.user);
export const getForemanForProject = (projectId) => foremanForProject(projectId);
export const getProjectMembership = (userId, projectId) => getMembership(userId, projectId);
// The permission level that applies to this user on this project (null = not on it).
export function getProjectPermission(userId, projectId) {
  const m = getMembership(userId, projectId), p = getProject(projectId);
  return m && p ? effectivePermissionLevel(m, getCompany(p.companyId)) : null;
}
export const canUserEditProject = (userId, projectId) => canUser(getUser(userId), CAP.REQUEST_MATERIALS, { projectId });
export const getCompanyUsers = (companyId) => usersInCompany(companyId);
export const getLocationsForCompany = (companyId) => companyLocations(companyId);
export const getJobsiteLocation = (projectId) => jobsiteForProject(projectId);
export const getWarehouseLocations = (companyId) => warehousesFor(companyId);
export const getAssignedWarehouse = (projectId) => assignedWarehouseFor(projectId);
export const getRequestsForProject = (projectId) => requestsForProject(projectId);
export const getRequestsForUser = (userId) => requestsForUser(userId);

/* ---------- actor-scoped reads: never return another company's records ---------- */
const sameCompany = (actor, rec) => !!actor && !!rec && rec.companyId === actor.companyId;
// A project the actor may see (member on it, or company-wide oversight), else null.
export const getProjectFor = (actor, projectId) => { const p = getProject(projectId); return p && canUser(actor, CAP.VIEW_PROJECT, { projectId }) ? p : null; };
// A request the actor may see: the warehouse of its own company, or someone who can see its project.
export function getRequestFor(actor, requestId) {
  const r = getRequest(requestId);
  if (!sameCompany(actor, r)) return null;
  return canUser(actor, CAP.VIEW_WAREHOUSE_ORDERS) || canUser(actor, CAP.VIEW_PROJECT, { projectId: r.projectId }) ? r : null;
}
export const getUsersFor = (actor) => (actor ? usersInCompany(actor.companyId) : []);
export const getUserFor = (actor, userId) => { const u = getUser(userId); return sameCompany(actor, u) ? u : null; };
export const getLocationsFor = (actor) => (actor ? companyLocations(actor.companyId) : []);
export const getLocationFor = (actor, locationId) => { const l = getLocation(locationId); return sameCompany(actor, l) ? l : null; };
export const getNotificationsFor = (actor) => (actor ? notificationsForUser(actor.id).filter((n) => n.companyId === actor.companyId) : []);
