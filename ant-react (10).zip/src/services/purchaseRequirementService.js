/* =========================================================================
   PURCHASE REQUIREMENTS (Phase 4) — approved demand the warehouse can't source.

   A requirement is created by ANT, never typed in: after approval + warehouse
   allocation, whatever a request line still needs from outside becomes a
   PurchaseRequirement linked to that exact request, line, project and
   variant. syncForRequestItem keeps it in step:
     external need = requested - warehouse coverage   (received supplier
                     material is warehouse coverage once converted)
     need grows    -> a new requirement for the difference (deterministic key
                      "prq:<line>:<tranche>": a retry can't create two)
     need shrinks  -> release only UNCOMMITTED, un-drafted quantity; the
                      original quantityRequired is never rewritten; a sent PO
                      is never touched (Purchasing is warned instead)
   Quantities (derived from the line's supplier allocations, never counters):
     active    = quantityRequired - quantityReleased
     inDraft   = on draft POs (PROPOSED)
     ordered   = committed to suppliers, net of cancellations
     received  = converted + stocked (arrived)        expected = ordered - received
     toSource  = active - inDraft - ordered   (active = inDraft + ordered + toSource)
   ========================================================================= */
import { db, now } from '../lib/db.js';
import { canUser, CAP } from '../lib/permissions.js';
import { getProject } from './repo.js';
import { stockVariantFor } from './inventoryService.js';
import { recordAudit, AUDIT_ACTIONS } from './auditService.js';
import { notify, NOTIFICATION_TYPES } from './notificationService.js';
import { getAllocatedQuantity, supplierAllocationsForItem, supplierRemaining, isSupplierCommitted, isV5 } from './requestProgress.js';
import { CLOSED_REQUIREMENT_STATUSES } from '../config/purchasing.js';
import { byOutstandingUrgency } from '../config/priorities.js';

const sum = (l, f) => l.reduce((a, x) => a + f(x), 0);
function nextRequirement() { db.PR_SEQ = (db.PR_SEQ || 1000) + 1; return { id: 'prq_' + db.PR_SEQ, number: 'PR-' + db.PR_SEQ }; }
export const getRequirementById = (id) => (db.PURCHASE_REQUIREMENTS || []).find((x) => x.id === id) || null;
export const requirementsForItem = (requestItemId) => (db.PURCHASE_REQUIREMENTS || []).filter((x) => x.requestItemId === requestItemId);
export const getRequirementsForRequest = (requestId) => (db.PURCHASE_REQUIREMENTS || []).filter((x) => x.requestId === requestId);
export const getRequirementsForProject = (projectId) => (db.PURCHASE_REQUIREMENTS || []).filter((x) => x.projectId === projectId);
export const isOpenRequirement = (pr) => CLOSED_REQUIREMENT_STATUSES.indexOf(pr.status) === -1;
export const supplierAllocationsForRequirement = (prId) => (db.ALLOCATIONS || []).filter((a) => a.sourceType === 'SUPPLIER' && a.purchaseRequirementId === prId);
const requestOf = (id) => db.REQUESTS.find((r) => r.id === id) || null;

export function getRequirementProgress(pr) {
  const allocs = supplierAllocationsForRequirement(pr.id);
  const active = Math.max(0, pr.quantityRequired - (pr.quantityReleased || 0));
  const inDraft = sum(allocs.filter((a) => a.status === 'PROPOSED'), supplierRemaining);
  const committed = allocs.filter(isSupplierCommitted);
  const ordered = sum(committed, (a) => a.quantity - (a.cancelledQuantity || 0) - (a.supersededQuantity || 0));
  const converted = sum(allocs, (a) => a.convertedQuantity || 0), stocked = sum(allocs, (a) => a.stockedQuantity || 0);
  const received = converted + stocked;
  return { required: pr.quantityRequired, released: pr.quantityReleased || 0, active, inDraft, ordered, received, converted, stocked,
    expected: Math.max(0, ordered - received), toSource: Math.max(0, active - inDraft - ordered),
    cancelledCommitment: sum(committed, (a) => a.cancelledQuantity || 0), superseded: sum(committed, (a) => a.supersededQuantity || 0) };
}
export function deriveRequirementStatus(pr) {
  if (pr.status === 'CLOSED') return 'CLOSED';
  const p = getRequirementProgress(pr);
  if (p.active === 0) return p.ordered > 0 ? (p.received >= p.ordered ? 'RECEIVED' : 'ORDERED') : 'CANCELLED';
  if (p.ordered > 0 && p.received >= p.active) return 'RECEIVED';
  if (p.received > 0) return 'PARTIALLY_RECEIVED';
  if (p.ordered >= p.active) return 'ORDERED';
  if (p.ordered > 0) return 'PARTIALLY_ORDERED';
  if (p.inDraft > 0) return 'IN_DRAFT';
  if ((db.SUPPLIER_QUOTES || []).some((q) => q.purchaseRequirementId === pr.id)) return 'SOURCING';
  return 'OPEN';
}
export function refreshRequirementStatus(pr) { const s = deriveRequirementStatus(pr); if (pr.status !== s) { pr.status = s; pr.updatedAt = now(); } return s; }

const requestOpen = (r) => isV5(r) && ['APPROVED', 'PROCESSING', 'PARTIALLY_FULFILLED'].indexOf(r.status) !== -1 &&
  (r.approvalStatus === 'APPROVED' || r.approvalStatus === 'NOT_REQUIRED') && r.allocationStatus !== 'NOT_STARTED';
const purchasers = (companyId) => db.USERS.filter((u) => u.companyId === companyId && u.status === 'ACTIVE' && canUser(u, CAP.MANAGE_PURCHASE_REQUIREMENTS)).map((u) => u.id);

export function syncForRequestItem(r, item, actor) {
  if (!isV5(r)) return { created: null, released: 0 };
  const prs = requirementsForItem(item.id).filter(isOpenRequirement);
  // converted units are warehouse coverage now; stocked units went to plain stock (the demand didn't need them):
  // neither is still "pending" for the requirement (otherwise demand re-opened later could go unseen)
  const convertedBy = (pr) => sum(supplierAllocationsForRequirement(pr.id), (a) => (a.convertedQuantity || 0) + (a.stockedQuantity || 0));
  // external need: what the warehouse doesn't cover (0 once the request is no longer open)
  const need = requestOpen(r) ? Math.max(0, item.quantity - getAllocatedQuantity(item)) : 0;
  const pending = sum(prs, (pr) => getRequirementProgress(pr).active - convertedBy(pr));
  let created = null, released = 0;
  if (need > pending) {
    const tranche = requirementsForItem(item.id).length + 1, key = 'prq:' + item.id + ':' + tranche;
    if (!(db.PURCHASE_REQUIREMENTS || []).some((x) => x.companyId === r.companyId && x.sourceKey === key)) {
      const project = getProject(r.projectId), ids = nextRequirement(), t = now();
      created = { id: ids.id, requirementNumber: ids.number, companyId: r.companyId, projectId: r.projectId, requestId: r.id, requestItemId: item.id,
        productVariantId: stockVariantFor(r.companyId, item.productVariantId), requestVariantId: item.productVariantId,
        productNameSnapshot: item.productNameSnapshot, variantSnapshot: item.variantSnapshot || null,
        quantityRequired: need - pending, quantityReleased: 0, unit: item.unit, priority: r.priority, neededBy: r.neededBy,
        destinationWarehouseId: project ? project.assignedWarehouseId : null, status: 'OPEN', assignedPurchasingUserId: null,
        sourceKey: key, tranche, createdAt: t, updatedAt: t,
        createdByActor: actor && actor.system ? { actorType: 'SYSTEM', source: actor.source, triggeredByUserId: actor.triggeredByUserId } : { actorType: 'USER', userId: actor ? actor.id : null },
        metadata: {} };
      db.PURCHASE_REQUIREMENTS.push(created);
      recordAudit({ action: AUDIT_ACTIONS.PURCHASE_REQUIREMENT_CREATED, entityType: 'PurchaseRequirement', entityId: created.id, companyId: r.companyId, projectId: r.projectId, before: null,
        after: { requirementNumber: created.requirementNumber, requestId: r.id, requestItemId: item.id, quantity: created.quantityRequired, unit: created.unit, tranche } }, actor);
      notify(purchasers(r.companyId), { companyId: r.companyId, type: NOTIFICATION_TYPES.PURCHASE_REQUIREMENT_CREATED,
        title: created.quantityRequired + ' ' + created.unit + ' ' + (item.productNameSnapshot || '') + ' need sourcing for ' + r.id,
        message: created.requirementNumber + ' \u00b7 ' + ((project && project.name) || ''), entityType: 'PurchaseRequirement', entityId: created.id, projectId: r.projectId });
    }
  } else if (need < pending) {
    // release only what nobody committed or drafted, newest requirement first
    let left = pending - need;
    prs.slice().sort((a, b) => b.tranche - a.tranche).forEach((pr) => {
      if (left <= 0) return;
      const take = Math.min(left, getRequirementProgress(pr).toSource);
      if (take <= 0) return;
      pr.quantityReleased = (pr.quantityReleased || 0) + take; pr.updatedAt = now(); left -= take; released += take;
      recordAudit({ action: AUDIT_ACTIONS.PURCHASE_REQUIREMENT_RELEASED, entityType: 'PurchaseRequirement', entityId: pr.id, companyId: pr.companyId, projectId: pr.projectId,
        before: { active: getRequirementProgress(pr).active + take }, after: { released: take, requirementNumber: pr.requirementNumber, reason: requestOpen(r) ? 'COVERED_ELSEWHERE' : 'REQUEST_CLOSED' } }, actor);
    });
  }
  requirementsForItem(item.id).forEach(refreshRequirementStatus);
  return { created, released };
}
export function syncForRequest(r, actor) {
  if (!r || !isV5(r)) return [];
  return r.items.map((it) => syncForRequestItem(r, it, actor));
}
// Reopen = release supplier commitment elsewhere; the next sync (or this) makes the requirement need it again.
export const reopenRequirementQuantity = (pr, actor) => { const r = requestOf(pr.requestId); return r ? syncForRequest(r, actor) : []; };
// Release only what the demand truly no longer needs from outside (never still-unsourced demand:
// the automatic sync would just need it again). Uncommitted quantity only.
export function releaseRequirementQuantity(actor, prId, quantity) {
  const pr = getRequirementById(prId);
  if (!pr || !actor || pr.companyId !== actor.companyId || !canUser(actor, CAP.MANAGE_PURCHASE_REQUIREMENTS)) return { error: 'forbidden' };
  const r = requestOf(pr.requestId), item = r && r.items.find((i) => i.id === pr.requestItemId);
  const need = item && requestOpen(r) ? Math.max(0, item.quantity - getAllocatedQuantity(item)) : 0;
  const pending = sum(requirementsForItem(pr.requestItemId).filter(isOpenRequirement), (x) => getRequirementProgress(x).active - getRequirementProgress(x).received);
  const take = Math.min(Number(quantity) || 0, getRequirementProgress(pr).toSource, Math.max(0, pending - need));
  if (!(take > 0)) return { error: 'nothing_to_release', message: 'Only uncommitted quantity can be released' };
  pr.quantityReleased = (pr.quantityReleased || 0) + take; refreshRequirementStatus(pr);
  recordAudit({ action: AUDIT_ACTIONS.PURCHASE_REQUIREMENT_RELEASED, entityType: 'PurchaseRequirement', entityId: pr.id, companyId: pr.companyId, projectId: pr.projectId, before: null,
    after: { released: take, requirementNumber: pr.requirementNumber, reason: 'MANUAL' } }, actor);
  return { ok: true, requirement: pr };
}
// What Purchasing works on: open requirements with anything left to source, most urgent first.
export function getOpenRequirements(user, opts) {
  if (!user || !canUser(user, CAP.VIEW_PURCHASE_REQUIREMENTS)) return [];
  const o = opts || {};
  return (db.PURCHASE_REQUIREMENTS || []).filter((pr) => pr.companyId === user.companyId && isOpenRequirement(pr) && (o.all || getRequirementProgress(pr).toSource > 0 || pr.status === 'IN_DRAFT'))
    .sort((a, b) => byOutstandingUrgency(a, b));
}
export const requirementsVisibleTo = (user) => (user && canUser(user, CAP.VIEW_PURCHASE_REQUIREMENTS) ? (db.PURCHASE_REQUIREMENTS || []).filter((pr) => pr.companyId === user.companyId) : []);
