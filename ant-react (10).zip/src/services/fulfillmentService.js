/* =========================================================================
   FULFILLMENT SERVICE (Phase 3) — the warehouse work, separate from demand.

   A Material Request is what the field needs. A Fulfillment is what the
   warehouse was asked to prepare: only the ALLOCATED quantity (request 100,
   allocated 60 -> the warehouse prepares 60; 40 stay outstanding on the
   request). One request can have several fulfillments (future supplier
   fulfillments); Phase 3 creates warehouse ones.

   v5 picking moves the request's OWN reservation: RESERVED -> PICKING, per
   allocation (the ledger refuses anything else). Un-picking returns it to
   the same reservation. When every line is picked, it is PACKED.
   Legacy (pre-v5) orders keep their Phase 2 flow; their compatibility
   fulfillment is read from the request (allocationMode LEGACY).

   Screens read fulfillments through read-only VIEWS (warehouseOrderView,
   fieldRequestView) that add request header context and keep the familiar
   "Orders" shape. The views are presentation only; nothing is stored twice.
   ========================================================================= */
import { db, now } from '../lib/db.js';
import { canUser, CAP } from '../lib/permissions.js';
import { postMovements, reversalDraftFor, getMovementsForRequestItem } from './materialLedgerService.js';
import { recordAudit, AUDIT_ACTIONS } from './auditService.js';
import { FULFILLMENT_EXTENDABLE_STATUSES } from '../config/requests.js';
import { notify, NOTIFICATION_TYPES } from './notificationService.js';
import { getProject } from './repo.js';
import { allocationState, refreshAllocationStatus, refreshRequestStatus, getLineProgress, isV5,
  getRequestAllocationSummary } from './requestProgress.js';

const fail = (error, message, extra) => Object.assign({ error, message }, extra || {});
function nextFulfillmentId() { db.FULFILLMENT_SEQ = (db.FULFILLMENT_SEQ || 1000) + 1; return 'FUL-' + db.FULFILLMENT_SEQ; }
/* ONE request -> MANY fulfillments (Fulfillment.requestId is the canonical
   link; nothing on the request points at "its" fulfillment). Each warehouse
   fulfillment is a "batch": batch 1 = the first allocation, batch 2 = stock
   allocated later for outstanding demand, and so on. */
export const fulfillmentsForRequest = (requestId) => (db.FULFILLMENTS || []).filter((f) => f.requestId === requestId);
export const fulfillmentById = (id) => (db.FULFILLMENTS || []).find((f) => f.id === id) || null;
const idNum = (f) => parseInt(String(f.id).replace(/\D/g, ''), 10) || 0;
// The request's warehouse batches, in creation order (cancelled ones excluded unless asked).
export function warehouseFulfillmentsFor(requestId, includeCancelled) {
  return fulfillmentsForRequest(requestId).filter((f) => f.sourceType === 'WAREHOUSE' && (includeCancelled || f.status !== 'CANCELLED'))
    .sort((a, b) => (a.createdAt - b.createdAt) || (idNum(a) - idNum(b)));
}
export const batchNumberOf = (f) => warehouseFulfillmentsFor(f.requestId, true).filter((x) => x.status !== 'CANCELLED' || x === f).indexOf(f) + 1;
const PROGRESS_RANK = { PENDING: 0, ALLOCATED: 0, PICKING: 1, PARTIALLY_PICKED: 1, PICKED: 2, VERIFIED: 2, PACKED: 2, READY: 3 };
const rankOf = (f) => (f.dispatchStatus === 'DELIVERED' ? 5 : f.dispatchStatus === 'SHIPPED' ? 4 : (PROGRESS_RANK[f.status] || 0));
const isActive = (f) => f.status !== 'CANCELLED' && f.dispatchStatus !== 'DELIVERED';
// Default batch when only a request id is given: the least advanced active batch.
export function warehouseFulfillmentFor(requestId) {
  const fs = warehouseFulfillmentsFor(requestId);
  const active = fs.filter(isActive).sort((a, b) => rankOf(a) - rankOf(b));
  return active[0] || fs[fs.length - 1] || warehouseFulfillmentsFor(requestId, true).slice(-1)[0] || null;
}
// A new allocation may join a batch only before physical work began on it.
function extendable(f) {
  if (f.allocationMode !== 'V5' || f.dispatchStatus || FULFILLMENT_EXTENDABLE_STATUSES.indexOf(f.status) === -1) return false;
  refreshFulfillment(f);
  return FULFILLMENT_EXTENDABLE_STATUSES.indexOf(f.status) !== -1 && f.items.every((i) => !i.pickedQuantity && !i.packedQuantity);
}
const managersOf = (companyId) => db.USERS.filter((u) => u.companyId === companyId && u.status === 'ACTIVE' && canUser(u, CAP.MANAGE_SHIPMENTS)).map((u) => u.id);

/* ---------- create / refresh ---------- */
export function createOrExtendWarehouseFulfillment(actor, r, allocations) {
  if (!allocations.length) return null;
  const earlier = warehouseFulfillmentsFor(r.id);
  // Reuse only a batch nobody has started; anything picked, packed, ready or
  // dispatched is left exactly as it is and the new stock gets its own batch.
  let f = earlier.find(extendable) || null;
  const created = !f;
  if (!f) {
    const project = getProject(r.projectId), t = now();
    f = { id: nextFulfillmentId(), companyId: r.companyId, projectId: r.projectId, requestId: r.id, sourceType: 'WAREHOUSE',
      sourceLocationId: project ? project.assignedWarehouseId : null, status: 'ALLOCATED', dispatchStatus: null, priority: r.priority, neededBy: r.neededBy,
      allocationMode: 'V5', legacyMigrated: false, createdAt: t, updatedAt: t, createdByUserId: actor.system ? null : actor.id, actorType: actor.system ? 'SYSTEM' : 'USER',
      packedAt: null, readyAt: null, shippedAt: null, deliveredAt: null, items: [], metadata: actor.system ? { source: actor.source, triggeredByUserId: actor.triggeredByUserId } : null };
    db.FULFILLMENTS.push(f);
  }
  allocations.forEach((a) => {
    let item = f.items.find((i) => i.requestItemId === a.requestItemId);
    if (!item) {
      item = { id: f.id + '-L' + (f.items.length + 1), fulfillmentId: f.id, requestItemId: a.requestItemId, allocationIds: [], productVariantId: a.productVariantId,
        allocatedQuantity: 0, unit: a.unit, pickedQuantity: 0, packedQuantity: 0, collected: false };
      f.items.push(item);
    }
    if (item.allocationIds.indexOf(a.id) === -1) item.allocationIds.push(a.id);
    a.fulfillmentId = f.id;
  });
  refreshFulfillment(f);
  if (created) {
    const batch = batchNumberOf(f), later = batch > 1;
    recordAudit({ action: later ? AUDIT_ACTIONS.FULFILLMENT_CREATED_FOR_OUTSTANDING_DEMAND : AUDIT_ACTIONS.FULFILLMENT_CREATED, entityType: 'Fulfillment', entityId: f.id,
      companyId: f.companyId, projectId: f.projectId, before: null,
      after: { requestId: r.id, batch, lines: f.items.length, quantity: f.items.reduce((s, i) => s + i.allocatedQuantity, 0), actorType: actor.system ? 'SYSTEM' : 'USER' } }, actor);
    const p = getProject(r.projectId);
    notify(managersOf(r.companyId), { companyId: r.companyId, type: NOTIFICATION_TYPES.FULFILLMENT_CREATED, title: later ? r.id + ' \u00b7 batch ' + batch + ' ready to prepare' : 'New material request',
      message: (p ? p.name : '') + ' \u00b7 prepare ' + f.items.length + ' line' + (f.items.length === 1 ? '' : 's'), entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId });
  }
  return f;
}
// Caches on fulfillment lines are written only here, from allocations + the ledger.
export function refreshFulfillment(f) {
  if (!f || f.allocationMode !== 'V5') return f;
  f.items.forEach((i) => {
    const allocs = i.allocationIds.map((id) => db.ALLOCATIONS.find((a) => a.id === id)).filter(Boolean);
    allocs.forEach(refreshAllocationStatus);
    i.allocatedQuantity = allocs.filter((a) => a.status !== 'RELEASED' && a.status !== 'CANCELLED').reduce((s, a) => s + a.quantity, 0);
    i.pickedQuantity = allocs.reduce((s, a) => { const st = allocationState(a.id); return s + st.PICKING + st.PACKED; }, 0);
    i.packedQuantity = allocs.reduce((s, a) => s + allocationState(a.id).PACKED, 0);
    i.collected = i.allocatedQuantity > 0 && i.pickedQuantity >= i.allocatedQuantity;
  });
  if (f.status === 'CANCELLED' || f.status === 'READY' || f.dispatchStatus) { f.updatedAt = now(); return f; }
  const live = f.items.filter((i) => i.allocatedQuantity > 0);
  const before = f.status;
  if (!live.length) f.status = 'CANCELLED';
  else if (live.every((i) => i.collected)) f.status = live.every((i) => i.packedQuantity >= i.allocatedQuantity) ? 'PACKED' : 'PICKED';
  else if (live.some((i) => i.collected)) f.status = 'PARTIALLY_PICKED';
  else if (live.some((i) => i.pickedQuantity > 0)) f.status = 'PICKING';
  else f.status = 'ALLOCATED';
  if (f.status === 'PACKED' && !f.packedAt) f.packedAt = now();
  if (f.status !== 'PACKED') f.packedAt = null;   // more was allocated after packing: packing continues
  if (before !== f.status) f.updatedAt = now();
  return f;
}

/* ---------- v5 warehouse picking (always from the line's own reservation) ---------- */
function loadLine(actor, r, requestItemId, cap, opts) {
  if (!canUser(actor, CAP[cap])) return fail('forbidden', 'Not allowed');
  if (!r || r.companyId !== actor.companyId || !isV5(r)) return fail('forbidden', 'Not your company\'s request');
  const o = opts || {};
  let f;
  if (o.fulfillmentId) {
    f = fulfillmentById(o.fulfillmentId);
    if (!f || f.requestId !== r.id) return fail('fulfillment_mismatch', 'That warehouse batch belongs to another request');
  } else {
    // no batch named: the least advanced active batch that holds this line with work left
    const want = o.want || 'RESERVED';
    const has = (x) => x.items.some((i) => i.requestItemId === requestItemId && lineAllocations(i).some((a) => allocationState(a.id)[want] > 0 || (want === 'ANY_PICKED' && (allocationState(a.id).PICKING + allocationState(a.id).PACKED) > 0)));
    f = warehouseFulfillmentsFor(r.id).filter((x) => isActive(x) && has(x)).sort((a, b) => rankOf(a) - rankOf(b))[0] || warehouseFulfillmentFor(r.id);
  }
  if (!f || f.status === 'CANCELLED') return fail('no_fulfillment', 'Nothing was allocated to the warehouse for this request');
  if (f.projectId !== r.projectId || f.companyId !== r.companyId) return fail('fulfillment_mismatch', 'Fulfillment does not match its request');
  const item = f.items.find((i) => i.requestItemId === requestItemId);
  if (!item) return fail('not_found', 'This line has no warehouse allocation');
  return { f, item };
}
const lineAllocations = (item) => item.allocationIds.map((id) => db.ALLOCATIONS.find((a) => a.id === id)).filter(Boolean);
const moveDraft = (a, f, qty, type, from, to) => ({ movementType: type, companyId: a.companyId, productVariantId: a.productVariantId, quantity: qty, unit: a.unit,
  fromLocationId: a.sourceLocationId, toLocationId: a.sourceLocationId, fromInventoryState: from, toInventoryState: to,
  projectId: a.projectId, requestId: a.requestId, requestItemId: a.requestItemId, allocationId: a.id, fulfillmentId: f.id });
const auditLine = (action, actor, f, item, movements) => recordAudit({ action, entityType: 'MaterialMovement', entityId: movements[0] ? movements[0].id : null,
  companyId: f.companyId, projectId: f.projectId, before: null, after: { movementIds: movements.map((m) => m.id), fulfillmentId: f.id, requestId: f.requestId,
    requestItemId: item.requestItemId, productVariantId: item.productVariantId, quantity: movements.reduce((s, m) => s + m.quantity, 0) } }, actor);

// PICK: RESERVED -> PICKING for this line's allocations (optionally a partial quantity).
export function pickLine(actor, r, requestItemId, opts) {
  const o = opts || {};
  const x = loadLine(actor, r, requestItemId, 'PICK_MATERIALS', o); if (x.error) return x;
  const { f, item } = x;
  let left = o.quantity == null ? Infinity : Number(o.quantity);
  const drafts = [];
  lineAllocations(item).forEach((a) => { const held = allocationState(a.id).RESERVED; if (held <= 0 || left <= 0) return; const q = Math.min(held, left); left -= q; drafts.push(moveDraft(a, f, q, 'PICK', 'RESERVED', 'PICKING')); });
  if (!drafts.length) return fail('nothing_reserved', 'Nothing left reserved to pick for this line');
  if (isFinite(left) && left > 0) return fail('insufficient_reservation', 'More than this line has reserved');
  const res = postMovements(actor, drafts, { operationKey: o.operationKey, operationType: 'PICK_FULFILLMENT_LINE', entityType: 'FulfillmentItem', entityId: item.id });
  if (res.error || res.duplicate) return res;
  refreshFulfillment(f);
  auditLine(AUDIT_ACTIONS.MATERIAL_PICKED, actor, f, item, res.movements);
  const packed = f.status === 'PICKED' ? packFulfillment(actor, f) : null;
  refreshRequestStatus(r);
  return Object.assign(res, { fulfillment: f, item, packed });
}
// Every line picked: pack it all (PICKING -> PACKED), one audit event for the fulfillment.
export function packFulfillment(actor, f) {
  const drafts = [];
  f.items.forEach((i) => lineAllocations(i).forEach((a) => { const q = allocationState(a.id).PICKING; if (q > 0) drafts.push(moveDraft(a, f, q, 'PACK', 'PICKING', 'PACKED')); }));
  if (!drafts.length) return null;
  const res = postMovements(actor, drafts, { operationType: 'PACK_FULFILLMENT', entityType: 'Fulfillment', entityId: f.id });
  if (res.error) return res;
  refreshFulfillment(f);
  recordAudit({ action: AUDIT_ACTIONS.MATERIAL_PACKED, entityType: 'Fulfillment', entityId: f.id, companyId: f.companyId, projectId: f.projectId, before: null,
    after: { movementIds: res.movements.map((m) => m.id), fulfillmentId: f.id, requestId: f.requestId, quantity: res.movements.reduce((s, m) => s + m.quantity, 0) } }, actor);
  return res;
}
// Un-check: UNPACK (if packed) and UNPICK back into the SAME reservation, each linked to what it undoes.
export function unpickLine(actor, r, requestItemId, opts) {
  const x = loadLine(actor, r, requestItemId, 'PICK_MATERIALS', Object.assign({ want: 'ANY_PICKED' }, opts)); if (x.error) return x;
  if (!canUser(actor, CAP.PACK_MATERIALS)) return fail('forbidden', 'Not allowed');
  const { f, item } = x;
  if (f.status === 'READY' || f.dispatchStatus) return fail('already_dispatched', 'This order has left packing');
  const all = [];
  const undo = (type, fromState, toState, undoes) => {
    const drafts = [];
    lineAllocations(item).forEach((a) => {
      let q = allocationState(a.id)[fromState]; if (q <= 0) return;
      getMovementsForRequestItem(item.requestItemId).filter((m) => m.allocationId === a.id && m.movementType === undoes).reverse().forEach((m) => {
        const can = Math.min(q, m.quantity - db.MATERIAL_MOVEMENTS.filter((n) => n.reversalOfMovementId === m.id).reduce((s, n) => s + n.quantity, 0));
        if (can > 0) { drafts.push(Object.assign(reversalDraftFor(m, can), { allocationId: a.id, fulfillmentId: f.id })); q -= can; }
      });
      if (q > 0) drafts.push(moveDraft(a, f, q, type, fromState, toState));
    });
    if (!drafts.length) return null;
    const res = postMovements(actor, drafts, { operationType: type + '_FULFILLMENT_LINE', entityType: 'FulfillmentItem', entityId: item.id });
    if (!res.error) all.push.apply(all, res.movements);
    return res;
  };
  const up = undo('UNPACK', 'PACKED', 'PICKING', 'PACK'); if (up && up.error) return up;
  const ur = undo('UNPICK', 'PICKING', 'RESERVED', 'PICK'); if (ur && ur.error) return ur;
  if (!all.length) return fail('not_collected', 'Nothing picked on this line');
  if (f.status === 'PACKED' || f.status === 'PICKED') { f.status = 'PARTIALLY_PICKED'; f.packedAt = null; }
  refreshFulfillment(f);
  auditLine(AUDIT_ACTIONS.MATERIAL_UNPICKED, actor, f, item, all);
  refreshRequestStatus(r);
  return { ok: true, movements: all, fulfillment: f, item };
}

/* ---------- dispatch (TRANSITIONAL until the Logistics phase) ---------- */
// Same steps as before: Packed -> Ready to Ship -> Shipped -> Completed. No
// inventory movement; packed stock stays PACKED at the warehouse (Phase 2 note).
export function advanceFulfillment(actor, r, to, opts) {
  if (!canUser(actor, CAP.MANAGE_SHIPMENTS)) return 'forbidden';
  if (!r || r.companyId !== actor.companyId) return 'forbidden';
  const ready = (x) => (to === 'READY_TO_SHIP' ? x.status === 'PACKED' && !x.dispatchStatus : to === 'SHIPPED' ? x.status === 'READY' && !x.dispatchStatus : x.dispatchStatus === 'SHIPPED');
  let f;
  if (opts && opts.fulfillmentId) { f = fulfillmentById(opts.fulfillmentId); if (!f || f.requestId !== r.id) return 'forbidden'; }
  else f = warehouseFulfillmentsFor(r.id).find(ready) || warehouseFulfillmentFor(r.id);   // the batch that can take this step
  if (!f) return 'out_of_order';
  const t = now(), before = { status: f.status, dispatchStatus: f.dispatchStatus };
  if (to === 'READY_TO_SHIP' && f.status === 'PACKED' && !f.dispatchStatus) { f.status = 'READY'; f.readyAt = t; }
  else if (to === 'SHIPPED' && f.status === 'READY' && !f.dispatchStatus) {
    f.dispatchStatus = 'SHIPPED'; f.shippedAt = t;
    notify([r.requestedByUserId], { companyId: r.companyId, type: NOTIFICATION_TYPES.REQUEST_SHIPPED, title: 'Materials on the way',
      message: r.id + ' \u00b7 ' + ((getProject(r.projectId) || {}).name || ''), entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId });
  } else if (to === 'COMPLETED' && f.dispatchStatus === 'SHIPPED') { f.dispatchStatus = 'DELIVERED'; f.deliveredAt = t; }
  else return 'out_of_order';
  f.updatedAt = t;
  recordAudit({ action: AUDIT_ACTIONS.FULFILLMENT_STATUS_CHANGED, entityType: 'Fulfillment', entityId: f.id, companyId: f.companyId, projectId: f.projectId, before,
    after: { status: f.status, dispatchStatus: f.dispatchStatus, requestId: r.id } }, actor);
  refreshRequestStatus(r);
  return 'ok';
}

/* ---------- stages and views for the screens ---------- */
// The familiar order stage (WORKFLOW keys) for any request, legacy or v5.
export function stageOf(r) {
  if (!r) return 'PENDING';
  if (r.status === 'CANCELLED' && r.approvalStatus === 'REJECTED') return 'REJECTED';
  if (r.status === 'CANCELLED') return 'CANCELLED';
  if (!isV5(r)) return r.workflowStatus;
  if (r.approvalStatus === 'PENDING') return 'PENDING_APPROVAL';
  const fs = warehouseFulfillmentsFor(r.id);
  if (!fs.length) return r.allocationStatus === 'NOT_STARTED' ? 'PENDING' : 'AWAITING_STOCK';
  // several batches: the request is as far along as its least advanced active batch
  const f = fs.every((x) => x.dispatchStatus === 'DELIVERED') ? fs[fs.length - 1] : fs.filter(isActive).sort((a, b) => rankOf(a) - rankOf(b))[0];
  return stageOfFulfillment(f);
}
export function stageOfFulfillment(f) {
  if (!f || f.status === 'CANCELLED') return 'CANCELLED';
  if (f.dispatchStatus === 'DELIVERED') return 'COMPLETED';
  if (f.dispatchStatus === 'SHIPPED') return 'SHIPPED';
  switch (f.status) {
    case 'READY': return 'READY_TO_SHIP';
    case 'PACKED': case 'PICKED': case 'VERIFIED': return 'PACKED';
    case 'PARTIALLY_PICKED': return 'PARTIALLY_PACKED';
    case 'PICKING': return 'IN_PROGRESS';
    default: return 'PENDING';
  }
}
// Fulfillment status for any request (legacy ones derived from their combined lifecycle).
export function fulfillmentStatusFor(r) {
  if (isV5(r)) { const f = warehouseFulfillmentFor(r.id); return f ? f.status : null; }   // the least advanced active batch
  switch (r.workflowStatus) { case 'PENDING': return 'PENDING'; case 'IN_PROGRESS': return 'PICKING'; case 'PARTIALLY_PACKED': return 'PARTIALLY_PICKED'; case 'PACKED': return 'PACKED'; default: return 'READY'; }
}
function times(r) {
  if (!isV5(r)) return { packedAt: r.packedAt, shippedAt: r.shippedAt, completedAt: r.completedAt };
  const fs = warehouseFulfillmentsFor(r.id);
  const all = (k) => (fs.length && fs.every((f) => f[k]) ? Math.max.apply(null, fs.map((f) => f[k])) : null);
  return { packedAt: all('packedAt'), shippedAt: all('shippedAt'), completedAt: all('deliveredAt') };
}
// Field view: the request plus its derived stage and per-line progress (read-only).
export function fieldRequestView(r) {
  const summary = getRequestAllocationSummary(r);
  const batches = isV5(r) ? warehouseFulfillmentsFor(r.id).map((f, i) => ({ id: f.id, number: i + 1, stage: stageOfFulfillment(f), status: f.status })) : [];
  return Object.assign({}, r, times(r), { workflowStatus: stageOf(r), allocationSummary: summary, outstandingTotal: summary.outstanding, batches,
    items: r.items.map((it) => { const p = getLineProgress(it, r); return Object.assign({}, it, { progress: p,
      batches: batches.map((b) => { const fi = fulfillmentById(b.id).items.find((x) => x.requestItemId === it.id); return fi && fi.allocatedQuantity > 0 ? { number: b.number, quantity: fi.allocatedQuantity, stage: b.stage } : null; }).filter(Boolean),
      collected: isV5(r) ? p.allocated > 0 && p.picked >= p.allocated : it.collected, pickedQuantity: p.picked, packedQuantity: p.packed,
      shortQuantity: isV5(r) ? p.outstanding : it.shortQuantity }); }) });
}
// Warehouse view: what the warehouse must prepare (allocated quantity, not the request quantity).
// One view per warehouse BATCH. v5 views use the fulfillment id as their id
// (so each batch is its own warehouse task) and keep the request number for
// display; legacy views keep the request id. Pass a fulfillment to pick a batch.
export function warehouseOrderView(r, fulfillment) {
  if (!r) return null;
  if (!isV5(r)) { const lf = fulfillmentsForRequest(r.id)[0];
    return Object.assign({}, r, times(r), { requestId: r.id, requestNumber: r.id, workflowStatus: stageOf(r), fulfillmentId: lf ? lf.id : null, legacy: true, batchNumber: 1, batchCount: 1 }); }
  const f = fulfillment || warehouseFulfillmentFor(r.id);
  if (!f || f.status === 'CANCELLED' || f.requestId !== r.id) return null;
  const fs = warehouseFulfillmentsFor(r.id);
  const base = Object.assign({}, r, { packedAt: f.packedAt || null, shippedAt: f.shippedAt || null, completedAt: f.deliveredAt || null },
    { id: f.id, requestId: r.id, requestNumber: r.id, workflowStatus: stageOfFulfillment(f), batchNumber: fs.indexOf(f) + 1, batchCount: fs.length });
  const lines = f.items.filter((i) => i.allocatedQuantity > 0 || i.pickedQuantity > 0).map((i) => {
    const it = r.items.find((x) => x.id === i.requestItemId) || {};
    const allocs = lineAllocations(i).filter((a) => a.quantity > 0);
    return Object.assign({}, it, { id: it.id, fulfillmentItemId: i.id, quantity: i.allocatedQuantity, requestedQuantity: it.quantity,
      outstandingQuantity: getLineProgress(it, r).outstanding, pickedQuantity: i.pickedQuantity, packedQuantity: i.packedQuantity, collected: i.collected,
      shortQuantity: 0, reservedQuantity: allocs.reduce((s, a) => s + allocationState(a.id).RESERVED, 0), stockVariantId: i.productVariantId,
      allocations: allocs.map((a) => ({ id: a.id, locationId: a.sourceLocationId, name: ((db.LOCATIONS.find((l) => l.id === a.sourceLocationId)) || {}).name || '',
        quantity: a.quantity, reserved: allocationState(a.id).RESERVED })) });
  });
  return Object.assign(base, { fulfillmentId: f.id, fulfillmentStatus: f.status, legacy: false, items: lines,
    outstandingTotal: r.items.reduce((s, it) => s + getLineProgress(it, r).outstanding, 0) });
}
// Every warehouse task: each v5 batch (fulfillment) + each legacy order.
export function warehouseOrdersForCompany(companyId) {
  const out = [];
  db.REQUESTS.forEach((r) => {
    if (r.companyId !== companyId || r.status === 'CANCELLED') return;
    if (!isV5(r)) { out.push(warehouseOrderView(r)); return; }
    warehouseFulfillmentsFor(r.id).forEach((f) => out.push(warehouseOrderView(r, f)));
  });
  return out.filter(Boolean);
}
// A warehouse task by id: a fulfillment id (a batch) or a request id (its default batch).
export function warehouseTaskFor(r, id) {
  if (!r) return null;
  const f = id && id !== r.id ? fulfillmentById(id) : null;
  return f && f.requestId === r.id ? warehouseOrderView(r, f) : warehouseOrderView(r);
}
export function requestIdForTask(id) { const f = fulfillmentById(id); return f ? f.requestId : id; }
