/* Users: one table for everyone (field, warehouse, management, purchasing, admin). */
import { db, uid, now } from '../lib/db.js';
import { getUser, usersInCompany, getCompany } from './repo.js';
import { ROLES, roleLabel, workerTypeOf, normalizeRole } from '../config/roles.js';
import { setUserNameFields, withNameAlias, companyRolesOf } from '../lib/userModel.js';
export { getUser, companyRolesOf };

export const fullName = (u) => (u ? u.fullName : '');
export const userRoleLabel = (u) => (u ? roleLabel(u.primaryRole) : '');
export const companyUsers = (companyId, workerType) => usersInCompany(companyId).filter((u) => !workerType || u.workerType === workerType);
export const homeScreenFor = (u) => (u && ROLES[u.primaryRole] && ROLES[u.primaryRole].home) || 'roleSelect';

// The one write path for names: first, last and full name stay together.
export function setUserName(u, full) { setUserNameFields(u, full); u.updatedAt = now(); }

// Joins an EXISTING, active company only (never a fallback). Returns null if
// the company or role is not valid. Field validation messages are the
// onboarding action's job.
export function createUser(input) {
  const role = normalizeRole(input.primaryRole);
  const company = getCompany(input.companyId);
  if (!role || !company || company.status !== 'ACTIVE') return null;
  const workerType = workerTypeOf(role);
  const u = { id: uid(workerType === 'FIELD' ? 'f' : 'm'), companyId: company.id, email: input.email, phone: input.phone, pin: input.pin,
    primaryRole: role, companyRoles: [role], workerType, status: 'ACTIVE', avatarUrl: null, createdAt: now(), updatedAt: now() };
  setUserName(u, input.name);
  withNameAlias(u);
  if (workerType === 'FIELD') Object.assign(u, { lastProjectId: null, mostUsed: [], recentlyUsed: [], brandPrefs: {} });
  db.USERS.push(u);
  return u;
}
