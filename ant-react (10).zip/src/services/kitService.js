/* Job Kits: reusable material templates. They only ever pre-fill a request. */
import { db, nextKitId, now } from '../lib/db.js';
import { getKit } from './repo.js';
import { getProduct } from '../lib/catalog.js';
export { getKit };

// A company's own kits only (no company: no kits).
export const companyKits = (companyId) => (companyId ? db.JOB_KITS.filter((k) => k.type === 'Company' && k.companyId === companyId) : []);
export const personalKits = (user) => (user ? db.JOB_KITS.filter((k) => k.type === 'Personal' && k.createdBy === user.id) : []);

// Personal kits belong to their creator and their company.
export function createPersonalKit(actor, { name, description, items }) {
  const kit = { id: nextKitId(), companyId: actor.companyId, name, description: description || '', type: 'Personal', createdBy: actor.id,
    dateCreated: now(), dateUpdated: now(), timesUsed: 0,
    // Accepts kit draft lines ({ productId, qty }) or request lines ({ productVariantId, quantity }).
    materials: items.map((it) => { const id = it.productVariantId || it.productId; const p = getProduct(id);
      return { productId: id, qty: it.quantity != null ? it.quantity : it.qty, unit: p ? p.unit : (it.unit || 'EA') }; }) };
  db.JOB_KITS.push(kit);
  return kit;
}
