/* Locations: where materials physically are (foundation for Inventory, Phase 2). */
import { db } from '../lib/db.js';
import { getLocation, locationsInCompany, getProject } from './repo.js';
import { LOCATION_TYPES } from '../config/locations.js';
import { jobsiteIdFor, ensureBin, ensureJobsite, mainWarehouseIdFor } from '../lib/locationModel.js';
import { formatAddress } from '../lib/address.js';
export { getLocation };

export const companyLocations = (companyId) => locationsInCompany(companyId);
export const warehousesFor = (companyId) => locationsInCompany(companyId).filter((l) => l.type === LOCATION_TYPES.WAREHOUSE);
// The company's own main warehouse (never another company's).
export const mainWarehouseFor = (companyId) => getLocation(mainWarehouseIdFor(db, companyId));
export const childLocations = (parentId) => db.LOCATIONS.filter((l) => l.parentLocationId === parentId);
export const jobsiteForProject = (projectId) => getLocation(jobsiteIdFor(projectId));
export const assignedWarehouseFor = (projectId) => { const p = getProject(projectId); return p ? getLocation(p.assignedWarehouseId) : null; };
export const ensureProjectJobsite = (project) => ensureJobsite(db, project, formatAddress(project));
export const ensureWarehouseBin = (warehouseId, name) => ensureBin(db, warehouseId, name);
// A location usable by this company: exists, active, and owned by it.
export const locationBelongsTo = (locationId, companyId) => { const l = getLocation(locationId); return !!l && l.companyId === companyId; };

// Every location inside a warehouse (zones and bins), for future pick paths.
export function descendantsOf(locationId) {
  const out = [];
  const walk = (id) => childLocations(id).forEach((c) => { out.push(c); walk(c.id); });
  walk(locationId);
  return out;
}
// "Main Warehouse > Wire Area > Wire Rack A-3"
export function locationPath(locationId) {
  const names = [];
  let l = getLocation(locationId), guard = 0;
  while (l && guard++ < 10) { names.unshift(l.name); l = getLocation(l.parentLocationId); }
  return names.join(' > ');
}
// The warehouse a location sits in (itself, if it is one).
export function warehouseOf(locationId) {
  let l = getLocation(locationId), guard = 0;
  while (l && l.type !== LOCATION_TYPES.WAREHOUSE && guard++ < 10) l = getLocation(l.parentLocationId);
  return l && l.type === LOCATION_TYPES.WAREHOUSE ? l : null;
}
