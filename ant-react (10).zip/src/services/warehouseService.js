/* =========================================================================
   WAREHOUSE FULFILLMENT (Phase 2) — the checklist actions, on the ledger.

   collect      -> PICK the line's outstanding quantity (AVAILABLE -> PICKING)
   un-collect   -> UNPACK if packed, then UNPICK (back to AVAILABLE), each
                   linked to the movement it undoes
   mark short   -> PICK what is available, record a shortage for the rest
                   (a shortage is demand, never negative stock)
   order Packed -> when every line is resolved, each line's picked material
                   is PACKED (PICKING -> PACKED). Ready to Ship / Shipped /
                   Completed post NO movement yet (Logistics phase).
   One user action = one inventory effect; no other code changes stock.
   ========================================================================= */
import { canUser, CAP } from '../lib/permissions.js';
import { now } from '../lib/db.js';
import { getRequest } from './repo.js';
import { LEGACY_TO_VARIANT } from '../data/catalog.js';
import { recomputeWorkflow } from './requestService.js';
import { pickLine, unpickLine } from './fulfillmentService.js';
import { refreshRequestStatus } from './requestProgress.js';
import { recordAudit, AUDIT_ACTIONS } from './auditService.js';
import { pickMaterial, unpickMaterial, packMaterial, unpackMaterial, planPick, stockVariantFor, refreshLineProgress,
  getOutstandingQuantityForRequestItem, getPackedQuantityForRequestItem } from './inventoryService.js';

export function findLine(r, ref) {
  if (!r || !ref) return null;
  return r.items.find((i) => i.id === ref) || r.items.find((i) => i.productVariantId === ref) ||
    r.items.find((i) => i.legacyProductId === ref || (LEGACY_TO_VARIANT[ref] && i.productVariantId === LEGACY_TO_VARIANT[ref])) || null;
}
export const isResolved = (it) => it.collected || (it.shortQuantity || 0) > 0;

function load(actor, requestId, lineRef) {
  if (!canUser(actor, CAP.PICK_MATERIALS)) return { error: 'forbidden' };
  const r = getRequest(requestId);
  if (!r || r.companyId !== actor.companyId) return { error: 'forbidden' };
  const it = findLine(r, lineRef);
  return it ? { r, it } : { error: 'not_found' };
}
const ids = (...results) => results.filter((x) => x && x.movements).reduce((a, x) => a.concat(x.movements.map((m) => m.id)), []);

// When the order becomes Packed, pack every line's picked material (one audit event for the order).
function afterLineChange(actor, r) {
  const before = r.workflowStatus;
  recomputeWorkflow(r, actor);
  refreshRequestStatus(r);
  if (r.workflowStatus !== 'PACKED' || before === 'PACKED') return [];
  const packed = r.items.map((it) => (it.pickedQuantity > it.packedQuantity ? packMaterial(actor, { requestId: r.id, requestItemId: it.id, audit: false }) : null)).filter((x) => x && x.ok);
  const movementIds = ids(...packed);
  if (movementIds.length) recordAudit({ action: AUDIT_ACTIONS.MATERIAL_PACKED, entityType: 'MaterialRequest', entityId: r.id, companyId: r.companyId, projectId: r.projectId,
    before: null, after: { movementIds, requestId: r.id, quantity: packed.reduce((a, x) => a + x.movements.reduce((b, m) => b + m.quantity, 0), 0) } }, actor);
  return movementIds;
}

// v5 requests: the warehouse picks the line's own reservation (fulfillmentService).
// Legacy (pre-v5) requests: the Phase 2 flow below, unchanged (AVAILABLE -> PICKING).
export function collectRequestItem(actor, requestId, lineRef, opts) {
  const x = load(actor, requestId, lineRef); if (x.error) return x;
  const { r, it } = x;
  if (r.allocationMode === 'V5') { const res = pickLine(actor, r, it.id, opts); return res.error ? res : { ok: true, request: r, item: it, movements: res.movements, duplicate: res.duplicate }; }
  if (isResolved(it)) return { error: 'already_resolved' };
  const res = pickMaterial(actor, { requestId, requestItemId: it.id, operationKey: opts && opts.operationKey });
  if (res.error) return res;
  if (res.duplicate) return { ok: true, duplicate: true, request: r, item: it };
  afterLineChange(actor, r);
  return { ok: true, request: r, item: it, movements: res.movements };
}

export function uncollectRequestItem(actor, requestId, lineRef, opts) {
  const x = load(actor, requestId, lineRef); if (x.error) return x;
  const { r, it } = x;
  if (r.allocationMode === 'V5') { const res = unpickLine(actor, r, it.id, opts); return res.error ? res : { ok: true, request: r, item: it, movements: res.movements }; }
  if (!it.collected) return { error: 'not_collected' };
  if (!canUser(actor, CAP.PACK_MATERIALS)) return { error: 'forbidden' };
  if (it.legacyProgress) return { error: 'legacy_line' };   // dispatched before the ledger: history only
  const key = opts && opts.operationKey;
  const unpacked = getPackedQuantityForRequestItem(it) > 0 ? unpackMaterial(actor, { requestId, requestItemId: it.id, audit: false, operationKey: key && key + ':unpack' }) : null;
  if (unpacked && unpacked.error) return unpacked;
  const unpicked = unpickMaterial(actor, { requestId, requestItemId: it.id, audit: false, operationKey: key && key + ':unpick' });
  if (unpicked.error) return unpicked;
  if (unpicked.duplicate) return { ok: true, duplicate: true, request: r, item: it };
  recomputeWorkflow(r, actor);
  const movementIds = ids(unpacked, unpicked);
  recordAudit({ action: AUDIT_ACTIONS.MATERIAL_UNPICKED, entityType: 'MaterialMovement', entityId: movementIds[0], companyId: r.companyId, projectId: r.projectId,
    before: null, after: { movementIds, requestId: r.id, requestItemId: it.id, productVariantId: unpicked.movements[0].productVariantId,
      quantity: unpicked.movements.reduce((a, m) => a + m.quantity, 0) } }, actor);
  return { ok: true, request: r, item: it, movements: (unpacked ? unpacked.movements : []).concat(unpicked.movements) };
}

// Pick what's available, record the rest as short. Only when there isn't enough.
export function markRequestItemShort(actor, requestId, lineRef, opts) {
  const x = load(actor, requestId, lineRef); if (x.error) return x;
  const { r, it } = x;
  // v5: what the warehouse couldn't cover is already outstanding demand on the request;
  // the warehouse only ever sees reserved (so pickable) quantities.
  if (r.allocationMode === 'V5') return { error: 'not_applicable' };
  if (isResolved(it)) return { error: 'already_resolved' };
  const need = getOutstandingQuantityForRequestItem(it);
  const plan = planPick(r.companyId, stockVariantFor(r.companyId, it.productVariantId), need);
  if (plan.total >= need) return { error: 'enough_stock' };   // collect it instead
  const picked = plan.total > 0 ? pickMaterial(actor, { requestId, requestItemId: it.id, quantity: plan.total, audit: false, operationKey: opts && opts.operationKey }) : null;
  if (picked && picked.error) return picked;
  if (picked && picked.duplicate) return { ok: true, duplicate: true, request: r, item: it };
  it.shortage = { requestId: r.id, requestItemId: it.id, productVariantId: it.productVariantId, requestedQuantity: it.quantity,
    pickedQuantity: it.pickedQuantity, shortQuantity: it.quantity - it.pickedQuantity, reportedByUserId: actor.id, reportedAt: now(),
    reason: (opts && opts.reason) || null, legacy: false };
  refreshLineProgress(it);
  recordAudit({ action: AUDIT_ACTIONS.REQUEST_ITEM_MARKED_SHORT, entityType: 'MaterialRequestItem', entityId: it.id, projectId: r.projectId, companyId: r.companyId,
    before: { shortQuantity: 0 }, after: { requestId: r.id, productVariantId: it.productVariantId, pickedQuantity: it.pickedQuantity, shortQuantity: it.shortQuantity,
      movementIds: ids(picked) } }, actor);
  afterLineChange(actor, r);
  return { ok: true, request: r, item: it, movements: picked ? picked.movements : [] };
}
