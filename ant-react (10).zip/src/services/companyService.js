/* Company, its settings, and feature flags. */
import { getCompany, allCompanies } from './repo.js';
import { FEATURE_REGISTRY } from '../config/features.js';
import { COMPANY_TYPE_LABELS } from '../config/companySettings.js';
export { getCompany };

export const companySettings = (companyId) => { const c = getCompany(companyId); return c ? c.settings : null; };
export const activeCompanies = () => allCompanies().filter((c) => c.status === 'ACTIVE');
// Self-onboarding may only join a company that is explicitly resolved: an
// exact (case-insensitive) name match of an ACTIVE company. Never a fallback.
export function resolveCompanyByName(name) {
  const n = String(name || '').trim().toLowerCase();
  if (!n) return null;
  return activeCompanies().find((c) => c.name.trim().toLowerCase() === n) || null;
}
export const companyTypeLabel = (c) => (c ? COMPANY_TYPE_LABELS[c.companyType] || c.companyType : '');
// Visible only when the module is built AND the company has it switched on.
export function isFeatureEnabled(companyId, key) {
  const reg = FEATURE_REGISTRY[key];
  if (!reg || !reg.implemented) return false;
  if (reg.alwaysOn) return true;   // infrastructure (the Material Ledger) can't be switched off
  const c = getCompany(companyId);
  if (!c || !c.features || c.features[key] === undefined) return reg.defaultEnabled;
  return c.features[key] === true;
}
