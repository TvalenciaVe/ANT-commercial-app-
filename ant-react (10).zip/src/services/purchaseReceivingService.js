/* =========================================================================
   PURCHASE RECEIVING (Phase 4) — supplier -> warehouse (NOT jobsite receiving).

   One receipt = one coordinated domain operation (inside transaction()):
     1. PurchaseReceipt (immutable, REC-xxxx)
     2. Material Ledger: PURCHASE_RECEIPT outside -> AVAILABLE (good) or
        -> DAMAGED (damaged), at the chosen bin of the PO's warehouse
     3. demand handoff, per line, good units first to its demand links in the
        receipt distribution policy order (config/purchasing.js):
          convert = what that request line STILL needs, re-checked now
                    -> warehouse allocation + RESERVE at that bin + fulfillment
                       (Phase 3 rules: a started batch is never enlarged)
          the rest of the link's units -> ordinary AVAILABLE stock (stocked)
        coverage moves supplier -> warehouse by exactly the converted amount
        (net change 0); never above the request
     4. damaged units: charged to the stock overage first; beyond that they
        release demand commitment, so the requirement reopens for Purchasing
     5. overage units stay plain AVAILABLE stock (never reserved to a project)
   Over-receipt is refused. The same operation key + payload never receives twice.
   Production note: a backend must do all of this in one DB transaction.
   ========================================================================= */
import { db, now } from '../lib/db.js';
import { deepFreeze } from '../lib/ledger.js';
import { canUser, CAP } from '../lib/permissions.js';
import { transaction } from '../lib/transaction.js';
import { recordAudit, AUDIT_ACTIONS } from './auditService.js';
import { notify, NOTIFICATION_TYPES } from './notificationService.js';
import { postMovements, systemActor } from './materialLedgerService.js';
import { allocateReceivedStock, refreshRequestAllocationStatus } from './allocationService.js';
import { createOrExtendWarehouseFulfillment } from './fulfillmentService.js';
import { syncForRequest, refreshRequirementStatus } from './purchaseRequirementService.js';
import { poById, lineProgress, sortedLinks, allocOf, refreshPoStatus, receiptsForPo } from './purchaseOrderService.js';
import { supplierRemaining, getAllocatedQuantity, supplierAllocationsForItem, isSupplierCommitted, refreshRequestStatus } from './requestProgress.js';
import { priorOperation, recordOperation, fingerprintOf } from './operationRecords.js';
import { RECEIVABLE_PO_STATUSES } from '../config/purchasing.js';

const fail = (error, message, extra) => Object.assign({ error, message }, extra || {});
const int = (v) => (v === '' || v == null ? 0 : Number(v));
const loc = (id) => db.LOCATIONS.find((l) => l.id === id) || null;
function within(locationId, warehouseId) { let cur = loc(locationId), g = 0; while (cur && g++ < 20) { if (cur.id === warehouseId) return true; cur = loc(cur.parentLocationId); } return false; }
function nextReceipt() { db.RECEIPT_SEQ = (db.RECEIPT_SEQ || 1000) + 1; return { id: 'rcp_' + db.RECEIPT_SEQ, number: 'REC-' + db.RECEIPT_SEQ }; }
const requestOf = (id) => db.REQUESTS.find((r) => r.id === id) || null;
const RECEIVING_TYPES = ['WAREHOUSE', 'WAREHOUSE_ZONE', 'WAREHOUSE_BIN'];
export const getReceiptsForPurchaseOrder = (user, poId) => { const po = poById(poId); return po && user && po.companyId === user.companyId && canUser(user, CAP.VIEW_PURCHASE_RECEIPTS) ? receiptsForPo(poId) : []; };
export const getRemainingToReceive = (po, item) => lineProgress(po, item).remaining;
// Where received material may go: a bin (or the warehouse itself) of the PO's ship-to warehouse.
export function receivingLocations(po) {
  return db.LOCATIONS.filter((l) => l.companyId === po.companyId && l.status !== 'INACTIVE' && RECEIVING_TYPES.indexOf(l.type) !== -1 && within(l.id, po.shipToWarehouseId));
}
// Default: the product's primary bin if it is in this warehouse; else a "Receiving" area; else none (the receiver chooses).
export function defaultReceivingLocation(po, item) {
  const inv = (db.INVENTORY_ITEMS || []).find((x) => x.companyId === po.companyId && x.productVariantId === item.productVariantId);
  if (inv && inv.primaryLocationId && within(inv.primaryLocationId, po.shipToWarehouseId)) return inv.primaryLocationId;
  const rcv = receivingLocations(po).find((l) => /receiv/i.test(l.name));
  return rcv ? rcv.id : null;
}
export function validateReceipt(actor, po, input) {
  if (!actor || !canUser(actor, CAP.RECEIVE_PURCHASE_ORDER)) return fail('forbidden', 'Not allowed to receive purchase orders');
  if (!po || po.companyId !== actor.companyId) return fail('forbidden', 'Not your company\'s purchase order');
  if (RECEIVABLE_PO_STATUSES.indexOf(po.status) === -1) return fail('not_receivable', 'This purchase order is not open for receiving');
  const lines = input.lines || [], issues = input.issues || [];
  let any = false;
  for (const l of lines) {
    const it = po.items.find((x) => x.id === l.purchaseOrderItemId);
    if (!it) return fail('not_found', 'Unknown line');
    const g = int(l.quantityGood), d = int(l.quantityDamaged);
    if (!Number.isInteger(g) || !Number.isInteger(d) || g < 0 || d < 0) return fail('invalid_quantity', 'Enter whole quantities');
    const rem = lineProgress(po, it).remaining;
    if (g + d > rem) return fail('over_receipt', 'Only ' + rem + ' ' + it.unit + ' of this line are still expected. Record the rest as a receiving issue.', { remaining: rem });
    if (g + d > 0) {
      any = true;
      const L = loc(l.locationId);
      if (!L || L.companyId !== po.companyId || !within(L.id, po.shipToWarehouseId) || RECEIVING_TYPES.indexOf(L.type) === -1)
        return fail('invalid_location', 'Receive into a bin of ' + ((loc(po.shipToWarehouseId) || {}).name || 'the PO\'s warehouse'));
    }
  }
  // Damage has ONE source of truth: the line's damaged quantity (which posts the DAMAGED stock and creates the
  // receipt's single DAMAGED issue). A separately supplied DAMAGED issue would duplicate it, or claim damage with no stock.
  if (issues.some((x) => x && x.type === 'DAMAGED')) return fail('damaged_is_a_quantity', 'Record damaged material as a damaged quantity on its line');
  if (!any && !issues.length) return fail('nothing_to_receive', 'Enter what arrived, or report an issue');
  return null;
}
const receiptFingerprint = (po, input) => fingerprintOf({ po: po.id, slip: input.packingSlipNumber || null,
  lines: (input.lines || []).map((l) => [l.purchaseOrderItemId, int(l.quantityGood), int(l.quantityDamaged), l.locationId || null].join('|')).sort(),
  issues: (input.issues || []).map((x) => [x.purchaseOrderItemId || '', x.type, (x.notes || '').trim()].join('|')).sort() });

// (a) good units -> the line's demand links, converting only what each request line still needs
function handOffGood(ctx, it, l, g) {
  let goodLeft = g;
  const conv = [];
  sortedLinks(it).forEach((link) => {
    const a = allocOf(link); if (!a || goodLeft <= 0) return;
    const t1 = Math.min(goodLeft, supplierRemaining(a)); if (t1 <= 0) return;
    goodLeft -= t1;
    const r = requestOf(link.requestId), ri = r && r.items.find((x) => x.id === link.requestItemId);
    const open = r && ['APPROVED', 'PROCESSING', 'PARTIALLY_FULFILLED'].indexOf(r.status) !== -1;
    const others = ri ? supplierAllocationsForItem(ri.id).filter((x) => isSupplierCommitted(x) && x.id !== a.id).reduce((s, x) => s + supplierRemaining(x), 0) : 0;
    const need = open && ri ? Math.max(0, ri.quantity - getAllocatedQuantity(ri) - others) : 0;
    const c = Math.min(t1, need), st = t1 - c;
    let allocation = null;
    if (c > 0) {
      const ar = allocateReceivedStock(ctx.sys, r, ri, l.locationId, c, { productVariantId: it.productVariantId,
        links: { purchaseOrderId: ctx.po.id, purchaseReceiptId: ctx.ids.id, supplierAllocationId: a.id, purchaseRequirementId: a.purchaseRequirementId } });
      if (ar.error) throw new Error(ar.message || ar.error);
      allocation = ar.allocation;
      createOrExtendWarehouseFulfillment(ctx.sys, r, [allocation]);
      recordAudit({ action: AUDIT_ACTIONS.PURCHASED_MATERIAL_CONVERTED_TO_WAREHOUSE_ALLOCATION, entityType: 'MaterialAllocation', entityId: allocation.id, companyId: ctx.po.companyId,
        projectId: r.projectId, before: { supplierRemaining: supplierRemaining(a) }, after: { supplierAllocationId: a.id, warehouseAllocationId: allocation.id, quantity: c,
          requestId: r.id, requestItemId: ri.id, purchaseOrderId: ctx.po.id, purchaseReceiptId: ctx.ids.id, actorType: 'SYSTEM', triggeredByUserId: ctx.actor.id } }, ctx.sys);
      ctx.conversions.push({ r, ri, qty: c, unit: it.unit });
    }
    a.convertedQuantity = (a.convertedQuantity || 0) + c; a.stockedQuantity = (a.stockedQuantity || 0) + st; a.updatedAt = ctx.t;
    a.status = supplierRemaining(a) === 0 ? 'RECEIVED' : 'PARTIALLY_RECEIVED';
    conv.push({ requestId: link.requestId, requestItemId: link.requestItemId, supplierAllocationId: a.id, converted: c, stocked: st, allocationId: allocation ? allocation.id : null });
    if (r && ctx.touched.indexOf(r) === -1) ctx.touched.push(r);
  });
  return { goodLeft, conv };
}
// (b) damaged units: charged to the overage first; beyond it they release demand commitment (reopens the requirement)
function handOffDamaged(ctx, it, overageRemaining, goodToOverage, d) {
  const damagedOnOverage = Math.min(d, Math.max(0, overageRemaining - goodToOverage));
  let dd = d - damagedOnOverage;
  const releases = [];
  sortedLinks(it).slice().reverse().forEach((link) => {
    if (dd <= 0) return;
    const a = allocOf(link), x = Math.min(dd, a ? supplierRemaining(a) : 0);
    if (x <= 0) return;
    a.cancelledQuantity = (a.cancelledQuantity || 0) + x; a.updatedAt = ctx.t; dd -= x;
    if (supplierRemaining(a) === 0) a.status = (a.convertedQuantity || a.stockedQuantity) ? 'RECEIVED' : 'RELEASED';
    releases.push({ supplierAllocationId: a.id, quantity: x });
    const r = requestOf(link.requestId); if (r && ctx.touched.indexOf(r) === -1) ctx.touched.push(r);
  });
  return { damagedOnOverage, releases };
}
function notifyReceipt(ctx, receipt, issues) {
  const po = ctx.po;
  const buyers = db.USERS.filter((u) => u.companyId === po.companyId && u.status === 'ACTIVE' && canUser(u, CAP.MANAGE_PURCHASE_REQUIREMENTS)).map((u) => u.id);
  if (issues.length) {
    recordAudit({ action: AUDIT_ACTIONS.PURCHASE_RECEIPT_ISSUE_REPORTED, entityType: 'PurchaseReceipt', entityId: receipt.id, companyId: po.companyId, before: null,
      after: { issues: issues.map((x) => x.type), purchaseOrderId: po.id } }, ctx.actor);
    notify(buyers, { companyId: po.companyId, type: NOTIFICATION_TYPES.PURCHASE_RECEIPT_ISSUE, title: po.purchaseOrderNumber + ' \u00b7 receiving issue',
      message: issues.map((x) => (x.type === 'DAMAGED' ? x.quantity + ' ' + (((po.items.find((i) => i.id === x.purchaseOrderItemId)) || {}).unit || '') + ' damaged' : x.type === 'WRONG_MATERIAL' ? 'wrong material' : 'issue')).join(', '), entityType: 'PurchaseOrder', entityId: po.id });
  }
  if (receipt.items.length) notify(buyers, { companyId: po.companyId, type: NOTIFICATION_TYPES.PURCHASE_ORDER_RECEIVED,
    title: po.purchaseOrderNumber + (po.status === 'RECEIVED' ? ' was received' : ' was partially received'), message: receipt.receiptNumber + ' \u00b7 ' + po.supplierSnapshot.name,
    entityType: 'PurchaseOrder', entityId: po.id });
  const byReq = {};
  ctx.conversions.forEach((x) => { (byReq[x.r.id] = byReq[x.r.id] || { r: x.r, parts: [] }).parts.push(x.qty + ' ' + x.unit + ' ' + (x.ri.productNameSnapshot || '')); });
  Object.keys(byReq).forEach((k) => { const g = byReq[k];
    notify([g.r.requestedByUserId], { companyId: g.r.companyId, type: NOTIFICATION_TYPES.PURCHASED_MATERIAL_ARRIVED, title: g.r.id + ' \u00b7 on-order material arrived',
      message: g.parts.join(', ') + ' arrived and ' + (g.parts.length === 1 ? 'is' : 'are') + ' being prepared.', entityType: 'MaterialRequest', entityId: g.r.id, projectId: g.r.projectId }); });
}

export function receivePurchaseOrder(actor, poId, input, opts) {
  const po = poById(poId), o = opts || {}, inp = input || {};
  // order matters: permission + company first, then the replay (a retry after
  // success must return the original receipt, not fail the quantity check), then validation
  if (!actor || !canUser(actor, CAP.RECEIVE_PURCHASE_ORDER)) return fail('forbidden', 'Not allowed to receive purchase orders');
  if (!po || po.companyId !== actor.companyId) return fail('forbidden', 'Not your company\'s purchase order');
  const fp = receiptFingerprint(po, inp);
  const prior = priorOperation(actor, 'po-receive', o.operationKey, fp, 'PURCHASE_RECEIPTS');
  if (prior) return prior.error ? prior : { ok: true, receipt: prior.replay, duplicate: true };   // double tap: once
  const bad = validateReceipt(actor, po, inp); if (bad) return bad;
  return transaction(() => {
    const ids = nextReceipt(), t = now();
    const ctx = { po, actor, ids, t, sys: systemActor(po.companyId, 'PURCHASE_RECEIPT', actor.id), touched: [], conversions: [] };
    const drafts = [], work = [], issues = [];
    (inp.lines || []).forEach((l) => {
      const g = int(l.quantityGood), d = int(l.quantityDamaged);
      if (g + d <= 0) return;
      const it = po.items.find((x) => x.id === l.purchaseOrderItemId);
      const base = { companyId: po.companyId, productVariantId: it.productVariantId, unit: it.unit, fromLocationId: null, toLocationId: l.locationId, fromInventoryState: null,
        purchaseOrderId: po.id, movementType: 'PURCHASE_RECEIPT', metadata: { purchaseReceiptId: ids.id, receiptNumber: ids.number, purchaseOrderItemId: it.id } };
      if (g > 0) drafts.push(Object.assign({}, base, { quantity: g, toInventoryState: 'AVAILABLE' }));
      if (d > 0) drafts.push(Object.assign({}, base, { quantity: d, toInventoryState: 'DAMAGED' }));
      work.push({ it, l, g, d, before: lineProgress(po, it) });
    });
    const res = drafts.length ? postMovements(actor, drafts, { operationType: 'PURCHASE_RECEIPT', entityType: 'PurchaseReceipt', entityId: ids.id }) : { ok: true, movements: [] };
    if (res.error) return res;
    const items = work.map(({ it, l, g, d, before }, k) => {
      const good = handOffGood(ctx, it, l, g);
      const dmg = handOffDamaged(ctx, it, before.overageRemaining, good.goodLeft, d);
      if (d > 0) issues.push({ type: 'DAMAGED', purchaseOrderItemId: it.id, quantity: d, notes: l.notes || null });
      return { id: ids.id + '-L' + (k + 1), purchaseOrderItemId: it.id, productVariantId: it.productVariantId, quantityReceivedGood: g, quantityReceivedDamaged: d, unit: it.unit,
        destinationLocationId: l.locationId, notes: l.notes || null, toDemand: g - good.goodLeft, toOverage: good.goodLeft,
        damagedOnOverage: dmg.damagedOnOverage, damagedOnDemand: d - dmg.damagedOnOverage, conversions: good.conv, damagedReleases: dmg.releases };
    });
    // wrong material: nothing expected was received; the issue is recorded, no inventory is invented
    (inp.issues || []).forEach((x) => issues.push({ type: x.type || 'OTHER', purchaseOrderItemId: x.purchaseOrderItemId || null, quantity: int(x.quantity) || null, notes: (x.notes || '').trim() || null }));
    const receipt = deepFreeze({ id: ids.id, receiptNumber: ids.number, companyId: po.companyId, purchaseOrderId: po.id, supplierId: po.supplierId, warehouseId: po.shipToWarehouseId,
      receivedByUserId: actor.id, receivedAt: t, packingSlipNumber: inp.packingSlipNumber || null, notes: inp.notes || null, items, issues,
      movementIds: res.movements.map((m) => m.id) });
    db.PURCHASE_RECEIPTS.push(receipt);
    refreshPoStatus(po); po.updatedAt = t;
    ctx.touched.forEach((r) => { syncForRequest(r, ctx.sys); refreshRequestAllocationStatus(r); refreshRequestStatus(r); });
    (db.PURCHASE_REQUIREMENTS || []).filter((pr) => po.items.some((i) => i.demandLinks.some((l) => l.purchaseRequirementId === pr.id))).forEach(refreshRequirementStatus);
    recordOperation(actor, 'po-receive', o.operationKey, fp, 'RECEIVE_PURCHASE_ORDER', 'PurchaseReceipt', receipt.id);
    recordAudit({ action: AUDIT_ACTIONS.PURCHASE_RECEIPT_POSTED, entityType: 'PurchaseReceipt', entityId: receipt.id, companyId: po.companyId, before: null,
      after: { receiptNumber: receipt.receiptNumber, purchaseOrderId: po.id, movementIds: receipt.movementIds, good: items.reduce((s, x) => s + x.quantityReceivedGood, 0),
        damaged: items.reduce((s, x) => s + x.quantityReceivedDamaged, 0), poStatus: po.status } }, actor);
    notifyReceipt(ctx, receipt, issues);
    return { ok: true, receipt, movements: res.movements, purchaseOrder: po };
  });
}
