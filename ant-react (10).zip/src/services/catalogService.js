/* =========================================================================
   CATALOG SERVICE — the master catalog is the only source of product identity.
   CATEGORY > SUBCATEGORY > PRODUCT FAMILY > PRODUCT VARIANT > UNIT.
   Request lines, kits, stock and (future) movements all store a
   productVariantId: the configured id, e.g. "pf-thhn::#12|Black|Stranded"
   ("~ROLL" suffix for a non-default unit). Stored under the field name
   `productId` for compatibility; it is always a variant id after migration.
   ========================================================================= */
import { getProduct, parseFamilyVariantId, searchProducts, familyById } from '../lib/catalog.js';
import { LEGACY_TO_VARIANT } from '../data/catalog.js';

// Resolves a variant id (or a legacy flat id) to the product it identifies.
export const getProductVariant = (productVariantId) => getProduct(productVariantId);
export const variantExists = (productVariantId) => !!getProduct(productVariantId);
export const unitOf = (productVariantId) => { const p = getProduct(productVariantId); return p ? p.unit : null; };
export const canonicalVariantId = (id) => LEGACY_TO_VARIANT[id] || id;
export function familyOf(productVariantId) {
  const parsed = parseFamilyVariantId(canonicalVariantId(productVariantId));
  return parsed ? parsed.fam : null;
}
export { searchProducts, familyById };
