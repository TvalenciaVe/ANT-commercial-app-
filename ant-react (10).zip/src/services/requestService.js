/* =========================================================================
   MATERIAL REQUESTS — what the field needs.

   Screens still say "Orders" where that's familiar to users. Internally a
   record in db.REQUESTS is a MaterialRequest. Its `workflowStatus` is the
   combined lifecycle ANT runs today; request, fulfillment, shipment and
   receipt statuses are derived from it (config/statuses.js) until later
   phases give those their own records.

   Every status change goes through setWorkflowStatus(), so each one is
   validated and audited in exactly one place.
   ========================================================================= */
import { db, now, nextOrderId } from '../lib/db.js';
import { getRequest, getProject, getUser, requestsInCompany } from './repo.js';
import { canUser, CAP } from '../lib/permissions.js';
import { normalizePriority } from '../config/priorities.js';
import { WORKFLOW, WORKFLOW_TRANSITIONS, WORKFLOW_GROUPS, requestStatusOf, shipmentStatusOf as shipmentOfStage, receiptStatusOf as receiptOfStage } from '../config/statuses.js';
import { getProductVariant } from './catalogService.js';
import { demandItem, displayProductFor } from '../lib/requestModel.js';
import { advanceFulfillment, stageOf, fulfillmentStatusFor } from './fulfillmentService.js';
import { refreshRequestStatus, isV5, getPackedQuantity } from './requestProgress.js';
// What should arrive for a line: v5 = what the warehouse packed; legacy = the line quantity.
export const expectedOnDelivery = (r, it) => (isV5(r) ? getPackedQuantity(it, r) : it.quantity);
import { recordAudit, AUDIT_ACTIONS } from './auditService.js';
import { notify, NOTIFICATION_TYPES } from './notificationService.js';
export { getRequest, requestStatusOf, displayProductFor };
/* The Phase 1 mapping layer, now reading the real records: fulfillment status
   comes from the Fulfillment (legacy: derived from the combined lifecycle);
   shipment / receipt from the request's stage. Screens keep calling these. */
export const fulfillmentStatusOf = (r) => fulfillmentStatusFor(r);
export const shipmentStatusOf = (r) => shipmentOfStage(Object.assign({}, r, { workflowStatus: stageOf(r) }));
export const receiptStatusOf = (r) => receiptOfStage(r, stageOf(r));

/* ---------- reads ---------- */
export const requestsForProject = (projectId) => db.REQUESTS.filter((r) => r.projectId === projectId);
export const requestsForUser = (userId) => db.REQUESTS.filter((r) => r.requestedByUserId === userId);
export const requestsForCompany = (companyId) => requestsInCompany(companyId);
export const requestProject = (r) => getProject(r.projectId);
export const requestProjectName = (r) => { const p = getProject(r.projectId); return p ? p.name : (r.legacyProjectName || ''); };
export const requester = (r) => getUser(r.requestedByUserId);
// Who confirmed the delivery: the current name from the user record, or the snapshot.
export const receiptConfirmerName = (r) => { const u = getUser(r.fieldConfirmedByUserId); return u ? u.fullName : (r.fieldConfirmedByNameSnapshot || ''); };
export const requesterName = (r) => { const u = getUser(r.requestedByUserId); return u ? u.name : (r.legacyRequesterName || 'Unknown'); };
export const requesterPhone = (r) => { const u = getUser(r.requestedByUserId); return u ? u.phone : (r.legacyRequesterPhone || ''); };
export const requestItems = (r) => r.items;

/* ---------- create + submit ---------- */
// Returns { request } or { error: <i18n key> }. Re-validates everything even
// though the screens already did: this is the real boundary.
export function createRequest(actor, input) {
  const project = getProject(input.projectId);
  if (!project) return { error: 'err_no_project' };
  if (!actor || actor.companyId !== project.companyId || !canUser(actor, CAP.REQUEST_MATERIALS, { projectId: project.id })) return { error: 'no_permission_submit' };
  // Cart lines -> canonical lines (exact variant, quantity, unit, name/variant/brand snapshots).
  const lines = (input.lines || []).filter((l) => l && l.qty > 0 && getProductVariant(l.productId));
  if (!lines.length) return { error: 'err_cart_empty' };
  if (!input.neededBy) return { error: 'err_needed_date' };
  const id = nextOrderId();
  const t = now();
  const r = {
    id, companyId: project.companyId, projectId: project.id, requestedByUserId: actor.id,
    priority: normalizePriority(input.priority), neededBy: input.neededBy, notes: input.notes || '',
    // v5: demand only. Warehouse work lives in Fulfillment records; approval
    // and allocation have their own status fields (see config/requests.js).
    requestNumber: id, status: 'SUBMITTED', approvalStatus: null, allocationStatus: 'NOT_STARTED', allocationMode: 'V5',
    createdAt: t, submittedAt: t, updatedAt: t,
    fieldConfirmed: false, fieldConfirmedByUserId: null, fieldConfirmedByNameSnapshot: null, fieldConfirmedAt: null, deliveryIssues: null,
    items: lines.map((l, i) => demandItem({ productId: l.productId, qty: l.qty, brandIdx: l.brandIdx || 0, configured: l.configured }, id, i)),
  };
  db.REQUESTS.unshift(r);
  recordAudit({ action: AUDIT_ACTIONS.MATERIAL_REQUEST_SUBMITTED, entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId,
    before: null, after: { status: r.status, lines: r.items.length, priority: r.priority } }, actor);
  // The warehouse is notified when a fulfillment exists (after approval + allocation), not before.
  return { request: r };
}

/* ---------- workflow status ---------- */
export function setWorkflowStatus(r, to, actor) {
  if (!r || r.workflowStatus === to) return false;
  const before = { workflowStatus: r.workflowStatus, requestStatus: requestStatusOf(r) };
  r.workflowStatus = to;
  r.updatedAt = now();
  recordAudit({ action: AUDIT_ACTIONS.REQUEST_STATUS_CHANGED, entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId,
    before, after: { workflowStatus: to, requestStatus: requestStatusOf(r) } }, actor);
  return true;
}

// After a pick or a shortage: derive packing progress from the lines, in one
// step (one audit event). Manual stages are never auto-downgraded.
export function recomputeWorkflow(r, actor) {
  if (WORKFLOW_GROUPS.MANUAL_STAGES.indexOf(r.workflowStatus) !== -1) return;
  const total = r.items.length;
  const done = r.items.filter((i) => i.collected || (i.shortQuantity || 0) > 0).length;
  if (done === 0) setWorkflowStatus(r, WORKFLOW.PENDING, actor);
  else if (done < total) setWorkflowStatus(r, WORKFLOW.PARTIALLY_PACKED, actor);
  else if (total > 0) { setWorkflowStatus(r, WORKFLOW.PACKED, actor); if (!r.packedAt) r.packedAt = now(); }
}

// Manual dispatch steps must follow the lifecycle in order.
// Returns 'ok' | 'forbidden' | 'out_of_order'.
export function advanceWorkflow(actor, requestId, to, opts) {
  if (!canUser(actor, CAP.MANAGE_SHIPMENTS)) return 'forbidden';
  const r = getRequest(requestId);
  if (!r || r.companyId !== actor.companyId) return 'forbidden';
  if (r.allocationMode === 'V5') return advanceFulfillment(actor, r, to, opts);   // v5: a warehouse batch moves, not the request
  if (WORKFLOW_TRANSITIONS[r.workflowStatus] !== to) return 'out_of_order';
  setWorkflowStatus(r, to, actor);
  if (to === WORKFLOW.SHIPPED) {
    r.shippedAt = now();
    notify([r.requestedByUserId], { companyId: r.companyId, type: NOTIFICATION_TYPES.REQUEST_SHIPPED, title: 'Materials on the way',
      message: r.id + ' \u00b7 ' + requestProjectName(r), entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId });
  }
  if (to === WORKFLOW.COMPLETED) r.completedAt = now();
  refreshRequestStatus(r);
  return 'ok';
}

/* ---------- jobsite receipt ---------- */
// received = null when everything arrived, or { requestItemId: quantity received }.
// The confirmer is stored by user id (their name is only a snapshot).
export function recordReceipt(actor, requestId, received) {
  const r = getRequest(requestId);
  if (!r || stageOf(r) !== WORKFLOW.COMPLETED) return null;
  if (!canUser(actor, CAP.CONFIRM_PROJECT_RECEIPT, { projectId: r.projectId })) return null;
  const issues = [];
  // Expected = what the warehouse actually sent (v5: packed), not the whole request:
  // outstanding demand was never shipped, so it is not "missing" from the delivery.
  if (received) r.items.forEach((it) => {
    const expected = expectedOnDelivery(r, it);
    const got = received[it.id] == null ? expected : Math.max(0, parseInt(received[it.id], 10) || 0);
    if (got < expected) issues.push({ requestItemId: it.id, productVariantId: it.productVariantId, productNameSnapshot: it.productNameSnapshot,
      unit: it.unit, expectedQuantity: expected, receivedQuantity: got, missingQuantity: expected - got });
  });
  Object.assign(r, { fieldConfirmed: true, fieldConfirmedByUserId: actor.id, fieldConfirmedByNameSnapshot: actor.fullName, fieldConfirmedAt: now(),
    deliveryIssues: issues.length ? issues : null, updatedAt: now() });
  refreshRequestStatus(r);
  const withIssues = issues.length > 0;
  recordAudit({ action: withIssues ? AUDIT_ACTIONS.DELIVERY_ISSUE_REPORTED : AUDIT_ACTIONS.DELIVERY_CONFIRMED, entityType: 'MaterialRequest',
    entityId: r.id, projectId: r.projectId, after: { receiptStatus: receiptOfStage(r, stageOf(r)), issues: issues.length, confirmedByUserId: actor.id } }, actor);
  if (withIssues) {
    const managers = db.USERS.filter((u) => u.companyId === r.companyId && canUser(u, CAP.MANAGE_SHIPMENTS)).map((u) => u.id);
    notify(managers, { companyId: r.companyId, type: NOTIFICATION_TYPES.DELIVERY_ISSUE, title: 'Delivery issue reported',
      message: r.id + ' \u00b7 ' + issues.length + ' line' + (issues.length === 1 ? '' : 's') + ' short', entityType: 'MaterialRequest', entityId: r.id, projectId: r.projectId });
  }
  return r;
}
