/* Entity-level idempotency (Phase 3 submission pattern, reused by Phase 4):
   one record per company + "<prefix>:<userId>:<operationKey>", with the
   payload fingerprint and the entity it created. Same key + same payload ->
   the original entity comes back; same key + different payload ->
   IDEMPOTENCY_CONFLICT; another user or company never sees the record. */
import { db, now } from '../lib/db.js';
import { deepFreeze } from '../lib/ledger.js';
import { fingerprintOf } from './materialLedgerService.js';

export const opKeyFor = (prefix, userId, key) => prefix + ':' + userId + ':' + key;
export { fingerprintOf };
// -> null (new operation) | { replay: entity } | { error }
export function priorOperation(actor, prefix, key, fp, collection, validate) {
  if (!key || !actor) return null;
  const rec = (db.IDEMPOTENCY_RECORDS || []).find((x) => x.companyId === actor.companyId && x.operationKey === opKeyFor(prefix, actor.id, key));
  if (!rec) return null;
  const entity = (db[collection] || []).find((x) => x.id === rec.resultEntityId);
  if (!entity || entity.companyId !== actor.companyId || rec.actorUserId !== actor.id || (validate && !validate(entity))) return { error: 'IDEMPOTENCY_INTEGRITY', message: 'This operation record is not valid for you' };
  if (rec.payloadFingerprint !== fp) return { error: 'IDEMPOTENCY_CONFLICT', message: 'This action was already done with different details' };
  return { replay: entity };
}
export function recordOperation(actor, prefix, key, fp, operationType, entityType, entityId) {
  if (!key) return null;
  const rec = deepFreeze({ companyId: actor.companyId, operationKey: opKeyFor(prefix, actor.id, key), operationType, actorUserId: actor.id, actorType: 'USER',
    entityType, entityId, payloadFingerprint: fp, resultMovementIds: [], resultEntityType: entityType, resultEntityId: entityId, createdAt: now() });
  db.IDEMPOTENCY_RECORDS.push(rec);
  return rec;
}
