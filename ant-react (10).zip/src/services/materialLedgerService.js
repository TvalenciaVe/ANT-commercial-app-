/* =========================================================================
   MATERIAL LEDGER SERVICE — the ONLY code that writes movements or balances.

   postMovements(actor, drafts, { operationKey, operationType, fingerprint }):
     1. idempotency, scoped to the actor's company: the same company + key +
        payload returns the original result (double tap / retry safe); the
        same key with a different payload is IDEMPOTENCY_CONFLICT. Another
        company's operations are never looked at, let alone returned.
     2. every draft is built and shape-checked (lib/ledger.js)
     3. every draft is checked in context: same company for actor, variant,
        locations, request, project and user; unit valid for the variant;
        type active and allowed for this person; reversals mirror their
        original and never exceed what is left to reverse
     4. the whole batch is simulated on CURRENT balances (re-read now, never
        trusted from earlier): nothing may go negative
     5. only then is it committed: all movements or none (rolled back on error)
   Posted movements are frozen and never edited or deleted. Mistakes are
   corrected with a new movement (UNPICK, UNPACK, REVERSAL, adjustment).

   PROTOTYPE NOTE: this is a domain transaction inside one browser tab. A
   production backend must enforce the same rules inside a database
   transaction with row locks; localStorage cannot provide that.
   ========================================================================= */
import { db, now } from '../lib/db.js';
import { canUser, CAP } from '../lib/permissions.js';
import { MOVEMENT_TYPES, REVERSAL_TYPE_FOR, INVENTORY_STATES } from '../config/ledger.js';
import { createMaterialMovement, applyMovement, movementIdFor, deepFreeze, balanceKey, byLedgerOrder } from '../lib/ledger.js';
import { getProduct } from '../lib/catalog.js';
import { LOCATION_TYPES } from '../config/locations.js';

const loc = (id) => db.LOCATIONS.find((l) => l.id === id) || null;
const balance = (id) => db.INVENTORY_BALANCES.find((b) => b.id === id) || null;
const fail = (error, message, extra) => Object.assign({ error, message }, extra || {});
// Warehouse states live only inside a warehouse (a warehouse, zone, rack or bin).
function insideWarehouse(l) {
  let cur = l, guard = 0;
  while (cur && guard++ < 20) { if (cur.type === LOCATION_TYPES.WAREHOUSE) return true; cur = loc(cur.parentLocationId); }
  return false;
}

/* ---------- reads ---------- */
const chrono = (list) => list.slice().sort(byLedgerOrder);
export const getMovementById = (id) => db.MATERIAL_MOVEMENTS.find((m) => m.id === id) || null;
export const getMovementsForCompany = (companyId) => chrono(db.MATERIAL_MOVEMENTS.filter((m) => m.companyId === companyId));
export const getMovementsForVariant = (companyId, productVariantId) => chrono(db.MATERIAL_MOVEMENTS.filter((m) => m.companyId === companyId && m.productVariantId === productVariantId));
export const getMovementsForRequest = (requestId) => chrono(db.MATERIAL_MOVEMENTS.filter((m) => m.requestId === requestId));
export const getMovementsForRequestItem = (requestItemId) => chrono(db.MATERIAL_MOVEMENTS.filter((m) => m.requestItemId === requestItemId));
export const getMovementsForProject = (projectId) => chrono(db.MATERIAL_MOVEMENTS.filter((m) => m.projectId === projectId));
export const getMovementsForLocation = (companyId, locationId) => chrono(db.MATERIAL_MOVEMENTS.filter((m) => m.companyId === companyId && (m.fromLocationId === locationId || m.toLocationId === locationId)));
export const reversedQuantityOf = (movementId) => db.MATERIAL_MOVEMENTS.filter((m) => m.reversalOfMovementId === movementId).reduce((a, m) => a + m.quantity, 0);
export const reversibleQuantity = (m) => (m ? m.quantity - reversedQuantityOf(m.id) : 0);

/* ---------- context validation (one draft) ---------- */
/* SYSTEM ACTOR (Phase 3). Automatic allocation is done by ANT, not by a
   person, and is recorded as such: performedByUserId null, actorType SYSTEM,
   metadata { source, triggeredByUserId }. There is no fake "ANT System" user.
   Only services create it, and it may post only movement types marked
   systemAllowed (RESERVE / UNRESERVE). */
export function systemActor(companyId, source, triggeredByUserId) {
  return Object.freeze({ id: null, system: true, companyId, status: 'ACTIVE', source, triggeredByUserId: triggeredByUserId || null });
}
const allocationOf = (id) => (db.ALLOCATIONS || []).find((a) => a.id === id) || null;
// Net quantity the ledger holds RESERVED for one allocation (its reservation ownership).
export function reservedForAllocation(allocationId) {
  let n = 0;
  db.MATERIAL_MOVEMENTS.forEach((m) => { if (m.allocationId !== allocationId) return;
    if (m.toInventoryState === 'RESERVED') n += m.quantity; if (m.fromInventoryState === 'RESERVED') n -= m.quantity; });
  return n;
}
function validateContext(actor, m) {
  const type = MOVEMENT_TYPES[m.movementType];
  if (!actor || actor.status !== 'ACTIVE') return fail('forbidden', 'No active user');
  if (actor.companyId !== m.companyId) return fail('company_mismatch', 'A movement can only touch your own company\'s inventory');
  if (!type.active) return fail('inactive_type', m.movementType + ' belongs to a later phase');
  if (type.systemOnly) return fail('forbidden', m.movementType + ' is posted only by ANT itself');
  if (actor.system) { if (!type.systemAllowed) return fail('forbidden', 'ANT may only post reservations automatically'); }
  else if (type.capability && !canUser(actor, CAP[type.capability])) return fail('forbidden', 'Not allowed to post ' + m.movementType);
  // Reserved stock always belongs to one allocation: anything entering or
  // leaving RESERVED must name it, and it must match exactly.
  if (m.fromInventoryState === 'RESERVED' || m.toInventoryState === 'RESERVED' || m.allocationId) {
    const a = allocationOf(m.allocationId);
    if (!a) return fail('allocation_required', 'Reserved stock can only move for its allocation');
    if (a.companyId !== m.companyId || a.productVariantId !== m.productVariantId || a.sourceLocationId !== (m.fromLocationId || m.toLocationId) ||
        a.requestId !== m.requestId || a.requestItemId !== m.requestItemId) return fail('allocation_mismatch', 'That reservation belongs to another request, material or bin');
    // and to one warehouse batch: a movement can't book one batch's reservation on another batch
    if (m.fulfillmentId && a.fulfillmentId && m.fulfillmentId !== a.fulfillmentId) return fail('allocation_mismatch', 'That reservation belongs to another warehouse batch');
  }
  const p = getProduct(m.productVariantId);
  if (!p) return fail('unknown_variant', 'Unknown product variant');
  if (p.unit !== m.unit) return fail('unit_mismatch', 'This variant is tracked in ' + p.unit + ', not ' + m.unit);
  for (const id of [m.fromLocationId, m.toLocationId]) {
    if (!id) continue;
    const l = loc(id);
    if (!l || l.status === 'INACTIVE') return fail('unknown_location', 'Unknown location ' + id);
    if (l.companyId !== m.companyId) return fail('location_company', 'That location belongs to another company');
    if (!insideWarehouse(l)) return fail('location_not_warehouse', 'Warehouse inventory states live inside a warehouse');
  }
  if (m.requestId) {
    const r = db.REQUESTS.find((x) => x.id === m.requestId);
    if (!r) return fail('unknown_request', 'Unknown request');
    if (r.companyId !== m.companyId) return fail('request_company', 'That request belongs to another company');
    if (m.requestItemId && !r.items.some((i) => i.id === m.requestItemId)) return fail('unknown_request_item', 'That line is not on this request');
    if (m.projectId && m.projectId !== r.projectId) return fail('project_mismatch', 'Project does not match the request');
  }
  if (m.projectId) { const pr = db.PROJECTS.find((x) => x.id === m.projectId); if (!pr || pr.companyId !== m.companyId) return fail('project_company', 'That project belongs to another company'); }
  if (m.movementType === 'REVERSAL' && !m.reversalOfMovementId) return fail('invalid_reversal', 'A reversal must name the movement it reverses');
  if (m.reversalOfMovementId) {
    const o = getMovementById(m.reversalOfMovementId);
    if (!o || o.companyId !== m.companyId || o.productVariantId !== m.productVariantId || o.unit !== m.unit) return fail('invalid_reversal', 'The reversed movement does not match');
    if (o.movementType === 'REVERSAL' || o.reversalOfMovementId) return fail('invalid_reversal', 'A reversal cannot itself be reversed');
    const mirrors = m.fromLocationId === o.toLocationId && m.toLocationId === o.fromLocationId && (m.fromInventoryState || null) === (o.toInventoryState || null) && (m.toInventoryState || null) === (o.fromInventoryState || null);
    if (!mirrors) return fail('invalid_reversal', 'A reversal must exactly mirror the original movement');
    const want = m.movementType === 'REVERSAL' ? 'REVERSAL' : REVERSAL_TYPE_FOR[o.movementType];
    if (m.movementType !== want) return fail('invalid_reversal', o.movementType + ' is reversed by ' + (REVERSAL_TYPE_FOR[o.movementType] || 'REVERSAL'));
    if (m.quantity > reversibleQuantity(o)) return fail('reversal_exceeds', 'Only ' + reversibleQuantity(o) + ' ' + o.unit + ' of that movement is left to reverse');
  }
  return null;
}

/* ---------- idempotency (company-scoped) ----------
   One IdempotencyRecord per company + operationKey:
     { companyId, operationKey, operationType, actorUserId, entityType, entityId,
       payloadFingerprint, resultMovementIds, createdAt }
   The fingerprint covers the business payload only (never timestamps or
   generated ids), so an identical retry produces the same fingerprint. */
const stable = (v) => (Array.isArray(v) ? '[' + v.map(stable).join(',') + ']'
  : v && typeof v === 'object' ? '{' + Object.keys(v).sort().map((k) => JSON.stringify(k) + ':' + stable(v[k])).join(',') + '}' : JSON.stringify(v === undefined ? null : v));
function hash32(str, seed) { let h = seed >>> 0; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return ('0000000' + h.toString(16)).slice(-8); }
export function fingerprintOf(payload) { const c = stable(payload); return 'fp1:' + hash32(c, 2166136261) + hash32(c, 3141592653) + ':' + c.length; }
const MOVEMENT_FINGERPRINT_FIELDS = ['movementType', 'productVariantId', 'quantity', 'unit', 'fromLocationId', 'toLocationId', 'fromInventoryState', 'toInventoryState',
  'requestId', 'requestItemId', 'projectId', 'allocationId', 'fulfillmentId', 'reversalOfMovementId', 'reasonCode'];
export const draftsFingerprint = (drafts) => fingerprintOf((drafts || []).map((d) => {
  const out = {}; MOVEMENT_FINGERPRINT_FIELDS.forEach((k) => { out[k] = k === 'quantity' ? Number(d[k]) : (d[k] == null ? null : d[k]); }); return out;
}));
// Company FIRST: a record of another company is never found, so never returned.
export function findOperation(companyId, operationKey) {
  if (!companyId || !operationKey) return null;
  return (db.IDEMPOTENCY_RECORDS || []).find((r) => r.companyId === companyId && r.operationKey === operationKey) || null;
}
// null = new operation; { duplicate } = replay of the original result; { error } = conflict / not allowed.
export function checkOperation(actor, operationKey, operationType, fingerprint) {
  if (!operationKey) return null;
  if (!actor || actor.status !== 'ACTIVE' || !actor.companyId) return fail('forbidden', 'No active user');
  const rec = findOperation(actor.companyId, operationKey);
  if (!rec) {
    // Data from before company-scoped records: this key is on movements but its payload can't be verified.
    if (db.MATERIAL_MOVEMENTS.some((m) => m.companyId === actor.companyId && m.operationKey === operationKey)) return fail('IDEMPOTENCY_CONFLICT', 'This operation key was used before and cannot be verified');
    return null;
  }
  if (rec.operationType !== operationType || rec.payloadFingerprint !== fingerprint) return fail('IDEMPOTENCY_CONFLICT', 'This operation key was already used for a different operation');
  const movements = rec.resultMovementIds.map(getMovementById);
  // Never hand back anything that isn't this company's (defense in depth).
  if (rec.companyId !== actor.companyId || movements.some((m) => !m || m.companyId !== actor.companyId)) return fail('IDEMPOTENCY_CONFLICT', 'The stored result for this key cannot be verified');
  return { ok: true, duplicate: true, movements, operation: rec };
}

/* ---------- the one write path ---------- */
export function postMovements(actor, drafts, opts) {
  const o = opts || {};
  const opType = o.operationType || 'POST_MOVEMENTS';
  const fp = o.fingerprint || draftsFingerprint(drafts);
  const prior = checkOperation(actor, o.operationKey, opType, fp);
  if (prior) return prior;
  if (!drafts || !drafts.length) return fail('nothing_to_post', 'No movement to post');
  const at = now();
  const built = [];
  const reversing = {};   // several reversals of the same movement in one batch
  for (const d of drafts) {
    const sys = actor && actor.system ? { actorType: 'SYSTEM', metadata: Object.assign({ actorType: 'SYSTEM', source: actor.source, triggeredByUserId: actor.triggeredByUserId }, d.metadata || {}) } : { actorType: 'USER' };
    const res = createMaterialMovement(Object.assign({}, d, { id: null, performedByUserId: actor && actor.id, timestamp: at, operationKey: o.operationKey || null }, sys),
      { variantExists: (id) => !!getProduct(id) });
    if (res.error) return res;
    const err = validateContext(actor, res.movement);
    if (err) return err;
    if (res.movement.reversalOfMovementId) {
      const k = res.movement.reversalOfMovementId;
      reversing[k] = (reversing[k] || 0) + res.movement.quantity;
      if (reversing[k] > reversibleQuantity(getMovementById(k))) return fail('reversal_exceeds', 'That movement cannot be reversed by more than it moved');
    }
    built.push(res.movement);
  }
  // an allocation's reservation can never be over-consumed (ownership, not just the bin total)
  const fromAlloc = {};
  for (const m of built) {
    if (m.fromInventoryState !== 'RESERVED') continue;
    fromAlloc[m.allocationId] = (fromAlloc[m.allocationId] || 0) + m.quantity;
    const held = reservedForAllocation(m.allocationId);
    if (fromAlloc[m.allocationId] > held) return fail('insufficient_reservation', 'Only ' + held + ' ' + m.unit + ' are reserved for this allocation', { available: held });
  }
  // simulate on CURRENT balances: nothing may go negative
  const projected = {};
  const cur = (k) => (k in projected ? projected[k] : (balance(k) ? balance(k).quantity : 0));
  for (const m of built) {
    if (m.fromLocationId) {
      const k = balanceKey(m.companyId, m.productVariantId, m.fromLocationId, m.fromInventoryState);
      if (cur(k) < m.quantity) return fail('insufficient_stock', 'Only ' + cur(k) + ' ' + m.unit + ' ' + INVENTORY_STATES[m.fromInventoryState].label.toLowerCase() + ' there', { available: cur(k) });
      projected[k] = cur(k) - m.quantity;
    }
    if (m.toLocationId) { const k = balanceKey(m.companyId, m.productVariantId, m.toLocationId, m.toInventoryState); projected[k] = cur(k) + m.quantity; }
  }
  // commit: all or nothing
  const undo = { count: db.MATERIAL_MOVEMENTS.length, seq: db.MOVEMENT_SEQ, balances: JSON.parse(JSON.stringify(db.INVENTORY_BALANCES)), records: (db.IDEMPOTENCY_RECORDS || []).length };
  try {
    const map = {};
    db.INVENTORY_BALANCES.forEach((b) => { map[b.id] = b; });
    built.forEach((m) => {
      db.MOVEMENT_SEQ += 1;
      m.id = movementIdFor(db.MOVEMENT_SEQ);
      deepFreeze(m);
      db.MATERIAL_MOVEMENTS.push(m);
      applyMovement(map, m, at).forEach((k) => { if (db.INVENTORY_BALANCES.indexOf(map[k]) === -1) db.INVENTORY_BALANCES.push(map[k]); });
    });
    if (o.operationKey) {
      db.IDEMPOTENCY_RECORDS = db.IDEMPOTENCY_RECORDS || [];
      db.IDEMPOTENCY_RECORDS.push(deepFreeze({ companyId: actor.companyId, operationKey: o.operationKey, operationType: opType, actorUserId: actor.id, actorType: actor.system ? 'SYSTEM' : 'USER',
        entityType: o.entityType || null, entityId: o.entityId || null, payloadFingerprint: fp, resultMovementIds: built.map((m) => m.id), createdAt: at }));
    }
  } catch (e) {
    db.MATERIAL_MOVEMENTS.length = undo.count; db.MOVEMENT_SEQ = undo.seq; db.INVENTORY_BALANCES = undo.balances;
    if (db.IDEMPOTENCY_RECORDS) db.IDEMPOTENCY_RECORDS.length = undo.records;
    return fail('commit_failed', String(e && e.message));
  }
  return { ok: true, movements: built };
}

// A mirror-image counter-movement (UNPICK for a PICK, UNPACK for a PACK,
// REVERSAL for anything else). The original stays untouched.
export function reversalDraftFor(original, quantity, extra) {
  return Object.assign({
    movementType: REVERSAL_TYPE_FOR[original.movementType] || 'REVERSAL', companyId: original.companyId, productVariantId: original.productVariantId,
    quantity, unit: original.unit, fromLocationId: original.toLocationId, toLocationId: original.fromLocationId,
    fromInventoryState: original.toInventoryState, toInventoryState: original.fromInventoryState,
    projectId: original.projectId, requestId: original.requestId, requestItemId: original.requestItemId, reversalOfMovementId: original.id,
  }, extra || {});
}
export function reverseMovement(actor, movementId, opts) {
  const o = opts || {};
  const original = getMovementById(movementId);
  if (!original || !actor || original.companyId !== actor.companyId) return fail('invalid_reversal', 'Unknown movement');
  if (!canUser(actor, CAP.MANAGE_INVENTORY)) return fail('forbidden', 'Only a warehouse manager can reverse a movement');
  const idem = { operationKey: o.operationKey, operationType: 'REVERSE_MOVEMENT', fingerprint: fingerprintOf({ op: 'REVERSE_MOVEMENT', movementId, quantity: o.quantity == null ? null : Number(o.quantity), reasonCode: o.reasonCode || null }),
    entityType: 'MaterialMovement', entityId: movementId };
  const prior = checkOperation(actor, o.operationKey, idem.operationType, idem.fingerprint);
  if (prior) return prior;
  const qty = o.quantity == null ? reversibleQuantity(original) : Number(o.quantity);
  return postMovements(actor, [reversalDraftFor(original, qty, { reasonCode: o.reasonCode || 'DATA_CORRECTION', notes: o.notes || '' })], idem);
}
