import { DuplicateWarningSheet, ApprovalsSheet, RequestDetailSheet } from './components/RequestSheets.jsx';
import { useEffect } from 'react';
import { ui, useAppVersion, prefs } from './lib/store.js';
import { RoleSelect, ProfilePicker, Pin, NewProfileRole, NewProfile } from './screens/Login.jsx';
import { FieldHome, Category, Cart } from './screens/Field.jsx';
import { ProductSheet, FamilySheet, ProjectSwitcher, ChangeProjectWarning } from './components/Overlays.jsx';
import { Toast } from './components/common.jsx';
import { OrderForm, MyOrders, FieldProfile } from './screens/Requests.jsx';
import { JobKits, CreateKit } from './screens/Kits.jsx';
import { ReviewSheet, SaveKitSheet, KitDetailSheet } from './components/FieldSheets.jsx';
import { ManagerHome, WorkerHome, ManagerOrders, WarehousePacking, PackingMode, Inventory, Suppliers, History, WarehouseProfile, OrderDetailSheet, AllocationSheet, OutstandingRequests, ReceivePoSheet, SupplierSheet, InventoryDetailSheet, AdjustInventorySheet } from './screens/Warehouse.jsx';
import { ProjectsList, AddProject, ProjectWorkspace, DuplicateProjectSheet, AddTeamMemberSheet, PermissionChangeSheet, DeliveryConfirmSheet } from './screens/Projects.jsx';
// Phase 4 purchasing (company supplier RECORDS: distinct from the illustrative warehouse supplier lookup above)
import { PurchasingHome, PurchaseOrders, Suppliers as SupplierRecords, SupplierSheet as SupplierRecordSheet, PurchasingProfile, RequirementSheet, CreatePoSheet, PoSheet, QuoteSheet } from './screens/Purchasing.jsx';

const SCREENS = {
  roleSelect: RoleSelect,
  foremanPicker: () => <ProfilePicker role="foreman" />,
  managerPicker: () => <ProfilePicker role="manager" />,
  purchasingPicker: () => <ProfilePicker role="purchasing" />,
  pHome: PurchasingHome, pOrders: PurchaseOrders, pSuppliers: SupplierRecords, pProfile: PurchasingProfile,
  pin: Pin, newProfileRole: NewProfileRole, newProfile: NewProfile,
  fHome: FieldHome, fCategory: Category, fCart: Cart,
  fOrderForm: OrderForm, fMyOrders: MyOrders, fProfile: FieldProfile, fJobKits: JobKits, fCreateKit: CreateKit,
  fProjects: ProjectsList, fAddProject: AddProject, fProjectWorkspace: ProjectWorkspace,
  mHome: ManagerHome, whHome: WorkerHome, mOrders: ManagerOrders, whPacking: WarehousePacking, whPackingMode: PackingMode,
  mInventory: Inventory, mSuppliers: Suppliers, mHistory: History, mProfile: WarehouseProfile, mOutstanding: OutstandingRequests,
};

// Same screens as the original where the warehouse order sheet can open.
const P_SCREENS = ['pHome', 'pOrders', 'pSuppliers', 'pProfile'];
const ORDER_SHEET_SCREENS = ['mOrders', 'mHistory', 'mHome', 'whHome', 'whPacking', 'mInventory', 'mOutstanding'];

export default function App() {
  useAppVersion();
  useEffect(() => {
    document.getElementById('root').classList.toggle('text-large', prefs.textSize === 'large');
  });
  const Screen = SCREENS[ui.screen];
  return (
    <>
      {Screen ? <Screen /> : <RoleSelect />}
      {ui.modalProduct ? <ProductSheet /> : null}
      {ui.modalFamily ? <FamilySheet /> : null}
      {ui.modalKit ? <KitDetailSheet /> : null}
      {ui.saveKitOrderId ? <SaveKitSheet /> : null}
      {ui.reviewOpen ? <ReviewSheet /> : null}
      {ui.duplicateWarning ? <DuplicateProjectSheet /> : null}
      {ui.addTeamMemberOpen ? <AddTeamMemberSheet /> : null}
      {ui.permissionChangeConfirm ? <PermissionChangeSheet /> : null}
      {ui.deliveryConfirmOrderId ? <DeliveryConfirmSheet /> : null}
      {ui.requestDuplicate ? <DuplicateWarningSheet /> : null}
      {ui.approvalsOpen ? <ApprovalsSheet /> : null}
      {ui.requestDetailId ? <RequestDetailSheet /> : null}
      {ui.openOrderId && ORDER_SHEET_SCREENS.indexOf(ui.screen) !== -1 ? <OrderDetailSheet /> : null}
      {ui.allocationOrderId ? <AllocationSheet /> : null}
      {ui.supplierOrderId ? <SupplierSheet /> : null}
      {ui.requirementId && P_SCREENS.indexOf(ui.screen) !== -1 ? <RequirementSheet /> : null}
      {ui.poId && P_SCREENS.indexOf(ui.screen) !== -1 ? <PoSheet /> : null}
      {ui.poDraft && P_SCREENS.indexOf(ui.screen) !== -1 ? <CreatePoSheet /> : null}
      {ui.quoteDraft && P_SCREENS.indexOf(ui.screen) !== -1 ? <QuoteSheet /> : null}
      {ui.supplierEdit && P_SCREENS.indexOf(ui.screen) !== -1 ? <SupplierRecordSheet /> : null}
      {ui.receivePoId ? <ReceivePoSheet /> : null}
      {ui.inventoryDetailId && ui.screen === 'mInventory' ? <InventoryDetailSheet /> : null}
      {ui.adjustDraft && ui.screen === 'mInventory' ? <AdjustInventorySheet /> : null}
      {ui.switcherOpen ? <ProjectSwitcher /> : null}
      {ui.changeProjectWarning ? <ChangeProjectWarning /> : null}
      <Toast />
    </>
  );
}
