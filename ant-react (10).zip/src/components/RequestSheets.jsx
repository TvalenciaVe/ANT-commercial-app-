/* Phase 3 sheets: possible-duplicate warning, approvals, request detail.
   Simple on the surface: the field sees "Requested / Warehouse / Outstanding",
   never allocations, reservations or ledger terms. */
import { ui } from '../lib/store.js';
import { t, tf } from '../lib/i18n.js';
import { getUser } from '../services/repo.js';
import { getRequestFor } from '../services/selectors.js';
import { displayProductFor, requesterName, requestProjectName } from '../services/requestService.js';
import { fieldRequestView } from '../services/fulfillmentService.js';
import { pendingApprovalsFor, approvalById, approvalsForRequest, estimatedMaterialValue, currentStep, requestForApproval } from '../services/approvalService.js';
import { priorityLabel, priorityCss } from '../config/priorities.js';
import { workflowLabel, workflowPillClass } from '../config/statuses.js';
import { ROLES } from '../config/roles.js';
import { fmtNeeded, relTime } from '../lib/orders.js';
import { Icon, Sheet } from './common.jsx';
import * as F from '../lib/actionsField.js';

const roleLabel = (k) => (ROLES[k] ? ROLES[k].label : k);
const userName = (id) => { const u = getUser(id); return u ? u.fullName : ''; };

export function DuplicateWarningSheet() {
  const w = ui.requestDuplicate; if (!w) return null;
  const first = w.matches[0];
  const byReq = {}; w.matches.forEach((m) => { (byReq[m.requestId] = byReq[m.requestId] || []).push(m); });
  return (
    <Sheet onClose={F.closeDuplicateWarning} title={t('possible_duplicate')}>
      <div className="section-pad" style={{ paddingTop: 0 }}>
        <div className="small" style={{ marginBottom: 12 }}>{t('duplicate_intro')}</div>
        {Object.keys(byReq).map((rid) => (
          <div className="info-card" style={{ marginBottom: 10 }} key={rid}>
            {byReq[rid].map((m) => { const p = displayProductFor(m); return <div key={m.requestItemId} style={{ fontWeight: 700 }}>{p.name}{p.size ? ' · ' + p.size : ''} · {m.quantity} {m.unit}</div>; })}
            <div className="tiny muted" style={{ marginTop: 4 }}>{tf('duplicate_requested_ago', { when: relTime(byReq[rid][0].submittedAt), id: rid })}</div>
          </div>
        ))}
        <button className="btn btn-secondary" style={{ marginBottom: 10 }} onClick={() => F.openRequestDetail(first.requestId)}>{t('view_request')}</button>
        <button className="btn btn-primary" style={{ marginBottom: 10 }} onClick={F.continueDespiteDuplicate}>{t('continue_anyway')}</button>
        <button className="btn btn-secondary" onClick={F.closeDuplicateWarning}>{t('go_back')}</button>
      </div>
    </Sheet>
  );
}

// Home card: only for people with something to approve.
export function ApprovalsCard() {
  const list = pendingApprovalsFor(ui.currentUser);
  if (!list.length) return null;
  return (
    <div className="section-pad" style={{ paddingBottom: 0 }}>
      <button className="info-card" style={{ width: '100%', textAlign: 'left', display: 'flex', alignItems: 'center', gap: 12, borderColor: 'var(--warning)' }} onClick={F.openApprovals}>
        <Icon name="alert" className="ico-md ico-warning" />
        <span style={{ flex: 1 }}><span style={{ fontWeight: 800, display: 'block' }}>{tf(list.length === 1 ? 'approvals_waiting_one' : 'approvals_waiting', { n: list.length })}</span>
          <span className="tiny muted">{t('approvals_tap')}</span></span>
        <Icon name="chev" className="ico-sm ico-mist" />
      </button>
    </div>
  );
}

function ApprovalDecision({ ap }) {
  const r = requestForApproval(ui.currentUser, ap); if (!r) return null;
  const est = estimatedMaterialValue(r);
  const step = currentStep(ap);
  return (
    <div className="section-pad" style={{ paddingTop: 0 }}>
      <div className="h1" style={{ marginBottom: 2 }}>{r.id}</div>
      <div className="small muted" style={{ marginBottom: 12 }}>{requestProjectName(r)}</div>
      <div className="spec-row"><span className="k">{t('requested_by')}</span><span className="v">{requesterName(r)}</span></div>
      <div className="spec-row"><span className="k">{t('priority')}</span><span className="v">{priorityLabel(r.priority)}</span></div>
      <div className="spec-row"><span className="k">{t('needed_label')}</span><span className="v">{fmtNeeded(r.neededBy)}</span></div>
      <div className="spec-row"><span className="k">{t('estimated_value')}</span><span className="v">{est.known ? '$' + Math.round(est.value).toLocaleString() : t('value_unavailable')}</span></div>
      <div className="spec-row"><span className="k">{t('approval_reason')}</span><span className="v">{ap.reasons.map((x) => (x.code === 'COST_UNKNOWN_REVIEW_REQUIRED' ? t('cost_unknown_review') : x.message)).join(', ')}</span></div>
      {step ? <div className="spec-row"><span className="k">{t('approver')}</span><span className="v">{roleLabel(step.requiredRole)}{ap.steps.length > 1 ? ' (' + step.sequence + '/' + ap.steps.length + ')' : ''}</span></div> : null}
      <div className="spec-block-title">{tf('materials_n', { n: r.items.length })}</div>
      {r.items.map((it) => { const p = displayProductFor(it); return (
        <div className="spec-row" key={it.id}><span className="k" style={{ color: 'var(--ink)', flexShrink: 1, minWidth: 0 }}>{p.name}{p.size ? ' · ' + p.size : ''}</span><span className="v" style={{ whiteSpace: 'nowrap' }}>{it.quantity} {it.unit}</span></div>
      ); })}
      {ui.approvalError ? <div className="alert-banner" style={{ marginTop: 12 }}><Icon name="alert" /><span>{ui.approvalError}</span></div> : null}
      <div className="field" style={{ marginTop: 14 }}><label htmlFor="approval-notes">{t('decision_notes')}</label>
        <textarea id="approval-notes" value={ui.approvalNotes || ''} onChange={(e) => F.setApprovalNotes(e.target.value)} /></div>
      <div style={{ display: 'flex', gap: 10 }}>
        <button className="btn btn-danger" style={{ flex: 1 }} onClick={() => F.rejectApproval(ap.id)}>{t('reject')}</button>
        <button className="btn btn-primary" style={{ flex: 1 }} onClick={() => F.approveApproval(ap.id)}>{t('approve')}</button>
      </div>
    </div>
  );
}
export function ApprovalsSheet() {
  if (!ui.approvalsOpen) return null;
  const ap = ui.approvalId ? approvalById(ui.approvalId) : null;
  const list = pendingApprovalsFor(ui.currentUser);
  return (
    <Sheet onClose={F.closeApprovals} title={t('request_approval')}>
      {ap && ap.status === 'PENDING' ? <ApprovalDecision ap={ap} /> : (
        <div className="section-pad" style={{ paddingTop: 0 }}>
          {list.length ? list.map((a) => { const r = requestForApproval(ui.currentUser, a); return r ? (
            <button className="profile-pick" key={a.id} onClick={() => F.openApproval(a.id)}>
              <div style={{ flex: 1, minWidth: 0 }}><div className="pname">{r.id} · {requestProjectName(r)}</div>
                <div className="pmeta">{requesterName(r)} · {priorityLabel(r.priority)} · {tf('materials_n', { n: r.items.length })}</div></div>
              <div className="chev"><Icon name="chev" /></div>
            </button>) : null; })
            : <div className="empty" style={{ padding: '24px 0' }}><div className="etitle">{t('no_approvals')}</div></div>}
        </div>
      )}
    </Sheet>
  );
}

// Field request detail: demand progress in plain words, approval history, cancel.
export function RequestDetailSheet() {
  const raw = ui.requestDetailId && getRequestFor(ui.currentUser, ui.requestDetailId);
  if (!raw) return null;
  const o = fieldRequestView(raw);
  const history = approvalsForRequest(o.id);
  const v5 = o.allocationMode === 'V5';
  const lineStatus = (p) => (!v5 || p.allocated == null ? null : p.outstanding === 0 ? (p.onOrder > 0 ? t('rest_on_order') : t('available_status')) : p.allocated > 0 || p.onOrder > 0 ? t('partially_available') : t('not_available_yet'));
  return (
    <Sheet onClose={F.closeRequestDetail} title={o.id}>
      <div className="section-pad" style={{ paddingTop: 0 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
          <div><div style={{ fontWeight: 800, fontSize: 17 }}>{requestProjectName(o)}</div><div className="tiny muted">{t('needed_label')} {fmtNeeded(o.neededBy)}</div></div>
          <span className={'badge badge-' + priorityCss(o.priority)}>{priorityLabel(o.priority)}</span>
        </div>
        <span className={'status-pill' + workflowPillClass(o.workflowStatus)}>{workflowLabel(o.workflowStatus)}</span>
        <div className="spec-block-title">{t('materials_label')}</div>
        {o.items.map((it) => { const p = displayProductFor(it), pr = it.progress; return (
          <div className="info-card" style={{ marginBottom: 10 }} key={it.id}>
            <div style={{ fontWeight: 700 }}>{p.name}</div>{p.size ? <div className="tiny muted">{p.size}</div> : null}
            <div className="spec-row"><span className="k">{t('requested_label')}</span><span className="v">{pr.requested} {it.unit}</span></div>
            {v5 && it.batches.length > 1
              ? it.batches.map((b) => <div className="spec-row" key={b.number}><span className="k">{tf('warehouse_batch_n', { n: b.number })}</span><span className="v">{b.quantity} {it.unit} · {workflowLabel(b.stage)}</span></div>)
              : v5 ? <div className="spec-row"><span className="k">{t('warehouse_label')}</span><span className="v">{pr.allocated} {it.unit}</span></div> : null}
            {v5 && pr.onOrder > 0 ? <div className="spec-row"><span className="k">{t('on_order_label')}</span><span className="v">{pr.onOrder} {it.unit}</span></div> : null}
            <div className="spec-row" style={{ borderBottom: 'none' }}><span className="k">{v5 ? t('needs_sourcing_label') : t('outstanding_label')}</span><span className="v" style={pr.outstanding > 0 ? { color: 'var(--warning)' } : undefined}>{pr.outstanding} {it.unit}</span></div>
            {v5 && pr.onOrder > 0 && pr.supplierExpected ? <div className="tiny muted">{tf('expected_from_supplier', { d: new Date(pr.supplierExpected + 'T12:00:00').toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) })}</div> : null}
            {lineStatus(pr) ? <div className="tiny" style={{ fontWeight: 700, color: pr.outstanding > 0 ? 'var(--warning)' : 'var(--good)' }}>{lineStatus(pr)}</div> : null}
          </div>
        ); })}
        {history.length ? <><div className="spec-block-title">{t('approval_history')}</div>
          {history.map((ap) => (
            <div className="info-card" style={{ marginBottom: 10 }} key={ap.id}>
              <div className="tiny muted">{tf('approval_required_because', { reason: ap.reasons.map((x) => (x.code === 'COST_UNKNOWN_REVIEW_REQUIRED' ? t('cost_unknown_review') : x.message)).join(', ') })}</div>
              {ap.steps.map((s) => (
                <div className="small" key={s.sequence} style={{ marginTop: 6 }}><b>{roleLabel(s.requiredRole)}:</b> {s.status === 'PENDING' ? t('waiting') : (s.status === 'APPROVED' ? t('approved_by') : t('rejected_by')) + ' ' + userName(s.resolvedByUserId) + ' · ' + relTime(s.resolvedAt)}
                  {s.notes ? <div className="tiny muted">"{s.notes}"</div> : null}</div>
              ))}
            </div>
          ))}</> : null}
        {ui.requestDetailError ? <div className="alert-banner"><Icon name="alert" /><span>{ui.requestDetailError}</span></div> : null}
        {['CANCELLED', 'FULFILLED'].indexOf(o.status) === -1 && o.requestedByUserId === (ui.currentUser && ui.currentUser.id)
          ? <button className="btn btn-danger" style={{ marginTop: 6 }} onClick={() => F.cancelMyRequest(o.id)}>{t('cancel_request')}</button> : null}
      </div>
    </Sheet>
  );
}
