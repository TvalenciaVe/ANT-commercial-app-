/* =========================================================================
   STATUSES — every status ANT knows, defined once.

   THE DOMAIN RULE. These are different business things, each with its own
   lifecycle:
     Material Request  what the field needs            RequestStatus
     Fulfillment       what the warehouse prepares     FulfillmentStatus
     Shipment          what physically travels         ShipmentStatus
     Receipt           what the jobsite actually gets  ReceiptStatus
     Purchase Order / Return                           PurchaseOrderStatus / ReturnStatus

   TODAY a request record still carries ONE combined lifecycle, stored as
   `workflowStatus` (the warehouse flow ANT already runs). Rather than rewrite
   that working flow, the four statuses above are DERIVED from it through the
   mapping functions below. When a later phase gives Fulfillment/Shipment/
   Receipt their own records, only these mapping functions change; screens
   that ask requestStatusOf() / shipmentStatusOf() keep working.

   Only statuses marked `implemented` ever appear in the UI.
   ========================================================================= */

/* ---------- the combined lifecycle actually stored today ---------- */
export const WORKFLOW = {
  PENDING: 'PENDING', IN_PROGRESS: 'IN_PROGRESS', PARTIALLY_PACKED: 'PARTIALLY_PACKED', PACKED: 'PACKED',
  READY_TO_SHIP: 'READY_TO_SHIP', SHIPPED: 'SHIPPED', COMPLETED: 'COMPLETED',
};
export const WORKFLOW_STATUS = {
  PENDING:          { label: 'Pending',          legacy: 'Pending',          stage: 0, fieldBucket: 'Requested',      pill: '' },
  IN_PROGRESS:      { label: 'In Progress',      legacy: 'In Progress',      stage: 1, fieldBucket: 'Requested',      pill: '' },
  PARTIALLY_PACKED: { label: 'Partially Packed', legacy: 'Partially Packed', stage: 1, fieldBucket: 'Requested',      pill: ' status-warning' },
  PACKED:           { label: 'Packed',           legacy: 'Packed',           stage: 2, fieldBucket: 'Being Prepared', pill: ' status-success' },
  READY_TO_SHIP:    { label: 'Ready to Ship',    legacy: 'Ready to Ship',    stage: 2, fieldBucket: 'Being Prepared', pill: '' },
  SHIPPED:          { label: 'Shipped',          legacy: 'Shipped',          stage: 3, fieldBucket: 'On the Way',     pill: '' },
  COMPLETED:        { label: 'Completed',        legacy: 'Completed',        stage: 4, fieldBucket: 'Delivered',      pill: ' status-success' },
  // Phase 3 display stages (derived, never stored on a request)
  PENDING_APPROVAL: { label: 'Awaiting Approval',  legacy: 'Awaiting Approval', stage: 0, fieldBucket: 'Requested',     pill: ' status-warning' },
  AWAITING_STOCK:   { label: 'Awaiting Stock',     legacy: 'Awaiting Stock',    stage: 0, fieldBucket: 'Requested',     pill: ' status-warning' },
  REJECTED:         { label: 'Rejected',           legacy: 'Rejected',          stage: 0, fieldBucket: 'Closed',        pill: '' },
  CANCELLED:        { label: 'Cancelled',          legacy: 'Cancelled',         stage: 0, fieldBucket: 'Closed',        pill: '' },
};
// Groups used by lists and counters (defined once instead of per screen).
export const WORKFLOW_GROUPS = {
  OPEN_FOR_PACKING: [WORKFLOW.PENDING, WORKFLOW.IN_PROGRESS, WORKFLOW.PARTIALLY_PACKED],
  PACKING_IN_PROGRESS: [WORKFLOW.IN_PROGRESS, WORKFLOW.PARTIALLY_PACKED],
  UPCOMING_DELIVERY: [WORKFLOW.PACKED, WORKFLOW.READY_TO_SHIP, WORKFLOW.SHIPPED],
  CLOSED_FOR_FIELD: [WORKFLOW.SHIPPED, WORKFLOW.COMPLETED, 'REJECTED', 'CANCELLED'],   // "previous orders" on the field side
  MANUAL_STAGES: [WORKFLOW.READY_TO_SHIP, WORKFLOW.SHIPPED, WORKFLOW.COMPLETED], // never auto-downgraded
};
export const FIELD_BUCKETS = ['Requested', 'Being Prepared', 'On the Way', 'Delivered'];
export const ORDER_STAGE_KEYS = ['requested', 'packing_stage', 'ready_to_ship', 'on_the_way', 'delivered'];
// The only allowed manual dispatch steps. Anything else is refused.
export const WORKFLOW_TRANSITIONS = {
  [WORKFLOW.PACKED]: WORKFLOW.READY_TO_SHIP,
  [WORKFLOW.READY_TO_SHIP]: WORKFLOW.SHIPPED,
  [WORKFLOW.SHIPPED]: WORKFLOW.COMPLETED,
};

/* ---------- standardized statuses (the target model) ---------- */
export const REQUEST_STATUS = {
  DRAFT:               { label: 'Draft',               implemented: true },  // the cart; never stored as a record yet
  SUBMITTED:           { label: 'Submitted',           implemented: true },
  PENDING_APPROVAL:    { label: 'Pending Approval',    implemented: true },  // Phase 3
  APPROVED:            { label: 'Approved',            implemented: true },
  PROCESSING:          { label: 'Processing',          implemented: true },
  PARTIALLY_FULFILLED: { label: 'Partially Fulfilled', implemented: true },
  FULFILLED:           { label: 'Fulfilled',           implemented: true },
  CANCELLED:           { label: 'Cancelled',           implemented: true },
};
// `implemented` = the current combined workflow can actually produce it (via
// the mapping below). Everything else waits for its module; the UI never
// shows a status that isn't implemented.
export const FULFILLMENT_STATUS = {
  PENDING:          { label: 'Pending',          implemented: true },
  ALLOCATED:        { label: 'Allocated',        implemented: false },
  PICKING:          { label: 'Picking',          implemented: true },
  PARTIALLY_PICKED: { label: 'Partially Picked', implemented: true },
  PICKED:           { label: 'Picked',           implemented: false },
  VERIFIED:         { label: 'Verified',         implemented: false },
  PACKED:           { label: 'Packed',           implemented: true },
  READY:            { label: 'Ready',            implemented: true },
  CANCELLED:        { label: 'Cancelled',        implemented: false },
};
export const SHIPMENT_STATUS = {
  PREPARING:  { label: 'Preparing',  implemented: false },
  READY:      { label: 'Ready',      implemented: false },
  LOADED:     { label: 'Loaded',     implemented: false },
  DISPATCHED: { label: 'Dispatched', implemented: false },
  IN_TRANSIT: { label: 'In Transit', implemented: true },
  DELIVERED:  { label: 'Delivered',  implemented: true },
  RECEIVED:   { label: 'Received',   implemented: true },
  ISSUE:      { label: 'Issue',      implemented: true },
  CANCELLED:  { label: 'Cancelled',  implemented: false },
};
// Receipt = what the jobsite says it got (today's delivery confirmation).
export const RECEIPT_STATUS = {
  AWAITING_CONFIRMATION: { label: 'Awaiting Confirmation', implemented: true },
  RECEIVED_COMPLETE:     { label: 'Received Complete',     implemented: true },
  RECEIVED_WITH_ISSUES:  { label: 'Received with Issues',  implemented: true },
};
export const PURCHASE_ORDER_STATUS = {
  DRAFT: { label: 'Draft' }, SENT: { label: 'Sent' }, CONFIRMED: { label: 'Confirmed' },
  PARTIALLY_RECEIVED: { label: 'Partially Received' }, RECEIVED: { label: 'Received' },
  BACKORDERED: { label: 'Backordered' }, CANCELLED: { label: 'Cancelled' }, CLOSED: { label: 'Closed' },
};
// The RETURN PROCESS. What happens to each returned item (restock, damaged,
// scrap...) is a separate DISPOSITION below, not a step of the lifecycle.
export const RETURN_STATUS = {
  REQUESTED: { label: 'Requested' }, APPROVED: { label: 'Approved' }, IN_TRANSIT: { label: 'In Transit' },
  RECEIVED: { label: 'Received' }, INSPECTING: { label: 'Inspecting' }, RESTOCKED: { label: 'Restocked' },
  PARTIALLY_RESTOCKED: { label: 'Partially Restocked' }, CLOSED: { label: 'Closed' },
};
export const RETURN_DISPOSITIONS = {
  RESTOCK: { label: 'Restock' }, RETURN_TO_SUPPLIER: { label: 'Return to Supplier' },
  DAMAGED: { label: 'Damaged' }, SCRAP: { label: 'Scrap' }, TRANSFER_TO_PROJECT: { label: 'Transfer to Project' },
};
export const PROJECT_STATUS = {
  PLANNING:  { label: 'Planning',  open: true },
  ACTIVE:    { label: 'Active',    open: true },
  ON_HOLD:   { label: 'On Hold',   open: true },
  CLOSING:   { label: 'Closing',   open: true },
  COMPLETED: { label: 'Completed', open: false },
  ARCHIVED:  { label: 'Archived',  open: false },
};
export const USER_STATUS = { ACTIVE: { label: 'Active' }, INVITED: { label: 'Invited' }, INACTIVE: { label: 'Inactive' } };
export const COMPANY_STATUS = { ACTIVE: { label: 'Active' }, SUSPENDED: { label: 'Suspended' }, CLOSED: { label: 'Closed' } };
export const LOCATION_STATUS = { ACTIVE: { label: 'Active' }, INACTIVE: { label: 'Inactive' } };
export const MEMBERSHIP_STATUS = { ACTIVE: { label: 'Active' }, REMOVED: { label: 'Removed' } };

/* ---------- compatibility: historical spellings -> keys ---------- */
const squash = (v) => String(v == null ? '' : v).trim().toUpperCase().replace(/[\s-]+/g, '_');
export function normalizeWorkflowStatus(v) { const k = squash(v); return WORKFLOW_STATUS[k] ? k : WORKFLOW.PENDING; }
export function normalizeProjectStatus(v) { const k = squash(v); return PROJECT_STATUS[k] ? k : 'ACTIVE'; }

/* ---------- labels & presentation ---------- */
export const workflowLabel = (s) => (WORKFLOW_STATUS[s] ? WORKFLOW_STATUS[s].label : s);
export const workflowPillClass = (s) => (WORKFLOW_STATUS[s] ? WORKFLOW_STATUS[s].pill : '');
export const workflowStageIndex = (s) => (WORKFLOW_STATUS[s] ? WORKFLOW_STATUS[s].stage : 0);
export const fieldBucketOf = (s) => (WORKFLOW_STATUS[s] ? WORKFLOW_STATUS[s].fieldBucket : 'Requested');
export const projectStatusLabel = (s) => (PROJECT_STATUS[s] ? PROJECT_STATUS[s].label : s);
export const isOpenProjectStatus = (s) => !!PROJECT_STATUS[s] && PROJECT_STATUS[s].open;
export const inWorkflowGroup = (group, s) => WORKFLOW_GROUPS[group].indexOf(s) !== -1;

/* ---------- the mapping layer: combined lifecycle -> separate statuses ---------- */
const hasShortage = (r) => (r.items || []).some((i) => (i.shortQuantity || 0) > 0);
const hasReceiptIssue = (r) => !!(r.deliveryIssues && r.deliveryIssues.length);
// v5 requests store their own status (derived from demand, see services/requestProgress.js).
export function requestStatusOf(r) {
  if (r.allocationMode === 'V5' || r.status === 'CANCELLED') return r.status;
  switch (r.workflowStatus) {
    case WORKFLOW.PENDING: return 'SUBMITTED';
    case WORKFLOW.COMPLETED: return hasShortage(r) || hasReceiptIssue(r) ? 'PARTIALLY_FULFILLED' : 'FULFILLED';
    default: return 'PROCESSING';
  }
}
export function fulfillmentStatusOf(r) {
  switch (r.workflowStatus) {
    case WORKFLOW.PENDING: return 'PENDING';
    case WORKFLOW.IN_PROGRESS: return 'PICKING';
    case WORKFLOW.PARTIALLY_PACKED: return 'PARTIALLY_PICKED';
    case WORKFLOW.PACKED: return 'PACKED';
    default: return 'READY';   // ready to ship, shipped or delivered: fulfillment is done
  }
}
// null = no shipment exists yet
export function shipmentStatusOf(r) {
  if (r.workflowStatus === WORKFLOW.SHIPPED) return 'IN_TRANSIT';
  if (r.workflowStatus !== WORKFLOW.COMPLETED) return null;
  if (!r.fieldConfirmed) return 'DELIVERED';
  return hasReceiptIssue(r) ? 'ISSUE' : 'RECEIVED';
}
// null = nothing has been delivered yet
export function receiptStatusOf(r, stage) {
  if ((stage || r.workflowStatus) !== WORKFLOW.COMPLETED) return null;
  if (!r.fieldConfirmed) return 'AWAITING_CONFIRMATION';
  return hasReceiptIssue(r) ? 'RECEIVED_WITH_ISSUES' : 'RECEIVED_COMPLETE';
}
