/* LOCATION TYPES — where materials can physically be. */
export const LOCATION_TYPES = {
  WAREHOUSE: 'WAREHOUSE', WAREHOUSE_ZONE: 'WAREHOUSE_ZONE', WAREHOUSE_BIN: 'WAREHOUSE_BIN',
  JOBSITE: 'JOBSITE', VEHICLE: 'VEHICLE', TRANSIT: 'TRANSIT',
  RETURN_INSPECTION: 'RETURN_INSPECTION', DAMAGED: 'DAMAGED', SCRAP: 'SCRAP', OTHER: 'OTHER',
};
// Which zone a bin belongs to, decided by how its label starts. Used when
// ANT turns the old text labels ("Wire Rack A-3") into real bin locations.
export const ZONE_RULES = [
  { key: 'wire', name: 'Wire Area', match: /^(wire rack|reel yard)\b/i },
  { key: 'conduit', name: 'Conduit Area', match: /^conduit rack\b/i },
  { key: 'shelving', name: 'Shelving', match: /^shelf\b/i },
  { key: 'bins', name: 'Small Parts Bins', match: /^bin\b/i },
  { key: 'yard', name: 'Yard', match: /^yard\b/i },
];
export const OTHER_ZONE = { key: 'other', name: 'Other Storage' };
