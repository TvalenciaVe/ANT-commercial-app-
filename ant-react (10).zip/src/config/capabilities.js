/* =========================================================================
   CAPABILITIES — what someone is allowed to do, in one table.

   Screens and actions never ask "is this person a Foreman?". They ask
   canUser(user, CAP.REQUEST_MATERIALS, { projectId }) and this table answers.

   Two kinds of capability, with DIFFERENT names so they can never be confused:
   - PROJECT-SCOPED (VIEW_PROJECT_DELIVERIES, CONFIRM_PROJECT_RECEIPT...):
     only meaningful on one project, granted by the person's ProjectMembership
     on THAT project. A Foreman seeing Project A's deliveries says nothing
     about the company's logistics module.
   - COMPANY-SCOPED (VIEW_SHIPMENTS, MANAGE_INVENTORY...): company-wide
     operational modules, granted by the person's companyRoles.

   A capability existing here does NOT mean a screen exists for it. Future
   modules are listed so the model is complete; feature flags decide what is
   actually available.
   ========================================================================= */

export const CAP = {
  // ---- project-scoped ----
  VIEW_PROJECT: 'VIEW_PROJECT', MANAGE_PROJECT: 'MANAGE_PROJECT',
  VIEW_PROJECT_TEAM: 'VIEW_PROJECT_TEAM', MANAGE_PROJECT_TEAM: 'MANAGE_PROJECT_TEAM',
  VIEW_MATERIALS: 'VIEW_MATERIALS', REQUEST_MATERIALS: 'REQUEST_MATERIALS',
  VIEW_PROJECT_DELIVERIES: 'VIEW_PROJECT_DELIVERIES',
  CONFIRM_PROJECT_RECEIPT: 'CONFIRM_PROJECT_RECEIPT',    // confirm what arrived at the jobsite
  VIEW_PROJECT_INVENTORY: 'VIEW_PROJECT_INVENTORY',
  VIEW_PROJECT_RETURNS: 'VIEW_PROJECT_RETURNS',
  // project-scoped approval authority (a Project Manager on THAT project); resolve = approve or reject
  VIEW_PROJECT_APPROVALS: 'VIEW_PROJECT_APPROVALS', RESOLVE_PROJECT_APPROVAL: 'RESOLVE_PROJECT_APPROVAL',
  // ---- company-scoped ----
  CREATE_PROJECT: 'CREATE_PROJECT',
  ASSIGN_PROJECT_LEADS: 'ASSIGN_PROJECT_LEADS',          // make someone a PM / Superintendent / Foreman on a project
  VIEW_WAREHOUSE_ORDERS: 'VIEW_WAREHOUSE_ORDERS', PICK_MATERIALS: 'PICK_MATERIALS',
  VERIFY_MATERIALS: 'VERIFY_MATERIALS', PACK_MATERIALS: 'PACK_MATERIALS',
  VIEW_INVENTORY: 'VIEW_INVENTORY', MANAGE_INVENTORY: 'MANAGE_INVENTORY', VIEW_INVENTORY_HISTORY: 'VIEW_INVENTORY_HISTORY',
  MANAGE_ALLOCATIONS: 'MANAGE_ALLOCATIONS',              // review / change warehouse allocations (Phase 3)
  MANAGE_APPROVAL_POLICIES: 'MANAGE_APPROVAL_POLICIES',
  // company-scoped approval authority (Purchasing Manager, Owner, Company Admin)
  VIEW_COMPANY_APPROVALS: 'VIEW_COMPANY_APPROVALS', RESOLVE_COMPANY_APPROVAL: 'RESOLVE_COMPANY_APPROVAL',
  SOURCE_MATERIALS: 'SOURCE_MATERIALS',                  // today's illustrative supplier lookup (not Purchasing)
  VIEW_PURCHASING: 'VIEW_PURCHASING', MANAGE_PURCHASING: 'MANAGE_PURCHASING',
  // Phase 4 purchasing (company-scoped)
  VIEW_PURCHASE_REQUIREMENTS: 'VIEW_PURCHASE_REQUIREMENTS', MANAGE_PURCHASE_REQUIREMENTS: 'MANAGE_PURCHASE_REQUIREMENTS',
  VIEW_SUPPLIERS: 'VIEW_SUPPLIERS', MANAGE_SUPPLIERS: 'MANAGE_SUPPLIERS',
  VIEW_PURCHASE_ORDERS: 'VIEW_PURCHASE_ORDERS', CREATE_PURCHASE_ORDER: 'CREATE_PURCHASE_ORDER', EDIT_DRAFT_PURCHASE_ORDER: 'EDIT_DRAFT_PURCHASE_ORDER',
  SEND_PURCHASE_ORDER: 'SEND_PURCHASE_ORDER', CONFIRM_PURCHASE_ORDER: 'CONFIRM_PURCHASE_ORDER', CANCEL_PURCHASE_ORDER: 'CANCEL_PURCHASE_ORDER',
  MANAGE_BACKORDERS: 'MANAGE_BACKORDERS', VIEW_PURCHASE_RECEIPTS: 'VIEW_PURCHASE_RECEIPTS', RECEIVE_PURCHASE_ORDER: 'RECEIVE_PURCHASE_ORDER',
  VIEW_PURCHASE_PRICES: 'VIEW_PURCHASE_PRICES',          // commercial prices (never shown to the field by default)
  VIEW_SHIPMENTS: 'VIEW_SHIPMENTS', MANAGE_SHIPMENTS: 'MANAGE_SHIPMENTS',
  VIEW_RETURNS: 'VIEW_RETURNS', MANAGE_RETURNS: 'MANAGE_RETURNS',
  VIEW_COSTS: 'VIEW_COSTS', VIEW_BUDGETS: 'VIEW_BUDGETS', MANAGE_BUDGETS: 'MANAGE_BUDGETS', VIEW_ANALYTICS: 'VIEW_ANALYTICS',
  MANAGE_USERS: 'MANAGE_USERS', MANAGE_COMPANY: 'MANAGE_COMPANY',
};

export const PROJECT_SCOPED = new Set([
  CAP.VIEW_PROJECT, CAP.MANAGE_PROJECT, CAP.VIEW_PROJECT_TEAM, CAP.MANAGE_PROJECT_TEAM,
  CAP.VIEW_MATERIALS, CAP.REQUEST_MATERIALS, CAP.VIEW_PROJECT_DELIVERIES, CAP.CONFIRM_PROJECT_RECEIPT,
  CAP.VIEW_PROJECT_INVENTORY, CAP.VIEW_PROJECT_RETURNS, CAP.VIEW_PROJECT_APPROVALS, CAP.RESOLVE_PROJECT_APPROVAL,
]);
/* Project grants by project ROLE (not by permission level): approving a
   request is a Project Manager decision on that project, so a Foreman with
   Full Control never gets it. Owner / Company Admin approve company-wide. */
export const PROJECT_ROLE_GRANTS = {
  PROJECT_MANAGER: new Set([CAP.VIEW_PROJECT_APPROVALS, CAP.RESOLVE_PROJECT_APPROVAL]),
};
export const COMPANY_SCOPED = new Set(Object.values(CAP).filter((c) => !PROJECT_SCOPED.has(c)));

/* ---------- project grants: by the membership's permission level ---------- */
const VIEWER_CAPS = [CAP.VIEW_PROJECT, CAP.VIEW_MATERIALS, CAP.VIEW_PROJECT_TEAM, CAP.VIEW_PROJECT_INVENTORY, CAP.VIEW_PROJECT_DELIVERIES];
const EDIT_CAPS = VIEWER_CAPS.concat([CAP.REQUEST_MATERIALS, CAP.CONFIRM_PROJECT_RECEIPT]);
const FULL_CAPS = EDIT_CAPS.concat([CAP.MANAGE_PROJECT_TEAM, CAP.MANAGE_PROJECT, CAP.VIEW_PROJECT_RETURNS]);
export const PERMISSION_GRANTS = {
  VIEWER: new Set(VIEWER_CAPS),
  CAN_EDIT: new Set(EDIT_CAPS),
  FULL_CONTROL: new Set(FULL_CAPS),
};
// Project capabilities a Journeyman/Apprentice gets only if the company allows it.
export const GATED_BY_SETTING = {
  JOURNEYMAN: { setting: 'allowJourneymanRequests', caps: new Set([CAP.REQUEST_MATERIALS, CAP.CONFIRM_PROJECT_RECEIPT]) },
  APPRENTICE: { setting: 'allowApprenticeRequests', caps: new Set([CAP.REQUEST_MATERIALS, CAP.CONFIRM_PROJECT_RECEIPT]) },
};

/* ---------- company grants: by company role ----------
   A person's company capabilities are the UNION over all their companyRoles.
   Only Owner and Company Admin carry project capabilities company-wide
   (they oversee every project). Every other role gets project rights only
   through a ProjectMembership, so a company role can never open a project
   to a normal field worker. */
const ALL_PROJECT_CAPS = Array.from(PROJECT_SCOPED);
const WAREHOUSE_BASE = [CAP.VIEW_WAREHOUSE_ORDERS, CAP.PICK_MATERIALS, CAP.VERIFY_MATERIALS, CAP.PACK_MATERIALS, CAP.VIEW_INVENTORY, CAP.VIEW_SHIPMENTS];
export const ROLE_GRANTS = {
  COMPANY_ADMIN: new Set(Object.values(CAP)),
  OWNER: new Set(Object.values(CAP)),
  PROJECT_MANAGER: new Set([CAP.CREATE_PROJECT, CAP.ASSIGN_PROJECT_LEADS, CAP.VIEW_COSTS, CAP.VIEW_BUDGETS, CAP.VIEW_ANALYTICS]),
  SUPERINTENDENT: new Set([CAP.CREATE_PROJECT]),
  FOREMAN: new Set([CAP.CREATE_PROJECT]),
  JOURNEYMAN: new Set([]),
  APPRENTICE: new Set([]),
  // Warehouse Manager: sees incoming POs and receives them; never edits prices, suppliers or sends POs
  WAREHOUSE_MANAGER: new Set(WAREHOUSE_BASE.concat([CAP.MANAGE_INVENTORY, CAP.VIEW_INVENTORY_HISTORY, CAP.MANAGE_ALLOCATIONS,
    CAP.VIEW_PURCHASE_ORDERS, CAP.VIEW_SUPPLIERS, CAP.VIEW_PURCHASE_RECEIPTS, CAP.RECEIVE_PURCHASE_ORDER, CAP.SOURCE_MATERIALS, CAP.MANAGE_SHIPMENTS, CAP.VIEW_RETURNS, CAP.VIEW_PURCHASING])),
  WAREHOUSE_WORKER: new Set(WAREHOUSE_BASE),
  // Purchasing Manager: requirements, suppliers, POs, backorders, receipts (view). NOT physical receiving,
  // picking, packing or inventory adjustment unless another role grants them.
  PURCHASING_MANAGER: new Set([CAP.VIEW_PURCHASING, CAP.MANAGE_PURCHASING, CAP.SOURCE_MATERIALS, CAP.VIEW_INVENTORY, CAP.VIEW_COSTS,
    CAP.VIEW_COMPANY_APPROVALS, CAP.RESOLVE_COMPANY_APPROVAL,
    CAP.VIEW_PURCHASE_REQUIREMENTS, CAP.MANAGE_PURCHASE_REQUIREMENTS, CAP.VIEW_SUPPLIERS, CAP.MANAGE_SUPPLIERS, CAP.VIEW_PURCHASE_ORDERS,
    CAP.CREATE_PURCHASE_ORDER, CAP.EDIT_DRAFT_PURCHASE_ORDER, CAP.SEND_PURCHASE_ORDER, CAP.CONFIRM_PURCHASE_ORDER, CAP.CANCEL_PURCHASE_ORDER,
    CAP.MANAGE_BACKORDERS, CAP.VIEW_PURCHASE_RECEIPTS, CAP.VIEW_PURCHASE_PRICES]),
};
// Roles whose company grant includes project capabilities.
export const COMPANY_WIDE_PROJECT_ROLES = Object.keys(ROLE_GRANTS).filter((r) => ALL_PROJECT_CAPS.some((c) => ROLE_GRANTS[r].has(c)));
export { ALL_PROJECT_CAPS };
