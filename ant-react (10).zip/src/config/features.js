/* =========================================================================
   FEATURE FLAGS answer ONE question: "Is this software module available to
   this company?" (built by ANT, and switched on for the tenant).

   COMPANY SETTINGS (companySettings.js) answer a different one: "How does this
   company choose to run a module it has?" e.g. features.approvals says the
   Approvals module is available; settings.approvalsEnabled says whether
   this contractor actually requires approval.

   A module is visible only when it is BOTH implemented (this registry) AND
   enabled (company.features). Switching on a module that isn't built yet does
   nothing, so unfinished work can never show up as a broken button.

   `inventory` means the future Inventory module (ledger-backed, multi-location
   stock). Today's warehouse stock screen is core fulfillment, not behind it.
   ========================================================================= */
export const FEATURE_REGISTRY = {
  // existing, working modules (on by default)
  materialRequests:     { implemented: true,  defaultEnabled: true },
  jobKits:              { implemented: true,  defaultEnabled: true },
  projectWorkspace:     { implemented: true,  defaultEnabled: true },
  warehouseFulfillment: { implemented: true,  defaultEnabled: true },
  packingMode:          { implemented: true,  defaultEnabled: true },
  deliveryConfirmation: { implemented: true,  defaultEnabled: true },
  supplierLookup:       { implemented: true,  defaultEnabled: true },   // illustrative sourcing help, NOT Purchasing
  // Phase 2: inventory is transactional. `inventory` shows the stock detail
  // and history views; the Material Ledger itself is infrastructure and is
  // always on (warehouse work can't run without it), whatever the flag says.
  inventory:            { implemented: true,  defaultEnabled: true },
  materialLedger:       { implemented: true,  defaultEnabled: true, alwaysOn: true },
  // future modules (not built yet)
  approvals:            { implemented: true,  defaultEnabled: true },   // Phase 3 (company decides via settings.approvalsEnabled)
  allocation:           { implemented: true,  defaultEnabled: true, alwaysOn: true },   // Phase 3: requests are allocated and reserved
  purchasing:           { implemented: true,  defaultEnabled: true },   // Phase 4: requirements, suppliers, POs, supplier receiving
  advancedLogistics:    { implemented: false, defaultEnabled: false },
  returns:              { implemented: false, defaultEnabled: false },
  costTracking:         { implemented: false, defaultEnabled: false },
  analytics:            { implemented: false, defaultEnabled: false },
  notificationsCenter:  { implemented: false, defaultEnabled: false },
};
export function defaultFeatures(overrides) {
  const out = {};
  Object.keys(FEATURE_REGISTRY).forEach((k) => { out[k] = FEATURE_REGISTRY[k].defaultEnabled; });
  return Object.assign(out, overrides || {});
}
