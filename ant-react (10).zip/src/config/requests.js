/* =========================================================================
   REQUESTS + ALLOCATION + APPROVALS (Phase 3) — the vocabulary, defined once.

   Five different things, never mixed:
     Material Request   what the field needs (demand)              request.status
     Allocation         where ANT plans to source part of it       allocation.status
     Reservation        warehouse stock held for an allocation      RESERVED movements
     Fulfillment        the warehouse work created from allocations fulfillment.status
     Outstanding        demand with no source yet                   requested - active allocated
   ========================================================================= */
export const REQUEST_STATUSES = ['DRAFT', 'SUBMITTED', 'PENDING_APPROVAL', 'APPROVED', 'PROCESSING', 'PARTIALLY_FULFILLED', 'FULFILLED', 'CANCELLED'];
// NOT_REQUIRED = no rule applied; LEGACY = submitted before approvals existed (never invented)
export const APPROVAL_STATUSES = ['NOT_REQUIRED', 'PENDING', 'APPROVED', 'REJECTED', 'CANCELLED', 'LEGACY'];
// request-level summary of its allocations
export const REQUEST_ALLOCATION_STATUSES = ['NOT_STARTED', 'UNALLOCATED', 'PARTIALLY_ALLOCATED', 'ALLOCATED', 'RELEASED', 'LEGACY'];
export const ALLOCATION_MODES = { V5: 'V5', LEGACY: 'LEGACY' };

export const ALLOCATION_SOURCE_TYPES = {
  WAREHOUSE:        { active: true },
  SUPPLIER:         { active: false },   // Phase 4 Purchasing
  JOBSITE_TRANSFER: { active: false },   // Logistics
  DIRECT_PURCHASE:  { active: false },
  SPECIAL_ORDER:    { active: false },
};
// one MaterialAllocation record
export const ALLOCATION_STATUSES = ['PROPOSED', 'ALLOCATED', 'RESERVED', 'PARTIALLY_FULFILLED', 'FULFILLED', 'RELEASED', 'CANCELLED'];
export const ACTIVE_ALLOCATION_STATUSES = ['PROPOSED', 'ALLOCATED', 'RESERVED', 'PARTIALLY_FULFILLED', 'FULFILLED'];
export const FULFILLMENT_STATUSES = ['PENDING', 'ALLOCATED', 'PICKING', 'PARTIALLY_PICKED', 'PICKED', 'VERIFIED', 'PACKED', 'READY', 'CANCELLED'];
// TRANSITIONAL: today's "Shipped" / "Completed" buttons, kept until the
// Logistics phase gives shipments their own records (ShipmentStatus).
export const DISPATCH_STATUSES = ['SHIPPED', 'DELIVERED'];

export const APPROVAL_REQUEST_STATUSES = ['PENDING', 'APPROVED', 'REJECTED', 'CANCELLED'];
// Sequential steps: exactly one PENDING (the active step) at a time; later steps WAITING.
export const APPROVAL_STEP_STATUSES = ['WAITING', 'PENDING', 'APPROVED', 'REJECTED', 'CANCELLED'];
/* Who may resolve a step, by its requiredRole. PROJECT scope: the person holds
   that role ON the request's project (ProjectMembership). COMPANY scope: the
   person holds that role in companyRoles (no project membership needed:
   Purchasing Manager is a company role, never a project role).
   ownerAdminOverride: Owner / Company Admin may also resolve the step. */
export const APPROVER_ROLE_SCOPES = {
  PROJECT_MANAGER:    { scope: 'PROJECT', ownerAdminOverride: true },
  SUPERINTENDENT:     { scope: 'PROJECT', ownerAdminOverride: true },
  PURCHASING_MANAGER: { scope: 'COMPANY', ownerAdminOverride: true },
  COMPANY_ADMIN:      { scope: 'COMPANY', ownerAdminOverride: false },
  OWNER:              { scope: 'COMPANY', ownerAdminOverride: false },
};
// A new allocation may join an existing warehouse fulfillment only before any
// physical work started on it; otherwise ANT creates a new one (safe default).
export const FULFILLMENT_EXTENDABLE_STATUSES = ['PENDING', 'ALLOCATED'];
/* Approval rule types. `evaluable` = ANT can decide it reliably from its own
   data today. REQUEST_VALUE is NOT: the catalog has no trusted prices, so a
   value rule never auto-approves; it routes to its approver for manual review. */
export const APPROVAL_RULE_TYPES = {
  PRIORITY:          { evaluable: true,  operators: ['EQUALS', 'IN'] },
  MATERIAL_CATEGORY: { evaluable: true,  operators: ['IN'] },
  PRODUCT_VARIANT:   { evaluable: true,  operators: ['IN'] },
  PROJECT:           { evaluable: true,  operators: ['IN'] },
  QUANTITY:          { evaluable: true,  operators: ['GREATER_THAN'] },   // any line above value
  REQUEST_VALUE:     { evaluable: false, operators: ['GREATER_THAN'] },   // estimated value; unknown cost -> manual review
};
export const APPROVAL_REASON_CODES = { RULE_MATCHED: 'RULE_MATCHED', COST_UNKNOWN_REVIEW_REQUIRED: 'COST_UNKNOWN_REVIEW_REQUIRED' };
// Open demand for duplicate detection and "needs attention".
export const OPEN_REQUEST_STATUSES = ['SUBMITTED', 'PENDING_APPROVAL', 'APPROVED', 'PROCESSING', 'PARTIALLY_FULFILLED'];
