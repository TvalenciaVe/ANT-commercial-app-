/* =========================================================================
   PURCHASING (Phase 4) — the vocabulary, defined once.

   Different things, never one generic "order":
     Purchase Requirement  approved demand the warehouse can't source (from a request line)
     Supplier              a vendor THIS company buys from (company-scoped)
     Supplier Quote        manually entered price / availability (never live data)
     Purchase Order        the commercial order to a supplier
     Purchase Receipt      what physically arrived from a PO (immutable)
   A SUPPLIER allocation is the request line's supplier sourcing: PROPOSED on a
   draft PO (claims the requirement, NOT "on order"), ORDERED once the PO is
   sent (a supplier commitment). Received quantity CONVERTS into a warehouse
   allocation (reserved, fulfilled) or, when the demand no longer needs it,
   becomes ordinary AVAILABLE stock.
   ========================================================================= */
export const PURCHASE_REQUIREMENT_STATUSES = ['OPEN', 'SOURCING', 'IN_DRAFT', 'PARTIALLY_ORDERED', 'ORDERED', 'PARTIALLY_RECEIVED', 'RECEIVED', 'CANCELLED', 'CLOSED'];
export const CLOSED_REQUIREMENT_STATUSES = ['CANCELLED', 'CLOSED'];
export const PURCHASE_ORDER_STATUSES = ['DRAFT', 'SENT', 'CONFIRMED', 'PARTIALLY_RECEIVED', 'RECEIVED', 'BACKORDERED', 'CANCELLED', 'CLOSED'];
// a PO the warehouse may still receive against
export const RECEIVABLE_PO_STATUSES = ['SENT', 'CONFIRMED', 'PARTIALLY_RECEIVED', 'BACKORDERED'];
export const SUPPLIER_STATUSES = { ACTIVE: { active: true }, INACTIVE: { active: false }, BLOCKED: { active: false, prepared: true } };
// supplier allocations (MaterialAllocation with sourceType SUPPLIER)
export const SUPPLIER_ALLOCATION_STATUSES = ['PROPOSED', 'ORDERED', 'PARTIALLY_RECEIVED', 'RECEIVED', 'RELEASED', 'CANCELLED'];
export const COMMITTED_SUPPLIER_STATUSES = ['ORDERED', 'PARTIALLY_RECEIVED', 'RECEIVED'];   // a real supplier commitment (never a draft)
export const RECEIPT_ISSUE_TYPES = ['DAMAGED', 'WRONG_MATERIAL', 'OTHER'];
/* Trusted package conversions only (e.g. 1 BOX = 50 EA for one product), by
   productVariantId. None are configured, so a PO line must use the
   variant's own unit: ANT never guesses a conversion. */
export const PACKAGE_CONVERSIONS = {};
/* Receipt distribution policy for a PO line shared by several demands:
   Emergency first, then earliest Needed By, then High / Normal / Low, then
   the order of the line's demand links. Good units serve demand links first,
   then the line's stock overage; damaged units are charged to the overage
   first, then release demand commitment (so Purchasing re-sources it). */
export const RECEIPT_DISTRIBUTION_POLICY = 'PRIORITY_NEEDED_BY_LINK_ORDER';
