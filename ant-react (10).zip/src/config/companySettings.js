/* =========================================================================
   COMPANY SETTINGS — how one contractor chooses to operate the modules it has.
   (Whether a module is available at all is a FEATURE FLAG: see features.js.)

   Enforced today: projectPermissionsEnabled, allowJourneymanRequests,
   allowApprenticeRequests, defaultPriority, defaultWarehouseId.
   The rest are policies for modules that aren't built yet; they are read
   only once their feature flag is on.

   Schema v3 removed the old `approvalsEnabled / inventoryTrackingEnabled /
   purchasingEnabled / returnsEnabled / costTrackingEnabled` booleans: each
   duplicated a feature flag. Their values were folded into company.features.
   `warehouseLocationsEnabled` was removed too: locations are always on.
   ========================================================================= */
export const COMPANY_TYPES = [
  'ELECTRICAL_CONTRACTOR', 'HVAC_CONTRACTOR', 'PLUMBING_CONTRACTOR', 'GENERAL_CONTRACTOR', 'CARPENTRY_CONTRACTOR',
  'CONCRETE_CONTRACTOR', 'IRONWORK_CONTRACTOR', 'PAINTING_CONTRACTOR', 'MECHANICAL_CONTRACTOR', 'OTHER',
];
export const COMPANY_TYPE_LABELS = {
  ELECTRICAL_CONTRACTOR: 'Electrical Contractor', HVAC_CONTRACTOR: 'HVAC Contractor', PLUMBING_CONTRACTOR: 'Plumbing Contractor',
  GENERAL_CONTRACTOR: 'General Contractor', CARPENTRY_CONTRACTOR: 'Carpentry Contractor', CONCRETE_CONTRACTOR: 'Concrete Contractor',
  IRONWORK_CONTRACTOR: 'Ironwork Contractor', PAINTING_CONTRACTOR: 'Painting Contractor', MECHANICAL_CONTRACTOR: 'Mechanical Contractor', OTHER: 'Other',
};
// v2 setting -> the feature flag it duplicated
export const LEGACY_SETTING_TO_FEATURE = {
  approvalsEnabled: 'approvals', inventoryTrackingEnabled: 'inventory', purchasingEnabled: 'purchasing',
  returnsEnabled: 'returns', costTrackingEnabled: 'costTracking',
};

export function defaultCompanySettings(overrides) {
  return Object.assign({
    // enforced today
    projectPermissionsEnabled: true,
    allowJourneymanRequests: true,
    allowApprenticeRequests: true,
    defaultPriority: 'NORMAL',
    defaultWarehouseId: null,
    // Phase 3: requests, approvals, allocation. `approvalsEnabled` = this company
    // chooses to require approvals (the `approvals` feature flag only says the
    // module is available). v5 renamed the dormant `requestApprovalRequired` to it.
    approvalsEnabled: false,
    duplicateDetectionEnabled: true,
    duplicateWindowHours: 24,
    autoAllocateWarehouseStock: true,
    allowManualAllocationAdjustment: true,
    // policies for future modules
    currency: 'USD',
    timezone: 'America/New_York',
  }, overrides || {});
}
