/* =========================================================================
   ROLES — the one place ANT defines who people are.

   Three separate ideas, never mixed:
   - primaryRole      what a person is in the company (User.primaryRole)
   - projectRole      what they are on ONE project (ProjectMembership.projectRole)
   - permissionLevel  what they may do on that project (ProjectMembership.permissionLevel)

   Pure configuration: no imports, no state. Screens show `label`; stored
   data always uses the uppercase key.
   ========================================================================= */

export const WORKER_TYPES = {
  FIELD: 'FIELD', WAREHOUSE: 'WAREHOUSE', MANAGEMENT: 'MANAGEMENT', PURCHASING: 'PURCHASING', ADMIN: 'ADMIN',
};

// `home` is the screen a person lands on after sign-in (a UX choice, not a permission).
export const ROLES = {
  COMPANY_ADMIN:      { key: 'COMPANY_ADMIN',      label: 'Company Admin',      workerType: 'ADMIN',      home: null },
  OWNER:              { key: 'OWNER',              label: 'Owner',              workerType: 'MANAGEMENT', home: null },
  PROJECT_MANAGER:    { key: 'PROJECT_MANAGER',    label: 'Project Manager',    workerType: 'MANAGEMENT', home: 'fHome' },
  SUPERINTENDENT:     { key: 'SUPERINTENDENT',     label: 'Superintendent',     workerType: 'MANAGEMENT', home: null },
  FOREMAN:            { key: 'FOREMAN',            label: 'Foreman',            workerType: 'FIELD',      home: 'fHome' },
  JOURNEYMAN:         { key: 'JOURNEYMAN',         label: 'Journeyman',         workerType: 'FIELD',      home: 'fHome' },
  APPRENTICE:         { key: 'APPRENTICE',         label: 'Apprentice',         workerType: 'FIELD',      home: 'fHome' },
  WAREHOUSE_MANAGER:  { key: 'WAREHOUSE_MANAGER',  label: 'Warehouse Manager',  workerType: 'WAREHOUSE',  home: 'mHome' },
  WAREHOUSE_WORKER:   { key: 'WAREHOUSE_WORKER',   label: 'Warehouse Worker',   workerType: 'WAREHOUSE',  home: 'whHome' },
  PURCHASING_MANAGER: { key: 'PURCHASING_MANAGER', label: 'Purchasing Manager', workerType: 'PURCHASING', home: 'pHome' },   // Phase 4: Purchasing home (with their approvals)
};

// Roles a person can hold ON a project.
export const PROJECT_ROLES = ['PROJECT_MANAGER', 'SUPERINTENDENT', 'FOREMAN', 'JOURNEYMAN', 'APPRENTICE'];
// Project roles that lead a project (the ones who manage its team).
export const PROJECT_LEAD_ROLES = ['PROJECT_MANAGER', 'SUPERINTENDENT', 'FOREMAN'];

export const PERMISSION_LEVELS = {
  VIEWER:       { key: 'VIEWER',       rank: 1, labelKey: 'view_only' },
  CAN_EDIT:     { key: 'CAN_EDIT',     rank: 2, labelKey: 'can_request_materials' },
  FULL_CONTROL: { key: 'FULL_CONTROL', rank: 3, labelKey: 'full_control' },
};
// Level given when someone joins a project in that role…
export const DEFAULT_PROJECT_PERMISSION = {
  PROJECT_MANAGER: 'FULL_CONTROL', SUPERINTENDENT: 'FULL_CONTROL', FOREMAN: 'FULL_CONTROL',
  JOURNEYMAN: 'VIEWER', APPRENTICE: 'VIEWER',
};
// …and the highest level a Foreman can grant that role. A Journeyman or
// Apprentice can be allowed to request materials, never to run the team.
export const MAX_PROJECT_PERMISSION = {
  PROJECT_MANAGER: 'FULL_CONTROL', SUPERINTENDENT: 'FULL_CONTROL', FOREMAN: 'FULL_CONTROL',
  JOURNEYMAN: 'CAN_EDIT', APPRENTICE: 'CAN_EDIT',
};

// What onboarding offers. Kept deliberately small: Field or Warehouse, then a role.
export const ONBOARDING_ROLES = {
  field: [
    { role: 'FOREMAN', sub: 'Manage project materials, team access, and Material Requests.' },
    { role: 'JOURNEYMAN', sub: 'Work with project materials and request materials when authorized by the Foreman.' },
    { role: 'APPRENTICE', sub: 'View project materials and request materials when authorized by the Foreman.' },
  ],
  warehouse: [
    { role: 'WAREHOUSE_MANAGER', sub: 'Manage warehouse operations, inventory, fulfillment, restocking, and dispatch.' },
    { role: 'WAREHOUSE_WORKER', sub: 'Pick and pack materials, complete checklists, and view warehouse inventory.' },
  ],
};

/* ---------- normalizers: accept any historical spelling, return the key ---------- */
const squash = (v) => String(v == null ? '' : v).trim().toUpperCase().replace(/[\s-]+/g, '_');
export function normalizeRole(v) {
  const k = squash(v);
  return ROLES[k] ? k : null;          // 'Foreman' / 'foreman' / 'warehouse_manager' / 'Warehouse Manager' -> key
}
export function normalizeProjectRole(v) {
  const k = normalizeRole(v);
  return k && PROJECT_ROLES.indexOf(k) !== -1 ? k : null;
}
export function normalizePermissionLevel(v) {
  const k = squash(v);                 // 'viewer' -> VIEWER, 'can_edit' -> CAN_EDIT
  return PERMISSION_LEVELS[k] ? k : null;
}
// Company responsibilities. One person can hold several (a small contractor's
// owner may also be the company admin and do the purchasing). primaryRole is
// the one that decides their home screen, and is always among companyRoles.
// Unknown strings are dropped, never promoted.
export function normalizeCompanyRoles(primaryRole, companyRoles) {
  const list = (Array.isArray(companyRoles) ? companyRoles : []).map(normalizeRole).filter(Boolean);
  if (primaryRole && list.indexOf(primaryRole) === -1) list.unshift(primaryRole);
  return list.filter((r, i) => list.indexOf(r) === i);
}
export const roleLabel = (key) => (ROLES[key] ? ROLES[key].label : '');
export const workerTypeOf = (roleKey) => (ROLES[roleKey] ? ROLES[roleKey].workerType : null);
export const isProjectLeadRole = (projectRole) => PROJECT_LEAD_ROLES.indexOf(projectRole) !== -1;
export const permissionRank = (level) => (PERMISSION_LEVELS[level] ? PERMISSION_LEVELS[level].rank : 0);
// A level is allowed for a project role if it doesn't exceed that role's maximum.
export const permissionAllowedFor = (projectRole, level) =>
  !!PERMISSION_LEVELS[level] && permissionRank(level) <= permissionRank(MAX_PROJECT_PERMISSION[projectRole]);
