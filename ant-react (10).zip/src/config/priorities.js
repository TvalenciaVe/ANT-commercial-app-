/* =========================================================================
   PRIORITIES — defined once, used by every chip, badge, stripe and sort.
   `cssKey` is the existing class suffix (badge-High, stripe-High,
   data-p="High"), so the look of ANT is unchanged.
   ========================================================================= */
export const PRIORITIES = {
  EMERGENCY: { value: 'EMERGENCY', label: 'Emergency', sortWeight: 4, cssKey: 'Emergency' },
  HIGH:      { value: 'HIGH',      label: 'High',      sortWeight: 3, cssKey: 'High' },
  NORMAL:    { value: 'NORMAL',    label: 'Normal',    sortWeight: 2, cssKey: 'Normal' },
  LOW:       { value: 'LOW',       label: 'Low',       sortWeight: 1, cssKey: 'Low' },
};
// Display order (highest first).
export const PRIORITY_ORDER = ['EMERGENCY', 'HIGH', 'NORMAL', 'LOW'];
export const DEFAULT_PRIORITY = 'NORMAL';

// Accepts 'High', 'high', 'HIGH' (older saved data used the label).
export function normalizePriority(v) {
  const k = String(v == null ? '' : v).trim().toUpperCase();
  return PRIORITIES[k] ? k : DEFAULT_PRIORITY;
}
export const priorityLabel = (v) => (PRIORITIES[v] || PRIORITIES[DEFAULT_PRIORITY]).label;
export const priorityCss = (v) => (PRIORITIES[v] || PRIORITIES[DEFAULT_PRIORITY]).cssKey;
export const priorityWeight = (v) => (PRIORITIES[v] ? PRIORITIES[v].sortWeight : 0);
// Outstanding demand (Needs attention): Emergency first, then earliest Needed By,
// then High / Normal / Low, then the oldest request.
export const byOutstandingUrgency = (a, b) => ((b.priority === 'EMERGENCY') - (a.priority === 'EMERGENCY')) || ((a.neededBy || 0) - (b.neededBy || 0)) ||
  (priorityWeight(b.priority) - priorityWeight(a.priority)) || (a.createdAt - b.createdAt);
// The one sort every warehouse list uses: most urgent first, then newest.
export const byPriorityThenNewest = (a, b) => (priorityWeight(b.priority) - priorityWeight(a.priority)) || (b.createdAt - a.createdAt);
