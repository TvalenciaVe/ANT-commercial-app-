/* =========================================================================
   MATERIAL LEDGER VOCABULARY (Phase 2) — one place for every rule about
   what a movement may do.

   LOCATION and STATE are different things. A location is WHERE material
   physically is (Main Warehouse > Shelving > Shelf A-1). A state is WHAT it
   is doing there (AVAILABLE, PICKING, PACKED). Picking 25 EA moves them from
   AVAILABLE to PICKING in the SAME bin: nothing leaves the shelf. There are no
   fake "Reserved" or "Packed" locations.

   NULL LOCATION SEMANTICS (the only two meanings null may have):
   - fromLocationId = null: material ENTERED tracked inventory
       (OPENING_BALANCE, INVENTORY_ADJUSTMENT_IN, future PURCHASE_RECEIPT).
   - toLocationId = null: material LEFT tracked inventory through an explicit
       adjustment or write-off (INVENTORY_ADJUSTMENT_OUT; a REVERSAL of an
       entry movement).
   Every other movement names both locations; state-only movements (PICK,
   UNPICK, PACK, UNPACK, STATUS_TRANSFER) use the same location on both sides.
   ========================================================================= */

// countsOnHand = physically in the warehouse (spec: AVAILABLE + RESERVED +
// PICKING + PACKED). IN_TRANSIT, project and return states do not count.
export const INVENTORY_STATES = {
  AVAILABLE:         { active: true,  countsOnHand: true,  label: 'Available' },
  RESERVED:          { active: true,  countsOnHand: true,  label: 'Reserved' },          // Phase 3: held for an allocation
  PICKING:           { active: true,  countsOnHand: true,  label: 'Picking' },
  PACKED:            { active: true,  countsOnHand: true,  label: 'Packed' },
  IN_TRANSIT:        { active: false, countsOnHand: false, label: 'In Transit' },        // Logistics phase
  PROJECT_AVAILABLE: { active: false, countsOnHand: false, label: 'Project Available' }, // Jobsite Receiving
  RETURN_PENDING:    { active: false, countsOnHand: false, label: 'Return Pending' },    // Returns
  INSPECTION:        { active: false, countsOnHand: false, label: 'Inspection' },
  DAMAGED:           { active: true,  countsOnHand: false, label: 'Damaged' },          // Phase 4: damaged on supplier receipt (not usable stock)
  SCRAP:             { active: false, countsOnHand: false, label: 'Scrap' },
};
export const ACTIVE_STATES = Object.keys(INVENTORY_STATES).filter((s) => INVENTORY_STATES[s].active);
export const ON_HAND_STATES = Object.keys(INVENTORY_STATES).filter((s) => INVENTORY_STATES[s].countsOnHand);

/* from / to: 'required' | 'null' (see null semantics above) | 'mirror' (REVERSAL)
   sameLocation: the physical location may not change (state-only transition)
   transitions: allowed [fromState, toState] pairs (null = outside inventory)
   capability: what the person posting it must be allowed to do
   systemOnly: only ANT itself posts it (the v4 migration), never a person
   active: false = prepared for a later phase; the ledger refuses it today. */
const S = (a, b) => [a, b];
export const MOVEMENT_TYPES = {
  OPENING_BALANCE:          { active: true,  from: 'null', to: 'required', transitions: [S(null, 'AVAILABLE'), S(null, 'PICKING'), S(null, 'PACKED')], capability: null, systemOnly: true },
  INVENTORY_ADJUSTMENT_IN:  { active: true,  from: 'null', to: 'required', transitions: [S(null, 'AVAILABLE')], capability: 'MANAGE_INVENTORY' },
  INVENTORY_ADJUSTMENT_OUT: { active: true,  from: 'required', to: 'null', transitions: [S('AVAILABLE', null)], capability: 'MANAGE_INVENTORY' },
  // v5 picks start from the request's own reservation; legacy (pre-v5) picks from AVAILABLE
  PICK:                     { active: true,  from: 'required', to: 'required', sameLocation: true, transitions: [S('AVAILABLE', 'PICKING'), S('RESERVED', 'PICKING')], capability: 'PICK_MATERIALS' },
  UNPICK:                   { active: true,  from: 'required', to: 'required', sameLocation: true, transitions: [S('PICKING', 'AVAILABLE'), S('PICKING', 'RESERVED')], capability: 'PICK_MATERIALS' },
  PACK:                     { active: true,  from: 'required', to: 'required', sameLocation: true, transitions: [S('PICKING', 'PACKED')], capability: 'PACK_MATERIALS' },
  UNPACK:                   { active: true,  from: 'required', to: 'required', sameLocation: true, transitions: [S('PACKED', 'PICKING')], capability: 'PACK_MATERIALS' },
  STATUS_TRANSFER:          { active: true,  from: 'required', to: 'required', sameLocation: true, transitions: 'ANY_ACTIVE_PAIR', capability: 'MANAGE_INVENTORY' },
  REVERSAL:                 { active: true,  from: 'mirror', to: 'mirror', transitions: 'MIRROR', capability: 'MANAGE_INVENTORY' },
  // ---- prepared for later phases (refused by the ledger today) ----
  // Phase 4: supplier -> warehouse. Good material AVAILABLE, damaged DAMAGED; always linked to its purchaseOrderId
  PURCHASE_RECEIPT:         { active: true,  from: 'null', to: 'required', transitions: [S(null, 'AVAILABLE'), S(null, 'DAMAGED')], capability: 'RECEIVE_PURCHASE_ORDER' },
  // Phase 3 Allocation: always tied to one MaterialAllocation (allocationId); may be posted by ANT itself
  RESERVE:                  { active: true,  from: 'required', to: 'required', sameLocation: true, transitions: [S('AVAILABLE', 'RESERVED')], capability: 'MANAGE_ALLOCATIONS', systemAllowed: true },
  UNRESERVE:                { active: true,  from: 'required', to: 'required', sameLocation: true, transitions: [S('RESERVED', 'AVAILABLE')], capability: 'MANAGE_ALLOCATIONS', systemAllowed: true },
  SHIP:                     { active: false, from: 'required', to: 'required', transitions: [S('PACKED', 'IN_TRANSIT')] },
  RECEIVE:                  { active: false, from: 'required', to: 'required', transitions: [S('IN_TRANSIT', 'PROJECT_AVAILABLE')] },
  PROJECT_TRANSFER:         { active: false, from: 'required', to: 'required', transitions: [S('PROJECT_AVAILABLE', 'PROJECT_AVAILABLE')] },
  RETURN:                   { active: false, from: 'required', to: 'required', transitions: [S('PROJECT_AVAILABLE', 'RETURN_PENDING'), S('RETURN_PENDING', 'INSPECTION')] },
  RESTOCK:                  { active: false, from: 'required', to: 'required', transitions: [S('INSPECTION', 'AVAILABLE')] },
  DAMAGE:                   { active: false, from: 'required', to: 'required', transitions: [S('AVAILABLE', 'DAMAGED'), S('INSPECTION', 'DAMAGED')] },
  LOSS:                     { active: false, from: 'required', to: 'null', transitions: [S('AVAILABLE', null)] },
  SCRAP:                    { active: false, from: 'required', to: 'required', transitions: [S('DAMAGED', 'SCRAP'), S('INSPECTION', 'SCRAP')] },
  CYCLE_COUNT_ADJUSTMENT:   { active: false, from: 'any', to: 'any', transitions: [S(null, 'AVAILABLE'), S('AVAILABLE', null)] },
};
// When a movement is corrected, the counter-movement that undoes it.
export const REVERSAL_TYPE_FOR = { PICK: 'UNPICK', PACK: 'UNPACK', RESERVE: 'UNRESERVE' };

// Why a manager changed stock by hand. Required on every adjustment.
export const ADJUSTMENT_REASONS = {
  PHYSICAL_COUNT_CORRECTION: { en: 'Physical count correction', es: 'Corrección por conteo físico' },
  DATA_CORRECTION:           { en: 'Data correction',           es: 'Corrección de datos' },
  FOUND_STOCK:               { en: 'Found stock',               es: 'Material encontrado' },
  DAMAGED_DISCOVERED:        { en: 'Damaged discovered',        es: 'Daño encontrado' },
  MISSING:                   { en: 'Missing',                   es: 'Faltante' },
  OTHER:                     { en: 'Other',                     es: 'Otro' },
};
// Reason codes only ANT itself uses.
export const SYSTEM_REASONS = { LEDGER_OPENING_BALANCE: 'Inventory ledger started (schema v4)' };

export function transitionAllowed(typeKey, fromState, toState) {
  const t = MOVEMENT_TYPES[typeKey];
  if (!t) return false;
  if (t.transitions === 'ANY_ACTIVE_PAIR') return ACTIVE_STATES.indexOf(fromState) !== -1 && ACTIVE_STATES.indexOf(toState) !== -1 && fromState !== toState;
  if (t.transitions === 'MIRROR') return true;   // checked against the original movement instead
  return t.transitions.some(([a, b]) => a === (fromState || null) && b === (toState || null));
}
// Physical warehouse stock changes only when material enters or leaves
// tracked inventory; state-only movements never change it.
export const changesPhysicalStock = (m) => !m.fromLocationId || !m.toLocationId;
